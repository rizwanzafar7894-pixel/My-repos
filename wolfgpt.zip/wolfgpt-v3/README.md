# 🐺 WolfGPT v3

> A production-ready AI SaaS platform — free & open-source models, full billing, GPU support.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](./LICENSE)
[![Docker](https://img.shields.io/badge/Docker-Ready-blue)](./docker-compose.yml)

---

## ✨ Features

| Feature | Models |
|---|---|
| **AI Chat** | Qwen 2.5, Llama 3, Mistral, Gemma, DeepSeek |
| **Image Generation** | FLUX.1-schnell, FLUX.1-dev, SDXL |
| **Voice STT** | OpenAI Whisper (tiny → large-v3) |
| **Voice TTS** | Coqui TTS |
| **Code Generation & Execution** | DeepSeek Coder, Code Llama (sandboxed) |
| **Music Generation** | MusicGen (small / medium / large / melody / stereo) |
| **Document AI** | PDF, DOCX, CSV parsing + Q&A |
| **Vision** | LLaVA 7B / 13B / 34B |

**Payments:** Stripe · PayPal · JazzCash · EasyPaisa

**Plans:** Free · Basic ($9.99/mo) · Premium ($19.99/mo) · Pro ($39.99/mo)

---

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose v2
- (Optional) NVIDIA GPU with drivers + CUDA toolkit
- Firebase project (free tier)

### 1. Clone & configure

```bash
git clone https://github.com/youruser/wolfgpt.git && cd wolfgpt

# Copy all env examples
cp .env.example               .env
cp backend/.env.example       backend/.env
cp ai-services/.env.example   ai-services/.env
cp frontend/.env.local.example frontend/.env.local

# Edit each file with your credentials
nano backend/.env
nano frontend/.env.local
```

### 2. Add Firebase credentials

1. Go to [Firebase Console](https://console.firebase.google.com)
2. Project Settings → Service Accounts → **Generate new private key**
3. Save as `firebase-admin-key.json` in the project root

### 3. Start (development)

```bash
# With GPU:
docker compose up -d

# Without GPU (CPU-only):
docker compose -f docker-compose.yml -f docker-compose.cpu.yml up -d

# One-command shortcut:
./start.sh dev         # GPU
./start.sh dev --no-gpu  # CPU
```

Open → **http://localhost:3000**

### 4. Pull AI models

```bash
# Pull free-tier model only (fastest):
./scripts/pull-models.sh --minimal

# Pull all standard models:
./scripts/pull-models.sh

# Pull all models including large GPU variants:
./scripts/pull-models.sh --gpu
```

---

## 🖥 Production Deployment (VPS + GPU)

```bash
# 1. Set your domain and Redis password
nano .env   # set DOMAIN=wolfgpt.yourdomain.com and REDIS_PASSWORD=...

# 2. Provision TLS certificates
./scripts/setup-ssl.sh wolfgpt.yourdomain.com admin@yourdomain.com

# 3. Fill in production backend/.env (Firebase, Stripe, PayPal, JazzCash)
nano backend/.env

# 4. Deploy
./scripts/deploy.sh
```

---

## 🏗 Architecture

```
wolfgpt-v3/
├── frontend/           Next.js 14 — ChatGPT-style UI
├── backend/            Express + TypeScript — API gateway
├── ai-services/        FastAPI + Python — AI model server
├── nginx/              Nginx reverse proxy + TLS
├── scripts/            SSL, deploy, model management
├── docker-compose.yml          Dev compose (with GPU)
├── docker-compose.cpu.yml      CPU-only override
├── docker-compose.prod.yml     Production compose
└── start.sh                    One-command launcher
```

### Services & Ports

| Service | Port | Purpose |
|---|---|---|
| Frontend | 3000 | Next.js app |
| Backend | 4000 | Express API |
| AI Service | 8000 | FastAPI / models |
| Ollama | 11434 | LLM inference |
| Redis | 6379 | Cache + rate limit |
| Nginx | 80/443 | Reverse proxy (prod) |

---

## 💳 Payment Setup

### Stripe
1. Create account at [stripe.com](https://stripe.com)
2. Dashboard → Products → create plans
3. Dashboard → Webhooks → add `https://yourdomain.com/api/payment/stripe/webhook`
4. Add keys to `backend/.env`

### PayPal
1. Create app at [developer.paypal.com](https://developer.paypal.com)
2. Get Client ID + Secret
3. Add to `backend/.env`

### JazzCash (Pakistan)
1. Register at [jazzcash.com.pk](https://jazzcash.com.pk) → Become a Merchant
2. Add Merchant ID, Password, and Integrity Salt to `backend/.env`

### EasyPaisa (Pakistan)
1. Contact EasyPaisa merchant support
2. Add Store ID and Secret Key to `backend/.env`

---

## 🔧 Development Commands

```bash
make dev          # start dev
make stop         # stop all
make logs         # tail logs
make status       # container status
make test         # run tests
make clean        # remove everything
make pull-models  # pull Ollama models
```

---

## 📋 Environment Variables

See each service's `.env.example` for full documentation:
- [Root](./.env.example) — domain, Redis
- [Backend](./backend/.env.example) — Firebase, payments, Redis
- [AI Services](./ai-services/.env.example) — model settings, Ollama
- [Frontend](./frontend/.env.local.example) — Firebase web SDK, Stripe public key

---

## 🛡 Security

- All tokens verified server-side via Firebase Admin SDK
- Redis token caching with 5-min TTL
- Rate limiting per user tier (minute/hour/day windows)
- JazzCash HMAC-SHA256 signature verification
- Stripe webhook signature verification
- Helmet.js + security headers on all responses
- Non-root Docker containers
- CORS locked to configured origins
- Input validation with Joi on all endpoints

---

## 📄 License

MIT — see [LICENSE](./LICENSE)
