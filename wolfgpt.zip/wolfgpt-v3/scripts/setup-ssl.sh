#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# WolfGPT v3 — SSL Certificate Setup Script
# ─────────────────────────────────────────────────────────────────────────────
# Usage:  ./scripts/setup-ssl.sh yourdomain.com admin@yourdomain.com
#
# This script:
#   1. Installs certbot (if not present)
#   2. Obtains a Let's Encrypt certificate for your domain
#   3. Copies certs to nginx/ssl/ where docker compose expects them
#   4. Generates a strong Diffie-Hellman params file
#   5. Sets up auto-renewal cron
#
# Prerequisites:
#   - Domain DNS A record pointing to this server's IP
#   - Port 80 open (for ACME challenge)
#   - Root or sudo access
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

DOMAIN="${1:-}"
EMAIL="${2:-}"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
log()  { echo -e "${GREEN}[SSL]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()  { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

[[ -z "$DOMAIN" ]] && err "Usage: $0 <domain> <email>"
[[ -z "$EMAIL"  ]] && err "Usage: $0 <domain> <email>"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
SSL_DIR="$PROJECT_ROOT/nginx/ssl"
mkdir -p "$SSL_DIR"

# ── Install certbot ────────────────────────────────────────────────────────
if ! command -v certbot &>/dev/null; then
    log "Installing certbot..."
    if command -v apt-get &>/dev/null; then
        sudo apt-get update -qq && sudo apt-get install -y certbot
    elif command -v yum &>/dev/null; then
        sudo yum install -y certbot
    else
        err "Cannot install certbot — please install manually: https://certbot.eff.org"
    fi
fi

# ── Obtain certificate ─────────────────────────────────────────────────────
log "Obtaining Let's Encrypt certificate for $DOMAIN..."
sudo certbot certonly \
    --standalone \
    --agree-tos \
    --non-interactive \
    --email "$EMAIL" \
    -d "$DOMAIN" \
    -d "www.$DOMAIN" || warn "www.$DOMAIN may not be configured — continuing without it"

# ── Copy certs ─────────────────────────────────────────────────────────────
log "Copying certificates to $SSL_DIR..."
sudo cp "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" "$SSL_DIR/fullchain.pem"
sudo cp "/etc/letsencrypt/live/$DOMAIN/privkey.pem"   "$SSL_DIR/privkey.pem"
sudo chmod 644 "$SSL_DIR/fullchain.pem"
sudo chmod 600 "$SSL_DIR/privkey.pem"

# ── Generate DH params (4096-bit, one-time) ────────────────────────────────
if [[ ! -f "$SSL_DIR/dhparam.pem" ]]; then
    log "Generating DH params (this takes 1-3 minutes)..."
    openssl dhparam -out "$SSL_DIR/dhparam.pem" 2048
    log "DH params generated."
fi

# ── Auto-renewal cron ──────────────────────────────────────────────────────
CRON_JOB="0 3 * * * certbot renew --quiet && cp /etc/letsencrypt/live/$DOMAIN/fullchain.pem $SSL_DIR/fullchain.pem && cp /etc/letsencrypt/live/$DOMAIN/privkey.pem $SSL_DIR/privkey.pem && docker compose -f $PROJECT_ROOT/docker-compose.prod.yml restart nginx"
(crontab -l 2>/dev/null | grep -q "certbot renew") || \
    (crontab -l 2>/dev/null; echo "$CRON_JOB") | crontab -

log ""
log "✅ SSL setup complete!"
log "   Domain:   $DOMAIN"
log "   Certs:    $SSL_DIR/"
log "   Renewal:  Daily cron at 03:00"
log ""
log "Next step:  docker compose -f docker-compose.prod.yml up -d --build"
