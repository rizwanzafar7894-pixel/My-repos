#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# WolfGPT v3 — VPS + GPU Production Deploy Script
# ─────────────────────────────────────────────────────────────────────────────
# Usage:  ./scripts/deploy.sh
#
# This script:
#   1. Verifies server prerequisites (Docker, NVIDIA drivers, CUDA)
#   2. Validates all required env files and credentials
#   3. Provisions SSL certificates
#   4. Builds and starts all containers
#   5. Pulls Ollama models
#   6. Runs smoke tests
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
log()    { echo -e "${GREEN}[Deploy]${NC} $1"; }
warn()   { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()    { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }
info()   { echo -e "${CYAN}[INFO]${NC} $1"; }
header() { echo -e "\n${BOLD}${CYAN}══ $1 ══${NC}\n"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$(dirname "$SCRIPT_DIR")"

header "WolfGPT v3 — Production Deploy"

# ── Step 1: Prerequisites ─────────────────────────────────────────────────
header "1/7 — Checking prerequisites"

command -v docker &>/dev/null          || err "Docker not installed"
docker compose version &>/dev/null     || err "Docker Compose V2 required"
command -v curl &>/dev/null            || err "curl not installed"

info "Docker:          $(docker --version)"
info "Docker Compose:  $(docker compose version --short)"

# NVIDIA GPU check (optional)
if command -v nvidia-smi &>/dev/null; then
    info "GPU:             $(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -1)"
    GPU_AVAILABLE=true
else
    warn "nvidia-smi not found — deploying in CPU-only mode"
    GPU_AVAILABLE=false
fi

# ── Step 2: Environment validation ────────────────────────────────────────
header "2/7 — Validating environment"

[[ -f .env ]]                    || err ".env not found. Run: cp .env.example .env && nano .env"
[[ -f backend/.env ]]            || err "backend/.env not found. Run: cp backend/.env.example backend/.env && nano backend/.env"
[[ -f ai-services/.env ]]        || err "ai-services/.env not found. Run: cp ai-services/.env.example ai-services/.env && nano ai-services/.env"
[[ -f frontend/.env.local ]]     || err "frontend/.env.local not found. Run: cp frontend/.env.local.example frontend/.env.local && nano frontend/.env.local"
[[ -f firebase-admin-key.json ]] || err "firebase-admin-key.json not found. Download from Firebase Console → Service Accounts."

source .env
[[ -z "${DOMAIN:-}" ]]          && err "DOMAIN must be set in .env"
[[ -z "${REDIS_PASSWORD:-}" ]]  && err "REDIS_PASSWORD must be set in .env"

# Check REDIS_PASSWORD strength
[[ ${#REDIS_PASSWORD} -lt 16 ]] && warn "REDIS_PASSWORD is short — use at least 16 chars in production"

info "Domain:  $DOMAIN"
log "✅ Environment OK"

# ── Step 3: SSL certificates ──────────────────────────────────────────────
header "3/7 — TLS / SSL"

if [[ -f nginx/ssl/fullchain.pem ]] && [[ -f nginx/ssl/privkey.pem ]]; then
    EXPIRY=$(openssl x509 -enddate -noout -in nginx/ssl/fullchain.pem 2>/dev/null | cut -d= -f2)
    info "Certificate expires: $EXPIRY"
    log "✅ SSL certificates found"
else
    warn "SSL certificates not found."
    read -rp "Run setup-ssl.sh now? (y/n): " SETUP_SSL
    if [[ "$SETUP_SSL" == "y" ]]; then
        read -rp "Email for Let's Encrypt: " SSL_EMAIL
        ./scripts/setup-ssl.sh "$DOMAIN" "$SSL_EMAIL"
    else
        warn "Skipping SSL setup — nginx will not start without certs"
    fi
fi

# ── Step 4: Build containers ──────────────────────────────────────────────
header "4/7 — Building containers"

if [[ "$GPU_AVAILABLE" == "true" ]]; then
    COMPOSE_FILES="-f docker-compose.prod.yml"
else
    COMPOSE_FILES="-f docker-compose.prod.yml -f docker-compose.cpu.yml"
fi

export DOMAIN REDIS_PASSWORD
log "Building images (this may take 5-10 minutes on first run)..."
docker compose $COMPOSE_FILES build --parallel

# ── Step 5: Start services ────────────────────────────────────────────────
header "5/7 — Starting services"

docker compose $COMPOSE_FILES up -d
log "Waiting 45 seconds for all services to be healthy..."
sleep 45
docker compose $COMPOSE_FILES ps

# ── Step 6: Pull Ollama models ────────────────────────────────────────────
header "6/7 — Pulling AI models"

log "Pulling default Ollama models (background)..."
./scripts/pull-models.sh --minimal &
MODEL_PID=$!
log "Model pull running in background (PID: $MODEL_PID)"
log "Monitor: docker exec wolfgpt-ollama ollama list"

# ── Step 7: Smoke tests ───────────────────────────────────────────────────
header "7/7 — Smoke tests"

BACKEND_HEALTH=$(curl -sf "http://localhost:4000/health" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('status','unknown'))" 2>/dev/null || echo "unreachable")
AI_HEALTH=$(curl -sf "http://localhost:8000/health" | python3 -c "import sys,json; d=json.load(sys.stdin); print(d.get('status','unknown'))" 2>/dev/null || echo "unreachable")

[[ "$BACKEND_HEALTH" == "healthy" ]] && log "✅ Backend:    healthy" || warn "⚠️  Backend: $BACKEND_HEALTH"
[[ "$AI_HEALTH"      == "healthy" ]] && log "✅ AI Service: healthy" || warn "⚠️  AI Service: $AI_HEALTH"

echo ""
log "════════════════════════════════════════════"
log "✅ WolfGPT v3 deployed successfully!"
log ""
log "   App URL:   https://$DOMAIN"
log "   API URL:   https://$DOMAIN/api/v1"
log "   Docs:      https://$DOMAIN/api/v1/health"
log ""
log "   Logs:      docker compose $COMPOSE_FILES logs -f"
log "   Status:    docker compose $COMPOSE_FILES ps"
log "   Stop:      docker compose $COMPOSE_FILES down"
log "════════════════════════════════════════════"
