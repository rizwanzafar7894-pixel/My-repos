#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# WolfGPT v3 — Pull all Ollama models
# ─────────────────────────────────────────────────────────────────────────────
# Usage:
#   ./scripts/pull-models.sh            → pull all models
#   ./scripts/pull-models.sh --gpu      → pull GPU-optimized variants
#   ./scripts/pull-models.sh --minimal  → pull only the free-tier model
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

MODE="${1:---all}"
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
log()  { echo -e "${GREEN}[Models]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }

# Check if Ollama is running (via docker or local)
if docker ps --format '{{.Names}}' 2>/dev/null | grep -q wolfgpt-ollama; then
    OLLAMA_CMD="docker exec wolfgpt-ollama ollama"
elif command -v ollama &>/dev/null; then
    OLLAMA_CMD="ollama"
else
    echo -e "${RED}[ERROR]${NC} Ollama not found. Start wolfgpt-ollama container or install Ollama."
    exit 1
fi

pull_model() {
    local model="$1"
    local desc="$2"
    log "Pulling $model ($desc)..."
    $OLLAMA_CMD pull "$model" && log "✅ $model ready" || warn "⚠️  Failed to pull $model — skipping"
}

# ── Minimal (free tier) ────────────────────────────────────────────────────
MINIMAL_MODELS=(
    "qwen2.5:7b|Qwen 2.5 7B — default chat model (free tier)"
)

# ── All chat models (per spec: Llama3, Mistral, Gemma, DeepSeek, Qwen) ────
ALL_CHAT_MODELS=(
    "qwen2.5:7b|Qwen 2.5 7B — fast, efficient (free tier)"
    "llama3.2:3b|Llama 3.2 3B — Meta's latest compact model"
    "llama3.1:8b|Llama 3.1 8B — Meta's instruction model"
    "mistral:7b|Mistral 7B — strong reasoning"
    "gemma2:9b|Gemma 2 9B — Google's open model"
    "deepseek-r1:7b|DeepSeek R1 7B — reasoning specialist"
    "deepseek-coder-v2:16b|DeepSeek Coder V2 — code generation"
    "codellama:7b|Code Llama 7B — code generation (Llama-based)"
    "llava:7b|LLaVA 7B — vision + language (free tier)"
)

# ── Large models (premium / pro tier, needs 24GB+ VRAM) ───────────────────
GPU_LARGE_MODELS=(
    "qwen2.5:32b|Qwen 2.5 32B — premium tier"
    "llama3.1:70b|Llama 3.1 70B — pro tier"
    "llava:13b|LLaVA 13B — premium vision"
)

case "$MODE" in
    --minimal)
        log "Pulling minimal model set (free tier only)..."
        for entry in "${MINIMAL_MODELS[@]}"; do
            IFS='|' read -r model desc <<< "$entry"
            pull_model "$model" "$desc"
        done
        ;;
    --gpu)
        log "Pulling all models including large GPU models..."
        for entry in "${ALL_CHAT_MODELS[@]}" "${GPU_LARGE_MODELS[@]}"; do
            IFS='|' read -r model desc <<< "$entry"
            pull_model "$model" "$desc"
        done
        ;;
    *)
        log "Pulling all standard models..."
        for entry in "${ALL_CHAT_MODELS[@]}"; do
            IFS='|' read -r model desc <<< "$entry"
            pull_model "$model" "$desc"
        done
        ;;
esac

log ""
log "✅ Model pull complete. Available models:"
$OLLAMA_CMD list
