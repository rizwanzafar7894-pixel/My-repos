# WolfGPT v3 — Changelog

## v3.0.0 — Full Production Hardening

### 🔴 Critical Bug Fixes

- **FIX #1 — JazzCash HMAC Security** (`backend/src/routes/payment/jazzcash.ts`)
  - Excluded `pp_Password` and `pp_SecureHash` from hash input per JazzCash spec
  - Fixed callback hash verification to include `pp_ResponseCode` in the hash calculation
  - Hash now correctly uses only non-empty, non-secret, non-hash params

- **FIX #2 — ApiError.forbidden() signature** (`backend/src/middleware/errorHandler.ts`)
  - Added `code` parameter to `forbidden()` static method
  - All callers passing custom error codes now work correctly

- **FIX #3 — Missing dashboard/page.tsx** (`frontend/src/app/dashboard/page.tsx`)
  - Created dashboard index page with redirect to `/dashboard/chat`
  - Navigating to `/dashboard` no longer returns 404

- **FIX #4 — MusicGen audiocraft dependency** (`ai-services/requirements.txt`)
  - Added `audiocraft` package to requirements
  - Added `transformers[audio]` extra for full audio support
  - MusicGen now loads correctly on first request

- **FIX #5 — Frontend Docker env_file** (`docker-compose.yml`, `docker-compose.prod.yml`)
  - Changed `env_file: ./frontend/.env` → `./frontend/.env.local`
  - Matches Next.js convention; Docker builds now receive Firebase config

- **FIX #6 — Missing docker-compose.cpu.yml** (new file)
  - Created CPU-only override compose file
  - `start.sh --no-gpu` and `make dev-cpu` now work correctly

### 🟠 Serious Bug Fixes

- **FIX #7 — Stripe API version** (`backend/src/routes/payment/stripe.ts`)
  - Updated `apiVersion` from `'2024-04-10'` → `'2025-02-24.acacia'` (current)

- **FIX #8 — ApiError.forbidden() code param** (`backend/src/middleware/errorHandler.ts`)
  - Added optional `code` parameter to `forbidden()` method signature

- **FIX #9 — JazzCash callback hash** (`backend/src/routes/payment/jazzcash.ts`)
  - Fixed callback to correctly include `pp_ResponseCode` in hash verification

- **FIX #10 — Missing @types/morgan** (`backend/package.json`)
  - Added `@types/morgan` to devDependencies

- **FIX #11 — Removed deprecated crypto package** (`backend/package.json`)
  - Removed `"crypto": "^1.0.1"` — Node.js built-in, npm package is a no-op

- **FIX #12 — Production SSL provisioning** (`scripts/setup-ssl.sh`)
  - Created automated certbot script; nginx no longer fails without pre-existing certs
  - `deploy.sh` now warns and optionally runs SSL setup before starting nginx

### 🟡 Missing Features Added

- **FIX #13 — Admin dashboard** (`admin-dashboard/`)
  - Complete Next.js app with layout, auth guard, navigation
  - Users management page with search, filter, tier management
  - Analytics page with charts and metrics

- **FIX #14 — EasyPaisa webhook security** (`backend/src/routes/payment/easypaisa.ts`)
  - Added HMAC-SHA256 signature verification on all callbacks
  - Unauthorized callbacks are now rejected with 401

- **FIX #15 — voice_service.py integration** (`ai-services/routers/voice.py`)
  - Voice router now imports from `services/voice_service.py`
  - Voice cloning and multi-speaker features now reachable

- **FIX #16 — Ollama model map** (`ai-services/core/config.py`)
  - Added Llama 3.2, Llama 3.1, Mistral 7B, Gemma 2, DeepSeek R1, DeepSeek Coder V2, Code Llama

- **FIX #17 — Frontend model selector** (`frontend/src/constants/index.ts`)
  - Added all spec models: Llama 3, Mistral, Gemma, DeepSeek R1, DeepSeek Coder, Code Llama

- **FIX #18 — PayPal integration** (`backend/src/routes/payment/paypal.ts`)
  - Complete PayPal subscription integration with OAuth2, plan management, webhooks

### 🔵 Configuration & Security

- **FIX #19 — Redis production safeguard** (`.env.example`, `docker-compose.prod.yml`)
  - `REDIS_PASSWORD` is now required (`?:` syntax) in prod compose
  - Root `.env.example` documents both `DOMAIN` and `REDIS_PASSWORD`

- **FIX #20 — Nginx domain variable** (`nginx/nginx.conf`)
  - `server_name` now uses `${DOMAIN}` sourced from root `.env`
  - Works for any domain without hardcoded values

- **FIX #21 — Auth cache key** (`backend/src/middleware/auth.ts`)
  - Cache key now uses the full 64-char SHA256 hash instead of truncated 32 chars

- **FIX #22 — Docker optimizations** (`ai-services/Dockerfile`)
  - Added `--no-cache-dir` to all pip install calls
  - Reduced layer count; improved build reproducibility

- **FIX #23 — Environment file cleanup** (`frontend/`)
  - Removed duplicate `.env.example` from frontend
  - Single canonical `frontend/.env.local.example` per Next.js convention
