import { Response, NextFunction } from 'express';
import { AuthRequest } from './auth';
import { cacheIncr } from '../utils/cache';
import logger from '../utils/logger';

const RATE_LIMITS: Record<string, { perMinute: number; perHour: number; perDay: number }> = {
  free:    { perMinute: 10,  perHour: 100,    perDay: 500    },
  basic:   { perMinute: 30,  perHour: 500,    perDay: 5_000  },
  premium: { perMinute: 60,  perHour: 3_000,  perDay: 50_000 },
  pro:     { perMinute: -1,  perHour: -1,     perDay: -1     },
  anon:    { perMinute: 5,   perHour: 30,     perDay: 100    },
};

type Window = 'minute' | 'hour' | 'day';
const WINDOW_TTL: Record<Window, number> = { minute: 60, hour: 3_600, day: 86_400 };

function windowKey(id: string, window: Window): string {
  const now = new Date();
  const y  = now.getUTCFullYear(), mo = now.getUTCMonth(), d = now.getUTCDate();
  const h  = now.getUTCHours(),   min = now.getUTCMinutes();
  const bucket =
    window === 'minute' ? `${y}-${mo}-${d}-${h}-${min}` :
    window === 'hour'   ? `${y}-${mo}-${d}-${h}` :
                          `${y}-${mo}-${d}`;
  return `rl:${window}:${id}:${bucket}`;
}

function windowReset(window: Window): number {
  const now = new Date();
  if (window === 'minute') return new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours(), now.getMinutes() + 1).getTime();
  if (window === 'hour')   return new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours() + 1).getTime();
  return new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1).getTime();
}

function limitFor(tier: string, window: Window): number {
  const cfg = RATE_LIMITS[tier] ?? RATE_LIMITS.free;
  return window === 'minute' ? cfg.perMinute : window === 'hour' ? cfg.perHour : cfg.perDay;
}

interface WindowResult { allowed: boolean; count: number; limit: number; reset: number; }

async function checkWindow(id: string, tier: string, window: Window): Promise<WindowResult> {
  const limit = limitFor(tier, window);
  const reset = windowReset(window);
  if (limit === -1) return { allowed: true, count: 0, limit: -1, reset };
  const count = await cacheIncr(windowKey(id, window), WINDOW_TTL[window]);
  return { allowed: count <= limit, count, limit, reset };
}

export const rateLimiter = async (
  req: AuthRequest, res: Response, next: NextFunction
): Promise<void> => {
  try {
    const id   = req.user?.uid || (req.ip ?? 'anonymous');
    const tier = req.user?.tier || 'anon';

    const [minR, hrR, dayR] = await Promise.all([
      checkWindow(id, tier, 'minute'),
      checkWindow(id, tier, 'hour'),
      checkWindow(id, tier, 'day'),
    ]);

    res.setHeader('X-RateLimit-Limit-Minute',     minR.limit);
    res.setHeader('X-RateLimit-Remaining-Minute', Math.max(0, minR.limit - minR.count));
    res.setHeader('X-RateLimit-Reset-Minute',     minR.reset);

    for (const [result, message] of [
      [minR, 'Per-minute rate limit exceeded. Please slow down.'],
      [hrR,  'Hourly rate limit exceeded. Please try again later.'],
      [dayR, 'Daily rate limit exceeded. Upgrade your plan for more requests.'],
    ] as [WindowResult, string][]) {
      if (!result.allowed) {
        res.status(429).json({
          success: false,
          error: {
            code: 'RATE_LIMIT_EXCEEDED', message,
            retryAfter: Math.ceil((result.reset - Date.now()) / 1_000),
            limit: result.limit, used: result.count,
          },
        });
        return;
      }
    }
    next();
  } catch (err) {
    logger.warn('Rate limiter error (allowing request):', err);
    next();
  }
};
