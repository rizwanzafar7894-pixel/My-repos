import { Request, Response, NextFunction } from 'express';
import { auth, db, FieldValue } from '../config/firebase';
import { cacheGet, cacheSet } from '../utils/cache';
import { hashKey } from '../utils/helpers';
import logger from '../utils/logger';

export interface AuthUser {
  uid:   string;
  email: string;
  tier:  'free' | 'basic' | 'premium' | 'pro';
}

export interface AuthRequest extends Request {
  user?:      AuthUser;
  requestId?: string;
}

async function fetchUserFromFirestore(uid: string): Promise<AuthUser | null> {
  try {
    const snap = await db.collection('users').doc(uid).get();
    if (!snap.exists) return null;
    const d = snap.data()!;
    return { uid, email: d.email ?? '', tier: (d.tier as AuthUser['tier']) ?? 'free' };
  } catch (err) {
    logger.error('Firestore user fetch error:', err);
    return null;
  }
}

// ── Firebase Bearer token auth ────────────────────────────────────────────────
export const authMiddleware = async (
  req: AuthRequest, res: Response, next: NextFunction
): Promise<void> => {
  const header = req.headers.authorization;

  if (!header?.startsWith('Bearer ')) {
    res.status(401).json({
      success: false,
      error: { code: 'MISSING_TOKEN', message: 'Authorization: Bearer <token> header required' },
    });
    return;
  }

  const token = header.slice(7);
  // FIX #21: use full 64-char SHA256 hash for cache key (was truncated to 32 chars)
  const cacheKey = `auth:${hashKey(token)}`;

  try {
    const cached = await cacheGet<AuthUser>(cacheKey);
    if (cached) { req.user = cached; return next(); }

    const decoded = await auth.verifyIdToken(token, true); // checkRevoked=true

    let user = await fetchUserFromFirestore(decoded.uid);

    if (!user) {
      // Auto-provision on first OAuth login
      user = { uid: decoded.uid, email: decoded.email ?? '', tier: 'free' };
      db.collection('users').doc(decoded.uid).set({
        uid:         decoded.uid,
        email:       decoded.email ?? '',
        displayName: decoded.name ?? decoded.email?.split('@')[0] ?? 'User',
        photoURL:    decoded.picture ?? null,
        tier:        'free',
        usage: {
          chat:  { used: 0 },
          images:{ used: 0 },
          code:  { used: 0 },
          voice: { sttUsed: 0, ttsUsed: 0 },
          music: { used: 0 },
          api:   { used: 0 },
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      }, { merge: true }).catch((e: Error) => logger.error('Auto user-create failed:', e.message));
    }

    await cacheSet(cacheKey, user, 300);
    req.user = user;
    next();

  } catch (err: unknown) {
    const code = (err as { code?: string })?.code;
    const errCode =
      code === 'auth/id-token-revoked' ? 'TOKEN_REVOKED' :
      code === 'auth/id-token-expired' ? 'TOKEN_EXPIRED' :
      'INVALID_TOKEN';

    res.status(401).json({
      success: false,
      error: { code: errCode, message: 'Invalid or expired authentication token' },
    });
  }
};

// ── API key auth ──────────────────────────────────────────────────────────────
export const apiKeyMiddleware = async (
  req: AuthRequest, res: Response, next: NextFunction
): Promise<void> => {
  const apiKey =
    (req.headers['x-api-key'] as string | undefined) ??
    (req.query.api_key as string | undefined);

  if (!apiKey) {
    res.status(401).json({
      success: false,
      error: { code: 'MISSING_API_KEY', message: 'x-api-key header or api_key query parameter required' },
    });
    return;
  }

  // FIX #21: full hash for cache key
  const keyHash  = hashKey(apiKey);
  const cacheKey = `apikey:${keyHash}`;

  try {
    const cached = await cacheGet<AuthUser>(cacheKey);
    if (cached) {
      req.user = cached;
      setImmediate(async () => {
        try {
          const snap = await db.collection('api_keys').where('keyHash','==',keyHash).where('active','==',true).limit(1).get();
          if (!snap.empty) await snap.docs[0].ref.update({ lastUsed: new Date(), usage: FieldValue.increment(1) });
        } catch { /* non-fatal */ }
      });
      return next();
    }

    const snap = await db.collection('api_keys')
      .where('keyHash', '==', keyHash)
      .where('active',  '==', true)
      .limit(1)
      .get();

    if (snap.empty) {
      res.status(401).json({ success: false, error: { code: 'INVALID_API_KEY', message: 'Invalid or inactive API key' } });
      return;
    }

    const keyData  = snap.docs[0].data();
    const userSnap = await db.collection('users').doc(keyData.userId).get();
    if (!userSnap.exists) {
      res.status(401).json({ success: false, error: { code: 'USER_NOT_FOUND', message: 'User not found' } });
      return;
    }

    const userData = userSnap.data()!;
    const user: AuthUser = { uid: keyData.userId, email: userData.email ?? '', tier: (userData.tier as AuthUser['tier']) ?? 'free' };

    await cacheSet(cacheKey, user, 300);
    req.user = user;

    snap.docs[0].ref.update({ lastUsed: new Date(), usage: FieldValue.increment(1) })
      .catch((e: Error) => logger.warn('API key update failed:', e.message));

    next();
  } catch (err) {
    logger.error('API key auth error:', err);
    res.status(500).json({ success: false, error: { code: 'AUTH_ERROR', message: 'API key authentication failed' } });
  }
};

// ── Optional auth ─────────────────────────────────────────────────────────────
export const optionalAuth = async (
  req: AuthRequest, _res: Response, next: NextFunction
): Promise<void> => {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) return next();
  const token    = header.slice(7);
  const cacheKey = `auth:${hashKey(token)}`;
  try {
    const cached = await cacheGet<AuthUser>(cacheKey);
    if (cached) { req.user = cached; return next(); }
    const decoded = await auth.verifyIdToken(token);
    const user    = await fetchUserFromFirestore(decoded.uid);
    if (user) { await cacheSet(cacheKey, user, 300); req.user = user; }
  } catch { /* silently ignore */ }
  next();
};
