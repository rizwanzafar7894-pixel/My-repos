import { Response, NextFunction } from 'express';
import { AuthRequest } from './auth';

const ADMIN_EMAILS = (process.env.ADMIN_EMAILS || '')
  .split(',')
  .map(e => e.trim().toLowerCase())
  .filter(Boolean);

export const adminMiddleware = (req: AuthRequest, res: Response, next: NextFunction): void => {
  const email = req.user?.email?.toLowerCase() || '';
  if (!ADMIN_EMAILS.includes(email)) {
    res.status(403).json({ success: false, error: { code: 'FORBIDDEN', message: 'Admin access required' } });
    return;
  }
  next();
};
