import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
import { asyncHandler, ApiError } from '../middleware/errorHandler';
import { db, FieldValue } from '../config/firebase';
import axios from 'axios';
import FormData from 'form-data';
import logger from '../utils/logger';

const AI_URL = () => process.env.AI_SERVICE_URL || 'http://localhost:8000';

// ── Image Controller ──────────────────────────────────────────────────────────
export const imageController = {
  generate: asyncHandler(async (req: AuthRequest, res: Response) => {
    const userId = req.user!.uid;
    const aiRes  = await axios.post(`${AI_URL()}/v1/images/generate`, req.body, { timeout: 120_000 });
    await db.collection('users').doc(userId).update({ 'usage.images.used': FieldValue.increment(1) });
    res.json({ success: true, data: aiRes.data });
  }),

  img2img: asyncHandler(async (req: AuthRequest, res: Response) => {
    const aiRes = await axios.post(`${AI_URL()}/v1/images/img2img`, req.body, { timeout: 120_000 });
    await db.collection('users').doc(req.user!.uid).update({ 'usage.images.used': FieldValue.increment(1) });
    res.json({ success: true, data: aiRes.data });
  }),

  inpaint: asyncHandler(async (req: AuthRequest, res: Response) => {
    const aiRes = await axios.post(`${AI_URL()}/v1/images/inpaint`, req.body, { timeout: 120_000 });
    await db.collection('users').doc(req.user!.uid).update({ 'usage.images.used': FieldValue.increment(1) });
    res.json({ success: true, data: aiRes.data });
  }),

  upscale: asyncHandler(async (req: AuthRequest, res: Response) => {
    const aiRes = await axios.post(`${AI_URL()}/v1/images/upscale`, req.body, { timeout: 120_000 });
    res.json({ success: true, data: aiRes.data });
  }),
};

// ── Voice Controller ──────────────────────────────────────────────────────────
export const voiceController = {
  stt: asyncHandler(async (req: AuthRequest, res: Response) => {
    if (!req.file) throw ApiError.badRequest('audio file is required');
    const userId = req.user!.uid;
    const fd     = new FormData();
    fd.append('audio',    req.file.buffer, { filename: req.file.originalname, contentType: req.file.mimetype });
    fd.append('language', req.body.language || 'en');
    fd.append('model',    req.body.model || 'base');
    const aiRes  = await axios.post(`${AI_URL()}/v1/voice/stt`, fd, { headers: fd.getHeaders(), timeout: 120_000 });
    await db.collection('users').doc(userId).update({ 'usage.voice.sttUsed': FieldValue.increment(1) });
    res.json({ success: true, data: aiRes.data });
  }),

  tts: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { text, voice = 'en-US-female-1', speed = 1.0 } = req.body;
    if (!text?.trim()) throw ApiError.badRequest('text is required');
    const aiRes = await axios.post(
      `${AI_URL()}/v1/voice/tts`,
      { text, voice, speed },
      { responseType: 'arraybuffer', timeout: 60_000 }
    );
    await db.collection('users').doc(req.user!.uid).update({ 'usage.voice.ttsUsed': FieldValue.increment(1) });
    res.set('Content-Type', 'audio/wav');
    res.send(Buffer.from(aiRes.data));
  }),
};

// ── Code Controller ───────────────────────────────────────────────────────────
export const codeController = {
  execute: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { code, language, stdin = '' } = req.body;
    if (!code?.trim())     throw ApiError.badRequest('code is required');
    if (!language?.trim()) throw ApiError.badRequest('language is required');
    const aiRes = await axios.post(
      `${AI_URL()}/v1/code/execute`,
      { code, language, stdin },
      { timeout: 90_000 }
    );
    await db.collection('users').doc(req.user!.uid).update({ 'usage.code.used': FieldValue.increment(1) });
    res.json({ success: true, data: aiRes.data });
  }),
};

// ── Music Controller ──────────────────────────────────────────────────────────
export const musicController = {
  generate: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { prompt, model = 'musicgen-small', duration = 10 } = req.body;
    if (!prompt?.trim()) throw ApiError.badRequest('prompt is required');
    const aiRes = await axios.post(
      `${AI_URL()}/v1/music/generate`,
      { prompt, model, duration },
      { timeout: 180_000 }
    );
    await db.collection('users').doc(req.user!.uid).update({ 'usage.music.used': FieldValue.increment(1) });
    res.json({ success: true, data: aiRes.data });
  }),

  melody: asyncHandler(async (req: AuthRequest, res: Response) => {
    const aiRes = await axios.post(`${AI_URL()}/v1/music/melody`, req.body, { timeout: 180_000 });
    res.json({ success: true, data: aiRes.data });
  }),

  continuation: asyncHandler(async (req: AuthRequest, res: Response) => {
    const aiRes = await axios.post(`${AI_URL()}/v1/music/continuation`, req.body, { timeout: 180_000 });
    res.json({ success: true, data: aiRes.data });
  }),
};

// ── Document Controller ───────────────────────────────────────────────────────
export const documentController = {
  upload: asyncHandler(async (req: AuthRequest, res: Response) => {
    if (!req.file) throw ApiError.badRequest('document file is required');
    const fd = new FormData();
    fd.append('document', req.file.buffer, { filename: req.file.originalname, contentType: req.file.mimetype });
    const aiRes = await axios.post(`${AI_URL()}/v1/documents/parse`, fd, { headers: fd.getHeaders(), timeout: 60_000 });
    const docId = `doc_${Date.now().toString(36)}`;
    await db.collection('documents').doc(docId).set({
      id: docId, userId: req.user!.uid,
      filename: req.file.originalname,
      content:  aiRes.data?.text || '',
      size:     req.file.size,
      createdAt: new Date(),
    });
    res.json({ success: true, data: { id: docId, filename: req.file.originalname, size: req.file.size } });
  }),

  chat: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id }       = req.params;
    const { question } = req.body;
    if (!question?.trim()) throw ApiError.badRequest('question is required');
    const docSnap = await db.collection('documents').doc(id).get();
    if (!docSnap.exists) throw ApiError.notFound('Document not found');
    if (docSnap.data()!.userId !== req.user!.uid) throw ApiError.forbidden();
    const context = docSnap.data()!.content?.slice(0, 8000) || '';
    const aiRes   = await axios.post(
      `${AI_URL()}/v1/chat/completions`,
      {
        messages: [
          { role: 'system', content: `Answer questions based on this document:\n\n${context}` },
          { role: 'user',   content: question },
        ],
        model: 'qwen-2.5-7b', stream: false,
      },
      { timeout: 60_000 }
    );
    const answer = aiRes.data.choices?.[0]?.message?.content || '';
    res.json({ success: true, data: { answer } });
  }),
};

// ── Translate Controller ──────────────────────────────────────────────────────
export const translateController = {
  translate: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { text, targetLanguage, sourceLanguage } = req.body;
    if (!text?.trim())           throw ApiError.badRequest('text is required');
    if (!targetLanguage?.trim()) throw ApiError.badRequest('targetLanguage is required');
    const prompt = `Translate the following text to ${targetLanguage}${sourceLanguage ? ` from ${sourceLanguage}` : ''}. Output only the translated text, nothing else:\n\n${text}`;
    const aiRes  = await axios.post(
      `${AI_URL()}/v1/chat/completions`,
      { messages: [{ role: 'user', content: prompt }], model: 'qwen-2.5-7b', stream: false },
      { timeout: 60_000 }
    );
    res.json({ success: true, data: { translation: aiRes.data.choices?.[0]?.message?.content?.trim() || '', sourceLanguage, targetLanguage } });
  }),
};

// ── Summarize Controller ──────────────────────────────────────────────────────
export const summarizeController = {
  summarize: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { text, maxLength = 500, style = 'paragraph' } = req.body;
    if (!text?.trim()) throw ApiError.badRequest('text is required');
    const prompt = `Summarize the following text in ${style} format, maximum ${maxLength} words. Output only the summary:\n\n${text}`;
    const aiRes  = await axios.post(
      `${AI_URL()}/v1/chat/completions`,
      { messages: [{ role: 'user', content: prompt }], model: 'qwen-2.5-7b', stream: false },
      { timeout: 60_000 }
    );
    res.json({ success: true, data: { summary: aiRes.data.choices?.[0]?.message?.content?.trim() || '' } });
  }),
};

// ── Analytics Controller ──────────────────────────────────────────────────────
export const analyticsController = {
  get: asyncHandler(async (req: AuthRequest, res: Response) => {
    const snap = await db.collection('users').doc(req.user!.uid).get();
    if (!snap.exists) throw ApiError.notFound('User not found');
    const usage = snap.data()!.usage || {};
    res.json({ success: true, data: { usage, tier: snap.data()!.tier } });
  }),
};
