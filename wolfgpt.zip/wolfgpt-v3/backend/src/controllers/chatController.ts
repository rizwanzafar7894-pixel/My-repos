import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
import { asyncHandler, ApiError } from '../middleware/errorHandler';
import { db, FieldValue } from '../config/firebase';
import { generateId } from '../utils/helpers';
import axios from 'axios';
import logger from '../utils/logger';

const AI_URL = () => process.env.AI_SERVICE_URL || 'http://localhost:8000';

// FIX #16 & #17: All models including Llama3, Mistral, Gemma, DeepSeek, CodeLlama
const TIER_MODELS: Record<string, string[]> = {
  free:    ['qwen-2.5-7b', 'llama-3.2-3b'],
  basic:   ['qwen-2.5-7b', 'llama-3.2-3b', 'llama-3.1-8b', 'mistral-7b', 'gemma-2-9b'],
  premium: ['qwen-2.5-7b', 'qwen-2.5-32b', 'llama-3.2-3b', 'llama-3.1-8b', 'mistral-7b',
            'gemma-2-9b', 'deepseek-r1-7b', 'deepseek-coder-v2', 'llava-7b', 'llava-13b'],
  pro:     ['qwen-2.5-7b', 'qwen-2.5-32b', 'qwen-2.5-72b', 'llama-3.2-3b', 'llama-3.1-8b',
            'llama-3.1-70b', 'mistral-7b', 'gemma-2-9b', 'deepseek-r1-7b', 'deepseek-coder-v2',
            'codellama-7b', 'llava-7b', 'llava-13b', 'llava-34b'],
};

function assertModelAllowed(model: string, tier: string): void {
  const allowed = TIER_MODELS[tier] || TIER_MODELS.free;
  if (!allowed.includes(model)) {
    // FIX #2: now correctly passes 'MODEL_NOT_ALLOWED' code to forbidden()
    throw ApiError.forbidden(
      `Model "${model}" is not available on the ${tier} plan. Upgrade to access this model.`,
      'MODEL_NOT_ALLOWED'
    );
  }
}

export const chatController = {

  // POST /api/v1/chat/completions
  createCompletion: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { messages, model = 'qwen-2.5-7b', temperature = 0.7, maxTokens = 2048, systemPrompt } = req.body;
    const userId   = req.user!.uid;
    const userTier = req.user!.tier;

    if (!messages?.length) throw ApiError.badRequest('messages array is required and must not be empty');
    assertModelAllowed(model, userTier);

    const fullMessages = systemPrompt ? [{ role: 'system', content: systemPrompt }, ...messages] : messages;

    const aiRes = await axios.post(
      `${AI_URL()}/v1/chat/completions`,
      { messages: fullMessages, model, temperature, max_tokens: maxTokens, stream: false },
      { timeout: 120_000 }
    );

    const assistantMessage = aiRes.data.choices?.[0]?.message;
    if (!assistantMessage) throw ApiError.internal('AI service returned empty response');

    const conversationId = generateId('conv');
    await Promise.all([
      db.collection('conversations').doc(conversationId).set({
        id: conversationId, userId,
        messages: [...fullMessages, assistantMessage],
        model, createdAt: new Date(), updatedAt: new Date(),
      }),
      db.collection('users').doc(userId).update({
        'usage.chat.used': FieldValue.increment(1),
        'updatedAt':       new Date(),
      }),
    ]);

    res.json({ success: true, data: { message: assistantMessage.content, model, conversationId, usage: aiRes.data.usage } });
  }),

  // POST /api/v1/chat/completions/stream
  createStreamingCompletion: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { messages, model = 'qwen-2.5-7b', temperature = 0.7, maxTokens = 2048, systemPrompt } = req.body;
    const userId   = req.user!.uid;
    const userTier = req.user!.tier;

    if (!messages?.length) throw ApiError.badRequest('messages array is required');
    assertModelAllowed(model, userTier);

    const fullMessages = systemPrompt ? [{ role: 'system', content: systemPrompt }, ...messages] : messages;

    res.setHeader('Content-Type',        'text/event-stream');
    res.setHeader('Cache-Control',       'no-cache');
    res.setHeader('Connection',          'keep-alive');
    res.setHeader('X-Accel-Buffering',   'no');

    const aiRes = await axios.post(
      `${AI_URL()}/v1/chat/completions`,
      { messages: fullMessages, model, temperature, max_tokens: maxTokens, stream: true },
      { responseType: 'stream', timeout: 180_000 }
    );

    let fullResponse = '';

    aiRes.data.on('data', (chunk: Buffer) => {
      const lines = chunk.toString().split('\n').filter(Boolean);
      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        const data = line.slice(6);
        if (data === '[DONE]') { res.write('data: [DONE]\n\n'); return; }
        try {
          const parsed  = JSON.parse(data);
          const content = parsed.choices?.[0]?.delta?.content || '';
          fullResponse += content;
          res.write(`data: ${JSON.stringify({ content })}\n\n`);
        } catch { /* skip malformed */ }
      }
    });

    aiRes.data.on('end', async () => {
      try {
        const conversationId = generateId('conv');
        await Promise.all([
          db.collection('conversations').doc(conversationId).set({
            id: conversationId, userId,
            messages: [...fullMessages, { role: 'assistant', content: fullResponse }],
            model, createdAt: new Date(), updatedAt: new Date(),
          }),
          db.collection('users').doc(userId).update({ 'usage.chat.used': FieldValue.increment(1) }),
        ]);
      } catch (e) { logger.error('Failed to save streaming conversation:', e); }
      res.end();
    });

    aiRes.data.on('error', (err: Error) => {
      logger.error('Stream error:', err);
      res.write(`data: ${JSON.stringify({ error: 'Stream interrupted' })}\n\n`);
      res.end();
    });

    req.on('close', () => { aiRes.data.destroy(); });
  }),

  // GET /api/v1/chat/conversations
  getConversations: asyncHandler(async (req: AuthRequest, res: Response) => {
    const userId = req.user!.uid;
    const limit  = Math.min(parseInt(req.query.limit as string) || 50, 200);
    const snap   = await db.collection('conversations')
      .where('userId', '==', userId).orderBy('updatedAt', 'desc').limit(limit).get();
    res.json({ success: true, data: snap.docs.map(d => ({ id: d.id, ...d.data() })) });
  }),

  // GET /api/v1/chat/conversations/:id
  getConversation: asyncHandler(async (req: AuthRequest, res: Response) => {
    const doc = await db.collection('conversations').doc(req.params.id).get();
    if (!doc.exists) throw ApiError.notFound('Conversation not found');
    if (doc.data()!.userId !== req.user!.uid) throw ApiError.forbidden();
    res.json({ success: true, data: { id: doc.id, ...doc.data() } });
  }),

  // PATCH /api/v1/chat/conversations/:id
  updateConversation: asyncHandler(async (req: AuthRequest, res: Response) => {
    const doc = await db.collection('conversations').doc(req.params.id).get();
    if (!doc.exists) throw ApiError.notFound('Conversation not found');
    if (doc.data()!.userId !== req.user!.uid) throw ApiError.forbidden();
    const allowed = ['title', 'archived', 'pinned'];
    const updates: Record<string, any> = { updatedAt: new Date() };
    allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });
    await doc.ref.update(updates);
    res.json({ success: true, data: { id: req.params.id, ...updates } });
  }),

  // DELETE /api/v1/chat/conversations/:id
  deleteConversation: asyncHandler(async (req: AuthRequest, res: Response) => {
    const doc = await db.collection('conversations').doc(req.params.id).get();
    if (!doc.exists) throw ApiError.notFound('Conversation not found');
    if (doc.data()!.userId !== req.user!.uid) throw ApiError.forbidden();
    await doc.ref.delete();
    res.json({ success: true, data: { deleted: true } });
  }),

  // DELETE /api/v1/chat/conversations
  clearConversations: asyncHandler(async (req: AuthRequest, res: Response) => {
    const snap  = await db.collection('conversations').where('userId','==',req.user!.uid).get();
    const batch = db.batch();
    snap.docs.forEach(d => batch.delete(d.ref));
    await batch.commit();
    res.json({ success: true, data: { deleted: snap.size } });
  }),
};
