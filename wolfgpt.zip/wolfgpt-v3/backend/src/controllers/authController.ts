import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
import { asyncHandler, ApiError } from '../middleware/errorHandler';
import { db, auth, FieldValue } from '../config/firebase';
import { generateApiKey, hashKey, maskKey } from '../utils/helpers';
import { cacheDel } from '../utils/cache';
import logger from '../utils/logger';

export const authController = {

  // POST /api/auth/verify — called after client-side Firebase login
  verifyToken: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { token } = req.body;
    if (!token) throw ApiError.badRequest('token is required');

    const decoded = await auth.verifyIdToken(token, true);

    let userSnap = await db.collection('users').doc(decoded.uid).get();
    if (!userSnap.exists) {
      await db.collection('users').doc(decoded.uid).set({
        uid:         decoded.uid,
        email:       decoded.email ?? '',
        displayName: decoded.name ?? decoded.email?.split('@')[0] ?? 'User',
        photoURL:    decoded.picture ?? null,
        tier:        'free',
        usage: { chat: { used: 0 }, images: { used: 0 }, code: { used: 0 }, voice: { sttUsed: 0, ttsUsed: 0 }, music: { used: 0 }, api: { used: 0 } },
        createdAt:   new Date(),
        updatedAt:   new Date(),
      });
      userSnap = await db.collection('users').doc(decoded.uid).get();
    }

    const data = userSnap.data()!;
    res.json({
      success: true,
      data: {
        uid:         data.uid,
        email:       data.email,
        displayName: data.displayName,
        photoURL:    data.photoURL,
        tier:        data.tier || 'free',
        usage:       data.usage,
        subscription: data.subscription,
      },
    });
  }),

  // GET /api/auth/me
  getMe: asyncHandler(async (req: AuthRequest, res: Response) => {
    const snap = await db.collection('users').doc(req.user!.uid).get();
    if (!snap.exists) throw ApiError.notFound('User not found');
    const d = snap.data()!;
    res.json({
      success: true,
      data: {
        uid: d.uid, email: d.email, displayName: d.displayName,
        photoURL: d.photoURL, tier: d.tier, usage: d.usage,
        subscription: d.subscription, createdAt: d.createdAt,
      },
    });
  }),

  // PATCH /api/auth/me
  updateMe: asyncHandler(async (req: AuthRequest, res: Response) => {
    const allowed = ['displayName', 'photoURL'];
    const updates: Record<string, any> = { updatedAt: new Date() };
    allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });
    await db.collection('users').doc(req.user!.uid).update(updates);
    res.json({ success: true, data: updates });
  }),

  // GET /api/auth/usage
  getUsage: asyncHandler(async (req: AuthRequest, res: Response) => {
    const snap = await db.collection('users').doc(req.user!.uid).get();
    if (!snap.exists) throw ApiError.notFound('User not found');
    res.json({ success: true, data: { usage: snap.data()!.usage, tier: snap.data()!.tier } });
  }),

  // POST /api/auth/api-keys
  createApiKey: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { name } = req.body;
    if (!name?.trim()) throw ApiError.badRequest('name is required');

    const uid   = req.user!.uid;
    const snap  = await db.collection('users').doc(uid).get();
    const tier  = snap.data()?.tier || 'free';

    if (tier === 'free') throw ApiError.forbidden('API keys require Basic plan or higher', 'UPGRADE_REQUIRED');

    // Count active keys
    const existing = await db.collection('api_keys').where('userId','==',uid).where('active','==',true).get();
    const maxKeys  = tier === 'basic' ? 1 : tier === 'premium' ? 5 : -1;
    if (maxKeys !== -1 && existing.size >= maxKeys) {
      throw ApiError.conflict(`Your ${tier} plan allows up to ${maxKeys} API key(s)`, 'KEY_LIMIT_REACHED');
    }

    const key     = generateApiKey();
    const keyHash = hashKey(key);
    const keyId   = `key_${Date.now().toString(36)}`;

    await db.collection('api_keys').doc(keyId).set({
      id: keyId, userId: uid, name: name.trim(),
      keyHash, prefix: key.slice(0, 12),
      active: true, usage: 0,
      createdAt: new Date(), lastUsed: null,
    });

    res.json({ success: true, data: { id: keyId, name: name.trim(), key, prefix: key.slice(0, 12) } });
  }),

  // GET /api/auth/api-keys
  getApiKeys: asyncHandler(async (req: AuthRequest, res: Response) => {
    const snap = await db.collection('api_keys')
      .where('userId', '==', req.user!.uid)
      .orderBy('createdAt', 'desc')
      .get();

    const keys = snap.docs.map(d => {
      const data = d.data();
      return { id: d.id, name: data.name, prefix: data.prefix, active: data.active, usage: data.usage, lastUsed: data.lastUsed, createdAt: data.createdAt };
    });

    res.json({ success: true, data: keys });
  }),

  // PATCH /api/auth/api-keys/:id/revoke
  revokeApiKey: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const snap   = await db.collection('api_keys').doc(id).get();
    if (!snap.exists) throw ApiError.notFound('API key not found');
    if (snap.data()!.userId !== req.user!.uid) throw ApiError.forbidden();

    await snap.ref.update({ active: false, revokedAt: new Date() });
    await cacheDel(`apikey:${snap.data()!.keyHash}`);
    res.json({ success: true, data: { id, revoked: true } });
  }),

  // DELETE /api/auth/api-keys/:id
  deleteApiKey: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const snap   = await db.collection('api_keys').doc(id).get();
    if (!snap.exists) throw ApiError.notFound('API key not found');
    if (snap.data()!.userId !== req.user!.uid) throw ApiError.forbidden();

    await cacheDel(`apikey:${snap.data()!.keyHash}`);
    await snap.ref.delete();
    res.json({ success: true, data: { id, deleted: true } });
  }),
};
