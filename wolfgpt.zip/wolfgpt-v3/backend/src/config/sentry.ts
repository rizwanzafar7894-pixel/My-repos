import * as Sentry from '@sentry/node';
import logger from '../utils/logger';

export function initSentry(): void {
  const dsn = process.env.SENTRY_DSN;
  if (!dsn) { logger.debug('Sentry DSN not set — skipping Sentry initialization'); return; }

  Sentry.init({
    dsn,
    environment: process.env.NODE_ENV || 'development',
    tracesSampleRate: process.env.NODE_ENV === 'production' ? 0.1 : 1.0,
    integrations: [
      Sentry.httpIntegration(),
      Sentry.expressIntegration(),
    ],
  });

  logger.info('✅ Sentry initialized');
}

export { Sentry };
