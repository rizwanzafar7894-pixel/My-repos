import * as admin from 'firebase-admin';
import fs from 'fs';
import path from 'path';

function resolveCredential(): admin.credential.Credential {
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT;

  if (!raw) return admin.credential.applicationDefault();

  // Inline JSON string
  if (raw.trimStart().startsWith('{')) {
    try {
      return admin.credential.cert(JSON.parse(raw) as admin.ServiceAccount);
    } catch (e) {
      throw new Error(`FIREBASE_SERVICE_ACCOUNT contains invalid JSON: ${(e as Error).message}`);
    }
  }

  // File path
  const resolved = path.isAbsolute(raw) ? raw : path.resolve(process.cwd(), raw);
  if (!fs.existsSync(resolved)) {
    throw new Error(
      `Firebase service account file not found: ${resolved}\n` +
      `Set FIREBASE_SERVICE_ACCOUNT in backend/.env (file path or inline JSON).`
    );
  }

  try {
    return admin.credential.cert(
      JSON.parse(fs.readFileSync(resolved, 'utf8')) as admin.ServiceAccount
    );
  } catch (e) {
    throw new Error(`Failed to parse Firebase service account file: ${(e as Error).message}`);
  }
}

if (!admin.apps.length) {
  admin.initializeApp({
    credential:    resolveCredential(),
    storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
  });
}

export const db         = admin.firestore();
export const auth       = admin.auth();
export const storage    = admin.storage();
export const FieldValue = admin.firestore.FieldValue;
export const Timestamp  = admin.firestore.Timestamp;

export default admin;
