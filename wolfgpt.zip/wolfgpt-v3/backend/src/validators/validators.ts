import Joi from 'joi';
import { Request, Response, NextFunction } from 'express';
import { ApiError } from '../middleware/errorHandler';

type Schema = Joi.ObjectSchema;

export const validate = (schema: Schema, target: 'body' | 'query' | 'params' = 'body') =>
  (req: Request, _res: Response, next: NextFunction): void => {
    const { error } = schema.validate(req[target], { abortEarly: false, stripUnknown: true });
    if (error) {
      const message = error.details.map(d => d.message).join(', ');
      return next(ApiError.badRequest(message, 'VALIDATION_ERROR'));
    }
    next();
  };

// ── Chat ─────────────────────────────────────────────────────────────────────
export const chatCompletionSchema = Joi.object({
  messages:    Joi.array().items(Joi.object({ role: Joi.string().valid('user','assistant','system').required(), content: Joi.string().required() })).min(1).required(),
  model:       Joi.string().default('qwen-2.5-7b'),
  temperature: Joi.number().min(0).max(2).default(0.7),
  maxTokens:   Joi.number().integer().min(1).max(8192).default(2048),
  systemPrompt:Joi.string().max(4000).optional(),
});

// ── Images ────────────────────────────────────────────────────────────────────
export const imageGenerateSchema = Joi.object({
  prompt:          Joi.string().min(1).max(2000).required(),
  negative_prompt: Joi.string().max(1000).optional(),
  model:           Joi.string().default('flux-schnell'),
  width:           Joi.number().integer().min(256).max(4096).default(1024),
  height:          Joi.number().integer().min(256).max(4096).default(1024),
  steps:           Joi.number().integer().min(1).max(100).default(4),
  guidance_scale:  Joi.number().min(0).max(30).default(7.5),
  seed:            Joi.number().integer().optional(),
});

// ── Voice ─────────────────────────────────────────────────────────────────────
export const ttsSchema = Joi.object({
  text:  Joi.string().min(1).max(5000).required(),
  voice: Joi.string().default('en-US-female-1'),
  speed: Joi.number().min(0.5).max(2.0).default(1.0),
});

// ── Code ─────────────────────────────────────────────────────────────────────
export const codeExecuteSchema = Joi.object({
  code:     Joi.string().min(1).max(50_000).required(),
  language: Joi.string().valid('python','javascript','typescript','bash','go','rust','java','cpp','ruby').required(),
  stdin:    Joi.string().max(10_000).default(''),
});

// ── Music ─────────────────────────────────────────────────────────────────────
export const musicGenerateSchema = Joi.object({
  prompt:   Joi.string().min(1).max(500).required(),
  model:    Joi.string().default('musicgen-small'),
  duration: Joi.number().integer().min(5).max(30).default(10),
});

// ── Translate & Summarize ─────────────────────────────────────────────────────
export const translateSchema = Joi.object({
  text:           Joi.string().min(1).max(10_000).required(),
  targetLanguage: Joi.string().min(2).max(50).required(),
  sourceLanguage: Joi.string().min(2).max(50).optional(),
});

export const summarizeSchema = Joi.object({
  text:      Joi.string().min(1).max(50_000).required(),
  maxLength: Joi.number().integer().min(50).max(2000).default(500),
  style:     Joi.string().valid('paragraph','bullet','headline').default('paragraph'),
});
