import winston from 'winston';
import path from 'path';
import fs from 'fs';

const logDir  = process.env.LOG_DIR || './logs';
const logLevel = process.env.LOG_LEVEL || 'info';
const isProd  = process.env.NODE_ENV === 'production';

if (!fs.existsSync(logDir)) fs.mkdirSync(logDir, { recursive: true });

const fmt = winston.format;

const consoleFormat = fmt.combine(
  fmt.colorize(),
  fmt.timestamp({ format: 'HH:mm:ss' }),
  fmt.printf(({ timestamp, level, message, ...meta }) => {
    const extras = Object.keys(meta).length ? ' ' + JSON.stringify(meta) : '';
    return `${timestamp} ${level}: ${message}${extras}`;
  })
);

const fileFormat = fmt.combine(
  fmt.timestamp(),
  fmt.errors({ stack: true }),
  fmt.json()
);

const logger = winston.createLogger({
  level: logLevel,
  transports: [
    new winston.transports.Console({ format: consoleFormat, silent: process.env.NODE_ENV === 'test' }),
    ...(isProd ? [
      new winston.transports.File({ filename: path.join(logDir, 'error.log'),  level: 'error', format: fileFormat }),
      new winston.transports.File({ filename: path.join(logDir, 'combined.log'),             format: fileFormat }),
    ] : []),
  ],
});

export default logger;
