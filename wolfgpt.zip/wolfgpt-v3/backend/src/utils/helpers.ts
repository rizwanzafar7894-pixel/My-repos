import crypto from 'node:crypto';

export function generateId(prefix = ''): string {
  const id = `${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 9)}`;
  return prefix ? `${prefix}_${id}` : id;
}

export function hashKey(key: string): string {
  return crypto.createHash('sha256').update(key).digest('hex');
}

export function generateApiKey(): string {
  return `wgpt_${crypto.randomBytes(32).toString('hex')}`;
}

export function maskKey(key: string): string {
  return key.slice(0, 12) + '••••••••';
}

export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export function parseIntSafe(val: unknown, fallback: number): number {
  const n = parseInt(String(val), 10);
  return isNaN(n) ? fallback : n;
}

export function paginate<T>(arr: T[], page: number, perPage: number): { data: T[]; total: number; pages: number } {
  const total = arr.length;
  const pages = Math.ceil(total / perPage);
  const data  = arr.slice((page - 1) * perPage, page * perPage);
  return { data, total, pages };
}
