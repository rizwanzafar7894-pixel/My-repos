import { createClient, RedisClientType } from 'redis';
import logger from './logger';

let _client: RedisClientType | null = null;
let _connected     = false;
let _connectPromise: Promise<RedisClientType | null> | null = null;

async function getClient(): Promise<RedisClientType | null> {
  if (_connected && _client) return _client;
  if (_connectPromise)        return _connectPromise;

  _connectPromise = (async () => {
    try {
      const url = process.env.REDIS_URL || 'redis://localhost:6379';

      _client = createClient({
        url,
        socket: {
          reconnectStrategy: (retries) => {
            if (retries > 10) { logger.warn('Redis: max retries — running without cache'); return false; }
            return Math.min(retries * 200, 5_000);
          },
          connectTimeout: 5_000,
        },
      }) as RedisClientType;

      _client.on('connect',      ()  => { _connected = true;  logger.info('✅ Redis connected'); });
      _client.on('disconnect',   ()  => { _connected = false; logger.warn('Redis disconnected'); });
      _client.on('reconnecting', ()  => logger.debug('Redis reconnecting…'));
      _client.on('error',        (e) => logger.warn('Redis error:', e.message));

      await _client.connect();
      return _client;
    } catch (err) {
      logger.warn('Redis unavailable — cache disabled.', (err as Error).message);
      _client         = null;
      _connectPromise = null;
      return null;
    }
  })();

  return _connectPromise;
}

export async function cacheGet<T = unknown>(key: string): Promise<T | null> {
  try {
    const c   = await getClient();
    if (!c)   return null;
    const val = await c.get(key);
    return val ? (JSON.parse(val) as T) : null;
  } catch { return null; }
}

export async function cacheSet(key: string, value: unknown, ttlSeconds = 300): Promise<void> {
  try {
    const c = await getClient();
    if (!c) return;
    await c.setEx(key, ttlSeconds, JSON.stringify(value));
  } catch { /* non-fatal */ }
}

export async function cacheDel(key: string): Promise<void> {
  try {
    const c = await getClient();
    if (!c) return;
    await c.del(key);
  } catch { /* non-fatal */ }
}

/** Atomic increment with TTL. Uses MULTI/EXEC to avoid race conditions. */
export async function cacheIncr(key: string, ttlSeconds?: number): Promise<number> {
  try {
    const c = await getClient();
    if (!c) return 0;
    if (!ttlSeconds) return (await c.incr(key)) ?? 0;
    const multi   = c.multi();
    multi.incr(key);
    multi.expire(key, ttlSeconds, 'NX');
    const results = await multi.exec();
    return (results?.[0] as number | null) ?? 0;
  } catch { return 0; }
}

export async function cacheFlushPattern(pattern: string): Promise<void> {
  try {
    const c = await getClient();
    if (!c) return;
    let cursor = 0;
    do {
      const result = await c.scan(cursor, { MATCH: pattern, COUNT: 100 });
      cursor = result.cursor;
      if (result.keys.length) await c.del(result.keys);
    } while (cursor !== 0);
  } catch { /* non-fatal */ }
}

export async function cacheDisconnect(): Promise<void> {
  try {
    if (_client && _connected) {
      await _client.quit();
      logger.info('Redis disconnected cleanly');
    }
  } catch { /* non-fatal */ }
}
