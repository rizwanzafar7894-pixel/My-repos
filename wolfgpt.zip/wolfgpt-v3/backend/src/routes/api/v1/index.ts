import express from 'express';
import multer from 'multer';
import { authMiddleware, apiKeyMiddleware } from '../../middleware/auth';
import { rateLimiter } from '../../middleware/rateLimit';
import { requireTier } from '../../middleware/requireTier';

import { chatController }      from '../../controllers/chatController';
import {
  imageController,
  voiceController,
  codeController,
  musicController,
  documentController,
  translateController,
  summarizeController,
  analyticsController,
} from '../../controllers/featureControllers';

const router  = express.Router();
const upload  = multer({ storage: multer.memoryStorage(), limits: { fileSize: 50 * 1024 * 1024 } });

// Auth: prefer Bearer token; fall back to API key
const authenticate = [
  (req: any, res: any, next: any) => {
    return (req.headers['x-api-key'] || req.query.api_key)
      ? apiKeyMiddleware(req, res, next)
      : authMiddleware(req, res, next);
  },
  rateLimiter,
];

// ── Chat ────────────────────────────────────────────────────────────────────
router.post('/chat/completions',        ...authenticate, chatController.createCompletion);
router.post('/chat/completions/stream', ...authenticate, chatController.createStreamingCompletion);
router.get( '/chat/conversations',      ...authenticate, chatController.getConversations);
router.get( '/chat/conversations/:id',  ...authenticate, chatController.getConversation);
router.patch('/chat/conversations/:id', ...authenticate, chatController.updateConversation);
router.delete('/chat/conversations/:id',...authenticate, chatController.deleteConversation);
router.delete('/chat/conversations',    ...authenticate, chatController.clearConversations);

// ── Images ──────────────────────────────────────────────────────────────────
router.post('/images/generate',         ...authenticate, imageController.generate);
router.post('/images/img2img',          ...authenticate, imageController.img2img);
router.post('/images/inpaint',          ...authenticate, imageController.inpaint);
router.post('/images/upscale',          ...authenticate, imageController.upscale);

// ── Voice ───────────────────────────────────────────────────────────────────
router.post('/voice/stt', ...authenticate, upload.single('audio'), voiceController.stt);
router.post('/voice/tts', ...authenticate, voiceController.tts);

// ── Code ────────────────────────────────────────────────────────────────────
router.post('/code/execute', ...authenticate, requireTier('free'), codeController.execute);

// ── Music ────────────────────────────────────────────────────────────────────
router.post('/music/generate',     ...authenticate, requireTier('free'),   musicController.generate);
router.post('/music/melody',       ...authenticate, requireTier('premium'), musicController.melody);
router.post('/music/continuation', ...authenticate, requireTier('basic'),   musicController.continuation);

// ── Documents ────────────────────────────────────────────────────────────────
router.post('/documents/upload',      ...authenticate, upload.single('document'), documentController.upload);
router.post('/documents/:id/chat',    ...authenticate, documentController.chat);

// ── Translate & Summarize ────────────────────────────────────────────────────
router.post('/translate', ...authenticate, translateController.translate);
router.post('/summarize', ...authenticate, summarizeController.summarize);

// ── Analytics ────────────────────────────────────────────────────────────────
router.get('/analytics', ...authenticate, analyticsController.get);

// ── Health ───────────────────────────────────────────────────────────────────
router.get('/health', (_req, res) => {
  res.json({
    success: true, version: 'v1',
    message: 'WolfGPT API v1 is running',
    timestamp: new Date().toISOString(),
  });
});

export default router;
