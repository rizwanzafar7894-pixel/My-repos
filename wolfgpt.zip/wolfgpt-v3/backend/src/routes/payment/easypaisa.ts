import express from 'express';
import crypto   from 'node:crypto';
import { authMiddleware }        from '../../middleware/auth';
import { asyncHandler, ApiError } from '../../middleware/errorHandler';
import { db }                    from '../../config/firebase';
import { AuthRequest }           from '../../middleware/auth';
import logger                    from '../../utils/logger';

// ══════════════════════════════════════════════════════════════════════════════
//  EASYPAISA PAYMENT GATEWAY (Pakistan)
//  Setup:
//  1. Contact EasyPaisa merchant support: https://easypaisa.com.pk
//  2. Request: Store ID, Secret Key, Hash Key
//  3. Add to backend/.env:
//       EASYPAISA_STORE_ID=00000
//       EASYPAISA_SECRET_KEY=your_secret_key
//       EASYPAISA_HASH_KEY=your_hash_key
//       EASYPAISA_CALLBACK_URL=https://yourdomain.com/api/payment/easypaisa/callback
//       EASYPAISA_MODE=sandbox   # or live
// ══════════════════════════════════════════════════════════════════════════════

const router = express.Router();

const CONFIG = {
  storeId:     process.env.EASYPAISA_STORE_ID     || '',
  secretKey:   process.env.EASYPAISA_SECRET_KEY   || '',
  hashKey:     process.env.EASYPAISA_HASH_KEY      || '',
  callbackUrl: process.env.EASYPAISA_CALLBACK_URL  || '',
  mode:        process.env.EASYPAISA_MODE === 'live' ? 'live' : 'sandbox',
  apiUrl: process.env.EASYPAISA_MODE === 'live'
    ? 'https://easypaisa.com.pk/easypay'
    : 'https://sandbox.easypaisa.com.pk/easypay',
};

const PLAN_AMOUNTS: Record<string, number> = {
  basic:   27_800,
  premium: 55_600,
  pro:     111_200,
};

// ── EasyPaisa HMAC-SHA256 signature ──────────────────────────────────────────
// FIX #14: Signature is computed from sorted key=value pairs joined with '&'
function computeSignature(params: Record<string, string>): string {
  const sortedKeys  = Object.keys(params).filter(k => k !== 'hash').sort();
  const queryString = sortedKeys.map(k => `${k}=${params[k]}`).join('&');
  return crypto
    .createHmac('sha256', CONFIG.hashKey)
    .update(queryString)
    .digest('hex')
    .toLowerCase();
}

// ── POST /api/payment/easypaisa/initiate ─────────────────────────────────────
router.post('/initiate', authMiddleware, asyncHandler(async (req: AuthRequest, res) => {
  const { tier, mobileNumber, period = 'yearly' } = req.body;
  const userId = req.user!.uid;

  if (!['basic','premium','pro'].includes(tier))
    throw ApiError.badRequest('Invalid tier', 'INVALID_PLAN');
  if (period !== 'yearly')
    throw ApiError.badRequest('EasyPaisa only supports yearly billing', 'YEARLY_ONLY');

  const mobileRegex = /^03\d{9}$/;
  if (!mobileNumber || !mobileRegex.test(mobileNumber))
    throw ApiError.badRequest('Invalid mobile number. Must be in format 03XXXXXXXXX', 'INVALID_MOBILE');

  const amount = PLAN_AMOUNTS[tier];
  if (!amount) throw ApiError.badRequest('Invalid plan', 'INVALID_PLAN');

  if (!CONFIG.storeId || !CONFIG.secretKey)
    throw ApiError.serviceUnavailable('EasyPaisa is not configured. Add EASYPAISA_* vars to backend/.env');

  const orderRef  = `WGPT-EP-${Date.now()}-${userId.slice(0, 6)}`;
  const expiryDate = new Date(Date.now() + 30 * 60_000).toISOString().replace(/[-:T.]/g, '').slice(0, 14);

  const params: Record<string, string> = {
    storeId:      CONFIG.storeId,
    amount:       (amount * 100).toString(), // paisas
    postBackURL:  CONFIG.callbackUrl,
    orderRefNum:  orderRef,
    mobileNum:    mobileNumber,
    emailAddr:    req.user!.email || '',
    expiryDate,
    paymentMethod: 'MA_JAZZCASH_WALLET',
    paymentType:  'MA',
  };

  params.hash = computeSignature(params);

  await db.collection('pending_payments').doc(orderRef).set({
    userId, tier, period, amount, provider: 'easypaisa',
    orderRef, mobileNumber, status: 'pending', createdAt: new Date(),
  });

  res.json({
    success: true,
    data: {
      orderRef, amount, currency: 'PKR',
      paymentUrl: CONFIG.apiUrl,
      params,
      message: 'Payment request sent. User will receive OTP on their mobile.',
    },
  });
}));

// ── POST /api/payment/easypaisa/callback ─────────────────────────────────────
// FIX #14: Proper HMAC-SHA256 webhook verification (was completely absent before)
router.post('/callback', asyncHandler(async (req, res) => {
  const body          = req.body as Record<string, string>;
  const receivedHash  = body.hash;
  const orderRefNum   = body.orderRefNum || body.pp_TxnRefNo;
  const responseCode  = body.responseCode || body.pp_ResponseCode;

  if (!orderRefNum) {
    logger.warn('EasyPaisa callback: missing orderRefNum');
    return res.status(400).json({ success: false, error: 'Missing orderRefNum' });
  }

  // FIX #14: Verify HMAC signature before processing any payment update
  if (!receivedHash) {
    logger.warn('EasyPaisa callback: missing hash — rejecting', { orderRefNum });
    return res.status(400).json({ success: false, error: 'Missing signature hash' });
  }

  const expectedHash = computeSignature(body);
  if (expectedHash !== receivedHash.toLowerCase()) {
    logger.warn('EasyPaisa callback: invalid signature', {
      orderRefNum,
      expected: expectedHash,
      received: receivedHash.toLowerCase(),
    });
    return res.status(400).json({ success: false, error: 'Invalid signature' });
  }

  const pending = await db.collection('pending_payments').doc(orderRefNum).get();
  if (!pending.exists) return res.status(404).json({ success: false, error: 'Transaction not found' });

  const { userId, tier } = pending.data()!;
  const success = responseCode === '0000' || responseCode === '000';

  if (success) {
    const expiresAt = new Date();
    expiresAt.setFullYear(expiresAt.getFullYear() + 1);

    await db.collection('users').doc(userId).update({
      tier,
      'subscription.status':    'active',
      'subscription.provider':  'easypaisa',
      'subscription.planId':    tier,
      'subscription.orderRef':  orderRefNum,
      'subscription.expiresAt': expiresAt,
      'subscription.updatedAt': new Date(),
    });
    logger.info(`✅ EasyPaisa payment success: ${userId} → ${tier}`);
  } else {
    logger.warn(`EasyPaisa payment failed: ${orderRefNum} code=${responseCode}`);
  }

  await db.collection('pending_payments').doc(orderRefNum).update({
    status:       success ? 'completed' : 'failed',
    responseCode,
    updatedAt:    new Date(),
  });

  const redirectUrl = success
    ? `${process.env.FRONTEND_URL}/dashboard/billing?success=true`
    : `${process.env.FRONTEND_URL}/dashboard/billing?error=payment_failed`;

  res.redirect(302, redirectUrl);
}));

// ── GET /api/payment/easypaisa/status/:orderRef ───────────────────────────────
router.get('/status/:orderRef', authMiddleware, asyncHandler(async (req: AuthRequest, res) => {
  const snap = await db.collection('pending_payments').doc(req.params.orderRef).get();
  if (!snap.exists) throw ApiError.notFound('Transaction not found');
  if (snap.data()!.userId !== req.user!.uid) throw ApiError.forbidden();
  res.json({ success: true, data: { status: snap.data()!.status, orderRef: req.params.orderRef } });
}));

export default router;
