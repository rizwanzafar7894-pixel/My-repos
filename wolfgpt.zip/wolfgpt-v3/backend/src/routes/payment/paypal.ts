import express from 'express';
import axios from 'axios';
import { authMiddleware }        from '../../middleware/auth';
import { rateLimiter }           from '../../middleware/rateLimit';
import { asyncHandler, ApiError } from '../../middleware/errorHandler';
import { db }                    from '../../config/firebase';
import { AuthRequest }           from '../../middleware/auth';
import logger                    from '../../utils/logger';
import crypto                    from 'node:crypto';

// ══════════════════════════════════════════════════════════════════════════════
//  PAYPAL SUBSCRIPTION GATEWAY  (FIX #18 — was completely missing)
//  Setup:
//  1. Go to https://developer.paypal.com → My Apps & Credentials → Create App
//  2. Copy Client ID and Client Secret to backend/.env
//  3. Create subscription plans at https://www.paypal.com/billing/plans
//     (one for each: basic_monthly, basic_yearly, premium_*, pro_*)
//  4. Copy each Plan ID (P-XXXX) to backend/.env
//  5. Add webhook at PayPal developer dashboard:
//       https://yourdomain.com/api/payment/paypal/webhook
//     Events: BILLING.SUBSCRIPTION.ACTIVATED, BILLING.SUBSCRIPTION.CANCELLED,
//             BILLING.SUBSCRIPTION.SUSPENDED, PAYMENT.SALE.COMPLETED
// ══════════════════════════════════════════════════════════════════════════════

const router = express.Router();

const PAYPAL_CLIENT_ID     = process.env.PAYPAL_CLIENT_ID     || '';
const PAYPAL_CLIENT_SECRET = process.env.PAYPAL_CLIENT_SECRET || '';
const PAYPAL_WEBHOOK_ID    = process.env.PAYPAL_WEBHOOK_ID    || '';
const PAYPAL_MODE          = process.env.PAYPAL_MODE === 'live' ? 'live' : 'sandbox';

const PAYPAL_BASE_URL = PAYPAL_MODE === 'live'
  ? 'https://api-m.paypal.com'
  : 'https://api-m.sandbox.paypal.com';

// Plan ID map — populated from env vars
const PLAN_IDS: Record<string, Record<string, string>> = {
  basic:   { monthly: process.env.PAYPAL_PLAN_BASIC_MONTHLY   || '', yearly: process.env.PAYPAL_PLAN_BASIC_YEARLY   || '' },
  premium: { monthly: process.env.PAYPAL_PLAN_PREMIUM_MONTHLY || '', yearly: process.env.PAYPAL_PLAN_PREMIUM_YEARLY || '' },
  pro:     { monthly: process.env.PAYPAL_PLAN_PRO_MONTHLY     || '', yearly: process.env.PAYPAL_PLAN_PRO_YEARLY     || '' },
};

function requirePayPal() {
  if (!PAYPAL_CLIENT_ID || !PAYPAL_CLIENT_SECRET) {
    throw ApiError.serviceUnavailable('PayPal is not configured. Set PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET in backend/.env');
  }
}

// ── Get OAuth2 access token ───────────────────────────────────────────────────
async function getPayPalToken(): Promise<string> {
  const res = await axios.post(
    `${PAYPAL_BASE_URL}/v1/oauth2/token`,
    'grant_type=client_credentials',
    {
      auth: { username: PAYPAL_CLIENT_ID, password: PAYPAL_CLIENT_SECRET },
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      timeout: 15_000,
    }
  );
  return res.data.access_token;
}

// ── GET /api/payment/paypal/plan-id — return the PayPal Plan ID for a tier ────
router.get('/plan-id', authMiddleware, asyncHandler(async (req: AuthRequest, res) => {
  requirePayPal();
  const tier   = (req.query.tier as string)   || 'basic';
  const period = (req.query.period as string) || 'monthly';

  if (!['basic','premium','pro'].includes(tier))
    throw ApiError.badRequest('Invalid tier', 'INVALID_PLAN');

  const planId = PLAN_IDS[tier]?.[period];
  if (!planId)
    throw ApiError.badRequest(
      `PayPal plan not configured for ${tier}/${period}. Set PAYPAL_PLAN_${tier.toUpperCase()}_${period.toUpperCase()} in .env`,
      'PLAN_NOT_CONFIGURED'
    );

  res.json({ success: true, data: { planId, tier, period, mode: PAYPAL_MODE } });
}));

// ── POST /api/payment/paypal/activate — called after PayPal SDK approves sub ──
router.post('/activate', rateLimiter, authMiddleware, asyncHandler(async (req: AuthRequest, res) => {
  requirePayPal();
  const { subscriptionId, tier } = req.body;

  if (!subscriptionId?.trim()) throw ApiError.badRequest('subscriptionId is required');
  if (!['basic','premium','pro'].includes(tier)) throw ApiError.badRequest('Invalid tier', 'INVALID_PLAN');

  const token = await getPayPalToken();

  // Verify subscription is active with PayPal
  const subRes = await axios.get(
    `${PAYPAL_BASE_URL}/v1/billing/subscriptions/${subscriptionId}`,
    { headers: { Authorization: `Bearer ${token}` }, timeout: 15_000 }
  );

  const sub = subRes.data;
  if (sub.status !== 'ACTIVE') {
    throw ApiError.badRequest(`PayPal subscription status is "${sub.status}", not ACTIVE`, 'SUBSCRIPTION_NOT_ACTIVE');
  }

  const userId = req.user!.uid;
  await db.collection('users').doc(userId).update({
    tier,
    'subscription.status':          'active',
    'subscription.provider':        'paypal',
    'subscription.planId':          tier,
    'subscription.paypalSubId':     subscriptionId,
    'subscription.updatedAt':       new Date(),
  });

  // Store in Firestore for webhook reconciliation
  await db.collection('paypal_subscriptions').doc(subscriptionId).set({
    subscriptionId, userId, tier,
    status:    'active',
    createdAt: new Date(),
    updatedAt: new Date(),
  }, { merge: true });

  logger.info(`PayPal: activated ${userId} → ${tier} (${subscriptionId})`);
  res.json({ success: true, data: { activated: true, tier } });
}));

// ── POST /api/payment/paypal/webhook ─────────────────────────────────────────
router.post('/webhook', express.json(), async (req, res) => {
  // Verify webhook signature using PayPal's verification API
  const transmissionId   = req.headers['paypal-transmission-id']   as string;
  const transmissionTime = req.headers['paypal-transmission-time'] as string;
  const certUrl          = req.headers['paypal-cert-url']          as string;
  const authAlgo         = req.headers['paypal-auth-algo']         as string;
  const transmissionSig  = req.headers['paypal-transmission-sig']  as string;

  if (PAYPAL_WEBHOOK_ID && transmissionId && transmissionSig) {
    try {
      const token = await getPayPalToken();
      const verifyRes = await axios.post(
        `${PAYPAL_BASE_URL}/v1/notifications/verify-webhook-signature`,
        {
          auth_algo:         authAlgo,
          cert_url:          certUrl,
          transmission_id:   transmissionId,
          transmission_sig:  transmissionSig,
          transmission_time: transmissionTime,
          webhook_id:        PAYPAL_WEBHOOK_ID,
          webhook_event:     req.body,
        },
        { headers: { Authorization: `Bearer ${token}` }, timeout: 15_000 }
      );

      if (verifyRes.data?.verification_status !== 'SUCCESS') {
        logger.warn('PayPal webhook signature verification failed');
        res.status(400).json({ error: 'Invalid signature' });
        return;
      }
    } catch (err) {
      logger.error('PayPal webhook verification error:', err);
      // Fail open in dev, fail closed in production
      if (process.env.NODE_ENV === 'production') {
        res.status(400).json({ error: 'Signature verification failed' });
        return;
      }
    }
  }

  const { event_type, resource } = req.body;

  try {
    switch (event_type) {

      case 'BILLING.SUBSCRIPTION.ACTIVATED': {
        const subscriptionId = resource?.id;
        const subSnap = await db.collection('paypal_subscriptions').doc(subscriptionId).get();
        if (subSnap.exists) {
          const { userId, tier } = subSnap.data()!;
          await db.collection('users').doc(userId).update({
            tier,
            'subscription.status':    'active',
            'subscription.updatedAt': new Date(),
          });
          logger.info(`PayPal webhook: activated ${userId} → ${tier}`);
        }
        break;
      }

      case 'BILLING.SUBSCRIPTION.CANCELLED':
      case 'BILLING.SUBSCRIPTION.SUSPENDED': {
        const subscriptionId = resource?.id;
        const subSnap = await db.collection('paypal_subscriptions').doc(subscriptionId).get();
        if (subSnap.exists) {
          const { userId } = subSnap.data()!;
          const status = event_type === 'BILLING.SUBSCRIPTION.CANCELLED' ? 'cancelled' : 'paused';
          await db.collection('users').doc(userId).update({
            tier: 'free',
            'subscription.status':    status,
            'subscription.updatedAt': new Date(),
          });
          await subSnap.ref.update({ status, updatedAt: new Date() });
          logger.info(`PayPal webhook: ${event_type} for subscription ${subscriptionId}`);
        }
        break;
      }

      case 'PAYMENT.SALE.COMPLETED': {
        const billingAgreementId = resource?.billing_agreement_id;
        if (billingAgreementId) {
          const subSnap = await db.collection('paypal_subscriptions').doc(billingAgreementId).get();
          if (subSnap.exists) {
            await subSnap.ref.update({ lastPayment: new Date(), updatedAt: new Date() });
          }
        }
        break;
      }
    }

    res.json({ received: true });
  } catch (err) {
    logger.error('PayPal webhook handler error:', err);
    res.status(500).json({ error: 'Handler error' });
  }
});

export default router;
