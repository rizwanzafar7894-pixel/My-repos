import express from 'express';
import crypto   from 'node:crypto';
import { authMiddleware }        from '../../middleware/auth';
import { asyncHandler, ApiError } from '../../middleware/errorHandler';
import { db }                    from '../../config/firebase';
import { AuthRequest }           from '../../middleware/auth';
import logger                    from '../../utils/logger';

// ══════════════════════════════════════════════════════════════════════════════
//  JAZZCASH PAYMENT GATEWAY (Pakistan)
//  Setup:
//  1. Sandbox: https://sandbox.jazzcash.com.pk
//     Live:    https://jazzcash.com.pk → Become a Merchant
//  2. After approval, receive via email:
//     - Merchant ID (MCxxxxxxxx)
//     - Password
//     - Integrity Salt
//  3. Add to backend/.env:
//       JAZZCASH_MERCHANT_ID=MCxxxxxxxx
//       JAZZCASH_PASSWORD=your_password
//       JAZZCASH_INTEGRITY_SALT=your_salt
//       JAZZCASH_RETURN_URL=https://yourdomain.com/api/payment/jazzcash/callback
//  4. PKR amounts: Basic Rs.27,800/yr | Premium Rs.55,600/yr | Pro Rs.1,11,200/yr
// ══════════════════════════════════════════════════════════════════════════════

const router = express.Router();

const CONFIG = {
  merchantId:    process.env.JAZZCASH_MERCHANT_ID    || '',
  password:      process.env.JAZZCASH_PASSWORD        || '',
  integritySalt: process.env.JAZZCASH_INTEGRITY_SALT  || '',
  returnUrl:     process.env.JAZZCASH_RETURN_URL       || '',
  apiUrl: process.env.NODE_ENV === 'production'
    ? 'https://payments.jazzcash.com.pk/CustomerPortal/transactionmanagement/merchantform'
    : 'https://sandbox.jazzcash.com.pk/CustomerPortal/transactionmanagement/merchantform',
};

const PLAN_AMOUNTS: Record<string, number> = {
  basic:   27_800,
  premium: 55_600,
  pro:     111_200,
};

// ══════════════════════════════════════════════════════════════════════════════
//  SECURE HASH — JazzCash HMAC-SHA256
//
//  FIX #1: Per JazzCash specification, the following fields MUST be excluded
//  from the hash computation:
//    - pp_Password        (secret — never included in hash)
//    - pp_SecureHash      (the hash itself)
//  All other non-empty params are sorted and joined with '&'.
//
//  FIX #9: The callback hash verification must include pp_ResponseCode,
//  which was previously excluded by the destructure spread (was in `rest`
//  but only `...rest` after removing pp_TxnRefNo, pp_ResponseCode was missing).
// ══════════════════════════════════════════════════════════════════════════════
const HASH_EXCLUDED_FIELDS = new Set(['pp_Password', 'pp_SecureHash']);

function generateSecureHash(params: Record<string, string>): string {
  const sortedKeys = Object.keys(params).sort();
  const hashStr    = sortedKeys
    .filter(k => !HASH_EXCLUDED_FIELDS.has(k) && params[k] !== '')
    .map(k => params[k])
    .join('&');

  return crypto
    .createHmac('sha256', CONFIG.integritySalt)
    .update(`${CONFIG.integritySalt}&${hashStr}`)
    .digest('hex')
    .toUpperCase();
}

// ── POST /api/payment/jazzcash/initiate ──────────────────────────────────────
router.post('/initiate', authMiddleware, asyncHandler(async (req: AuthRequest, res) => {
  const { tier, period = 'yearly' } = req.body;
  const userId = req.user!.uid;

  if (!['basic','premium','pro'].includes(tier))
    throw ApiError.badRequest('Invalid tier', 'INVALID_PLAN');
  if (period !== 'yearly')
    throw ApiError.badRequest('JazzCash only supports yearly billing', 'YEARLY_ONLY');

  const amount = PLAN_AMOUNTS[tier];
  if (!amount) throw ApiError.badRequest('Invalid plan', 'INVALID_PLAN');

  if (!CONFIG.merchantId || !CONFIG.integritySalt)
    throw ApiError.serviceUnavailable('JazzCash is not configured. Add JAZZCASH_* vars to backend/.env');

  const userDoc = await db.collection('users').doc(userId).get();
  const txnRef  = `WGPT-${Date.now()}-${userId.slice(0, 6)}`;
  const now     = new Date();
  const txnDate = now.toISOString().replace(/[-:T.]/g, '').slice(0, 14);
  const expiry  = new Date(now.getTime() + 30 * 60_000).toISOString().replace(/[-:T.]/g, '').slice(0, 14);

  // Note: pp_Password is included in the POST to JazzCash but NOT in the hash
  const params: Record<string, string> = {
    pp_Version:           '1.1',
    pp_TxnType:           'MWALLET',
    pp_Language:          'EN',
    pp_MerchantID:        CONFIG.merchantId,
    pp_Password:          CONFIG.password,   // sent to JazzCash but EXCLUDED from hash (FIX #1)
    pp_TxnRefNo:          txnRef,
    pp_Amount:            (amount * 100).toString(), // paisas
    pp_TxnCurrency:       'PKR',
    pp_TxnDateTime:       txnDate,
    pp_BillReference:     `wolfgpt_${tier}`,
    pp_Description:       `WolfGPT ${tier} plan (${period})`,
    pp_TxnExpiryDateTime: expiry,
    pp_ReturnURL:         CONFIG.returnUrl,
    pp_MobileNumber:      userDoc.data()?.phone || '',
    pp_CNIC:              '',
  };

  // FIX #1: generateSecureHash() now excludes pp_Password automatically
  params.pp_SecureHash = generateSecureHash(params);

  await db.collection('pending_payments').doc(txnRef).set({
    userId, tier, period, amount, provider: 'jazzcash',
    txnRef, status: 'pending', createdAt: new Date(),
  });

  res.json({
    success: true,
    data: {
      txnRef, amount, currency: 'PKR',
      paymentUrl: CONFIG.apiUrl,
      params,  // POST these fields to paymentUrl
    },
  });
}));

// ── POST /api/payment/jazzcash/callback ──────────────────────────────────────
router.post('/callback', asyncHandler(async (req, res) => {
  // FIX #9: Include ALL fields (including pp_ResponseCode) when verifying hash.
  // The previous code destructured pp_ResponseCode OUT of the hash check.
  // Now we spread the full body and only exclude the two designated fields.
  const body = req.body as Record<string, string>;
  const pp_TxnRefNo    = body.pp_TxnRefNo;
  const pp_SecureHash  = body.pp_SecureHash;
  const pp_ResponseCode = body.pp_ResponseCode;

  if (!pp_TxnRefNo || !pp_SecureHash) {
    logger.warn('JazzCash callback: missing required fields');
    return res.status(400).json({ success: false, error: 'Missing required callback fields' });
  }

  // FIX #9: Pass the ENTIRE body to hash verification (pp_Password and
  // pp_SecureHash are excluded inside generateSecureHash via HASH_EXCLUDED_FIELDS)
  const expectedHash = generateSecureHash(body);
  if (expectedHash !== pp_SecureHash) {
    logger.warn('JazzCash: invalid hash on callback', { txnRef: pp_TxnRefNo, expected: expectedHash, received: pp_SecureHash });
    return res.status(400).json({ success: false, error: 'Invalid signature' });
  }

  const pending = await db.collection('pending_payments').doc(pp_TxnRefNo).get();
  if (!pending.exists) return res.status(404).json({ success: false, error: 'Transaction not found' });

  const { userId, tier } = pending.data()!;
  const success = pp_ResponseCode === '000';

  if (success) {
    const expiresAt = new Date();
    expiresAt.setFullYear(expiresAt.getFullYear() + 1);

    await db.collection('users').doc(userId).update({
      tier,
      'subscription.status':    'active',
      'subscription.provider':  'jazzcash',
      'subscription.planId':    tier,
      'subscription.txnRef':    pp_TxnRefNo,
      'subscription.expiresAt': expiresAt,
      'subscription.updatedAt': new Date(),
    });
    logger.info(`✅ JazzCash payment success: ${userId} → ${tier}`);
  } else {
    logger.warn(`JazzCash payment failed: ${pp_TxnRefNo} code=${pp_ResponseCode}`);
  }

  await db.collection('pending_payments').doc(pp_TxnRefNo).update({
    status:       success ? 'completed' : 'failed',
    responseCode: pp_ResponseCode,
    updatedAt:    new Date(),
  });

  const redirectUrl = success
    ? `${process.env.FRONTEND_URL}/dashboard/billing?success=true`
    : `${process.env.FRONTEND_URL}/dashboard/billing?error=payment_failed`;

  res.redirect(302, redirectUrl);
}));

export default router;
