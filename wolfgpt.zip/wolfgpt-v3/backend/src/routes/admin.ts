import express from 'express';
import { authMiddleware } from '../middleware/auth';
import { adminMiddleware } from '../middleware/admin';
import { asyncHandler, ApiError } from '../middleware/errorHandler';
import { db } from '../config/firebase';
import { AuthRequest } from '../middleware/auth';
import { Response } from 'express';

const router = express.Router();

const guard = [authMiddleware, adminMiddleware];

// GET /api/admin/users
router.get('/users', ...guard, asyncHandler(async (req: AuthRequest, res: Response) => {
  const limit  = Math.min(parseInt(req.query.limit as string) || 50, 200);
  const snap   = await db.collection('users').orderBy('createdAt', 'desc').limit(limit).get();
  const users  = snap.docs.map(d => {
    const data = d.data();
    return {
      uid: data.uid, email: data.email, displayName: data.displayName,
      tier: data.tier, createdAt: data.createdAt, usage: data.usage,
      subscription: data.subscription,
    };
  });
  res.json({ success: true, data: users, count: users.length });
}));

// GET /api/admin/users/:uid
router.get('/users/:uid', ...guard, asyncHandler(async (req: AuthRequest, res: Response) => {
  const snap = await db.collection('users').doc(req.params.uid).get();
  if (!snap.exists) throw ApiError.notFound('User not found');
  res.json({ success: true, data: snap.data() });
}));

// PATCH /api/admin/users/:uid/tier
router.patch('/users/:uid/tier', ...guard, asyncHandler(async (req: AuthRequest, res: Response) => {
  const { tier } = req.body;
  if (!['free', 'basic', 'premium', 'pro'].includes(tier)) throw ApiError.badRequest('Invalid tier');
  await db.collection('users').doc(req.params.uid).update({ tier, updatedAt: new Date() });
  res.json({ success: true, data: { uid: req.params.uid, tier } });
}));

// DELETE /api/admin/users/:uid
router.delete('/users/:uid', ...guard, asyncHandler(async (req: AuthRequest, res: Response) => {
  await db.collection('users').doc(req.params.uid).delete();
  res.json({ success: true, data: { deleted: true } });
}));

// GET /api/admin/stats
router.get('/stats', ...guard, asyncHandler(async (_req, res: Response) => {
  const [usersSnap, convSnap] = await Promise.all([
    db.collection('users').get(),
    db.collection('conversations').get(),
  ]);

  const tierCounts: Record<string, number> = { free: 0, basic: 0, premium: 0, pro: 0 };
  usersSnap.docs.forEach(d => {
    const tier = d.data().tier || 'free';
    tierCounts[tier] = (tierCounts[tier] || 0) + 1;
  });

  res.json({
    success: true,
    data: {
      totalUsers:         usersSnap.size,
      totalConversations: convSnap.size,
      tierDistribution:   tierCounts,
      timestamp:          new Date().toISOString(),
    },
  });
}));

// GET /api/admin/payments
router.get('/payments', ...guard, asyncHandler(async (req: AuthRequest, res: Response) => {
  const limit = Math.min(parseInt(req.query.limit as string) || 50, 200);
  const snap  = await db.collection('pending_payments').orderBy('createdAt', 'desc').limit(limit).get();
  res.json({ success: true, data: snap.docs.map(d => ({ id: d.id, ...d.data() })) });
}));

export default router;
