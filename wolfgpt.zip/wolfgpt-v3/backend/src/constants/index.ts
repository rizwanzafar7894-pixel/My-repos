export const TIER_RANK: Record<string, number> = { free: 0, basic: 1, premium: 2, pro: 3 };

export const PLAN_NAMES = ['free', 'basic', 'premium', 'pro'] as const;
export type PlanName = typeof PLAN_NAMES[number];

export const DEFAULT_MODEL = 'qwen-2.5-7b';

// Usage field paths (Firestore dot-notation)
export const USAGE_FIELDS = {
  chat:     'usage.chat.used',
  images:   'usage.images.used',
  code:     'usage.code.used',
  stt:      'usage.voice.sttUsed',
  tts:      'usage.voice.ttsUsed',
  music:    'usage.music.used',
  api:      'usage.api.used',
} as const;

export const DAILY_LIMITS: Record<PlanName, Record<string, number>> = {
  free:    { images: 5,   code: 50,  music: 3   },
  basic:   { images: 25,  code: 200, music: 10  },
  premium: { images: 100, code: 500, music: 50  },
  pro:     { images: -1,  code: -1,  music: -1  },
};
