# WolfGPT Backend

Express + TypeScript API server · Node 20 · Firebase Auth · Redis · Stripe · PayPal · JazzCash · EasyPaisa

## Quick Start

```bash
npm install
cp .env.example .env   # fill in credentials
npm run dev            # http://localhost:4000
```

## Build & Run

```bash
npm run build          # compiles TypeScript → dist/
npm start              # runs dist/server.js
```

## Endpoints

| Method | Path | Description |
|---|---|---|
| GET  | `/health` | Service health |
| POST | `/api/auth/verify` | Verify Firebase token, create user |
| GET  | `/api/auth/me` | Current user profile |
| POST | `/api/v1/chat/completions` | Non-streaming chat |
| POST | `/api/v1/chat/completions/stream` | SSE streaming chat |
| POST | `/api/v1/images/generate` | Image generation |
| POST | `/api/v1/voice/stt` | Speech-to-text |
| POST | `/api/v1/voice/tts` | Text-to-speech |
| POST | `/api/v1/code/execute` | Sandboxed code execution |
| POST | `/api/v1/music/generate` | Music generation |
| POST | `/api/v1/documents/upload` | Document upload |
| POST | `/api/v1/translate` | Text translation |
| POST | `/api/v1/summarize` | Text summarization |
| POST | `/api/payment/stripe/checkout` | Create Stripe checkout |
| POST | `/api/payment/paypal/activate` | Activate PayPal subscription |
| POST | `/api/payment/jazzcash/initiate` | Initiate JazzCash payment |
| POST | `/api/payment/easypaisa/initiate` | Initiate EasyPaisa payment |

## Key Fixes (v3)
- FIX #1/#9: JazzCash HMAC — pp_Password excluded from hash; pp_ResponseCode included
- FIX #2/#8: ApiError.forbidden() now has code parameter
- FIX #7: Stripe API version updated to 2025-02-24.acacia
- FIX #10: @types/morgan added to devDependencies
- FIX #11: Removed deprecated npm `crypto` package (Node built-in used instead)
- FIX #14: EasyPaisa webhook HMAC-SHA256 signature verification
- FIX #18: Full PayPal subscription integration (was completely missing)
- FIX #21: Auth cache key uses full 64-char SHA256 hash
