#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# WolfGPT v3 — One-command startup script
# ─────────────────────────────────────────────────────────────────────────────
# Usage:
#   ./start.sh              → development mode (GPU)
#   ./start.sh dev          → development mode (GPU)
#   ./start.sh dev --no-gpu → development mode (CPU-only)
#   ./start.sh prod         → production mode  (GPU)
#   ./start.sh prod --no-gpu → production mode (CPU-only)
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

MODE="${1:-dev}"
GPU_FLAG="${2:-}"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
log()   { echo -e "${GREEN}[WolfGPT]${NC} $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()   { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }
info()  { echo -e "${CYAN}[INFO]${NC} $1"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# ── Prerequisite checks ────────────────────────────────────────────────────
command -v docker &>/dev/null || err "Docker is not installed. See https://docs.docker.com/get-docker/"
docker compose version &>/dev/null || err "Docker Compose V2 is required. Update Docker Desktop or install the compose plugin."

# ── Compose command builder ─────────────────────────────────────────────────
build_compose_cmd() {
    local compose_file="$1"
    local cmd="docker compose -f $compose_file"
    if [[ "$GPU_FLAG" == "--no-gpu" ]]; then
        warn "Running in CPU-only mode (no GPU acceleration)"
        cmd="$cmd -f docker-compose.cpu.yml"
    fi
    echo "$cmd"
}

# ═════════════════════════════════════════════════════════════════════════════
# DEVELOPMENT MODE
# ═════════════════════════════════════════════════════════════════════════════
if [[ "$MODE" == "dev" ]]; then
    log "Starting WolfGPT in DEVELOPMENT mode..."

    # Check env files
    [[ -f backend/.env ]]     || { warn "backend/.env missing — copying from example"; cp backend/.env.example backend/.env; }
    [[ -f ai-services/.env ]] || { warn "ai-services/.env missing — copying from example"; cp ai-services/.env.example ai-services/.env; }
    [[ -f frontend/.env.local ]] || { warn "frontend/.env.local missing — copying from example"; cp frontend/.env.local.example frontend/.env.local; }

    COMPOSE_CMD=$(build_compose_cmd "docker-compose.yml")

    log "Building and starting all services..."
    $COMPOSE_CMD up -d --build

    log "Waiting for services to be healthy..."
    sleep 5

    # Pull default Ollama model if not already present
    info "Checking Ollama models..."
    docker exec wolfgpt-ollama ollama list 2>/dev/null | grep -q "qwen2.5:7b" \
        || { log "Pulling default model qwen2.5:7b (this may take a few minutes)..."; \
             docker exec wolfgpt-ollama ollama pull qwen2.5:7b; }

    $COMPOSE_CMD ps

    log ""
    log "✅ WolfGPT is running!"
    log "   Frontend  → http://localhost:3000"
    log "   Backend   → http://localhost:4000"
    log "   AI API    → http://localhost:8000"
    log "   Ollama    → http://localhost:11434"
    log ""
    log "Logs:  docker compose logs -f"
    log "Stop:  docker compose down"

# ═════════════════════════════════════════════════════════════════════════════
# PRODUCTION MODE
# ═════════════════════════════════════════════════════════════════════════════
elif [[ "$MODE" == "prod" ]]; then
    log "Starting WolfGPT in PRODUCTION mode..."

    # Check required files
    [[ -f .env ]]                     || err ".env not found — copy from .env.example and fill in DOMAIN + REDIS_PASSWORD"
    [[ -f backend/.env ]]             || err "backend/.env not found — copy from backend/.env.example"
    [[ -f ai-services/.env ]]         || err "ai-services/.env not found — copy from ai-services/.env.example"
    [[ -f frontend/.env.local ]]      || err "frontend/.env.local not found — copy from frontend/.env.local.example"
    [[ -f firebase-admin-key.json ]]  || err "firebase-admin-key.json not found — download from Firebase Console"

    # Warn if SSL certs missing
    if [[ ! -f nginx/ssl/fullchain.pem ]] || [[ ! -f nginx/ssl/privkey.pem ]]; then
        warn "SSL certificates not found at nginx/ssl/"
        warn "Run: ./scripts/setup-ssl.sh yourdomain.com admin@yourdomain.com"
        warn "Skipping nginx — the other services will still start"
    fi

    # Load DOMAIN from .env
    source .env
    [[ -z "${DOMAIN:-}" ]] && err "DOMAIN must be set in .env"
    [[ -z "${REDIS_PASSWORD:-}" ]] && err "REDIS_PASSWORD must be set in .env"

    COMPOSE_CMD=$(build_compose_cmd "docker-compose.prod.yml")

    log "Building containers..."
    DOMAIN="$DOMAIN" REDIS_PASSWORD="$REDIS_PASSWORD" $COMPOSE_CMD build

    log "Starting all services..."
    DOMAIN="$DOMAIN" REDIS_PASSWORD="$REDIS_PASSWORD" $COMPOSE_CMD up -d

    log "Waiting for health checks (30s)..."
    sleep 30
    $COMPOSE_CMD ps

    # Pull default Ollama model
    info "Checking Ollama models..."
    docker exec wolfgpt-ollama ollama list 2>/dev/null | grep -q "qwen2.5:7b" \
        || { log "Pulling default model qwen2.5:7b..."; \
             docker exec wolfgpt-ollama ollama pull qwen2.5:7b; }

    log ""
    log "✅ WolfGPT Production is running!"
    log "   App:      https://${DOMAIN}"
    log "   API:      https://${DOMAIN}/api"
    log ""
    log "Logs:  docker compose -f docker-compose.prod.yml logs -f"
    log "Stop:  docker compose -f docker-compose.prod.yml down"

else
    err "Unknown mode: '$MODE'. Use: dev | prod"
fi
