# WolfGPT v3 — Stage 5: Payments & Billing

Complete billing system with 4 payment providers.

## Files in this stage

### Backend additions
```
backend/src/
├── controllers/paymentController.ts  — shared subscription/history endpoints
├── middleware/usageLimit.ts          — per-feature daily usage enforcement
├── utils/paymentUtils.ts             — shared helpers (activate, deactivate, sign)
└── routes/payment/
    ├── index.ts      — /api/payment/{subscription,history,plans,usage-limits,cancel}
    ├── stripe.ts     — Stripe checkout + portal + webhooks (FIX #7)
    ├── paypal.ts     — PayPal subscriptions + webhooks (FIX #18)
    ├── jazzcash.ts   — JazzCash PKR payments (FIX #1/#9)
    └── easypaisa.ts  — EasyPaisa PKR payments (FIX #14)
```

### Frontend additions
```
frontend/src/
├── hooks/useSubscription.ts               — subscription state hook
├── lib/api-payment.ts                     — typed payment API helpers
├── components/billing/
│   ├── PlanCard.tsx                       — individual plan card
│   ├── PayPalButton.tsx                   — PayPal SDK subscription button
│   └── UsageCard.tsx                      — daily usage progress bars
└── app/dashboard/billing/page.tsx         — complete billing page
```

## Key Fixes
- **FIX #1/#9**: JazzCash — `pp_Password` excluded from hash; `pp_ResponseCode` included in callback
- **FIX #7**: Stripe API version `2025-02-24.acacia`
- **FIX #14**: EasyPaisa — HMAC-SHA256 verification on all callbacks
- **FIX #18**: PayPal — full integration (was completely missing)

## Integration with server.ts

Add these routes to `server.ts`:
```typescript
import paymentRoutes from './routes/payment';
app.use('/api/payment', paymentRoutes);
```

The provider-specific routes (`/stripe`, `/paypal`, `/jazzcash`, `/easypaisa`)
are already registered in Stage 3's `server.ts`.
