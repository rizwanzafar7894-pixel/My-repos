'use client';

import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import type { UsageLimits } from '@/hooks/useSubscription';
import { MessageSquare, Image, Code2, Music, Mic, Key, BarChart2 } from 'lucide-react';

const FEATURE_META: Record<string, { label: string; icon: React.ElementType; color: string }> = {
  images: { label: 'Images',      icon: Image,        color: 'text-violet-400' },
  code:   { label: 'Code runs',   icon: Code2,        color: 'text-amber-400'  },
  music:  { label: 'Music',       icon: Music,        color: 'text-pink-400'   },
  stt:    { label: 'Voice (STT)', icon: Mic,          color: 'text-emerald-400' },
  api:    { label: 'API calls',   icon: Key,          color: 'text-cyan-400'   },
};

interface Props {
  data: UsageLimits;
}

export default function UsageCard({ data }: Props) {
  const { tier, limits, usage } = data;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold">Daily Usage</h3>
        <Badge variant="secondary" className="capitalize text-[10px]">{tier} plan</Badge>
      </div>

      <div className="space-y-3">
        {Object.entries(FEATURE_META).map(([key, meta]) => {
          const used    = usage[key]  ?? 0;
          const limit   = limits[key] ?? 0;
          const pct     = limit === -1 ? 0 : limit === 0 ? 100 : Math.min((used / limit) * 100, 100);
          const isUnlim = limit === -1;
          const noAccess = limit === 0;

          return (
            <div key={key}>
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5">
                  <meta.icon className={cn('h-3.5 w-3.5', meta.color)} />
                  <span className="text-xs text-muted-foreground">{meta.label}</span>
                </div>
                <span className={cn('text-xs font-medium', noAccess ? 'text-muted-foreground/50' : '')}>
                  {noAccess ? 'Upgrade required' : isUnlim ? `${used} / ∞` : `${used} / ${limit}`}
                </span>
              </div>
              {!isUnlim && !noAccess && (
                <Progress
                  value={pct}
                  className={cn('h-1.5', pct >= 90 ? '[&>div]:bg-destructive' : pct >= 70 ? '[&>div]:bg-amber-400' : '')}
                />
              )}
              {noAccess && <div className="h-1.5 bg-muted rounded-full opacity-30" />}
              {isUnlim  && <div className="h-1.5 bg-primary/20 rounded-full" />}
            </div>
          );
        })}
      </div>

      <p className="text-[10px] text-muted-foreground text-center">
        Resets daily at 00:00 UTC · Chat is always unlimited
      </p>
    </div>
  );
}
