'use client';

import { useEffect, useRef, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { apiClient } from '@/lib/api';
import { PAYPAL_CONFIG } from '@/constants';
import { toast } from 'sonner';
import type { UserTier } from '@/types';

interface Props {
  tier:      Exclude<UserTier, 'free'>;
  period:    'monthly' | 'yearly';
  onSuccess: (subscriptionId: string) => void;
  onError?:  (err: Error) => void;
}

declare global {
  interface Window {
    paypal?: {
      Buttons: (opts: Record<string, unknown>) => { render: (el: HTMLElement) => void; close: () => void };
    };
  }
}

export default function PayPalButton({ tier, period, onSuccess, onError }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [ready, setReady]   = useState(false);
  const [loading, setLoading] = useState(true);
  const [planId, setPlanId]   = useState<string | null>(null);
  const btnsRef = useRef<{ close: () => void } | null>(null);

  // Load PayPal SDK script
  useEffect(() => {
    if (!PAYPAL_CONFIG.clientId) return;

    const scriptId = 'paypal-sdk';
    if (document.getElementById(scriptId)) { setReady(true); return; }

    const script     = document.createElement('script');
    script.id        = scriptId;
    script.src       = `https://www.paypal.com/sdk/js?client-id=${PAYPAL_CONFIG.clientId}&vault=true&intent=subscription`;
    script.async     = true;
    script.onload    = () => setReady(true);
    script.onerror   = () => toast.error('Failed to load PayPal SDK');
    document.head.appendChild(script);

    return () => {
      btnsRef.current?.close();
    };
  }, []);

  // Fetch plan ID
  useEffect(() => {
    (async () => {
      try {
        const res = await apiClient.paypalGetPlanId(tier, period) as any;
        setPlanId(res?.data?.planId || res?.planId || null);
      } catch {
        toast.error('PayPal plan not configured for this tier');
      } finally {
        setLoading(false);
      }
    })();
  }, [tier, period]);

  // Render PayPal button
  useEffect(() => {
    if (!ready || !planId || !containerRef.current || !window.paypal) return;

    btnsRef.current?.close();

    const btns = window.paypal.Buttons({
      style: {
        shape: 'rect', color: 'gold', layout: 'vertical',
        label: 'subscribe', height: 40,
      },
      createSubscription: (_data: unknown, actions: any) => {
        return actions.subscription.create({ plan_id: planId });
      },
      onApprove: async (data: any) => {
        try {
          await apiClient.paypalActivateSubscription(data.subscriptionID, tier);
          onSuccess(data.subscriptionID);
          toast.success('PayPal subscription activated!');
        } catch (e: any) {
          const err = new Error(e?.message || 'Activation failed');
          onError?.(err);
          toast.error(err.message);
        }
      },
      onError: (err: any) => {
        const error = new Error(String(err));
        onError?.(error);
        toast.error('PayPal payment failed. Please try again.');
      },
      onCancel: () => {
        toast.info('PayPal payment cancelled');
      },
    });

    btns.render(containerRef.current);
    btnsRef.current = btns;
  }, [ready, planId, tier, period, onSuccess, onError]);

  if (!PAYPAL_CONFIG.clientId) {
    return (
      <div className="rounded-lg border border-border bg-muted/30 px-4 py-3 text-xs text-muted-foreground text-center">
        PayPal not configured. Set <code>NEXT_PUBLIC_PAYPAL_CLIENT_ID</code>.
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-10">
        <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!planId) {
    return (
      <div className="rounded-lg border border-border bg-muted/30 px-4 py-3 text-xs text-muted-foreground text-center">
        PayPal plan not configured for {tier} ({period}).
      </div>
    );
  }

  return <div ref={containerRef} className="w-full" />;
}
