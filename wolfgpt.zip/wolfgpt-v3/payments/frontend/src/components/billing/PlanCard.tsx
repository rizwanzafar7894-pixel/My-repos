'use client';

import { motion } from 'framer-motion';
import { Check, Crown, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import type { UserTier } from '@/types';

interface PlanCardProps {
  tier:     string;
  name:     string;
  popular?: boolean;
  price:    number;
  period:   'monthly' | 'yearly';
  currency: 'USD' | 'PKR';
  features: string[];
  current:  boolean;
  loading:  boolean;
  onSelect: () => void;
}

const TIER_RANK: Record<string, number> = { free: 0, basic: 1, premium: 2, pro: 3 };

export default function PlanCard({
  tier, name, popular, price, period, currency, features,
  current, loading, onSelect,
}: PlanCardProps) {
  const isPro     = tier === 'pro';
  const isFree    = tier === 'free';
  const currencySymbol = currency === 'USD' ? '$' : 'Rs.';

  return (
    <motion.div whileHover={!current ? { y: -4 } : {}}>
      <div className={cn(
        'relative flex flex-col h-full rounded-xl border p-5 transition-all',
        isPro    ? 'border-primary/50 shadow-glow-sm bg-primary/3' : 'border-border bg-card',
        popular  ? 'border-primary/30' : '',
        current  ? 'border-primary/40 bg-primary/5' : '',
      )}>
        {popular && (
          <div className="absolute -top-3 left-1/2 -translate-x-1/2">
            <Badge className="gap-1 text-[10px] px-2.5">
              <Crown className="h-2.5 w-2.5" /> Most Popular
            </Badge>
          </div>
        )}

        {current && (
          <Badge variant="success" className="absolute top-3 right-3 text-[10px]">
            Current
          </Badge>
        )}

        <div className="mb-4">
          <h3 className="font-bold text-base text-foreground">{name}</h3>
          <div className="flex items-baseline gap-1 mt-2">
            <span className="text-3xl font-bold">
              {price === 0 ? 'Free' : `${currencySymbol}${price.toLocaleString()}`}
            </span>
            {price > 0 && (
              <span className="text-xs text-muted-foreground">
                /{period === 'yearly' ? 'yr' : 'mo'}
              </span>
            )}
          </div>
          {period === 'yearly' && price > 0 && currency === 'USD' && (
            <p className="text-[10px] text-emerald-500 mt-0.5">
              Save {Math.round(100 - (price / ((price / 12) * 12 * 1.17)) * 100)}% vs monthly
            </p>
          )}
        </div>

        <ul className="space-y-2 mb-5 flex-1">
          {features.map(f => (
            <li key={f} className="flex items-start gap-2 text-xs text-muted-foreground">
              <Check className="h-3.5 w-3.5 text-primary shrink-0 mt-0.5" />
              {f}
            </li>
          ))}
        </ul>

        {current ? (
          <Button variant="outline" size="sm" disabled className="w-full text-xs">
            Current Plan
          </Button>
        ) : isFree ? (
          <Button variant="ghost" size="sm" disabled className="w-full text-xs text-muted-foreground">
            Always Free
          </Button>
        ) : (
          <Button
            size="sm"
            variant={isPro || popular ? 'default' : 'outline'}
            className={cn('w-full text-xs', (isPro || popular) && 'shadow-glow-sm')}
            onClick={onSelect}
            disabled={loading}
          >
            {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Upgrade'}
          </Button>
        )}
      </div>
    </motion.div>
  );
}
