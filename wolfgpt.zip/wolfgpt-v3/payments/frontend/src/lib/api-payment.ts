/**
 * Payment-specific API helpers — thin wrappers around apiClient.
 * Imported by billing components that need typed responses.
 */

import { apiClient } from './api';
import type { UserTier } from '@/types';

export type BillingPeriod = 'monthly' | 'yearly';

export const paymentApi = {

  // Plans
  getPlans:       ()                             => apiClient.get('/api/payment/plans'),
  getSubscription:()                             => apiClient.get('/api/payment/subscription'),
  getHistory:     (limit = 20)                   => apiClient.get('/api/payment/history', { limit }),
  getUsageLimits: ()                             => apiClient.get('/api/payment/usage-limits'),
  cancelSub:      ()                             => apiClient.post('/api/payment/cancel'),

  // Stripe
  stripeCheckout: (tier: string, period: BillingPeriod = 'yearly') =>
    apiClient.post('/api/payment/stripe/checkout', { tier, period }),
  stripePortal:   () => apiClient.post('/api/payment/stripe/portal'),

  // PayPal
  paypalPlanId:   (tier: string, period: BillingPeriod = 'monthly') =>
    apiClient.get('/api/payment/paypal/plan-id', { tier, period }),
  paypalActivate: (subscriptionId: string, tier: string) =>
    apiClient.post('/api/payment/paypal/activate', { subscriptionId, tier }),

  // JazzCash
  jazzCashInit:   (tier: string) =>
    apiClient.post('/api/payment/jazzcash/initiate', { tier, period: 'yearly' }),

  // EasyPaisa
  easyPaisaInit:  (tier: string, mobileNumber: string) =>
    apiClient.post('/api/payment/easypaisa/initiate', { tier, mobileNumber, period: 'yearly' }),
  easyPaisaStatus:(orderRef: string) =>
    apiClient.get(`/api/payment/easypaisa/status/${orderRef}`),
};
