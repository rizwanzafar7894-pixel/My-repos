'use client';

import { useState, useEffect, useCallback } from 'react';
import { apiClient } from '@/lib/api';
import { useAuthStore } from '@/store/auth';
import type { UserTier } from '@/types';

export interface SubscriptionData {
  tier:         UserTier;
  subscription: {
    status:        'active' | 'cancelled' | 'paused' | 'past_due' | null;
    provider?:     string;
    planId?:       string;
    expiresAt?:    string;
    providerSubId?: string;
    txnRef?:       string;
  } | null;
}

export interface UsageLimits {
  tier:   UserTier;
  limits: Record<string, number>;
  usage:  Record<string, number>;
}

export interface Plan {
  tier:     string;
  name:     string;
  popular?: boolean;
  pricing:  { USD: { monthly: number; yearly: number }; PKR: { yearly: number } };
  features: string[];
}

export function useSubscription() {
  const { user }  = useAuthStore();
  const [sub, setSub]     = useState<SubscriptionData | null>(null);
  const [plans, setPlans] = useState<Plan[]>([]);
  const [usage, setUsage] = useState<UsageLimits | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    setError(null);
    try {
      const [subRes, plansRes, usageRes] = await Promise.all([
        apiClient.get('/api/payment/subscription'),
        apiClient.get('/api/payment/plans'),
        apiClient.get('/api/payment/usage-limits'),
      ]);
      setSub(subRes);
      setPlans((plansRes as any)?.plans || []);
      setUsage(usageRes);
    } catch (e: any) {
      setError(e?.response?.data?.error?.message || 'Failed to load billing info');
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => { load(); }, [load]);

  const cancel = async (): Promise<boolean> => {
    try {
      await apiClient.post('/api/payment/cancel');
      await load();
      return true;
    } catch {
      return false;
    }
  };

  return { sub, plans, usage, loading, error, refresh: load, cancel };
}
