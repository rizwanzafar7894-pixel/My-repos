'use client';

import { useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import {
  CreditCard, Zap, CheckCircle, AlertCircle, ExternalLink,
  Loader2, ChevronDown, ChevronUp, RotateCcw
} from 'lucide-react';
import { Button }           from '@/components/ui/button';
import { Badge }            from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input }            from '@/components/ui/input';
import { Label }            from '@/components/ui/label';
import { Separator }        from '@/components/ui/separator';
import PlanCard             from '@/components/billing/PlanCard';
import PayPalButton         from '@/components/billing/PayPalButton';
import UsageCard            from '@/components/billing/UsageCard';
import LoadingSpinner       from '@/components/shared/LoadingSpinner';
import { useSubscription }  from '@/hooks/useSubscription';
import { useAuthStore }     from '@/store/auth';
import { apiClient }        from '@/lib/api';
import { PRICING_PKR }      from '@/constants';
import type { UserTier }    from '@/types';
import { toast }            from 'sonner';

const TIER_RANK: Record<string, number> = { free: 0, basic: 1, premium: 2, pro: 3 };

type BillingPeriod = 'monthly' | 'yearly';
type PakProvider   = 'jazzcash' | 'easypaisa';

export default function BillingPage() {
  const searchParams = useSearchParams();
  const { user, refreshUser } = useAuthStore();
  const { sub, plans, usage, loading, refresh } = useSubscription();

  const [period, setPeriod]           = useState<BillingPeriod>('yearly');
  const [activeProvider, setActiveProvider] = useState('stripe');
  const [loadingTier, setLoadingTier] = useState<string | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  const [history, setHistory]         = useState<any[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [mobileNumber, setMobileNumber]     = useState('');
  const [easyPaisaTier, setEasyPaisaTier]   = useState<string>('basic');

  const currentTier = user?.tier || 'free';
  const currentRank = TIER_RANK[currentTier];

  // Handle success/error query params from payment redirects
  useEffect(() => {
    const success   = searchParams.get('success');
    const error     = searchParams.get('error');
    const cancelled = searchParams.get('cancelled');

    if (success === 'true') {
      toast.success('Payment successful! Your plan has been upgraded.');
      refreshUser();
      refresh();
    } else if (error) {
      toast.error('Payment failed. Please try again.');
    } else if (cancelled === 'true') {
      toast.info('Payment cancelled.');
    }
  }, [searchParams]);

  const loadHistory = async () => {
    setHistoryLoading(true);
    try {
      const res = await apiClient.get('/api/payment/history') as any;
      setHistory(res || []);
    } catch { toast.error('Failed to load payment history'); }
    finally   { setHistoryLoading(false); }
  };

  const handleStripeCheckout = async (tier: string) => {
    setLoadingTier(tier);
    try {
      const res = await apiClient.stripeCheckout(tier, period) as any;
      const url = res?.data?.url || res?.url;
      if (url) window.location.href = url;
      else toast.error('Failed to start checkout');
    } catch (e: any) {
      toast.error(e?.response?.data?.error?.message || 'Stripe checkout failed');
    } finally { setLoadingTier(null); }
  };

  const handleManageStripe = async () => {
    setLoadingTier('portal');
    try {
      const res = await apiClient.stripeBillingPortal() as any;
      const url = res?.data?.url || res?.url;
      if (url) window.location.href = url;
    } catch { toast.error('Failed to open billing portal'); }
    finally   { setLoadingTier(null); }
  };

  const handleJazzCash = async (tier: string) => {
    setLoadingTier(`jc-${tier}`);
    try {
      const res  = await apiClient.jazzCashInitiate(tier, 'yearly') as any;
      const data = res?.data;
      if (!data?.paymentUrl) { toast.error('JazzCash initiation failed'); return; }
      const form = document.createElement('form');
      form.method = 'POST'; form.action = data.paymentUrl;
      Object.entries(data.params || {}).forEach(([k, v]) => {
        const i = document.createElement('input');
        i.type = 'hidden'; i.name = k; i.value = v as string;
        form.appendChild(i);
      });
      document.body.appendChild(form); form.submit();
    } catch { toast.error('JazzCash checkout failed'); }
    finally   { setLoadingTier(null); }
  };

  const handleEasyPaisa = async (tier: string) => {
    if (!mobileNumber.match(/^03\d{9}$/)) {
      toast.error('Enter a valid Pakistani mobile number (03XXXXXXXXX)');
      return;
    }
    setLoadingTier(`ep-${tier}`);
    try {
      await apiClient.easyPaisaInitiate(tier, mobileNumber, 'yearly');
      toast.success('EasyPaisa request sent. Check your phone for payment prompt.');
    } catch (e: any) {
      toast.error(e?.response?.data?.error?.message || 'EasyPaisa checkout failed');
    } finally { setLoadingTier(null); }
  };

  const handlePayPalSuccess = async () => {
    await refreshUser();
    await refresh();
    toast.success('PayPal subscription activated!');
  };

  if (loading) return <div className="flex items-center justify-center h-full"><LoadingSpinner text="Loading billing…" /></div>;

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-7">

      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-xl font-bold flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-primary" /> Billing & Plans
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Current plan: <span className="font-semibold capitalize text-foreground">{currentTier}</span>
            {sub?.subscription?.status === 'active' && <Badge variant="success" className="ml-2 text-[10px]">Active</Badge>}
            {sub?.subscription?.status === 'past_due' && <Badge variant="destructive" className="ml-2 text-[10px]">Past Due</Badge>}
            {sub?.subscription?.expiresAt && (
              <span className="text-xs text-muted-foreground ml-2">
                · Expires {new Date(sub.subscription.expiresAt).toLocaleDateString()}
              </span>
            )}
          </p>
        </div>
        <div className="flex gap-2">
          {currentTier !== 'free' && (
            <Button variant="outline" size="sm" onClick={handleManageStripe} disabled={loadingTier === 'portal'}>
              {loadingTier === 'portal' ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ExternalLink className="h-3.5 w-3.5" />}
              Manage
            </Button>
          )}
          <Button variant="ghost" size="icon" onClick={refresh}><RotateCcw className="h-4 w-4" /></Button>
        </div>
      </div>

      {/* Usage card */}
      {usage && (
        <Card className="p-5">
          <UsageCard data={usage} />
        </Card>
      )}

      {/* Period toggle */}
      <div className="flex items-center justify-center gap-3">
        <button onClick={() => setPeriod('monthly')} className={`text-sm font-medium transition-colors ${period === 'monthly' ? 'text-foreground' : 'text-muted-foreground'}`}>Monthly</button>
        <button
          onClick={() => setPeriod(p => p === 'monthly' ? 'yearly' : 'monthly')}
          className={`relative w-11 h-6 rounded-full transition-colors ${period === 'yearly' ? 'bg-primary' : 'bg-muted'}`}
        >
          <span className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${period === 'yearly' ? 'left-6' : 'left-1'}`} />
        </button>
        <button onClick={() => setPeriod('yearly')} className={`text-sm font-medium transition-colors ${period === 'yearly' ? 'text-foreground' : 'text-muted-foreground'}`}>
          Yearly <Badge variant="success" className="ml-1 text-[10px]">Save ~17%</Badge>
        </button>
      </div>

      {/* Plan cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {plans.map(plan => {
          const price = period === 'yearly' ? plan.pricing.USD.yearly : plan.pricing.USD.monthly;
          return (
            <PlanCard
              key={plan.tier}
              tier={plan.tier}
              name={plan.name}
              popular={plan.popular}
              price={price}
              period={period}
              currency="USD"
              features={plan.features}
              current={plan.tier === currentTier}
              loading={loadingTier === plan.tier}
              onSelect={() => setActiveProvider('stripe')}
            />
          );
        })}
      </div>

      {/* Payment method selector */}
      {currentTier === 'free' || TIER_RANK[currentTier] < 3 ? (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Zap className="h-4 w-4 text-amber-400" /> Choose Payment Method
            </CardTitle>
            <CardDescription>All plans come with a 14-day money-back guarantee.</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={activeProvider} onValueChange={setActiveProvider}>
              <TabsList className="mb-5 w-full sm:w-auto">
                <TabsTrigger value="stripe">💳 Card (Stripe)</TabsTrigger>
                <TabsTrigger value="paypal">🅿️ PayPal</TabsTrigger>
                <TabsTrigger value="jazzcash">📱 JazzCash</TabsTrigger>
                <TabsTrigger value="easypaisa">📲 EasyPaisa</TabsTrigger>
              </TabsList>

              {/* Stripe */}
              <TabsContent value="stripe">
                <p className="text-sm text-muted-foreground mb-4">Pay securely with any credit or debit card via Stripe.</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {(['basic','premium','pro'] as const).filter(t => TIER_RANK[t] > currentRank).map(tier => {
                    const plan   = plans.find(p => p.tier === tier);
                    const price  = plan ? (period === 'yearly' ? plan.pricing.USD.yearly : plan.pricing.USD.monthly) : 0;
                    return (
                      <Card key={tier} className="p-4">
                        <p className="font-semibold capitalize mb-1">{tier}</p>
                        <p className="text-2xl font-bold">${price}</p>
                        <p className="text-[10px] text-muted-foreground mb-3">/{period === 'yearly' ? 'year' : 'month'}</p>
                        <Button size="sm" className="w-full text-xs" onClick={() => handleStripeCheckout(tier)} disabled={!!loadingTier}>
                          {loadingTier === tier ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Pay with Card'}
                        </Button>
                      </Card>
                    );
                  })}
                </div>
              </TabsContent>

              {/* PayPal */}
              <TabsContent value="paypal">
                <p className="text-sm text-muted-foreground mb-4">Subscribe using your PayPal account — monthly or yearly.</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {(['basic','premium','pro'] as const).filter(t => TIER_RANK[t] > currentRank).map(tier => (
                    <Card key={tier} className="p-4">
                      <p className="font-semibold capitalize mb-3">{tier}</p>
                      <PayPalButton
                        tier={tier}
                        period={period}
                        onSuccess={handlePayPalSuccess}
                        onError={err => toast.error(err.message)}
                      />
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* JazzCash */}
              <TabsContent value="jazzcash">
                <p className="text-sm text-muted-foreground mb-4">Pay via JazzCash mobile wallet (Pakistan). Yearly plans only.</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {(['basic','premium','pro'] as const).filter(t => TIER_RANK[t] > currentRank).map(tier => (
                    <Card key={tier} className="p-4">
                      <p className="font-semibold capitalize mb-1">{tier}</p>
                      <p className="text-2xl font-bold">Rs.{PRICING_PKR[tier as keyof typeof PRICING_PKR]?.yearly?.toLocaleString()}</p>
                      <p className="text-[10px] text-muted-foreground mb-3">/year</p>
                      <Button size="sm" variant="outline" className="w-full text-xs" onClick={() => handleJazzCash(tier)} disabled={!!loadingTier}>
                        {loadingTier === `jc-${tier}` ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Pay with JazzCash'}
                      </Button>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              {/* EasyPaisa */}
              <TabsContent value="easypaisa">
                <p className="text-sm text-muted-foreground mb-4">Pay via EasyPaisa mobile account (Pakistan). Yearly plans only.</p>
                <div className="mb-4 max-w-xs">
                  <Label htmlFor="mobile" className="text-sm mb-1.5 block">Your mobile number</Label>
                  <Input id="mobile" placeholder="03XXXXXXXXX" value={mobileNumber} onChange={e => setMobileNumber(e.target.value)} className="text-sm" />
                  <p className="text-[10px] text-muted-foreground mt-1">Must be registered with EasyPaisa</p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {(['basic','premium','pro'] as const).filter(t => TIER_RANK[t] > currentRank).map(tier => (
                    <Card key={tier} className="p-4">
                      <p className="font-semibold capitalize mb-1">{tier}</p>
                      <p className="text-2xl font-bold">Rs.{PRICING_PKR[tier as keyof typeof PRICING_PKR]?.yearly?.toLocaleString()}</p>
                      <p className="text-[10px] text-muted-foreground mb-3">/year</p>
                      <Button size="sm" variant="outline" className="w-full text-xs" onClick={() => handleEasyPaisa(tier)} disabled={!!loadingTier}>
                        {loadingTier === `ep-${tier}` ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Pay with EasyPaisa'}
                      </Button>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      ) : (
        <Card className="border-primary/20 bg-primary/3">
          <CardContent className="py-5 flex items-center gap-3">
            <CheckCircle className="h-5 w-5 text-primary shrink-0" />
            <div>
              <p className="text-sm font-semibold">You're on the Pro plan — all features unlocked!</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                Provider: <span className="capitalize">{sub?.subscription?.provider}</span>
                {sub?.subscription?.expiresAt && ` · Renews ${new Date(sub.subscription.expiresAt).toLocaleDateString()}`}
              </p>
            </div>
            <Button variant="outline" size="sm" className="ml-auto shrink-0" onClick={handleManageStripe}>
              Manage
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Payment history */}
      <div>
        <button
          onClick={() => { setShowHistory(!showHistory); if (!showHistory && history.length === 0) loadHistory(); }}
          className="flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
        >
          Payment History
          {showHistory ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </button>

        <AnimatePresence>
          {showHistory && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="mt-3"
            >
              {historyLoading ? (
                <LoadingSpinner text="Loading history…" className="py-6" />
              ) : history.length === 0 ? (
                <p className="text-sm text-muted-foreground py-4 text-center">No payment history yet.</p>
              ) : (
                <div className="space-y-2">
                  {history.map(h => (
                    <div key={h.id} className="flex items-center gap-3 p-3 rounded-lg border border-border text-sm">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-medium capitalize">{h.tier} plan</span>
                          <Badge variant={h.status === 'completed' ? 'success' : h.status === 'failed' ? 'destructive' : 'secondary'} className="text-[10px]">
                            {h.status}
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground capitalize">
                          {h.provider} · {h.currency} · {h.period}
                        </p>
                      </div>
                      <span className="text-sm font-semibold shrink-0">
                        {h.currency === 'PKR' ? 'Rs.' : '$'}{Number(h.amount).toLocaleString()}
                      </span>
                      <span className="text-xs text-muted-foreground shrink-0">
                        {h.createdAt?.seconds ? new Date(h.createdAt.seconds * 1000).toLocaleDateString() : '—'}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
