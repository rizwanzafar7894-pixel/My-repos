/**
 * Payment Controller — shared utilities for all payment providers.
 * Handles subscription activation, plan enforcement, and billing history.
 */

import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
import { asyncHandler, ApiError } from '../middleware/errorHandler';
import { db, FieldValue } from '../config/firebase';
import logger from '../utils/logger';

const VALID_TIERS = ['basic', 'premium', 'pro'] as const;
type PayableTier = typeof VALID_TIERS[number];

function assertTier(tier: string): asserts tier is PayableTier {
  if (!VALID_TIERS.includes(tier as PayableTier)) {
    throw ApiError.badRequest(`Invalid tier "${tier}". Must be one of: ${VALID_TIERS.join(', ')}`, 'INVALID_PLAN');
  }
}

export const paymentController = {

  // GET /api/payment/subscription — current subscription status
  getSubscription: asyncHandler(async (req: AuthRequest, res: Response) => {
    const snap = await db.collection('users').doc(req.user!.uid).get();
    if (!snap.exists) throw ApiError.notFound('User not found');
    const d = snap.data()!;
    res.json({
      success: true,
      data: {
        tier:         d.tier || 'free',
        subscription: d.subscription || null,
      },
    });
  }),

  // GET /api/payment/history — payment transaction history
  getHistory: asyncHandler(async (req: AuthRequest, res: Response) => {
    const limit = Math.min(parseInt(req.query.limit as string) || 20, 100);
    const snap  = await db.collection('pending_payments')
      .where('userId', '==', req.user!.uid)
      .orderBy('createdAt', 'desc')
      .limit(limit)
      .get();

    const history = snap.docs.map(d => {
      const data = d.data();
      return {
        id:           d.id,
        provider:     data.provider,
        tier:         data.tier,
        period:       data.period,
        amount:       data.amount,
        currency:     data.currency || (data.provider === 'stripe' || data.provider === 'paypal' ? 'USD' : 'PKR'),
        status:       data.status,
        createdAt:    data.createdAt,
        updatedAt:    data.updatedAt,
      };
    });

    res.json({ success: true, data: history, count: history.length });
  }),

  // POST /api/payment/cancel — downgrade to free
  cancelSubscription: asyncHandler(async (req: AuthRequest, res: Response) => {
    const userId = req.user!.uid;
    const snap   = await db.collection('users').doc(userId).get();
    if (!snap.exists) throw ApiError.notFound('User not found');

    const sub = snap.data()!.subscription;
    if (!sub || sub.status !== 'active') {
      throw ApiError.badRequest('No active subscription to cancel', 'NO_ACTIVE_SUBSCRIPTION');
    }

    // For Stripe: should also cancel via Stripe API in production
    // (handled by the billing portal redirect in stripe.ts)
    await db.collection('users').doc(userId).update({
      tier:                      'free',
      'subscription.status':     'cancelled',
      'subscription.cancelledAt': new Date(),
      'subscription.updatedAt':  new Date(),
      updatedAt:                 new Date(),
    });

    logger.info(`User ${userId} cancelled subscription (provider: ${sub.provider})`);
    res.json({ success: true, data: { cancelled: true, tier: 'free' } });
  }),

  // GET /api/payment/plans — return all plan details with pricing
  getPlans: asyncHandler(async (_req: AuthRequest, res: Response) => {
    res.json({
      success: true,
      data: {
        plans: [
          {
            tier: 'free',
            name: 'Free',
            pricing: { USD: { monthly: 0, yearly: 0 }, PKR: { yearly: 0 } },
            features: ['Unlimited chat', '5 images/day', 'Qwen 2.5 7B + Llama 3.2 3B', 'Voice AI (60 min/mo)', 'Code execution'],
          },
          {
            tier: 'basic',
            name: 'Basic',
            pricing: { USD: { monthly: 9.99, yearly: 99 }, PKR: { yearly: 27800 } },
            features: ['25 images/day', '5 chat models', '100 voice min/mo', 'API access (1 key)', 'Analytics'],
          },
          {
            tier: 'premium',
            name: 'Premium',
            popular: true,
            pricing: { USD: { monthly: 19.99, yearly: 199 }, PKR: { yearly: 55600 } },
            features: ['100 images/day', '10 chat models', '500 voice min/mo', 'Music generation', '5 API keys', 'Priority queue'],
          },
          {
            tier: 'pro',
            name: 'Pro',
            pricing: { USD: { monthly: 39.99, yearly: 399 }, PKR: { yearly: 111200 } },
            features: ['Unlimited images', 'All 14 models', 'Unlimited voice', 'Unlimited API', 'Dedicated support', 'Beta features'],
          },
        ],
        providers: {
          stripe:    { available: !!process.env.STRIPE_SECRET_KEY,       currencies: ['USD'], periods: ['monthly', 'yearly'] },
          paypal:    { available: !!process.env.PAYPAL_CLIENT_ID,        currencies: ['USD'], periods: ['monthly', 'yearly'] },
          jazzcash:  { available: !!process.env.JAZZCASH_MERCHANT_ID,    currencies: ['PKR'], periods: ['yearly'] },
          easypaisa: { available: !!process.env.EASYPAISA_STORE_ID,      currencies: ['PKR'], periods: ['yearly'] },
        },
      },
    });
  }),

  // GET /api/payment/usage-limits — return usage limits for current tier
  getUsageLimits: asyncHandler(async (req: AuthRequest, res: Response) => {
    const snap = await db.collection('users').doc(req.user!.uid).get();
    if (!snap.exists) throw ApiError.notFound('User not found');

    const tier  = snap.data()!.tier || 'free';
    const usage = snap.data()!.usage || {};

    const LIMITS: Record<string, Record<string, number>> = {
      free:    { images: 5,   code: 50,  music: 3,  api: 0    },
      basic:   { images: 25,  code: 200, music: 10, api: 1000 },
      premium: { images: 100, code: 500, music: 50, api: 50000 },
      pro:     { images: -1,  code: -1,  music: -1, api: -1   },
    };

    const limits = LIMITS[tier] || LIMITS.free;

    res.json({
      success: true,
      data: {
        tier,
        limits,
        usage: {
          images:  usage.images?.used  || 0,
          code:    usage.code?.used    || 0,
          music:   usage.music?.used   || 0,
          api:     usage.api?.used     || 0,
          stt:     usage.voice?.sttUsed || 0,
          tts:     usage.voice?.ttsUsed || 0,
        },
      },
    });
  }),
};
