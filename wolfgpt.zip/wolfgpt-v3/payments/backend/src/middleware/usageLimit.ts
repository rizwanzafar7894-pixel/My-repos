/**
 * Usage limit middleware — checks per-feature daily limits by tier.
 * Applied on feature routes that have hard daily caps (images, code, music).
 * Chat and voice are unlimited on all tiers (only API-level rate limiting).
 */

import { Response, NextFunction } from 'express';
import { AuthRequest } from './auth';
import { db } from '../config/firebase';
import logger from '../utils/logger';

// -1 = unlimited
const DAILY_LIMITS: Record<string, Record<string, number>> = {
  free:    { images: 5,   code: 50,  music: 3   },
  basic:   { images: 25,  code: 200, music: 10  },
  premium: { images: 100, code: 500, music: 50  },
  pro:     { images: -1,  code: -1,  music: -1  },
};

const USAGE_FIELD: Record<string, string> = {
  images: 'usage.images.used',
  code:   'usage.code.used',
  music:  'usage.music.used',
};

export const checkUsageLimit = (feature: 'images' | 'code' | 'music') =>
  async (req: AuthRequest, res: Response, next: NextFunction): Promise<void> => {
    try {
      const tier  = req.user?.tier || 'free';
      const limit = (DAILY_LIMITS[tier] || DAILY_LIMITS.free)[feature];

      if (limit === -1) return next(); // pro = unlimited

      const uid    = req.user!.uid;
      const snap   = await db.collection('users').doc(uid).get();
      if (!snap.exists) return next();

      const used = (snap.data()![USAGE_FIELD[feature].split('.')[1]] as any)?.used ?? 0;

      if (used >= limit) {
        res.status(429).json({
          success: false,
          error: {
            code:       'USAGE_LIMIT_EXCEEDED',
            message:    `You've reached your daily ${feature} limit (${limit}/${limit}). Resets at midnight UTC.`,
            feature,
            used,
            limit,
            tier,
            upgradeUrl: '/dashboard/billing',
          },
        });
        return;
      }

      next();
    } catch (err) {
      logger.warn('Usage limit check failed (allowing request):', err);
      next();
    }
  };
