/**
 * Shared payment utilities used across Stripe, PayPal, JazzCash, EasyPaisa.
 */

import crypto from 'node:crypto';
import { db } from '../config/firebase';
import logger  from './logger';

export type PaymentProvider = 'stripe' | 'paypal' | 'jazzcash' | 'easypaisa';
export type SubscriptionStatus = 'active' | 'cancelled' | 'paused' | 'past_due';
export type UserTier = 'free' | 'basic' | 'premium' | 'pro';

export interface ActivateSubscriptionOptions {
  userId:         string;
  tier:           UserTier;
  provider:       PaymentProvider;
  providerSubId?: string;          // Stripe subId or PayPal subId
  txnRef?:        string;          // JazzCash / EasyPaisa txn ref
  expiresAt?:     Date;            // for annual plans without auto-renewal
}

/**
 * Activate a subscription in Firestore — single source of truth for all providers.
 */
export async function activateSubscription(opts: ActivateSubscriptionOptions): Promise<void> {
  const { userId, tier, provider, providerSubId, txnRef, expiresAt } = opts;

  const update: Record<string, unknown> = {
    tier,
    'subscription.status':    'active',
    'subscription.provider':   provider,
    'subscription.planId':     tier,
    'subscription.updatedAt':  new Date(),
    updatedAt:                 new Date(),
  };

  if (providerSubId) update['subscription.providerSubId'] = providerSubId;
  if (txnRef)        update['subscription.txnRef']        = txnRef;
  if (expiresAt)     update['subscription.expiresAt']     = expiresAt;

  await db.collection('users').doc(userId).update(update);
  logger.info(`✅ Subscription activated: user=${userId} tier=${tier} provider=${provider}`);
}

/**
 * Deactivate a subscription (downgrade to free).
 */
export async function deactivateSubscription(
  userId: string,
  provider: PaymentProvider,
  status: SubscriptionStatus = 'cancelled'
): Promise<void> {
  await db.collection('users').doc(userId).update({
    tier:                      'free',
    'subscription.status':     status,
    'subscription.updatedAt':  new Date(),
    updatedAt:                 new Date(),
  });
  logger.info(`Subscription ${status}: user=${userId} provider=${provider}`);
}

/**
 * Store a pending payment record.
 */
export async function storePendingPayment(data: {
  txnRef:    string;
  userId:    string;
  tier:      UserTier;
  period:    string;
  amount:    number;
  currency:  string;
  provider:  PaymentProvider;
}): Promise<void> {
  await db.collection('pending_payments').doc(data.txnRef).set({
    ...data,
    status:    'pending',
    createdAt: new Date(),
    updatedAt: new Date(),
  });
}

/**
 * Update a pending payment status.
 */
export async function updatePaymentStatus(
  txnRef: string,
  status: 'completed' | 'failed',
  extras?: Record<string, unknown>
): Promise<void> {
  await db.collection('pending_payments').doc(txnRef).update({
    status,
    updatedAt: new Date(),
    ...extras,
  });
}

/**
 * Generate a one-time payment reference ID.
 */
export function generateTxnRef(prefix: string, userId: string): string {
  return `${prefix}-${Date.now()}-${userId.slice(0, 6)}`;
}

/**
 * Build a redirect URL based on payment outcome.
 */
export function buildRedirectUrl(success: boolean, extra?: string): string {
  const base   = process.env.FRONTEND_URL || 'http://localhost:3000';
  const params = success
    ? 'success=true'
    : `error=payment_failed${extra ? `&reason=${encodeURIComponent(extra)}` : ''}`;
  return `${base}/dashboard/billing?${params}`;
}

/**
 * Compute yearly expiry date (one year from now).
 */
export function yearlyExpiryDate(): Date {
  const d = new Date();
  d.setFullYear(d.getFullYear() + 1);
  return d;
}

/**
 * Safe constant-time string comparison (for signature checks).
 */
export function safeCompare(a: string, b: string): boolean {
  try {
    return crypto.timingSafeEqual(Buffer.from(a), Buffer.from(b));
  } catch {
    return false;
  }
}
