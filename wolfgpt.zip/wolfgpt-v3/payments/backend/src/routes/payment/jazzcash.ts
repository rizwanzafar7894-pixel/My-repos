/**
 * JazzCash payment gateway (v3 — Pakistan).
 * FIX #1: pp_Password excluded from HMAC hash (JazzCash spec).
 * FIX #9: pp_ResponseCode included in callback hash verification.
 * Uses shared paymentUtils for consistent Firestore updates.
 */

import express from 'express';
import crypto  from 'node:crypto';
import { authMiddleware }         from '../../middleware/auth';
import { asyncHandler, ApiError } from '../../middleware/errorHandler';
import { db }                     from '../../config/firebase';
import { AuthRequest }            from '../../middleware/auth';
import {
  activateSubscription,
  storePendingPayment,
  updatePaymentStatus,
  generateTxnRef,
  buildRedirectUrl,
  yearlyExpiryDate,
}                                 from '../../utils/paymentUtils';
import logger                     from '../../utils/logger';

const router = express.Router();

const CONFIG = {
  merchantId:    process.env.JAZZCASH_MERCHANT_ID    || '',
  password:      process.env.JAZZCASH_PASSWORD        || '',
  integritySalt: process.env.JAZZCASH_INTEGRITY_SALT  || '',
  returnUrl:     process.env.JAZZCASH_RETURN_URL       || '',
  apiUrl: process.env.NODE_ENV === 'production'
    ? 'https://payments.jazzcash.com.pk/CustomerPortal/transactionmanagement/merchantform'
    : 'https://sandbox.jazzcash.com.pk/CustomerPortal/transactionmanagement/merchantform',
};

const PLAN_AMOUNTS: Record<string, number> = { basic: 27_800, premium: 55_600, pro: 111_200 };

// FIX #1: These fields are NEVER included in the hash computation
const HASH_EXCLUDED = new Set(['pp_Password', 'pp_SecureHash']);

function computeHash(params: Record<string, string>): string {
  const hashStr = Object.keys(params)
    .sort()
    .filter(k => !HASH_EXCLUDED.has(k) && params[k] !== '')
    .map(k => params[k])
    .join('&');
  return crypto
    .createHmac('sha256', CONFIG.integritySalt)
    .update(`${CONFIG.integritySalt}&${hashStr}`)
    .digest('hex')
    .toUpperCase();
}

// ── POST /api/payment/jazzcash/initiate ───────────────────────────────────
router.post('/initiate', authMiddleware, asyncHandler(async (req: AuthRequest, res) => {
  const { tier, period = 'yearly' } = req.body;
  const userId = req.user!.uid;

  if (!['basic','premium','pro'].includes(tier)) throw ApiError.badRequest('Invalid tier', 'INVALID_PLAN');
  if (period !== 'yearly') throw ApiError.badRequest('JazzCash only supports yearly billing', 'YEARLY_ONLY');
  if (!CONFIG.merchantId) throw ApiError.serviceUnavailable('JazzCash not configured');

  const amount  = PLAN_AMOUNTS[tier];
  const txnRef  = generateTxnRef('WGPT-JC', userId);
  const now     = new Date();
  const txnDate = now.toISOString().replace(/[-:T.]/g, '').slice(0, 14);
  const expiry  = new Date(now.getTime() + 30 * 60_000).toISOString().replace(/[-:T.]/g, '').slice(0, 14);

  const userDoc = await db.collection('users').doc(userId).get();

  const params: Record<string, string> = {
    pp_Version:           '1.1',
    pp_TxnType:           'MWALLET',
    pp_Language:          'EN',
    pp_MerchantID:        CONFIG.merchantId,
    pp_Password:          CONFIG.password,      // sent to JazzCash; FIX #1: excluded from hash
    pp_TxnRefNo:          txnRef,
    pp_Amount:            (amount * 100).toString(),
    pp_TxnCurrency:       'PKR',
    pp_TxnDateTime:       txnDate,
    pp_BillReference:     `wolfgpt_${tier}`,
    pp_Description:       `WolfGPT ${tier} plan (${period})`,
    pp_TxnExpiryDateTime: expiry,
    pp_ReturnURL:         CONFIG.returnUrl,
    pp_MobileNumber:      userDoc.data()?.phone || '',
    pp_CNIC:              '',
  };

  // FIX #1: computeHash automatically excludes pp_Password and pp_SecureHash
  params.pp_SecureHash = computeHash(params);

  await storePendingPayment({ txnRef, userId, tier, period, amount, currency: 'PKR', provider: 'jazzcash' });

  res.json({ success: true, data: { txnRef, amount, currency: 'PKR', paymentUrl: CONFIG.apiUrl, params } });
}));

// ── POST /api/payment/jazzcash/callback ───────────────────────────────────
router.post('/callback', asyncHandler(async (req, res) => {
  const body           = req.body as Record<string, string>;
  const txnRef         = body.pp_TxnRefNo;
  const receivedHash   = body.pp_SecureHash;
  const responseCode   = body.pp_ResponseCode;

  if (!txnRef || !receivedHash) {
    return res.status(400).json({ error: 'Missing required callback fields' });
  }

  // FIX #9: Pass the FULL body to computeHash — pp_ResponseCode is now included.
  // computeHash() internally excludes only pp_Password and pp_SecureHash via HASH_EXCLUDED.
  const expectedHash = computeHash(body);
  if (expectedHash !== receivedHash) {
    logger.warn('JazzCash: invalid hash on callback', { txnRef, expected: expectedHash, received: receivedHash });
    return res.status(400).json({ error: 'Invalid signature' });
  }

  const pending = await db.collection('pending_payments').doc(txnRef).get();
  if (!pending.exists) return res.status(404).json({ error: 'Transaction not found' });

  const { userId, tier } = pending.data()!;
  const success = responseCode === '000';

  if (success) {
    await activateSubscription({ userId, tier, provider: 'jazzcash', txnRef, expiresAt: yearlyExpiryDate() });
  }
  await updatePaymentStatus(txnRef, success ? 'completed' : 'failed', { responseCode });

  res.redirect(302, buildRedirectUrl(success));
}));

export default router;
