/**
 * EasyPaisa payment gateway (v3 — Pakistan).
 * FIX #14: Full HMAC-SHA256 webhook signature verification.
 * Uses shared paymentUtils for consistent Firestore updates.
 */

import express from 'express';
import crypto  from 'node:crypto';
import { authMiddleware }         from '../../middleware/auth';
import { asyncHandler, ApiError } from '../../middleware/errorHandler';
import { db }                     from '../../config/firebase';
import { AuthRequest }            from '../../middleware/auth';
import {
  activateSubscription,
  storePendingPayment,
  updatePaymentStatus,
  generateTxnRef,
  buildRedirectUrl,
  yearlyExpiryDate,
  safeCompare,
}                                 from '../../utils/paymentUtils';
import logger                     from '../../utils/logger';

const router = express.Router();

const CONFIG = {
  storeId:     process.env.EASYPAISA_STORE_ID    || '',
  secretKey:   process.env.EASYPAISA_SECRET_KEY  || '',
  hashKey:     process.env.EASYPAISA_HASH_KEY     || '',
  callbackUrl: process.env.EASYPAISA_CALLBACK_URL || '',
  mode:        process.env.EASYPAISA_MODE === 'live' ? 'live' : 'sandbox',
};

const PLAN_AMOUNTS: Record<string, number> = { basic: 27_800, premium: 55_600, pro: 111_200 };

// FIX #14: HMAC-SHA256 over sorted key=value pairs
function computeSignature(params: Record<string, string>): string {
  const qs = Object.keys(params)
    .filter(k => k !== 'hash')
    .sort()
    .map(k => `${k}=${params[k]}`)
    .join('&');
  return crypto.createHmac('sha256', CONFIG.hashKey).update(qs).digest('hex').toLowerCase();
}

// ── POST /api/payment/easypaisa/initiate ──────────────────────────────────
router.post('/initiate', authMiddleware, asyncHandler(async (req: AuthRequest, res) => {
  const { tier, mobileNumber, period = 'yearly' } = req.body;
  const userId = req.user!.uid;

  if (!['basic','premium','pro'].includes(tier)) throw ApiError.badRequest('Invalid tier', 'INVALID_PLAN');
  if (period !== 'yearly') throw ApiError.badRequest('EasyPaisa only supports yearly billing', 'YEARLY_ONLY');
  if (!mobileNumber?.match(/^03\d{9}$/)) throw ApiError.badRequest('Invalid mobile number. Format: 03XXXXXXXXX', 'INVALID_MOBILE');
  if (!CONFIG.storeId) throw ApiError.serviceUnavailable('EasyPaisa not configured');

  const amount    = PLAN_AMOUNTS[tier];
  const orderRef  = generateTxnRef('WGPT-EP', userId);
  const expiryDate = new Date(Date.now() + 30 * 60_000).toISOString().replace(/[-:T.]/g, '').slice(0, 14);

  const params: Record<string, string> = {
    storeId:       CONFIG.storeId,
    amount:        (amount * 100).toString(),
    postBackURL:   CONFIG.callbackUrl,
    orderRefNum:   orderRef,
    mobileNum:     mobileNumber,
    emailAddr:     req.user!.email || '',
    expiryDate,
    paymentMethod: 'MA_JAZZCASH_WALLET',
    paymentType:   'MA',
  };
  params.hash = computeSignature(params);

  await storePendingPayment({ txnRef: orderRef, userId, tier, period, amount, currency: 'PKR', provider: 'easypaisa' });

  res.json({ success: true, data: { orderRef, amount, currency: 'PKR', params } });
}));

// ── POST /api/payment/easypaisa/callback ──────────────────────────────────
router.post('/callback', asyncHandler(async (req, res) => {
  const body         = req.body as Record<string, string>;
  const orderRefNum  = body.orderRefNum || body.pp_TxnRefNo;
  const receivedHash = body.hash;
  const responseCode = body.responseCode || body.pp_ResponseCode;

  if (!orderRefNum) {
    logger.warn('EasyPaisa callback: missing orderRefNum');
    return res.status(400).json({ error: 'Missing orderRefNum' });
  }

  // FIX #14: HMAC verification — reject callbacks without a valid signature
  if (!receivedHash) {
    logger.warn('EasyPaisa callback: missing hash — rejecting', { orderRefNum });
    return res.status(400).json({ error: 'Missing signature' });
  }

  const expectedHash = computeSignature(body);
  if (!safeCompare(expectedHash, receivedHash.toLowerCase())) {
    logger.warn('EasyPaisa: invalid signature', { orderRefNum });
    return res.status(400).json({ error: 'Invalid signature' });
  }

  const pending = await db.collection('pending_payments').doc(orderRefNum).get();
  if (!pending.exists) return res.status(404).json({ error: 'Transaction not found' });

  const { userId, tier } = pending.data()!;
  const success = responseCode === '0000' || responseCode === '000';

  if (success) {
    await activateSubscription({ userId, tier, provider: 'easypaisa', txnRef: orderRefNum, expiresAt: yearlyExpiryDate() });
  }
  await updatePaymentStatus(orderRefNum, success ? 'completed' : 'failed', { responseCode });

  res.redirect(302, buildRedirectUrl(success));
}));

// ── GET /api/payment/easypaisa/status/:orderRef ───────────────────────────
router.get('/status/:orderRef', authMiddleware, asyncHandler(async (req: AuthRequest, res) => {
  const snap = await db.collection('pending_payments').doc(req.params.orderRef).get();
  if (!snap.exists) throw ApiError.notFound('Transaction not found');
  if (snap.data()!.userId !== req.user!.uid) throw ApiError.forbidden();
  res.json({ success: true, data: { status: snap.data()!.status, orderRef: req.params.orderRef } });
}));

export default router;
