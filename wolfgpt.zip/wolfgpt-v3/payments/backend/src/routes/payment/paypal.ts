/**
 * PayPal subscription gateway (v3) — FIX #18.
 * Full OAuth2 flow, plan ID lookup, subscription activation, webhook verification.
 * Uses shared paymentUtils for consistent Firestore updates.
 */

import express from 'express';
import axios   from 'axios';
import { authMiddleware }         from '../../middleware/auth';
import { rateLimiter }            from '../../middleware/rateLimit';
import { asyncHandler, ApiError } from '../../middleware/errorHandler';
import { db }                     from '../../config/firebase';
import { AuthRequest }            from '../../middleware/auth';
import {
  activateSubscription,
  deactivateSubscription,
  buildRedirectUrl,
}                                 from '../../utils/paymentUtils';
import logger                     from '../../utils/logger';

const router = express.Router();

const PAYPAL_CLIENT_ID     = process.env.PAYPAL_CLIENT_ID     || '';
const PAYPAL_CLIENT_SECRET = process.env.PAYPAL_CLIENT_SECRET || '';
const PAYPAL_WEBHOOK_ID    = process.env.PAYPAL_WEBHOOK_ID    || '';
const PAYPAL_MODE          = process.env.PAYPAL_MODE === 'live' ? 'live' : 'sandbox';
const PAYPAL_BASE          = PAYPAL_MODE === 'live'
  ? 'https://api-m.paypal.com'
  : 'https://api-m.sandbox.paypal.com';

const PLAN_IDS: Record<string, Record<string, string>> = {
  basic:   { monthly: process.env.PAYPAL_PLAN_BASIC_MONTHLY   || '', yearly: process.env.PAYPAL_PLAN_BASIC_YEARLY   || '' },
  premium: { monthly: process.env.PAYPAL_PLAN_PREMIUM_MONTHLY || '', yearly: process.env.PAYPAL_PLAN_PREMIUM_YEARLY || '' },
  pro:     { monthly: process.env.PAYPAL_PLAN_PRO_MONTHLY     || '', yearly: process.env.PAYPAL_PLAN_PRO_YEARLY     || '' },
};

function requirePayPal() {
  if (!PAYPAL_CLIENT_ID || !PAYPAL_CLIENT_SECRET) {
    throw ApiError.serviceUnavailable('PayPal is not configured. Set PAYPAL_CLIENT_ID and PAYPAL_CLIENT_SECRET in backend/.env');
  }
}

async function getToken(): Promise<string> {
  const res = await axios.post(
    `${PAYPAL_BASE}/v1/oauth2/token`,
    'grant_type=client_credentials',
    { auth: { username: PAYPAL_CLIENT_ID, password: PAYPAL_CLIENT_SECRET }, headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, timeout: 15_000 }
  );
  return res.data.access_token;
}

// ── GET /api/payment/paypal/plan-id ───────────────────────────────────────
router.get('/plan-id', authMiddleware, asyncHandler(async (req: AuthRequest, res) => {
  requirePayPal();
  const tier   = (req.query.tier   as string) || 'basic';
  const period = (req.query.period as string) || 'monthly';

  if (!['basic','premium','pro'].includes(tier))
    throw ApiError.badRequest('Invalid tier', 'INVALID_PLAN');

  const planId = PLAN_IDS[tier]?.[period];
  if (!planId)
    throw ApiError.badRequest(
      `PayPal plan not configured for ${tier}/${period}. Set PAYPAL_PLAN_${tier.toUpperCase()}_${period.toUpperCase()} in .env`,
      'PLAN_NOT_CONFIGURED'
    );

  res.json({ success: true, data: { planId, tier, period, mode: PAYPAL_MODE } });
}));

// ── POST /api/payment/paypal/activate ─────────────────────────────────────
router.post('/activate', rateLimiter, authMiddleware, asyncHandler(async (req: AuthRequest, res) => {
  requirePayPal();
  const { subscriptionId, tier } = req.body;

  if (!subscriptionId?.trim()) throw ApiError.badRequest('subscriptionId is required');
  if (!['basic','premium','pro'].includes(tier)) throw ApiError.badRequest('Invalid tier', 'INVALID_PLAN');

  const token = await getToken();
  const subRes = await axios.get(
    `${PAYPAL_BASE}/v1/billing/subscriptions/${subscriptionId}`,
    { headers: { Authorization: `Bearer ${token}` }, timeout: 15_000 }
  );

  if (subRes.data.status !== 'ACTIVE')
    throw ApiError.badRequest(`PayPal subscription is "${subRes.data.status}", not ACTIVE`, 'SUBSCRIPTION_NOT_ACTIVE');

  const userId = req.user!.uid;
  await activateSubscription({ userId, tier, provider: 'paypal', providerSubId: subscriptionId });

  await db.collection('paypal_subscriptions').doc(subscriptionId).set(
    { subscriptionId, userId, tier, status: 'active', createdAt: new Date(), updatedAt: new Date() },
    { merge: true }
  );

  res.json({ success: true, data: { activated: true, tier } });
}));

// ── POST /api/payment/paypal/webhook ──────────────────────────────────────
router.post('/webhook', express.json(), async (req, res) => {
  // Signature verification
  if (PAYPAL_WEBHOOK_ID) {
    try {
      const token = await getToken();
      const verifyRes = await axios.post(
        `${PAYPAL_BASE}/v1/notifications/verify-webhook-signature`,
        {
          auth_algo:         req.headers['paypal-auth-algo'],
          cert_url:          req.headers['paypal-cert-url'],
          transmission_id:   req.headers['paypal-transmission-id'],
          transmission_sig:  req.headers['paypal-transmission-sig'],
          transmission_time: req.headers['paypal-transmission-time'],
          webhook_id:        PAYPAL_WEBHOOK_ID,
          webhook_event:     req.body,
        },
        { headers: { Authorization: `Bearer ${token}` }, timeout: 15_000 }
      );
      if (verifyRes.data?.verification_status !== 'SUCCESS') {
        res.status(400).json({ error: 'Invalid PayPal signature' }); return;
      }
    } catch (e) {
      if (process.env.NODE_ENV === 'production') { res.status(400).json({ error: 'Signature check failed' }); return; }
    }
  }

  const { event_type, resource } = req.body;
  try {
    switch (event_type) {
      case 'BILLING.SUBSCRIPTION.ACTIVATED': {
        const subSnap = await db.collection('paypal_subscriptions').doc(resource?.id).get();
        if (subSnap.exists) {
          const { userId, tier } = subSnap.data()!;
          await activateSubscription({ userId, tier, provider: 'paypal', providerSubId: resource?.id });
        }
        break;
      }
      case 'BILLING.SUBSCRIPTION.CANCELLED':
      case 'BILLING.SUBSCRIPTION.SUSPENDED': {
        const subSnap = await db.collection('paypal_subscriptions').doc(resource?.id).get();
        if (subSnap.exists) {
          const status = event_type === 'BILLING.SUBSCRIPTION.CANCELLED' ? 'cancelled' : 'paused';
          await deactivateSubscription(subSnap.data()!.userId, 'paypal', status as any);
          await subSnap.ref.update({ status, updatedAt: new Date() });
        }
        break;
      }
    }
    res.json({ received: true });
  } catch (err) {
    logger.error('PayPal webhook handler error:', err);
    res.status(500).json({ error: 'Handler error' });
  }
});

export default router;
