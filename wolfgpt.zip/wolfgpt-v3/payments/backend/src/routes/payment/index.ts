/**
 * Shared payment routes — subscription status, history, plans, usage limits.
 * These routes are mounted at /api/payment and supplement the provider-specific
 * routes (/api/payment/stripe, /api/payment/paypal, etc.).
 */

import express from 'express';
import { authMiddleware }    from '../../middleware/auth';
import { rateLimiter }       from '../../middleware/rateLimit';
import { paymentController } from '../../controllers/paymentController';

const router = express.Router();

// Public (no auth needed)
router.get('/plans',          paymentController.getPlans);

// Auth required
router.get('/subscription',   rateLimiter, authMiddleware, paymentController.getSubscription);
router.get('/history',        rateLimiter, authMiddleware, paymentController.getHistory);
router.post('/cancel',        rateLimiter, authMiddleware, paymentController.cancelSubscription);
router.get('/usage-limits',   rateLimiter, authMiddleware, paymentController.getUsageLimits);

export default router;
