#!/usr/bin/env python3
"""
WolfGPT v3 — Pre-download AI models script.
Run this before first launch to avoid slow cold starts.

Usage:
  python scripts/download_models.py                  # download all defaults
  python scripts/download_models.py --whisper large  # specific whisper size
  python scripts/download_models.py --skip-images    # skip SD/FLUX download
  python scripts/download_models.py --minimal        # only qwen2.5:7b
"""

import argparse
import asyncio
import logging
import os
import sys

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
logger = logging.getLogger(__name__)

# Add project root to path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))


async def download_ollama_model(model_id: str, ollama_url: str) -> bool:
    import httpx
    logger.info("Pulling Ollama model: %s …", model_id)
    try:
        async with httpx.AsyncClient(timeout=3600) as client:
            async with client.stream("POST", f"{ollama_url}/api/pull", json={"name": model_id, "stream": True}) as r:
                r.raise_for_status()
                prev = ""
                async for line in r.aiter_lines():
                    if '"status":' in line and line != prev:
                        import json
                        try:
                            d = json.loads(line)
                            status = d.get("status", "")
                            if "pulling" in status or "success" in status:
                                logger.info("  %s", status)
                        except Exception:
                            pass
                        prev = line
        logger.info("✅ Pulled: %s", model_id)
        return True
    except Exception as e:
        logger.error("❌ Failed to pull %s: %s", model_id, e)
        return False


def download_whisper(model_size: str, cache_dir: str) -> None:
    logger.info("Downloading Whisper model: %s …", model_size)
    try:
        import whisper
        whisper.load_model(model_size, download_root=cache_dir)
        logger.info("✅ Whisper %s ready", model_size)
    except Exception as e:
        logger.error("❌ Whisper download failed: %s", e)


def download_tts(model_name: str, cache_dir: str) -> None:
    logger.info("Downloading Coqui TTS model: %s …", model_name)
    try:
        from TTS.api import TTS
        TTS(model_name=model_name, progress_bar=True)
        logger.info("✅ Coqui TTS ready")
    except Exception as e:
        logger.error("❌ TTS download failed: %s", e)


async def main():
    parser = argparse.ArgumentParser(description="WolfGPT model pre-downloader")
    parser.add_argument("--ollama-url",   default=os.environ.get("OLLAMA_URL",    "http://localhost:11434"))
    parser.add_argument("--whisper",      default=os.environ.get("WHISPER_MODEL", "base"),
                        choices=["tiny","base","small","medium","large-v3"])
    parser.add_argument("--whisper-cache",default=os.environ.get("WHISPER_CACHE_DIR", "/app/models/whisper"))
    parser.add_argument("--tts-model",    default=os.environ.get("TTS_MODEL", "tts_models/en/ljspeech/tacotron2-DDC"))
    parser.add_argument("--tts-cache",    default=os.environ.get("TTS_CACHE_DIR", "/app/models/tts"))
    parser.add_argument("--skip-whisper", action="store_true")
    parser.add_argument("--skip-tts",     action="store_true")
    parser.add_argument("--skip-images",  action="store_true", help="Skip FLUX/SDXL download (large, GPU only)")
    parser.add_argument("--minimal",      action="store_true", help="Only download default Ollama model")
    args = parser.parse_args()

    logger.info("=" * 60)
    logger.info("WolfGPT v3 — Model Pre-Download")
    logger.info("=" * 60)

    # ── Ollama models ──────────────────────────────────────────────────────────
    from core.config import OLLAMA_MODEL_MAP
    models_to_pull = ["qwen2.5:7b"] if args.minimal else [
        "qwen2.5:7b",
        "llama3.2:3b",
        "llama3.1:8b",
        "mistral:7b",
    ]
    logger.info("Pulling %d Ollama model(s)…", len(models_to_pull))
    for m in models_to_pull:
        await download_ollama_model(m, args.ollama_url)

    # ── Whisper ────────────────────────────────────────────────────────────────
    if not args.skip_whisper:
        download_whisper(args.whisper, args.whisper_cache)

    # ── Coqui TTS ──────────────────────────────────────────────────────────────
    if not args.skip_tts:
        download_tts(args.tts_model, args.tts_cache)

    logger.info("=" * 60)
    logger.info("✅ Download complete. Run: python main.py")
    logger.info("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
