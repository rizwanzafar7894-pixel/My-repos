# WolfGPT AI Services

FastAPI · Python 3.11 · Ollama · FLUX/SDXL · Whisper · Coqui TTS · MusicGen · Docker sandbox

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Configure environment
cp .env.example .env

# 3. Start Ollama (separately)
ollama serve
ollama pull qwen2.5:7b

# 4. Pre-download models (optional but recommended)
python scripts/download_models.py --minimal

# 5. Start the service
python main.py
# → http://localhost:8000/health
```

## Endpoints

| Method | Path | Description |
|---|---|---|
| GET  | `/health` | Service health + model info |
| POST | `/v1/chat/completions` | Chat via Ollama (streaming + non-streaming) |
| POST | `/v1/images/generate` | Text-to-image (FLUX / SDXL) |
| POST | `/v1/images/img2img` | Image-to-image |
| POST | `/v1/images/inpaint` | Inpainting with mask |
| POST | `/v1/images/upscale` | 4x upscaling |
| POST | `/v1/voice/stt` | Speech-to-text (Whisper) |
| POST | `/v1/voice/tts` | Text-to-speech (Coqui TTS) |
| POST | `/v1/code/execute` | Sandboxed code execution |
| POST | `/v1/documents/parse` | PDF/DOCX/CSV text extraction |
| POST | `/v1/music/generate` | Text-to-music (MusicGen) |
| POST | `/v1/music/melody` | Melody-conditioned generation |
| POST | `/v1/music/continuation` | Audio continuation |
| GET  | `/admin/models` | List available models |
| GET  | `/admin/health/detailed` | GPU + model detailed health |

## Supported Models

### Chat (via Ollama)
| WolfGPT ID | Ollama Name | Notes |
|---|---|---|
| `qwen-2.5-7b` | `qwen2.5:7b` | Default, free tier |
| `llama-3.2-3b` | `llama3.2:3b` | Meta, fast |
| `llama-3.1-8b` | `llama3.1:8b` | Meta, balanced |
| `llama-3.1-70b` | `llama3.1:70b` | Meta, pro tier |
| `mistral-7b` | `mistral:7b` | Mistral AI |
| `gemma-2-9b` | `gemma2:9b` | Google |
| `deepseek-r1-7b` | `deepseek-r1:7b` | Reasoning |
| `deepseek-coder-v2` | `deepseek-coder-v2:16b` | Code |
| `codellama-7b` | `codellama:7b` | Code |
| `llava-7b/13b/34b` | `llava:*` | Vision |

### Images
- `flux-schnell` — FLUX.1-schnell (2–4 steps, fastest)
- `flux-dev` — FLUX.1-dev (20–50 steps, quality)
- `sdxl-base` — Stable Diffusion XL Base
- `sdxl-refiner` — SDXL Refiner

### Voice
- STT: Whisper `tiny` → `large-v3`
- TTS: Coqui TTS `tts_models/en/ljspeech/tacotron2-DDC`

### Music
- `musicgen-small/medium/large/melody/stereo-small`

## Key Fixes (v3)
- **FIX #4**: `audiocraft` added to `requirements.txt` — MusicGen now loads correctly
- **FIX #15**: `routers/voice.py` imports from `services/voice_service.py` (was inline)
- **FIX #16**: Full `OLLAMA_MODEL_MAP` — Llama3, Mistral, Gemma, DeepSeek, CodeLlama
- **FIX #22**: `--no-cache-dir` on all pip calls in Dockerfile

## GPU Notes

With NVIDIA GPU (`USE_GPU=true`, `WHISPER_DEVICE=cuda`):
- Image generation: 3–8s per image (vs 60–120s on CPU)
- Whisper: 10–20× faster transcription
- MusicGen: 5–15s per clip (vs 60–120s on CPU)

CPU-only mode: set `USE_GPU=false` and `WHISPER_DEVICE=cpu` in `.env`.
