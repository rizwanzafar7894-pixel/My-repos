"""Central configuration — reads from environment variables.

FIX #16: OLLAMA_MODEL_MAP now includes all models from the spec:
  Llama 3 (3.2:3b, 3.1:8b, 3.1:70b), Mistral 7B, Gemma 2 9B,
  DeepSeek R1 7B, DeepSeek Coder V2, Code Llama 7B — previously
  only Qwen and LLaVA variants were mapped.
"""

import os
from typing import List
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # ── Server ────────────────────────────────────────────────────────────────
    PORT:  int  = 8000
    DEBUG: bool = False

    # ── Ollama ────────────────────────────────────────────────────────────────
    OLLAMA_URL:   str = "http://localhost:11434"
    OLLAMA_MODEL: str = "qwen2.5:7b"   # default; overridden per-request

    # ── Image generation ──────────────────────────────────────────────────────
    IMAGE_MODEL:     str  = "black-forest-labs/FLUX.1-schnell"
    IMAGE_CACHE_DIR: str  = "/app/models/images"
    USE_GPU:         bool = True

    # ── Whisper STT ───────────────────────────────────────────────────────────
    WHISPER_MODEL:     str = "base"     # tiny | base | small | medium | large-v3
    WHISPER_DEVICE:    str = "cpu"      # "cpu" or "cuda"
    WHISPER_CACHE_DIR: str = "/app/models/whisper"

    # ── Coqui TTS ─────────────────────────────────────────────────────────────
    TTS_MODEL:     str = "tts_models/en/ljspeech/tacotron2-DDC"
    TTS_CACHE_DIR: str = "/app/models/tts"

    # ── MusicGen ──────────────────────────────────────────────────────────────
    MUSICGEN_DEFAULT_MODEL: str = "musicgen-small"
    MUSICGEN_CACHE_DIR:     str = "/app/models/musicgen"

    # ── Code sandbox ──────────────────────────────────────────────────────────
    CODE_TIMEOUT:    int = 30
    CODE_MAX_OUTPUT: int = 50_000

    # ── Document parsing ──────────────────────────────────────────────────────
    MAX_DOC_SIZE: int = 50 * 1024 * 1024   # 50 MB

    # ── CORS ──────────────────────────────────────────────────────────────────
    ALLOWED_ORIGINS: List[str] = ["http://localhost:4000", "http://backend:4000"]

    # ── Redis ─────────────────────────────────────────────────────────────────
    REDIS_URL: str = "redis://localhost:6379"

    class Config:
        env_file      = ".env"
        case_sensitive = True


settings = Settings()


# ══════════════════════════════════════════════════════════════════════════════
#  FIX #16 — OLLAMA MODEL MAP
#  Maps WolfGPT frontend model IDs → Ollama pull names.
#  Previously only Qwen + LLaVA were mapped; all spec models now included.
# ══════════════════════════════════════════════════════════════════════════════
OLLAMA_MODEL_MAP: dict[str, str] = {
    # Qwen 2.5
    "qwen-2.5-7b":  "qwen2.5:7b",
    "qwen-2.5-32b": "qwen2.5:32b",
    "qwen-2.5-72b": "qwen2.5:72b",

    # Llama 3 (FIX #16)
    "llama-3.2-3b":  "llama3.2:3b",
    "llama-3.1-8b":  "llama3.1:8b",
    "llama-3.1-70b": "llama3.1:70b",

    # Mistral (FIX #16)
    "mistral-7b": "mistral:7b",

    # Gemma 2 (FIX #16)
    "gemma-2-9b": "gemma2:9b",

    # DeepSeek (FIX #16)
    "deepseek-r1-7b":    "deepseek-r1:7b",
    "deepseek-coder-v2": "deepseek-coder-v2:16b",

    # Code Llama (FIX #16)
    "codellama-7b": "codellama:7b",

    # LLaVA vision models
    "llava-7b":  "llava:7b",
    "llava-13b": "llava:13b",
    "llava-34b": "llava:34b",
}

# ── Image model map ───────────────────────────────────────────────────────────
IMAGE_MODEL_MAP: dict[str, str] = {
    "flux-schnell":  "black-forest-labs/FLUX.1-schnell",
    "flux-dev":      "black-forest-labs/FLUX.1-dev",
    "flux-pro":      "black-forest-labs/FLUX.1-pro",
    "sdxl-base":     "stabilityai/stable-diffusion-xl-base-1.0",
    "sdxl-refiner":  "stabilityai/stable-diffusion-xl-refiner-1.0",
}

# ── Whisper model sizes ───────────────────────────────────────────────────────
WHISPER_MODEL_MAP: dict[str, str] = {
    "tiny":               "tiny",
    "base":               "base",
    "small":              "small",
    "medium":             "medium",
    "large":              "large-v3",
    "whisper-large-v3":   "large-v3",
    "large-v3":           "large-v3",
}

# ── MusicGen model map ────────────────────────────────────────────────────────
MUSICGEN_MODEL_MAP: dict[str, str] = {
    "musicgen-small":         "facebook/musicgen-small",
    "musicgen-medium":        "facebook/musicgen-medium",
    "musicgen-large":         "facebook/musicgen-large",
    "musicgen-melody":        "facebook/musicgen-melody",
    "musicgen-stereo-small":  "facebook/musicgen-stereo-small",
    "musicgen-stereo-medium": "facebook/musicgen-stereo-medium",
}
