import logging
import sys
import os


def setup_logging() -> None:
    level_name = os.environ.get("LOG_LEVEL", "INFO").upper()
    level      = getattr(logging, level_name, logging.INFO)

    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    datefmt = "%H:%M:%S"

    logging.basicConfig(
        level=level,
        format=fmt,
        datefmt=datefmt,
        handlers=[logging.StreamHandler(sys.stdout)],
        force=True,
    )

    # Quiet down noisy libraries
    for noisy in ("httpx", "httpcore", "diffusers", "transformers", "urllib3", "PIL"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
