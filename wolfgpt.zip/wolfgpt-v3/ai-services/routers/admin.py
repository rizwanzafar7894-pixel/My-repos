"""Admin router — model management, health checks, cache control."""

import logging
from fastapi import APIRouter
from services.ollama_service import ollama_service
from core.config import settings, OLLAMA_MODEL_MAP

logger = logging.getLogger(__name__)
router = APIRouter()


@router.get("/models")
async def list_models():
    """List all available Ollama models."""
    running    = await ollama_service.is_running()
    models     = await ollama_service.list_models() if running else []
    return {
        "ollama_running": running,
        "models":         models,
        "ollama_url":     settings.OLLAMA_URL,
        "model_map":      OLLAMA_MODEL_MAP,
    }


@router.post("/models/{model_id}/pull")
async def pull_model(model_id: str):
    """Pull/download an Ollama model by WolfGPT model ID or raw Ollama name."""
    ollama_name = OLLAMA_MODEL_MAP.get(model_id, model_id)
    success     = await ollama_service.pull_model(ollama_name)
    return {"model_id": model_id, "ollama_name": ollama_name, "success": success}


@router.get("/health/detailed")
async def detailed_health():
    """Detailed health including GPU memory and model status."""
    import torch

    gpu_info = None
    if torch.cuda.is_available():
        props    = torch.cuda.get_device_properties(0)
        reserved = torch.cuda.memory_reserved(0)
        alloc    = torch.cuda.memory_allocated(0)
        gpu_info = {
            "name":          props.name,
            "total_mb":      props.total_memory // 1024 // 1024,
            "reserved_mb":   reserved // 1024 // 1024,
            "allocated_mb":  alloc // 1024 // 1024,
            "free_mb":       (props.total_memory - reserved) // 1024 // 1024,
        }

    return {
        "status":       "healthy",
        "ollama":       await ollama_service.is_running(),
        "gpu":          gpu_info,
        "torch_version": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "settings": {
            "ollama_model":  settings.OLLAMA_MODEL,
            "image_model":   settings.IMAGE_MODEL,
            "whisper_model": settings.WHISPER_MODEL,
            "whisper_device": settings.WHISPER_DEVICE,
            "use_gpu":       settings.USE_GPU,
        },
    }
