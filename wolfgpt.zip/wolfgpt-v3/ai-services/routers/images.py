"""
Image generation router.
Supports: text-to-image, image-to-image, inpainting, upscaling.
Models: FLUX.1-schnell, FLUX.1-dev, SDXL base + refiner.
All pipelines are lazy-loaded and cached in-process.
GPU OOM is caught and retried after evicting pipelines.
"""

from __future__ import annotations
import base64, gc, io, logging, time
from typing import Optional

import torch
from fastapi import APIRouter, HTTPException, UploadFile, File, Form
from PIL import Image
from pydantic import BaseModel, Field, model_validator

from core.config import settings, IMAGE_MODEL_MAP

logger = logging.getLogger(__name__)
router = APIRouter()

_pipelines: dict[str, object] = {}


# ── Device & memory helpers ───────────────────────────────────────────────────
def get_device() -> str:
    if settings.USE_GPU and torch.cuda.is_available():
        return "cuda"
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def _apply_memory_opts(pipe, device: str):
    if device == "cuda":
        for method in ("enable_model_cpu_offload", "enable_xformers_memory_efficient_attention"):
            try: getattr(pipe, method)()
            except Exception: pass
    return pipe


def evict_pipelines():
    global _pipelines
    _pipelines.clear()
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    logger.warning("All pipelines evicted due to OOM or explicit request.")


def _load_pipeline(model_id: str, pipeline_type: str):
    key = f"{pipeline_type}:{model_id}"
    if key in _pipelines:
        return _pipelines[key]

    device  = get_device()
    dtype   = torch.bfloat16 if device in ("cuda", "mps") else torch.float32
    logger.info("Loading %s pipeline: %s on %s", pipeline_type, model_id, device)

    try:
        if pipeline_type == "txt2img":
            if "FLUX" in model_id or "flux" in model_id.lower():
                from diffusers import FluxPipeline
                pipe = FluxPipeline.from_pretrained(
                    model_id, torch_dtype=dtype,
                    cache_dir=settings.IMAGE_CACHE_DIR,
                )
            else:
                from diffusers import StableDiffusionXLPipeline
                pipe = StableDiffusionXLPipeline.from_pretrained(
                    model_id, torch_dtype=dtype,
                    use_safetensors=True, variant="fp16" if device == "cuda" else None,
                    cache_dir=settings.IMAGE_CACHE_DIR,
                )
            pipe = _apply_memory_opts(pipe, device)
            if device not in ("cuda",):
                pipe = pipe.to(device)

        elif pipeline_type == "img2img":
            from diffusers import StableDiffusionXLImg2ImgPipeline
            pipe = StableDiffusionXLImg2ImgPipeline.from_pretrained(
                model_id, torch_dtype=dtype, use_safetensors=True,
                cache_dir=settings.IMAGE_CACHE_DIR,
            )
            pipe = _apply_memory_opts(pipe, device)

        elif pipeline_type == "inpaint":
            from diffusers import StableDiffusionXLInpaintPipeline
            pipe = StableDiffusionXLInpaintPipeline.from_pretrained(
                model_id, torch_dtype=dtype, use_safetensors=True,
                cache_dir=settings.IMAGE_CACHE_DIR,
            )
            pipe = _apply_memory_opts(pipe, device)

        elif pipeline_type == "upscale":
            from diffusers import StableDiffusionUpscalePipeline
            pipe = StableDiffusionUpscalePipeline.from_pretrained(
                "stabilityai/stable-diffusion-x4-upscaler",
                torch_dtype=dtype,
                cache_dir=settings.IMAGE_CACHE_DIR,
            )
            pipe = pipe.to(device)

        else:
            raise ValueError(f"Unknown pipeline type: {pipeline_type}")

        _pipelines[key] = pipe
        logger.info("✅ Pipeline ready: %s", key)
        return pipe

    except RuntimeError as e:
        if "CUDA out of memory" in str(e) or "out of memory" in str(e).lower():
            evict_pipelines()
            raise HTTPException(status_code=507, detail="GPU out of memory. Retry with smaller settings.")
        raise


def pil_to_base64(img: Image.Image, fmt: str = "PNG") -> str:
    buf = io.BytesIO()
    img.save(buf, format=fmt)
    return base64.b64encode(buf.getvalue()).decode()


def base64_to_pil(b64: str) -> Image.Image:
    data = base64.b64decode(b64)
    return Image.open(io.BytesIO(data)).convert("RGB")


# ── Schemas ───────────────────────────────────────────────────────────────────
class GenerateRequest(BaseModel):
    prompt:          str   = Field(..., min_length=1, max_length=2000)
    negative_prompt: str   = Field(default="")
    model:           str   = Field(default="flux-schnell")
    width:           int   = Field(default=1024, ge=256, le=4096)
    height:          int   = Field(default=1024, ge=256, le=4096)
    steps:           int   = Field(default=4,    ge=1,   le=100)
    guidance_scale:  float = Field(default=3.5,  ge=0.0, le=30.0)
    seed:            Optional[int] = None

    @model_validator(mode="after")
    def snap_dimensions(self):
        self.width  = (self.width  // 64) * 64 or 64
        self.height = (self.height // 64) * 64 or 64
        return self


class Img2ImgRequest(BaseModel):
    prompt:          str
    image:           str          # base64
    negative_prompt: str   = ""
    model:           str   = "sdxl-base"
    strength:        float = Field(default=0.75, ge=0.0, le=1.0)
    steps:           int   = Field(default=30, ge=1, le=100)
    guidance_scale:  float = Field(default=7.5)
    seed:            Optional[int] = None


class InpaintRequest(BaseModel):
    prompt:    str
    image:     str    # base64
    mask:      str    # base64
    model:     str    = "sdxl-base"
    steps:     int    = Field(default=30, ge=1, le=100)
    seed:      Optional[int] = None


# ── Routes ────────────────────────────────────────────────────────────────────
@router.post("/generate")
async def generate_image(req: GenerateRequest):
    hf_model = IMAGE_MODEL_MAP.get(req.model, req.model)
    generator = torch.Generator().manual_seed(req.seed) if req.seed is not None else None

    try:
        t0   = time.time()
        pipe = _load_pipeline(hf_model, "txt2img")

        kwargs = dict(
            prompt=req.prompt,
            num_inference_steps=req.steps,
            generator=generator,
        )
        if req.negative_prompt:
            kwargs["negative_prompt"] = req.negative_prompt
        if "FLUX" not in hf_model:
            kwargs["guidance_scale"] = req.guidance_scale
            kwargs["width"]  = req.width
            kwargs["height"] = req.height
        else:
            kwargs["width"]  = req.width
            kwargs["height"] = req.height

        result  = pipe(**kwargs)
        image   = result.images[0]
        elapsed = round(time.time() - t0, 2)

        return {"image": pil_to_base64(image), "width": image.width, "height": image.height, "model": req.model, "duration": elapsed}

    except HTTPException:
        raise
    except RuntimeError as e:
        if "out of memory" in str(e).lower():
            evict_pipelines()
            raise HTTPException(status_code=507, detail="GPU OOM — evicted pipelines, please retry.")
        logger.error("Image generation error: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Image generation failed: {e}")


@router.post("/img2img")
async def image_to_image(req: Img2ImgRequest):
    hf_model  = IMAGE_MODEL_MAP.get(req.model, req.model)
    input_img = base64_to_pil(req.image)
    generator = torch.Generator().manual_seed(req.seed) if req.seed else None

    try:
        pipe   = _load_pipeline(hf_model, "img2img")
        result = pipe(
            prompt=req.prompt, image=input_img,
            strength=req.strength, num_inference_steps=req.steps,
            guidance_scale=req.guidance_scale, negative_prompt=req.negative_prompt or None,
            generator=generator,
        )
        return {"image": pil_to_base64(result.images[0]), "model": req.model}
    except RuntimeError as e:
        if "out of memory" in str(e).lower():
            evict_pipelines()
            raise HTTPException(status_code=507, detail="GPU OOM — please retry.")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/img2img/upload")
async def image_to_image_upload(
    prompt:          str   = Form(...),
    image:           UploadFile = File(...),
    negative_prompt: str   = Form(default=""),
    model:           str   = Form(default="sdxl-base"),
    strength:        float = Form(default=0.75),
    steps:           int   = Form(default=30),
):
    content   = await image.read()
    input_img = Image.open(io.BytesIO(content)).convert("RGB")
    hf_model  = IMAGE_MODEL_MAP.get(model, model)

    try:
        pipe   = _load_pipeline(hf_model, "img2img")
        result = pipe(
            prompt=prompt, image=input_img, strength=strength,
            num_inference_steps=steps, negative_prompt=negative_prompt or None,
        )
        return {"image": pil_to_base64(result.images[0]), "model": model}
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/inpaint")
async def inpaint(req: InpaintRequest):
    hf_model  = IMAGE_MODEL_MAP.get(req.model, req.model)
    input_img = base64_to_pil(req.image)
    mask_img  = Image.open(io.BytesIO(base64.b64decode(req.mask))).convert("L")
    generator = torch.Generator().manual_seed(req.seed) if req.seed else None

    try:
        pipe   = _load_pipeline(hf_model, "inpaint")
        result = pipe(
            prompt=req.prompt, image=input_img, mask_image=mask_img,
            num_inference_steps=req.steps, generator=generator,
        )
        return {"image": pil_to_base64(result.images[0]), "model": req.model}
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/upscale")
async def upscale(image: str):
    input_img = base64_to_pil(image)
    try:
        pipe   = _load_pipeline("upscale", "upscale")
        result = pipe(prompt="high quality, detailed", image=input_img)
        return {"image": pil_to_base64(result.images[0])}
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/pipelines")
async def evict_all_pipelines():
    evict_pipelines()
    return {"evicted": True}
