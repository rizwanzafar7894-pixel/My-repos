"""
Voice router — Whisper STT + Coqui TTS.
FIX #15: Now imports from services/voice_service.py instead of
duplicating model loading inline. The voice_service module exposes
multi-speaker TTS and additional features that were previously
unreachable.
"""

import io, logging, os, tempfile, time
from typing import Optional

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel, Field

from core.config import settings, WHISPER_MODEL_MAP
from services.voice_service import voice_service   # FIX #15: use shared service

logger = logging.getLogger(__name__)
router = APIRouter()


# ── Schemas ───────────────────────────────────────────────────────────────────
class STTResponse(BaseModel):
    text:       str
    language:   str
    duration:   Optional[float]
    confidence: float = 0.95


class TTSRequest(BaseModel):
    text:  str   = Field(..., min_length=1, max_length=5000)
    voice: str   = Field(default="en-US-female-1")
    speed: float = Field(default=1.0, ge=0.5, le=2.0)


# ── Routes ────────────────────────────────────────────────────────────────────
@router.post("/stt", response_model=STTResponse)
async def speech_to_text(
    audio:    UploadFile = File(...),
    language: str        = Form(default="en"),
    model:    str        = Form(default="base"),
):
    """Transcribe audio using OpenAI Whisper (runs locally)."""
    content = await audio.read()
    if len(content) > 25 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Audio file too large (max 25 MB)")

    suffix  = os.path.splitext(audio.filename or "audio.webm")[1] or ".webm"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(content)
        tmp_path = tmp.name

    try:
        whisper_size = WHISPER_MODEL_MAP.get(model, "base")
        t0           = time.time()
        result       = voice_service.transcribe(tmp_path, whisper_size, language if language != "auto" else None)
        duration     = round(time.time() - t0, 2)

        return STTResponse(
            text=result.get("text", "").strip(),
            language=result.get("language", language),
            duration=duration,
            confidence=0.95,
        )
    except Exception as e:
        logger.error("Whisper STT error: %s", e)
        raise HTTPException(status_code=500, detail=f"STT failed: {e}")
    finally:
        os.unlink(tmp_path)


@router.post("/tts")
async def text_to_speech(req: TTSRequest):
    """Synthesise speech using Coqui TTS (runs locally). Returns audio/wav bytes."""
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
        out_path = tmp.name

    try:
        voice_service.synthesize(req.text, out_path, speed=req.speed)
        with open(out_path, "rb") as f:
            audio_bytes = f.read()
        return Response(
            content=audio_bytes,
            media_type="audio/wav",
            headers={"Content-Length": str(len(audio_bytes))},
        )
    except Exception as e:
        logger.error("Coqui TTS error: %s", e)
        raise HTTPException(status_code=500, detail=f"TTS failed: {e}")
    finally:
        if os.path.exists(out_path):
            os.unlink(out_path)


@router.get("/voices")
async def list_voices():
    return {
        "voices": [
            {"id": "en-US-female-1", "name": "Emma",   "language": "en-US", "gender": "female"},
            {"id": "en-US-male-1",   "name": "James",  "language": "en-US", "gender": "male"},
            {"id": "en-GB-female-1", "name": "Sophie", "language": "en-GB", "gender": "female"},
            {"id": "en-GB-male-1",   "name": "Oliver", "language": "en-GB", "gender": "male"},
            {"id": "ur-PK-female-1", "name": "Ayesha", "language": "ur-PK", "gender": "female"},
            {"id": "ur-PK-male-1",   "name": "Ahmed",  "language": "ur-PK", "gender": "male"},
        ]
    }


@router.get("/languages")
async def list_languages():
    return {
        "languages": [
            {"code": "en", "name": "English",    "native": "English"},
            {"code": "ur", "name": "Urdu",        "native": "اردو"},
            {"code": "ar", "name": "Arabic",      "native": "العربية"},
            {"code": "zh", "name": "Chinese",     "native": "中文"},
            {"code": "es", "name": "Spanish",     "native": "Español"},
            {"code": "fr", "name": "French",      "native": "Français"},
            {"code": "de", "name": "German",      "native": "Deutsch"},
            {"code": "hi", "name": "Hindi",       "native": "हिन्दी"},
            {"code": "ja", "name": "Japanese",    "native": "日本語"},
            {"code": "ko", "name": "Korean",      "native": "한국어"},
            {"code": "pt", "name": "Portuguese",  "native": "Português"},
            {"code": "ru", "name": "Russian",     "native": "Русский"},
            {"code": "tr", "name": "Turkish",     "native": "Türkçe"},
        ]
    }
