"""
Chat router — proxies requests to Ollama.
Supports streaming (SSE) and non-streaming completions.
FIX #16: Uses updated OLLAMA_MODEL_MAP (Llama3, Mistral, Gemma, DeepSeek).
"""

import json
import logging
from typing import AsyncGenerator, List, Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from core.config import settings, OLLAMA_MODEL_MAP
from services.ollama_service import ollama_service

logger = logging.getLogger(__name__)
router = APIRouter()


# ── Schemas ───────────────────────────────────────────────────────────────────
class ChatMessage(BaseModel):
    role:    str
    content: str


class ChatRequest(BaseModel):
    messages:    List[ChatMessage]
    model:       str   = Field(default="qwen-2.5-7b")
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    max_tokens:  int   = Field(default=2048, ge=1, le=32768)
    stream:      bool  = Field(default=False)


# ── Routes ────────────────────────────────────────────────────────────────────
@router.post("/completions")
async def chat_completions(req: ChatRequest):
    """Non-streaming and streaming chat completions via Ollama."""
    # FIX #16: resolve frontend model ID → Ollama pull name
    ollama_model = OLLAMA_MODEL_MAP.get(req.model, req.model)

    if not await ollama_service.is_running():
        raise HTTPException(
            status_code=503,
            detail="Ollama is not running. Start it with: ollama serve"
        )

    # Auto-pull if model not available
    available = await ollama_service.list_models()
    base_name  = ollama_model.split(":")[0]
    if not any(base_name in m for m in available):
        logger.info("Model %s not found locally — pulling from Ollama registry…", ollama_model)
        ok = await ollama_service.pull_model(ollama_model)
        if not ok:
            raise HTTPException(
                status_code=503,
                detail=f"Failed to pull model '{ollama_model}'. Check Ollama connectivity."
            )

    messages = [{"role": m.role, "content": m.content} for m in req.messages]

    if req.stream:
        async def event_stream() -> AsyncGenerator[str, None]:
            try:
                gen = ollama_service.stream_chat(messages, ollama_model, req.temperature, req.max_tokens)
                async for line in gen:
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                        content = data.get("message", {}).get("content", "")
                        if content:
                            chunk = {"choices": [{"delta": {"content": content}, "index": 0}]}
                            yield f"data: {json.dumps(chunk)}\n\n"
                        if data.get("done"):
                            yield "data: [DONE]\n\n"
                    except json.JSONDecodeError:
                        pass
            except Exception as e:
                logger.error("Streaming chat error: %s", e)
                yield f"data: {json.dumps({'error': str(e)})}\n\n"

        return StreamingResponse(
            event_stream(),
            media_type="text/event-stream",
            headers={"X-Accel-Buffering": "no", "Cache-Control": "no-cache"},
        )

    # Non-streaming
    response = await ollama_service.chat(messages, ollama_model, req.temperature, req.max_tokens)
    assistant_content = response.get("message", {}).get("content", "")
    prompt_tokens     = response.get("prompt_eval_count", 0)
    completion_tokens = response.get("eval_count", 0)

    return {
        "id":      f"chatcmpl-{id(response)}",
        "object":  "chat.completion",
        "model":   ollama_model,
        "choices": [{"index": 0, "message": {"role": "assistant", "content": assistant_content}, "finish_reason": "stop"}],
        "usage": {
            "prompt_tokens":     prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens":      prompt_tokens + completion_tokens,
        },
    }
