"""
Code execution router — runs code in isolated Docker containers.
Supports Python, JavaScript, TypeScript, Bash, Go, Rust, Java, C++, Ruby.
"""

import logging, time
from typing import Optional

import docker
from docker.errors import ImageNotFound, ContainerError, DockerException
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from core.config import settings

logger = logging.getLogger(__name__)
router = APIRouter()

# Docker images per language (pulled on demand)
LANGUAGE_IMAGES: dict[str, str] = {
    "python":     "python:3.11-slim",
    "javascript": "node:20-alpine",
    "typescript": "node:20-alpine",
    "bash":       "bash:5-alpine3.18",
    "go":         "golang:1.22-alpine",
    "rust":       "rust:1.78-slim",
    "java":       "openjdk:21-slim",
    "cpp":        "gcc:14-bookworm",
    "ruby":       "ruby:3.3-slim",
}

# Entry commands per language
LANGUAGE_COMMANDS: dict[str, list[str]] = {
    "python":     ["python3", "-c"],
    "javascript": ["node", "-e"],
    "typescript": ["npx", "--yes", "ts-node", "-e"],
    "bash":       ["bash", "-c"],
    "go":         ["sh", "-c"],   # wrapped differently below
    "rust":       ["sh", "-c"],
    "java":       ["sh", "-c"],
    "cpp":        ["sh", "-c"],
    "ruby":       ["ruby", "-e"],
}


class ExecuteRequest(BaseModel):
    code:     str = Field(..., min_length=1, max_length=50_000)
    language: str = Field(..., pattern="^(python|javascript|typescript|bash|go|rust|java|cpp|ruby)$")
    stdin:    str = Field(default="")


class ExecuteResponse(BaseModel):
    output:   str
    error:    Optional[str]
    exitCode: int
    duration: float


@router.post("/execute", response_model=ExecuteResponse)
async def execute_code(req: ExecuteRequest):
    lang  = req.language.lower()
    image = LANGUAGE_IMAGES.get(lang)
    if not image:
        raise HTTPException(status_code=400, detail=f"Unsupported language: {lang}")

    try:
        client = docker.from_env()
    except DockerException as e:
        raise HTTPException(status_code=503, detail=f"Docker unavailable: {e}. Is Docker running?")

    # Build the run command
    if lang == "go":
        cmd = ["sh", "-c", f"echo {repr(req.code)} | go run /dev/stdin 2>&1"]
        cmd = ["sh", "-c", "cat << 'GOEOF' > /tmp/main.go\n" + req.code + "\nGOEOF\ncd /tmp && go run main.go"]
    elif lang == "rust":
        cmd = ["sh", "-c", f"cat << 'RUSTEOF' > /tmp/main.rs\n{req.code}\nRUSTEOF\nrustc /tmp/main.rs -o /tmp/out 2>&1 && /tmp/out"]
    elif lang == "java":
        cmd = ["sh", "-c", f"cat << 'JAVAEOF' > /tmp/Main.java\n{req.code}\nJAVAEOF\njavac /tmp/Main.java -d /tmp 2>&1 && java -cp /tmp Main"]
    elif lang == "cpp":
        cmd = ["sh", "-c", f"cat << 'CPPEOF' > /tmp/main.cpp\n{req.code}\nCPPEOF\ng++ /tmp/main.cpp -o /tmp/out 2>&1 && /tmp/out"]
    else:
        cmd_prefix = LANGUAGE_COMMANDS[lang]
        cmd        = cmd_prefix + [req.code]

    t0 = time.time()
    try:
        container = client.containers.run(
            image,
            cmd,
            remove=True,
            mem_limit="128m",
            cpu_quota=50_000,          # 50% of one CPU
            network_disabled=True,
            read_only=True,
            tmpfs={"/tmp": "size=32m"},
            timeout=settings.CODE_TIMEOUT,
            stdin_open=bool(req.stdin),
            stdout=True,
            stderr=True,
            detach=False,
        )
        output   = container.decode("utf-8", errors="replace") if isinstance(container, bytes) else str(container)
        exit_code = 0
    except ContainerError as e:
        output    = (e.stderr or b"").decode("utf-8", errors="replace")
        exit_code = e.exit_status
    except Exception as e:
        logger.error("Code execution error: %s", e)
        raise HTTPException(status_code=500, detail=str(e))

    elapsed = round(time.time() - t0, 3)
    output  = output[:settings.CODE_MAX_OUTPUT]

    return ExecuteResponse(
        output=output if exit_code == 0 else "",
        error=output  if exit_code != 0 else None,
        exitCode=exit_code,
        duration=elapsed,
    )
