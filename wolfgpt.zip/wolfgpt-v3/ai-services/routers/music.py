"""
Music generation router — Meta MusicGen via transformers + audiocraft.
FIX #4: requires both `transformers[audio]` and `audiocraft` packages.
"""

from __future__ import annotations
import base64, gc, io, logging, time
from typing import Optional, Literal

import torch
import numpy as np
from fastapi import APIRouter, HTTPException, UploadFile, File, Form
from pydantic import BaseModel, Field, model_validator

from core.config import settings, MUSICGEN_MODEL_MAP

logger = logging.getLogger(__name__)
router = APIRouter()

_models: dict[str, tuple] = {}   # model_id → (processor, model)

MusicGenModelId = Literal[
    "musicgen-small", "musicgen-medium", "musicgen-large",
    "musicgen-melody", "musicgen-stereo-small", "musicgen-stereo-medium",
]

MUSICGEN_INFO = {
    "musicgen-small":         {"name": "MusicGen Small",  "params": "300M",  "stereo": False, "melody": False, "vram_gb": 2},
    "musicgen-medium":        {"name": "MusicGen Medium", "params": "1.5B",  "stereo": False, "melody": False, "vram_gb": 4},
    "musicgen-large":         {"name": "MusicGen Large",  "params": "3.3B",  "stereo": False, "melody": False, "vram_gb": 8},
    "musicgen-melody":        {"name": "MusicGen Melody", "params": "1.5B",  "stereo": False, "melody": True,  "vram_gb": 4},
    "musicgen-stereo-small":  {"name": "MusicGen Stereo Small",  "params": "300M", "stereo": True, "melody": False, "vram_gb": 2},
    "musicgen-stereo-medium": {"name": "MusicGen Stereo Medium", "params": "1.5B", "stereo": True, "melody": False, "vram_gb": 4},
}


# ── Model loading ─────────────────────────────────────────────────────────────
def get_device() -> str:
    if settings.USE_GPU and torch.cuda.is_available(): return "cuda"
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available(): return "mps"
    return "cpu"


def load_musicgen(model_id: str):
    """Lazy-load and cache a MusicGen processor + model pair.

    FIX #4: This function requires both `transformers[audio]` and
    `audiocraft` to be installed. The original requirements.txt was
    missing `audiocraft`, causing an ImportError at this import.
    """
    if model_id in _models:
        return _models[model_id]

    hf_name = MUSICGEN_MODEL_MAP.get(model_id, "facebook/musicgen-small")
    device  = get_device()
    dtype   = torch.float16 if device == "cuda" else torch.float32
    logger.info("Loading MusicGen %s (%s) on %s …", model_id, hf_name, device)

    try:
        # FIX #4: Both of these imports require `audiocraft` to be installed
        # alongside `transformers[audio]` — see requirements.txt
        from transformers import MusicgenForConditionalGeneration, AutoProcessor
        processor = AutoProcessor.from_pretrained(
            hf_name, cache_dir=settings.MUSICGEN_CACHE_DIR
        )
        model = MusicgenForConditionalGeneration.from_pretrained(
            hf_name,
            torch_dtype=dtype,
            cache_dir=settings.MUSICGEN_CACHE_DIR,
        )
        if device != "cuda":
            model = model.to(device)
        else:
            model.enable_model_cpu_offload()

        _models[model_id] = (processor, model)
        logger.info("✅ MusicGen %s ready on %s", model_id, device)
        return processor, model

    except ImportError as e:
        raise RuntimeError(
            f"MusicGen import failed: {e}. "
            "Run: pip install 'transformers[audio]' audiocraft"
        ) from e
    except Exception as e:
        logger.error("Failed to load MusicGen %s: %s", model_id, e)
        raise


def tensor_to_wav_base64(audio_tensor: torch.Tensor, sample_rate: int) -> str:
    """Convert MusicGen output tensor to base64-encoded WAV."""
    import soundfile as sf
    audio = audio_tensor.squeeze().cpu().numpy()
    if audio.ndim == 1:
        audio = audio[np.newaxis, :]
    buf = io.BytesIO()
    sf.write(buf, audio.T, sample_rate, format="WAV")
    return base64.b64encode(buf.getvalue()).decode()


def load_audio_bytes(content: bytes) -> np.ndarray:
    """Load raw audio bytes to float32 numpy array for melody conditioning."""
    import librosa
    buf      = io.BytesIO(content)
    waveform, _ = librosa.load(buf, sr=32000, mono=True)
    return waveform


# ── Schemas ───────────────────────────────────────────────────────────────────
class MusicGenRequest(BaseModel):
    prompt:   str              = Field(..., min_length=1, max_length=500)
    model:    MusicGenModelId  = Field(default="musicgen-small")
    duration: int              = Field(default=10, ge=5, le=30)


class MelodyRequest(BaseModel):
    prompt:  str             = Field(..., min_length=1)
    melody:  str             = Field(..., description="Base64-encoded audio for melody conditioning")
    model:   MusicGenModelId = Field(default="musicgen-melody")
    duration:int             = Field(default=10, ge=5, le=30)


class ContinuationRequest(BaseModel):
    prompt:   str             = Field(..., min_length=1)
    audio:    str             = Field(..., description="Base64-encoded audio to continue")
    model:    MusicGenModelId = Field(default="musicgen-small")
    duration: int             = Field(default=10, ge=5, le=30)


# ── Routes ────────────────────────────────────────────────────────────────────
@router.post("/generate")
async def generate_music(req: MusicGenRequest):
    try:
        t0             = time.time()
        processor, mdl = load_musicgen(req.model)
        sampling_rate  = mdl.config.audio_encoder.sampling_rate

        inputs = processor(text=[req.prompt], padding=True, return_tensors="pt")
        device = next(mdl.parameters()).device
        inputs = {k: v.to(device) for k, v in inputs.items()}

        max_new_tokens = int(sampling_rate / mdl.config.audio_encoder.hop_length * req.duration)

        with torch.no_grad():
            audio_values = mdl.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=True, guidance_scale=3.0)

        audio_b64 = tensor_to_wav_base64(audio_values[0], sampling_rate)
        elapsed   = round(time.time() - t0, 2)

        return {"audio": audio_b64, "model": req.model, "duration": req.duration, "sample_rate": sampling_rate, "generation_time": elapsed}

    except RuntimeError as e:
        if "out of memory" in str(e).lower():
            _models.clear(); gc.collect()
            if torch.cuda.is_available(): torch.cuda.empty_cache()
            raise HTTPException(status_code=507, detail="GPU OOM — please retry with musicgen-small.")
        logger.error("MusicGen error: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        logger.error("MusicGen error: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/melody")
async def generate_with_melody(req: MelodyRequest):
    info = MUSICGEN_INFO.get(req.model, {})
    if not info.get("melody"):
        raise HTTPException(status_code=400, detail=f"{req.model} does not support melody conditioning. Use musicgen-melody.")
    try:
        processor, mdl = load_musicgen(req.model)
        sampling_rate  = mdl.config.audio_encoder.sampling_rate

        melody_bytes   = base64.b64decode(req.melody)
        melody_np      = load_audio_bytes(melody_bytes)

        inputs = processor(
            text=[req.prompt], audio=melody_np, sampling_rate=sampling_rate,
            padding=True, return_tensors="pt",
        )
        device = next(mdl.parameters()).device
        inputs = {k: v.to(device) for k, v in inputs.items()}
        max_new_tokens = int(sampling_rate / mdl.config.audio_encoder.hop_length * req.duration)

        with torch.no_grad():
            audio_values = mdl.generate(**inputs, max_new_tokens=max_new_tokens)

        return {"audio": tensor_to_wav_base64(audio_values[0], sampling_rate), "model": req.model}

    except Exception as e:
        logger.error("Melody generation error: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/continuation")
async def continue_audio(req: ContinuationRequest):
    try:
        processor, mdl = load_musicgen(req.model)
        sampling_rate  = mdl.config.audio_encoder.sampling_rate

        audio_bytes    = base64.b64decode(req.audio)
        audio_np       = load_audio_bytes(audio_bytes)

        inputs = processor(
            text=[req.prompt], audio=audio_np, sampling_rate=sampling_rate,
            padding=True, return_tensors="pt",
        )
        device = next(mdl.parameters()).device
        inputs = {k: v.to(device) for k, v in inputs.items()}
        max_new_tokens = int(sampling_rate / mdl.config.audio_encoder.hop_length * req.duration)

        with torch.no_grad():
            audio_values = mdl.generate(**inputs, max_new_tokens=max_new_tokens)

        return {"audio": tensor_to_wav_base64(audio_values[0], sampling_rate), "model": req.model}

    except Exception as e:
        logger.error("Continuation error: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/models")
async def list_models():
    return {"models": [{"id": k, **v} for k, v in MUSICGEN_INFO.items()]}


@router.delete("/models")
async def evict_models():
    _models.clear(); gc.collect()
    if torch.cuda.is_available(): torch.cuda.empty_cache()
    return {"evicted": True}
