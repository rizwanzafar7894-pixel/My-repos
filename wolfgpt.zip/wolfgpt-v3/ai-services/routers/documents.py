"""Document parsing router — PDF, DOCX, CSV text extraction."""

import csv, io, logging
from fastapi import APIRouter, File, HTTPException, UploadFile
from core.config import settings

logger = logging.getLogger(__name__)
router = APIRouter()


@router.post("/parse")
async def parse_document(document: UploadFile = File(...)):
    content = await document.read()
    if len(content) > settings.MAX_DOC_SIZE:
        raise HTTPException(status_code=413, detail=f"File too large (max {settings.MAX_DOC_SIZE // 1024 // 1024} MB)")

    filename = document.filename or ""
    ext      = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""

    try:
        if ext == "pdf":
            text = _parse_pdf(content)
        elif ext in ("docx", "doc"):
            text = _parse_docx(content)
        elif ext == "csv":
            text = _parse_csv(content)
        elif ext in ("txt", "md", "rst"):
            text = content.decode("utf-8", errors="replace")
        else:
            # Try plain text as fallback
            try:
                text = content.decode("utf-8", errors="replace")
            except Exception:
                raise HTTPException(status_code=415, detail=f"Unsupported file type: .{ext}")

        word_count = len(text.split())
        char_count = len(text)
        return {
            "text":       text[:50_000],   # Truncate at 50k chars for context window
            "word_count": word_count,
            "char_count": char_count,
            "truncated":  char_count > 50_000,
            "filename":   filename,
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Document parse error (%s): %s", filename, e, exc_info=True)
        raise HTTPException(status_code=500, detail=f"Failed to parse document: {e}")


def _parse_pdf(content: bytes) -> str:
    try:
        from pypdf import PdfReader
        reader = PdfReader(io.BytesIO(content))
        pages  = [page.extract_text() or "" for page in reader.pages]
        return "\n\n".join(p for p in pages if p.strip())
    except ImportError:
        raise HTTPException(status_code=501, detail="pypdf not installed. Run: pip install pypdf")


def _parse_docx(content: bytes) -> str:
    try:
        import docx
        doc        = docx.Document(io.BytesIO(content))
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        # Include table text
        for table in doc.tables:
            for row in table.rows:
                paragraphs.append(" | ".join(cell.text for cell in row.cells))
        return "\n\n".join(paragraphs)
    except ImportError:
        raise HTTPException(status_code=501, detail="python-docx not installed. Run: pip install python-docx")


def _parse_csv(content: bytes) -> str:
    text    = content.decode("utf-8", errors="replace")
    reader  = csv.reader(io.StringIO(text))
    rows    = [", ".join(row) for row in reader]
    return "\n".join(rows)
