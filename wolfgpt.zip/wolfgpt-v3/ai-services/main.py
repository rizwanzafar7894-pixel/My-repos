"""
WolfGPT AI Services — FastAPI micro-service
============================================
Runs on port 8000, called exclusively by the Node.js backend.

Endpoints:
  POST /v1/chat/completions        → LLMs via Ollama
  POST /v1/images/generate         → FLUX / SDXL via diffusers
  POST /v1/images/img2img          → Image-to-image
  POST /v1/images/inpaint          → Inpainting
  POST /v1/images/upscale          → Upscaling
  POST /v1/voice/stt               → Whisper STT
  POST /v1/voice/tts               → Coqui TTS
  POST /v1/code/execute            → Sandboxed execution
  POST /v1/documents/parse         → PDF / DOCX / CSV extraction
  POST /v1/music/generate          → MusicGen text-to-music
  POST /v1/music/melody            → Melody-conditioned generation
  POST /v1/music/continuation      → Audio continuation
  GET  /health                     → Service health
"""

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn

from routers import chat, images, voice, code, documents, music, admin
from core.config import settings
from core.logging import setup_logging

setup_logging()
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 WolfGPT AI Service starting on port %s …", settings.PORT)
    logger.info("   Ollama URL : %s", settings.OLLAMA_URL)
    logger.info("   Default LLM: %s", settings.OLLAMA_MODEL)
    logger.info("   Image model: %s", settings.IMAGE_MODEL)
    logger.info("   Whisper    : %s on %s", settings.WHISPER_MODEL, settings.WHISPER_DEVICE)
    logger.info("   GPU        : %s", settings.USE_GPU)
    yield
    logger.info("🛑 WolfGPT AI Service shutting down")


app = FastAPI(
    title="WolfGPT AI Services",
    version="3.0.0",
    description="AI micro-service: chat, images, voice, code, documents, music",
    lifespan=lifespan,
    # Swagger/ReDoc only in DEBUG mode
    docs_url="/docs"   if os.environ.get("DEBUG", "").lower() in ("1", "true") else None,
    redoc_url="/redoc" if os.environ.get("DEBUG", "").lower() in ("1", "true") else None,
)


# ── CORS (internal only — backend:4000) ──────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_methods=["POST", "GET", "DELETE"],
    allow_headers=["Content-Type", "Authorization"],
)


# ── Trusted host guard ────────────────────────────────────────────────────────
_TRUSTED = {
    h.strip()
    for h in os.environ.get("TRUSTED_HOSTS", "localhost,127.0.0.1,backend").split(",")
    if h.strip()
} | {"localhost", "127.0.0.1"}


@app.middleware("http")
async def trusted_host_guard(request: Request, call_next):
    host = request.headers.get("host", "").split(":")[0]
    if _TRUSTED and host not in _TRUSTED:
        logger.warning("Blocked request from untrusted host: %s", host)
        return JSONResponse(status_code=400, content={"detail": "Invalid host header"})
    return await call_next(request)


# ── Global exception handler ──────────────────────────────────────────────────
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error("Unhandled exception on %s: %s", request.url.path, exc, exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "type": type(exc).__name__},
    )


# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(chat.router,      prefix="/v1/chat",      tags=["Chat"])
app.include_router(images.router,    prefix="/v1/images",    tags=["Images"])
app.include_router(voice.router,     prefix="/v1/voice",     tags=["Voice"])
app.include_router(code.router,      prefix="/v1/code",      tags=["Code"])
app.include_router(documents.router, prefix="/v1/documents", tags=["Documents"])
app.include_router(music.router,     prefix="/v1/music",     tags=["Music"])
app.include_router(admin.router,     prefix="/admin",        tags=["Admin"])


# ── Health ────────────────────────────────────────────────────────────────────
@app.get("/health", tags=["Health"])
async def health():
    return {
        "status":  "healthy",
        "service": "wolfgpt-ai-services",
        "version": "3.0.0",
        "models": {
            "chat":  settings.OLLAMA_MODEL,
            "image": settings.IMAGE_MODEL,
            "stt":   settings.WHISPER_MODEL,
            "tts":   settings.TTS_MODEL,
            "music": settings.MUSICGEN_DEFAULT_MODEL,
        },
    }


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=settings.PORT,
        reload=settings.DEBUG,
        workers=1,          # 1 worker — GPU memory is not shareable
        log_level="info",
        access_log=not settings.DEBUG,
    )
