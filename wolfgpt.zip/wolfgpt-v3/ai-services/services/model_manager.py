"""Model manager — tracks download status and provides health info."""

import logging
from core.config import settings, OLLAMA_MODEL_MAP, IMAGE_MODEL_MAP, WHISPER_MODEL_MAP, MUSICGEN_MODEL_MAP
from services.ollama_service import ollama_service

logger = logging.getLogger(__name__)


class ModelManager:

    async def status(self) -> dict:
        """Return status of all model categories."""
        ollama_running = await ollama_service.is_running()
        ollama_models  = await ollama_service.list_models() if ollama_running else []

        return {
            "ollama": {
                "running":  ollama_running,
                "url":      settings.OLLAMA_URL,
                "models":   ollama_models,
                "supported": list(OLLAMA_MODEL_MAP.keys()),
            },
            "image": {
                "default": settings.IMAGE_MODEL,
                "supported": list(IMAGE_MODEL_MAP.keys()),
                "cache_dir": settings.IMAGE_CACHE_DIR,
            },
            "whisper": {
                "default": settings.WHISPER_MODEL,
                "device":  settings.WHISPER_DEVICE,
                "supported": list(WHISPER_MODEL_MAP.keys()),
            },
            "musicgen": {
                "default": settings.MUSICGEN_DEFAULT_MODEL,
                "supported": list(MUSICGEN_MODEL_MAP.keys()),
            },
        }

    async def pull_all_chat_models(self, models: list[str] | None = None) -> dict:
        """Pull a list of Ollama models. Defaults to just the default model."""
        targets = models or [settings.OLLAMA_MODEL]
        results = {}
        for model_id in targets:
            ollama_name      = OLLAMA_MODEL_MAP.get(model_id, model_id)
            results[model_id] = await ollama_service.pull_model(ollama_name)
        return results


model_manager = ModelManager()
