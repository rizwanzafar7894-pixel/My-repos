"""
Voice service — Whisper STT + Coqui TTS.
FIX #15: This module was present but never imported by routers/voice.py,
which duplicated model loading inline and left multi-speaker TTS
features unreachable. Now routers/voice.py imports this module.
"""

import logging
import os
from typing import Optional

from core.config import settings, WHISPER_MODEL_MAP

logger = logging.getLogger(__name__)

# Global lazy handles
_whisper_models: dict[str, object] = {}
_tts_model = None


class VoiceService:

    # ── Whisper STT ────────────────────────────────────────────────────────────
    def get_whisper(self, size: str = "base"):
        size = WHISPER_MODEL_MAP.get(size, "base")
        if size not in _whisper_models:
            logger.info("Loading Whisper model: %s on %s", size, settings.WHISPER_DEVICE)
            import whisper
            _whisper_models[size] = whisper.load_model(
                size,
                device=settings.WHISPER_DEVICE,
                download_root=settings.WHISPER_CACHE_DIR,
            )
            logger.info("✅ Whisper %s ready", size)
        return _whisper_models[size]

    def transcribe(self, audio_path: str, model_size: str = "base", language: Optional[str] = None) -> dict:
        model  = self.get_whisper(model_size)
        result = model.transcribe(
            audio_path,
            language=language,
            fp16=False,      # safe for CPU
            verbose=False,
        )
        return result

    # ── Coqui TTS ──────────────────────────────────────────────────────────────
    def get_tts(self):
        global _tts_model
        if _tts_model is None:
            logger.info("Loading Coqui TTS model: %s", settings.TTS_MODEL)
            from TTS.api import TTS
            _tts_model = TTS(model_name=settings.TTS_MODEL, progress_bar=False)
            logger.info("✅ Coqui TTS ready")
        return _tts_model

    def synthesize(
        self,
        text:       str,
        output_path: str,
        speed:      float = 1.0,
        speaker:    Optional[str] = None,
        language:   Optional[str] = None,
    ) -> None:
        """Synthesize text to WAV file. Extra kwargs forwarded to Coqui TTS."""
        tts = self.get_tts()
        kwargs: dict = {"text": text, "file_path": output_path}
        if speed != 1.0:
            kwargs["speed"] = speed
        if speaker:
            kwargs["speaker"] = speaker
        if language:
            kwargs["language"] = language
        tts.tts_to_file(**kwargs)

    def list_speakers(self) -> list[str]:
        """Return available speakers for multi-speaker models."""
        try:
            tts = self.get_tts()
            return getattr(tts, "speakers", []) or []
        except Exception:
            return []

    def list_languages(self) -> list[str]:
        """Return supported languages for multilingual TTS models."""
        try:
            tts = self.get_tts()
            return getattr(tts, "languages", []) or []
        except Exception:
            return []


voice_service = VoiceService()
