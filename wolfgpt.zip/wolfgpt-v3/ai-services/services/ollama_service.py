"""
OllamaService — manages Ollama model lifecycle and inference.
FIX #16: pull_model and ensure_model use the updated OLLAMA_MODEL_MAP
which now includes Llama3, Mistral, Gemma, DeepSeek, CodeLlama.
"""

import logging
from typing import AsyncGenerator

import httpx

from core.config import settings, OLLAMA_MODEL_MAP

logger = logging.getLogger(__name__)


class OllamaService:
    def __init__(self, base_url: str | None = None):
        self.base_url = base_url or settings.OLLAMA_URL

    async def is_running(self) -> bool:
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                r = await client.get(f"{self.base_url}/api/tags")
                return r.status_code == 200
        except Exception:
            return False

    async def list_models(self) -> list[str]:
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                r = await client.get(f"{self.base_url}/api/tags")
                r.raise_for_status()
                return [m["name"] for m in r.json().get("models", [])]
        except Exception as e:
            logger.error("Failed to list Ollama models: %s", e)
            return []

    async def pull_model(self, model_name: str) -> bool:
        logger.info("Pulling Ollama model: %s", model_name)
        try:
            async with httpx.AsyncClient(timeout=3600) as client:
                async with client.stream(
                    "POST", f"{self.base_url}/api/pull",
                    json={"name": model_name, "stream": True},
                ) as resp:
                    resp.raise_for_status()
                    async for line in resp.aiter_lines():
                        if '"status":"success"' in line:
                            logger.info("✅ Model pulled: %s", model_name)
                            return True
            return True
        except Exception as e:
            logger.error("Failed to pull model %s: %s", model_name, e)
            return False

    async def ensure_model(self, model_id: str) -> bool:
        """Pull model if not present. model_id is the WolfGPT alias."""
        # FIX #16: uses updated model map
        ollama_name = OLLAMA_MODEL_MAP.get(model_id, model_id)
        available   = await self.list_models()
        base        = ollama_name.split(":")[0]
        if any(base in m for m in available):
            return True
        return await self.pull_model(ollama_name)

    async def chat(
        self,
        messages:    list[dict],
        model:       str   = "qwen2.5:7b",
        temperature: float = 0.7,
        max_tokens:  int   = 2048,
    ) -> dict:
        payload = {
            "model":    model,
            "messages": messages,
            "stream":   False,
            "options":  {"temperature": temperature, "num_predict": max_tokens},
        }
        async with httpx.AsyncClient(timeout=120) as client:
            r = await client.post(f"{self.base_url}/api/chat", json=payload)
            r.raise_for_status()
            return r.json()

    async def stream_chat(
        self,
        messages:    list[dict],
        model:       str   = "qwen2.5:7b",
        temperature: float = 0.7,
        max_tokens:  int   = 2048,
    ) -> AsyncGenerator[str, None]:
        payload = {
            "model":    model,
            "messages": messages,
            "stream":   True,
            "options":  {"temperature": temperature, "num_predict": max_tokens},
        }
        async with httpx.AsyncClient(timeout=180) as client:
            async with client.stream("POST", f"{self.base_url}/api/chat", json=payload) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if line:
                        yield line


ollama_service = OllamaService()
