# WolfGPT v3 — Complete Setup Guide

## Prerequisites

| Tool | Required | Version | Install |
|---|---|---|---|
| Docker | ✅ | 24.x+ | [docs.docker.com](https://docs.docker.com/get-docker/) |
| Docker Compose | ✅ | v2 | Bundled with Docker Desktop |
| NVIDIA drivers | GPU only | 525+ | [nvidia.com/drivers](https://www.nvidia.com/drivers) |
| CUDA toolkit | GPU only | 12.x | [developer.nvidia.com/cuda](https://developer.nvidia.com/cuda-downloads) |
| NVIDIA Container Toolkit | GPU only | latest | [docs.nvidia.com/datacenter/cloud-native](https://docs.nvidia.com/datacenter/cloud-native/container-toolkit/install-guide.html) |

---

## Step 1 — Firebase Setup

1. Go to [console.firebase.google.com](https://console.firebase.google.com) → Create project
2. **Enable Authentication:** Authentication → Sign-in method → Enable **Email/Password** + **Google**
3. **Create Firestore:** Firestore Database → Create database → Production mode
4. **Deploy security rules:**
   ```bash
   npm install -g firebase-tools
   firebase login
   firebase use your-project-id
   firebase deploy --only firestore:rules,firestore:indexes
   ```
5. **Get Admin SDK key:** Project Settings → Service accounts → Generate new private key
   → Save as `firebase-admin-key.json` in the project root
6. **Get Web SDK config:** Project Settings → Your apps → Add Web app → copy config values

---

## Step 2 — Configure Environment Files

```bash
# Root (domain + Redis password)
cp .env.example .env
nano .env

# Backend (Firebase, payments, Redis)
cp backend/.env.example backend/.env
nano backend/.env

# AI Services (model settings)
cp ai-services/.env.example ai-services/.env
nano ai-services/.env

# Frontend (Firebase web SDK, Stripe, PayPal)
cp frontend/.env.local.example frontend/.env.local
nano frontend/.env.local
```

---

## Step 3 — Start (Development)

```bash
# With NVIDIA GPU:
docker compose up -d
# OR: make dev

# CPU-only VPS (no GPU):
docker compose -f docker-compose.yml -f docker-compose.cpu.yml up -d
# OR: make dev-cpu

# One-command launcher:
./start.sh           # GPU
./start.sh dev --no-gpu  # CPU
```

Open → **http://localhost:3000**

---

## Step 4 — Pull AI Models

```bash
# Minimum (free tier only):
./scripts/pull-models.sh --minimal
# OR: make pull-models-minimal

# All standard models (recommended, 4GB+ RAM per model):
./scripts/pull-models.sh
# OR: make pull-models

# All + large GPU variants (24GB+ VRAM):
./scripts/pull-models.sh --gpu
# OR: make pull-models-gpu
```

---

## Production Deployment (VPS + GPU)

### Recommended Server Specs

| Component | Minimum | Recommended |
|---|---|---|
| CPU | 4 cores | 8+ cores |
| RAM | 16 GB | 32 GB |
| SSD | 100 GB | 500 GB NVMe |
| GPU | NVIDIA RTX 3080 (10GB) | A100 (40GB) |
| OS | Ubuntu 22.04 LTS | Ubuntu 22.04 LTS |

### Deploy Steps

```bash
# 1. Set domain + Redis password
nano .env    # DOMAIN=wolfgpt.yourdomain.com + REDIS_PASSWORD=...

# 2. Fill in all credentials
nano backend/.env
nano frontend/.env.local
cp your-firebase-key.json firebase-admin-key.json

# 3. Provision TLS certificates (needs port 80 open)
./scripts/setup-ssl.sh wolfgpt.yourdomain.com admin@yourdomain.com

# 4. Full automated deploy
./scripts/deploy.sh
# OR: make deploy
```

### CPU-only Production

```bash
docker compose -f docker-compose.prod.yml -f docker-compose.cpu.yml up -d
# OR: ./start.sh prod --no-gpu
```

---

## Payment Provider Setup

### Stripe
1. Create account: [stripe.com](https://stripe.com)
2. Dashboard → Products → Create Basic, Premium, Pro plans (monthly + yearly prices)
3. Dashboard → Developers → Webhooks → Add:
   - URL: `https://yourdomain.com/api/payment/stripe/webhook`
   - Events: `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.payment_failed`, `invoice.payment_succeeded`
4. Add keys to `backend/.env`

### PayPal
1. [developer.paypal.com](https://developer.paypal.com) → My Apps → Create App
2. [paypal.com/billing/plans](https://www.paypal.com/billing/plans) → Create subscription plans
3. Add webhook: `https://yourdomain.com/api/payment/paypal/webhook`
4. Add keys to `backend/.env`

### JazzCash (Pakistan)
1. [jazzcash.com.pk](https://jazzcash.com.pk) → Become a Merchant
2. Sandbox: [sandbox.jazzcash.com.pk](https://sandbox.jazzcash.com.pk)
3. After approval: add Merchant ID, Password, Integrity Salt to `backend/.env`

### EasyPaisa (Pakistan)
1. Contact EasyPaisa merchant support
2. Request: Store ID, Secret Key, Hash Key
3. Add to `backend/.env`

---

## Monitoring (Optional)

```bash
# Start Prometheus + Grafana
make monitoring

# Access
# Prometheus → http://localhost:9090
# Grafana    → http://localhost:3001  (admin / your GRAFANA_PASSWORD)
```

---

## Operations

```bash
make health     # Run health checks
make backup     # Backup Redis + logs
make logs       # Tail all service logs
make status     # Show container status

# View logs for a specific service:
docker compose logs -f backend
docker compose logs -f ai-service
docker compose logs -f nginx
```

---

## Troubleshooting

### Services won't start
```bash
docker compose logs redis
docker compose logs ai-service
docker compose logs backend
docker compose logs frontend
```

### AI models not responding
```bash
# Check Ollama is running
docker exec wolfgpt-ollama ollama list

# Pull the default model
docker exec wolfgpt-ollama ollama pull qwen2.5:7b

# Check GPU availability
docker exec wolfgpt-ollama nvidia-smi
```

### Firebase auth errors
- Verify `firebase-admin-key.json` exists and is valid
- Check `FIREBASE_STORAGE_BUCKET` matches your project ID
- Ensure Firestore is enabled in the same project

### Payment webhooks not firing
- Use `stripe listen --forward-to localhost:4000/api/payment/stripe/webhook` for Stripe local testing
- Verify webhook secrets match `.env` values
- HTTPS is required for PayPal and JazzCash callbacks in production

### CORS errors
- Ensure `ALLOWED_ORIGINS` in `backend/.env` includes your frontend URL exactly
- No trailing slashes in URLs

### GPU not detected
```bash
# Verify NVIDIA Container Toolkit
docker run --rm --gpus all nvidia/cuda:12.1-base-ubuntu22.04 nvidia-smi
```
