# 🐺 WolfGPT v3

> Production-ready AI SaaS platform — 100% open-source models, self-hosted, GPU-accelerated.

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](./LICENSE)
[![Docker](https://img.shields.io/badge/Docker-Ready-blue)](./docker-compose.yml)
[![GPU](https://img.shields.io/badge/GPU-NVIDIA-green)](./docker-compose.yml)

---

## ✨ Features

| Feature | Technology |
|---|---|
| **AI Chat** | Qwen 2.5, Llama 3, Mistral, Gemma, DeepSeek via Ollama |
| **Image Generation** | FLUX.1-schnell, FLUX.1-dev, SDXL (txt2img, img2img, inpaint) |
| **Voice STT** | OpenAI Whisper (tiny → large-v3) |
| **Voice TTS** | Coqui TTS |
| **Code Execution** | Sandboxed Docker (Python, JS, Go, Rust, Java, C++, Ruby) |
| **Music Generation** | MusicGen (small / medium / large / melody / stereo) |
| **Document AI** | PDF, DOCX, CSV parsing + RAG Q&A |

**Payments:** Stripe · PayPal · JazzCash · EasyPaisa  
**Plans:** Free · Basic ($9.99/mo) · Premium ($19.99/mo) · Pro ($39.99/mo)

---

## 🚀 Quick Start

```bash
# 1. Copy and fill in env files
cp .env.example               .env
cp backend/.env.example       backend/.env
cp ai-services/.env.example   ai-services/.env
cp frontend/.env.local.example frontend/.env.local

# 2. Add Firebase credentials
cp your-firebase-key.json firebase-admin-key.json

# 3. Start (GPU)
docker compose up -d

# 4. Pull AI models
./scripts/pull-models.sh --minimal   # qwen2.5:7b only (fastest)

# 5. Open
open http://localhost:3000
```

CPU-only VPS? Add `-f docker-compose.cpu.yml` to any compose command.

---

## 🏗 Architecture

```
┌─────────────────────────────────────────────────┐
│                   Nginx (443/80)                │
│              Rate limiting · TLS · SSE          │
└──────────────┬──────────────────┬───────────────┘
               │                  │
    ┌──────────▼──────┐  ┌────────▼──────────┐
    │  Frontend       │  │  Backend           │
    │  Next.js 14     │  │  Express + TypeScript│
    │  Tailwind CSS   │  │  Firebase Auth      │
    │  Framer Motion  │  │  Redis rate-limit   │
    └─────────────────┘  └────────┬───────────┘
                                  │
                         ┌────────▼───────────┐
                         │  AI Services       │
                         │  FastAPI + Python  │
                         ├────────────────────┤
                         │ Ollama (LLMs)      │
                         │ Diffusers (images) │
                         │ Whisper (STT)      │
                         │ Coqui TTS          │
                         │ MusicGen           │
                         │ Docker (code exec) │
                         └────────────────────┘
```

---

## 🖥 Services & Ports

| Service | Port | Purpose |
|---|---|---|
| Frontend | 3000 | Next.js app |
| Backend | 4000 | Express API |
| AI Service | 8000 | FastAPI / models |
| Ollama | 11434 | LLM inference |
| Redis | 6379 | Cache + rate limit |
| Nginx | 80/443 | Reverse proxy (prod) |
| Prometheus | 9090 | Metrics (optional) |
| Grafana | 3001 | Dashboards (optional) |

---

## 🤖 Supported AI Models

### Chat (via Ollama)
`qwen-2.5-7b` · `qwen-2.5-32b` · `qwen-2.5-72b` · `llama-3.2-3b` · `llama-3.1-8b` · `llama-3.1-70b` · `mistral-7b` · `gemma-2-9b` · `deepseek-r1-7b` · `deepseek-coder-v2` · `codellama-7b` · `llava-7b` · `llava-13b` · `llava-34b`

### Images (via diffusers)
`flux-schnell` · `flux-dev` · `flux-pro` · `sdxl-base` · `sdxl-refiner`

### Music (via transformers + audiocraft)
`musicgen-small` · `musicgen-medium` · `musicgen-large` · `musicgen-melody` · `musicgen-stereo-small`

---

## 📦 Commands

```bash
make dev              # Start development (GPU)
make dev-cpu          # Start development (CPU)
make prod             # Start production
make deploy           # Full VPS deploy
make pull-models      # Pull all Ollama models
make health           # Health check all services
make backup           # Backup Redis + logs
make monitoring       # Start Prometheus + Grafana
make logs             # Tail all logs
make status           # Container status
make clean            # Remove everything
```

---

## 🛡 Security Highlights

- Firebase Admin SDK token verification with revocation checking
- Redis-backed rate limiting (per-minute, hourly, daily) per user tier
- JazzCash HMAC-SHA256 signature verification (pp_Password excluded from hash per spec)
- EasyPaisa HMAC-SHA256 webhook verification with timing-safe comparison
- Stripe webhook signature verification
- PayPal webhook signature verification via PayPal API
- Helmet.js security headers on all API responses
- Non-root Docker containers for all services
- CORS locked to configured origins only
- Joi input validation on all endpoints

---

## 📄 License

MIT — see [LICENSE](./LICENSE)
