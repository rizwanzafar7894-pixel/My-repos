#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# WolfGPT v3 — One-command startup
# ─────────────────────────────────────────────────────────────────────────────
# Usage:
#   ./start.sh                — dev, GPU
#   ./start.sh dev            — dev, GPU
#   ./start.sh dev --no-gpu   — dev, CPU-only
#   ./start.sh prod           — prod, GPU
#   ./start.sh prod --no-gpu  — prod, CPU-only
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

MODE="${1:-dev}"
GPU="${2:-}"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'
log()  { echo -e "${GREEN}[WolfGPT]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()  { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Prerequisites
command -v docker &>/dev/null          || err "Docker not installed"
docker compose version &>/dev/null     || err "Docker Compose v2 required"

compose_cmd() {
  local base="$1"
  local cmd="docker compose -f $base"
  [[ "$GPU" == "--no-gpu" ]] && { warn "CPU-only mode"; cmd="$cmd -f docker-compose.cpu.yml"; }
  echo "$cmd"
}

# ── DEV ───────────────────────────────────────────────────────────────────────
if [[ "$MODE" == "dev" ]]; then
  log "Starting in DEVELOPMENT mode…"

  # Auto-create env files from examples if missing
  for pair in ".env.example:.env" "backend/.env.example:backend/.env" "ai-services/.env.example:ai-services/.env" "frontend/.env.local.example:frontend/.env.local"; do
    src="${pair%%:*}"; dst="${pair##*:}"
    [[ -f "$dst" ]] || { warn "$dst missing — copying from $src"; cp "$src" "$dst"; }
  done

  CMD=$(compose_cmd "docker-compose.yml")
  log "Building and starting…"
  $CMD up -d --build

  # Pull default model
  sleep 5
  docker exec wolfgpt-ollama ollama list 2>/dev/null | grep -q "qwen2.5:7b" \
    || { log "Pulling qwen2.5:7b (first run)…"; docker exec wolfgpt-ollama ollama pull qwen2.5:7b; }

  $CMD ps
  log ""
  log "✅ WolfGPT is running!"
  log "   Frontend  →  http://localhost:3000"
  log "   Backend   →  http://localhost:4000"
  log "   AI API    →  http://localhost:8000"
  log "   Ollama    →  http://localhost:11434"
  log ""
  log "Logs:  docker compose logs -f"
  log "Stop:  docker compose down"

# ── PROD ──────────────────────────────────────────────────────────────────────
elif [[ "$MODE" == "prod" ]]; then
  log "Starting in PRODUCTION mode…"
  [[ -f .env ]]                    || err ".env not found"
  [[ -f backend/.env ]]            || err "backend/.env not found"
  [[ -f ai-services/.env ]]        || err "ai-services/.env not found"
  [[ -f frontend/.env.local ]]     || err "frontend/.env.local not found"
  [[ -f firebase-admin-key.json ]] || err "firebase-admin-key.json not found"

  set -a; source .env; set +a
  [[ -z "${DOMAIN:-}" ]]         && err "DOMAIN must be set in .env"
  [[ -z "${REDIS_PASSWORD:-}" ]] && err "REDIS_PASSWORD must be set in .env"

  CMD=$(compose_cmd "docker-compose.prod.yml")
  DOMAIN="$DOMAIN" REDIS_PASSWORD="$REDIS_PASSWORD" $CMD build
  DOMAIN="$DOMAIN" REDIS_PASSWORD="$REDIS_PASSWORD" $CMD up -d
  sleep 30
  $CMD ps

  log ""
  log "✅ WolfGPT Production is running!"
  log "   App:  https://$DOMAIN"
  log ""
  log "Logs:  $CMD logs -f"
  log "Stop:  $CMD down"

else
  err "Unknown mode: '$MODE'. Use: dev | prod"
fi
