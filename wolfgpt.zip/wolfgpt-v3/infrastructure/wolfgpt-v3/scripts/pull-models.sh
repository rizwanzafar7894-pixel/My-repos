#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# WolfGPT v3 — Pull Ollama Models
# ─────────────────────────────────────────────────────────────────────────────
# Usage:
#   ./scripts/pull-models.sh              — all standard models
#   ./scripts/pull-models.sh --minimal    — free tier only (qwen2.5:7b)
#   ./scripts/pull-models.sh --gpu        — all models including large GPU variants
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

MODE="${1:---all}"
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
log()  { echo -e "${GREEN}[Models]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
ok()   { echo -e "${GREEN}  ✅ $1${NC}"; }
fail() { echo -e "${RED}  ❌ Failed: $1${NC}"; }

# Detect Ollama runner (Docker or local)
if docker ps --format '{{.Names}}' 2>/dev/null | grep -q wolfgpt-ollama; then
  OLLAMA="docker exec wolfgpt-ollama ollama"
elif command -v ollama &>/dev/null; then
  OLLAMA="ollama"
else
  echo -e "${RED}[ERROR]${NC} Ollama not found. Start wolfgpt-ollama container or install Ollama."
  exit 1
fi

pull() {
  local model="$1" desc="$2"
  log "Pulling $model — $desc"
  $OLLAMA pull "$model" &>/dev/null && ok "$model" || fail "$model"
}

# ── Model lists ──────────────────────────────────────────────────────────────
# Minimal: free tier only
MINIMAL=(
  "qwen2.5:7b|Qwen 2.5 7B (default free tier)"
)

# Standard: all spec models (4GB+ RAM required per model)
STANDARD=(
  "qwen2.5:7b|Qwen 2.5 7B"
  "llama3.2:3b|Llama 3.2 3B (Meta, fast)"
  "llama3.1:8b|Llama 3.1 8B (Meta)"
  "mistral:7b|Mistral 7B"
  "gemma2:9b|Gemma 2 9B (Google)"
  "deepseek-r1:7b|DeepSeek R1 7B (reasoning)"
  "deepseek-coder-v2:16b|DeepSeek Coder V2 (code)"
  "codellama:7b|Code Llama 7B"
  "llava:7b|LLaVA 7B (vision)"
)

# Large GPU models — require 24GB+ VRAM
GPU_LARGE=(
  "qwen2.5:32b|Qwen 2.5 32B (premium)"
  "llama3.1:70b|Llama 3.1 70B (pro)"
  "llava:13b|LLaVA 13B (premium vision)"
)

echo ""
log "WolfGPT v3 — Ollama Model Pull"
log "Mode: $MODE"
echo ""

case "$MODE" in
  --minimal)
    log "Pulling minimal model set (free tier)…"
    for entry in "${MINIMAL[@]}"; do
      IFS='|' read -r model desc <<< "$entry"
      pull "$model" "$desc"
    done
    ;;
  --gpu)
    log "Pulling all models including large GPU variants…"
    for entry in "${STANDARD[@]}" "${GPU_LARGE[@]}"; do
      IFS='|' read -r model desc <<< "$entry"
      pull "$model" "$desc"
    done
    ;;
  *)
    log "Pulling all standard models…"
    for entry in "${STANDARD[@]}"; do
      IFS='|' read -r model desc <<< "$entry"
      pull "$model" "$desc"
    done
    ;;
esac

echo ""
log "✅ Model pull complete. Available models:"
$OLLAMA list
