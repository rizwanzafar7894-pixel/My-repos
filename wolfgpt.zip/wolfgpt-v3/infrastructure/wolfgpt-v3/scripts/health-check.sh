#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# WolfGPT v3 — Health Check Script
# ─────────────────────────────────────────────────────────────────────────────
# Usage:  ./scripts/health-check.sh
# Cron (every 5 min):
#   */5 * * * * /path/to/scripts/health-check.sh
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
ok()   { echo -e "${GREEN}  ✅ $1${NC}"; }
warn() { echo -e "${YELLOW}  ⚠️  $1${NC}"; }
fail() { echo -e "${RED}  ❌ $1${NC}"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$SCRIPT_DIR")"
[[ -f "$ROOT/.env" ]] && { set -a; source "$ROOT/.env"; set +a; }

echo ""
echo "WolfGPT v3 — Health Check — $(date)"
echo "──────────────────────────────────────"

ALL_OK=true

check_http() {
  local name="$1" url="$2" expected="$3"
  local status
  status=$(curl -sf --max-time 5 "$url" 2>/dev/null | python3 -c "import sys,json; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null || echo "unreachable")
  if [[ "$status" == "$expected" ]]; then
    ok "$name: $status"
  else
    fail "$name: $status (expected $expected)"
    ALL_OK=false
  fi
}

check_container() {
  local name="$1" container="$2"
  if docker ps --format '{{.Names}}' 2>/dev/null | grep -q "^$container$"; then
    local health
    health=$(docker inspect --format '{{.State.Health.Status}}' "$container" 2>/dev/null || echo "no health check")
    if [[ "$health" == "healthy" || "$health" == "no health check" ]]; then
      ok "$name: running ($health)"
    else
      warn "$name: $health"
      ALL_OK=false
    fi
  else
    fail "$name: not running"
    ALL_OK=false
  fi
}

# ── Containers ────────────────────────────────────────────────────────────────
echo ""
echo "Containers:"
check_container "Redis"    "wolfgpt-redis"
check_container "Ollama"   "wolfgpt-ollama"
check_container "AI Svc"   "wolfgpt-ai"
check_container "Backend"  "wolfgpt-backend"
check_container "Frontend" "wolfgpt-frontend"

# ── HTTP endpoints ─────────────────────────────────────────────────────────────
echo ""
echo "HTTP Endpoints:"
check_http "Backend"   "http://localhost:4000/health" "healthy"
check_http "AI Svc"    "http://localhost:8000/health" "healthy"
check_http "Frontend"  "http://localhost:3000"        "healthy" 2>/dev/null || warn "Frontend: HTTP check (non-JSON response is OK)"

# ── Disk space ────────────────────────────────────────────────────────────────
echo ""
echo "Disk:"
DF_OUT=$(df -h / | tail -1)
USED_PCT=$(echo "$DF_OUT" | awk '{print $5}' | tr -d '%')
if [[ "$USED_PCT" -lt 80 ]]; then
  ok "Disk: $USED_PCT% used"
elif [[ "$USED_PCT" -lt 90 ]]; then
  warn "Disk: $USED_PCT% used (approaching limit)"
else
  fail "Disk: $USED_PCT% used (CRITICAL)"
  ALL_OK=false
fi

# ── GPU (if available) ────────────────────────────────────────────────────────
echo ""
echo "GPU:"
if command -v nvidia-smi &>/dev/null; then
  GPU_UTIL=$(nvidia-smi --query-gpu=utilization.gpu  --format=csv,noheader,nounits 2>/dev/null | head -1 || echo "?")
  GPU_MEM=$(nvidia-smi  --query-gpu=memory.used,memory.total --format=csv,noheader 2>/dev/null | head -1 || echo "?")
  ok "GPU: util=$GPU_UTIL%  mem=$GPU_MEM"
else
  warn "GPU: nvidia-smi not available (CPU-only mode)"
fi

echo ""
echo "──────────────────────────────────────"
if $ALL_OK; then
  echo -e "${GREEN}✅ All systems healthy${NC}"
  exit 0
else
  echo -e "${RED}❌ One or more checks failed — review above${NC}"
  exit 1
fi
