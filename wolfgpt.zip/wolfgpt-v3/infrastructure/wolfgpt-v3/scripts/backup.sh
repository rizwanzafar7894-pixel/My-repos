#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# WolfGPT v3 — Backup Script
# ─────────────────────────────────────────────────────────────────────────────
# Usage:
#   ./scripts/backup.sh          — backup Redis + logs
#   ./scripts/backup.sh redis    — Redis only
#   ./scripts/backup.sh logs     — logs only
#
# Cron (daily at 02:00):
#   0 2 * * * /path/to/wolfgpt-v3/scripts/backup.sh >> /var/log/wolfgpt-backup.log 2>&1
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

TARGET="${1:-all}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$SCRIPT_DIR")"
BACKUP_DIR="$ROOT/backups"
DATE=$(date +%Y%m%d-%H%M%S)
KEEP_DAYS=7

GREEN='\033[0;32m'; NC='\033[0m'
log() { echo -e "${GREEN}[Backup]${NC} $(date '+%H:%M:%S') $1"; }

mkdir -p "$BACKUP_DIR"

# ── Redis backup ─────────────────────────────────────────────────────────────
backup_redis() {
  if docker ps --format '{{.Names}}' 2>/dev/null | grep -q wolfgpt-redis; then
    log "Saving Redis data…"
    docker exec wolfgpt-redis redis-cli BGSAVE &>/dev/null || true
    sleep 2
    docker cp wolfgpt-redis:/data/dump.rdb "$BACKUP_DIR/redis-$DATE.rdb" && \
      log "✅ Redis backup: $BACKUP_DIR/redis-$DATE.rdb" || \
      log "⚠️  Redis backup failed"
  else
    log "wolfgpt-redis not running — skipping Redis backup"
  fi
}

# ── Log archive ───────────────────────────────────────────────────────────────
backup_logs() {
  log "Archiving logs…"
  tar -czf "$BACKUP_DIR/logs-$DATE.tar.gz" \
    -C "$ROOT" \
    backend/logs \
    nginx/logs \
    ai-services/logs \
    2>/dev/null || true
  log "✅ Logs archived: $BACKUP_DIR/logs-$DATE.tar.gz"
}

# ── Cleanup old backups ────────────────────────────────────────────────────────
cleanup() {
  log "Removing backups older than $KEEP_DAYS days…"
  find "$BACKUP_DIR" -name "*.rdb"     -mtime +$KEEP_DAYS -delete 2>/dev/null || true
  find "$BACKUP_DIR" -name "*.tar.gz"  -mtime +$KEEP_DAYS -delete 2>/dev/null || true
  local count
  count=$(ls "$BACKUP_DIR" | wc -l)
  log "Backup directory now has $count files"
}

case "$TARGET" in
  redis) backup_redis; cleanup ;;
  logs)  backup_logs;  cleanup ;;
  all|*) backup_redis; backup_logs; cleanup ;;
esac

log "Backup complete."
