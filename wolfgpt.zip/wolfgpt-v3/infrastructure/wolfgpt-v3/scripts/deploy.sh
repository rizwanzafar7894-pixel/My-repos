#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# WolfGPT v3 — Production Deploy Script
# ─────────────────────────────────────────────────────────────────────────────
# Usage:
#   ./scripts/deploy.sh           — GPU mode
#   ./scripts/deploy.sh --no-gpu  — CPU-only mode
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

GPU_FLAG="${1:-}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$(dirname "$SCRIPT_DIR")"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
log()    { echo -e "${GREEN}[Deploy]${NC} $1"; }
warn()   { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()    { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }
info()   { echo -e "${CYAN}[INFO]${NC} $1"; }
section(){ echo -e "\n${BOLD}${CYAN}══ $1 ══${NC}\n"; }

# ── 1. Prerequisites ──────────────────────────────────────────────────────
section "1/7 — Prerequisites"

command -v docker         &>/dev/null || err "Docker not installed. See https://docs.docker.com/get-docker/"
docker compose version    &>/dev/null || err "Docker Compose v2 required. Update Docker Desktop."
command -v curl           &>/dev/null || err "curl required"

info "Docker:  $(docker --version)"
info "Compose: $(docker compose version --short)"

GPU_AVAILABLE=false
if command -v nvidia-smi &>/dev/null; then
  GPU_NAME=$(nvidia-smi --query-gpu=name --format=csv,noheader 2>/dev/null | head -1 || echo "unknown")
  info "GPU:     $GPU_NAME"
  GPU_AVAILABLE=true
else
  warn "nvidia-smi not found — CPU-only mode"
  GPU_FLAG="--no-gpu"
fi

# Build compose command
if [[ "$GPU_FLAG" == "--no-gpu" ]]; then
  warn "Running in CPU-only mode (no GPU acceleration)"
  COMPOSE_CMD="docker compose -f docker-compose.prod.yml -f docker-compose.cpu.yml"
else
  COMPOSE_CMD="docker compose -f docker-compose.prod.yml"
fi

# ── 2. Environment validation ────────────────────────────────────────────
section "2/7 — Environment"

[[ -f .env ]]                     || err ".env not found — cp .env.example .env && fill in DOMAIN + REDIS_PASSWORD"
[[ -f backend/.env ]]             || err "backend/.env not found — cp backend/.env.example backend/.env"
[[ -f ai-services/.env ]]         || err "ai-services/.env not found — cp ai-services/.env.example ai-services/.env"
[[ -f frontend/.env.local ]]      || err "frontend/.env.local not found — cp frontend/.env.local.example frontend/.env.local"
[[ -f firebase-admin-key.json ]]  || err "firebase-admin-key.json not found — download from Firebase Console"

set -a; source .env; set +a
[[ -z "${DOMAIN:-}" ]]         && err "DOMAIN not set in .env"
[[ -z "${REDIS_PASSWORD:-}" ]] && err "REDIS_PASSWORD not set in .env"
[[ ${#REDIS_PASSWORD} -lt 16 ]] && warn "REDIS_PASSWORD is short (< 16 chars) — use a stronger password in production"

info "Domain:  $DOMAIN"
log "✅ Environment OK"

# ── 3. SSL certificates ───────────────────────────────────────────────────
section "3/7 — TLS / SSL"

if [[ -f nginx/ssl/fullchain.pem && -f nginx/ssl/privkey.pem ]]; then
  EXPIRY=$(openssl x509 -enddate -noout -in nginx/ssl/fullchain.pem 2>/dev/null | cut -d= -f2 || echo "unknown")
  info "Certificate expires: $EXPIRY"
  log "✅ SSL certificates found"
else
  warn "SSL certificates not found at nginx/ssl/"
  read -rp "Run setup-ssl.sh now? [y/N]: " SETUP_SSL
  if [[ "${SETUP_SSL,,}" == "y" ]]; then
    read -rp "Admin email for Let's Encrypt: " SSL_EMAIL
    ./scripts/setup-ssl.sh "$DOMAIN" "$SSL_EMAIL"
  else
    warn "Skipping SSL — nginx will not start without certs"
  fi
fi

# ── 4. Build images ───────────────────────────────────────────────────────
section "4/7 — Building images"

log "Building Docker images (first build may take 5–15 min)…"
DOMAIN="$DOMAIN" REDIS_PASSWORD="$REDIS_PASSWORD" \
  $COMPOSE_CMD build --parallel

log "✅ Images built"

# ── 5. Start services ─────────────────────────────────────────────────────
section "5/7 — Starting services"

DOMAIN="$DOMAIN" REDIS_PASSWORD="$REDIS_PASSWORD" \
  $COMPOSE_CMD up -d

log "Waiting 45s for health checks…"
sleep 45
$COMPOSE_CMD ps

# ── 6. Pull Ollama models ─────────────────────────────────────────────────
section "6/7 — AI models"

log "Pulling default Ollama model (background)…"
docker exec wolfgpt-ollama ollama list 2>/dev/null | grep -q "qwen2.5:7b" \
  || { docker exec wolfgpt-ollama ollama pull qwen2.5:7b &
       log "Pull running in background. Monitor: docker exec wolfgpt-ollama ollama list"; }

# ── 7. Smoke tests ────────────────────────────────────────────────────────
section "7/7 — Smoke tests"

BACKEND_STATUS=$(curl -sf "http://localhost:4000/health" 2>/dev/null | python3 -c "import sys,json; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null || echo "unreachable")
AI_STATUS=$(     curl -sf "http://localhost:8000/health" 2>/dev/null | python3 -c "import sys,json; print(json.load(sys.stdin).get('status','?'))" 2>/dev/null || echo "unreachable")

[[ "$BACKEND_STATUS" == "healthy" ]] && log "✅ Backend:    healthy" || warn "⚠️  Backend: $BACKEND_STATUS"
[[ "$AI_STATUS"      == "healthy" ]] && log "✅ AI Service: healthy" || warn "⚠️  AI Service: $AI_STATUS"

echo ""
log "══════════════════════════════════════════════════"
log "✅ WolfGPT v3 deployed successfully!"
log ""
log "   App:       https://$DOMAIN"
log "   API:       https://$DOMAIN/api/v1/health"
log ""
log "   Logs:      $COMPOSE_CMD logs -f"
log "   Status:    $COMPOSE_CMD ps"
log "   Stop:      $COMPOSE_CMD down"
log "   Restart:   $COMPOSE_CMD restart"
log "══════════════════════════════════════════════════"
