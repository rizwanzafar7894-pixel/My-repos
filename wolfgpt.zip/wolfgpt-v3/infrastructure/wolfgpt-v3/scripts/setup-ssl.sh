#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# WolfGPT v3 — SSL Certificate Setup
# ─────────────────────────────────────────────────────────────────────────────
# Usage:  ./scripts/setup-ssl.sh yourdomain.com admin@yourdomain.com
#
# What it does:
#   1. Installs certbot (if missing)
#   2. Obtains Let's Encrypt certificate for your domain
#   3. Copies certs to nginx/ssl/ (where docker compose expects them)
#   4. Generates 2048-bit DH parameters (dhparam.pem)
#   5. Registers auto-renewal cron job
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

DOMAIN="${1:-}"
EMAIL="${2:-}"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
log()  { echo -e "${GREEN}[SSL]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()  { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

[[ -z "$DOMAIN" || -z "$EMAIL" ]] && err "Usage: $0 <domain> <admin-email>"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(dirname "$SCRIPT_DIR")"
SSL_DIR="$ROOT/nginx/ssl"
mkdir -p "$SSL_DIR"

# ── Install certbot ────────────────────────────────────────────────────────
if ! command -v certbot &>/dev/null; then
  log "Installing certbot…"
  if   command -v apt-get &>/dev/null; then sudo apt-get update -qq && sudo apt-get install -y certbot
  elif command -v yum     &>/dev/null; then sudo yum install -y certbot
  elif command -v dnf     &>/dev/null; then sudo dnf install -y certbot
  else err "Cannot install certbot — please install manually: https://certbot.eff.org"; fi
fi

# ── Obtain certificate (standalone — port 80 must be free) ────────────────
log "Obtaining certificate for $DOMAIN…"
sudo certbot certonly \
  --standalone \
  --agree-tos \
  --non-interactive \
  --email "$EMAIL" \
  -d "$DOMAIN" \
  -d "www.$DOMAIN" 2>/dev/null \
  || sudo certbot certonly \
       --standalone \
       --agree-tos \
       --non-interactive \
       --email "$EMAIL" \
       -d "$DOMAIN"   # retry without www if it fails

# ── Copy to nginx/ssl/ ─────────────────────────────────────────────────────
log "Copying certificates to $SSL_DIR…"
sudo cp  "/etc/letsencrypt/live/$DOMAIN/fullchain.pem"  "$SSL_DIR/fullchain.pem"
sudo cp  "/etc/letsencrypt/live/$DOMAIN/privkey.pem"    "$SSL_DIR/privkey.pem"
sudo chmod 644 "$SSL_DIR/fullchain.pem"
sudo chmod 600 "$SSL_DIR/privkey.pem"
sudo chown "$USER:$USER" "$SSL_DIR/"*.pem

# ── DH parameters (2048-bit, one-time) ────────────────────────────────────
if [[ ! -f "$SSL_DIR/dhparam.pem" ]]; then
  log "Generating DH parameters (this takes ~1 min)…"
  openssl dhparam -out "$SSL_DIR/dhparam.pem" 2048
  chmod 644 "$SSL_DIR/dhparam.pem"
  log "DH params generated."
fi

# ── Auto-renewal cron ──────────────────────────────────────────────────────
RENEW_CMD="certbot renew --quiet && cp /etc/letsencrypt/live/$DOMAIN/fullchain.pem $SSL_DIR/fullchain.pem && cp /etc/letsencrypt/live/$DOMAIN/privkey.pem $SSL_DIR/privkey.pem && docker compose -f $ROOT/docker-compose.prod.yml restart nginx"
CRON="0 3 * * * $RENEW_CMD"
(crontab -l 2>/dev/null | grep -q "certbot renew") || \
  { (crontab -l 2>/dev/null; echo "$CRON") | crontab -; log "Auto-renewal cron registered (03:00 daily)."; }

log ""
log "✅ SSL setup complete!"
log "   Domain:  $DOMAIN"
log "   Certs:   $SSL_DIR/"
log ""
log "Next: docker compose -f docker-compose.prod.yml up -d --build"
