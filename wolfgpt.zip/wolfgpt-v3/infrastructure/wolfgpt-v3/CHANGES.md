# WolfGPT v3 — Changelog

## v3.0.0 — Full Production Hardening

All 23 bugs identified in the deep audit of v2 have been fixed.

### 🔴 Critical Bug Fixes

**FIX #1 — JazzCash HMAC Security** (`backend/src/routes/payment/jazzcash.ts`)
- `pp_Password` is now excluded from the HMAC hash via `HASH_EXCLUDED_FIELDS` set
- Per JazzCash specification, only `pp_SecureHash` and `pp_Password` should be excluded

**FIX #2 — ApiError.forbidden() signature** (`backend/src/middleware/errorHandler.ts`)
- Added `code` parameter: `static forbidden(msg, code = 'FORBIDDEN')`
- `MODEL_NOT_ALLOWED` and all custom codes now propagate correctly

**FIX #3 — Missing dashboard/page.tsx** (`frontend/src/app/dashboard/page.tsx`)
- Created dashboard index page with `redirect('/dashboard/chat')`
- Navigating to `/dashboard` no longer 404s

**FIX #4 — MusicGen audiocraft dependency** (`ai-services/requirements.txt`)
- Added `audiocraft>=1.3.0` and `transformers[audio]>=4.40.2`
- MusicGen loads successfully without ImportError

**FIX #5 — Frontend Docker env_file** (`docker-compose.yml`, `docker-compose.prod.yml`)
- Changed `env_file: ./frontend/.env` → `./frontend/.env.local` (Next.js convention)

**FIX #6 — Missing docker-compose.cpu.yml** (new file)
- Created CPU-only override; `--no-gpu` mode now works

### 🟠 Serious Bug Fixes

**FIX #7 — Stripe API version** (`backend/src/routes/payment/stripe.ts`)
- Updated `'2024-04-10'` → `'2025-02-24.acacia'`

**FIX #8 — ApiError.forbidden() code param** (`backend/src/middleware/errorHandler.ts`)
- Same fix as #2; static method signature corrected

**FIX #9 — JazzCash callback hash** (`backend/src/routes/payment/jazzcash.ts`)
- `pp_ResponseCode` is now included in callback hash verification
- Full body passed to `computeHash()` which excludes only designated fields

**FIX #10 — @types/morgan missing** (`backend/package.json`)
- Added `"@types/morgan": "^1.9.9"` to devDependencies

**FIX #11 — Deprecated crypto package** (`backend/package.json`)
- Removed `"crypto": "^1.0.1"` (npm no-op); using `node:crypto` built-in

**FIX #12 — SSL cert provisioning** (`scripts/setup-ssl.sh`)
- Automated Let's Encrypt + DH params; nginx no longer fails without pre-existing certs

### 🟡 Missing Features Added

**FIX #13 — Admin dashboard** (`admin-dashboard/`)
- Complete admin panel with user management and analytics

**FIX #14 — EasyPaisa webhook security** (`backend/src/routes/payment/easypaisa.ts`)
- Full HMAC-SHA256 verification using `safeCompare()` (timing-safe)
- Callbacks without signature are rejected with 400

**FIX #15 — voice_service.py integration** (`ai-services/routers/voice.py`)
- Voice router now imports from `services/voice_service.py`
- Multi-speaker TTS and voice cloning features now reachable

**FIX #16 — Ollama model map** (`ai-services/core/config.py`)
- Added: Llama 3.2 3B, Llama 3.1 8B/70B, Mistral 7B, Gemma 2 9B, DeepSeek R1 7B, DeepSeek Coder V2, Code Llama 7B

**FIX #17 — Frontend model selector** (`frontend/src/constants/index.ts`)
- All 14 models added with provider grouping and tier restrictions

**FIX #18 — PayPal integration** (`backend/src/routes/payment/paypal.ts`)
- Complete new file: OAuth2, plan ID lookup, subscription activation, webhook verification

### 🔵 Configuration & Security

**FIX #19 — Redis production safeguard** (`.env.example`, `docker-compose.prod.yml`)
- `REDIS_PASSWORD` required via `${REDIS_PASSWORD:?}` in prod compose

**FIX #20 — Nginx domain variable** (`nginx/nginx.conf`)
- `server_name` uses `${DOMAIN}` from root `.env` — no hardcoded domain

**FIX #21 — Auth cache key** (`backend/src/middleware/auth.ts`)
- Full 64-char SHA256 hash used (was truncated to 32 chars)

**FIX #22 — Docker optimizations** (`ai-services/Dockerfile`)
- `--no-cache-dir` on all pip calls; optimized layer order

**FIX #23 — Environment file cleanup** (`frontend/`)
- Single canonical `frontend/.env.local.example`; duplicate removed
