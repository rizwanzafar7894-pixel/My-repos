# WolfGPT v3 — Nginx Configuration Template
# ─────────────────────────────────────────────────────────────────────────────
# This file is used by the nginx Docker container.
# At startup, ${DOMAIN} is replaced with the actual domain via envsubst.
# 
# If you want to edit nginx config:
#   1. Edit this file
#   2. Restart: docker compose restart nginx
#
# The actual nginx.conf is identical to this file — it is also provided
# as nginx/nginx.conf for static editing.
# ─────────────────────────────────────────────────────────────────────────────
# See nginx/nginx.conf for the full configuration.
