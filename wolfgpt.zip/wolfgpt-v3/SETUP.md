# WolfGPT v3 — Complete Setup Guide

## Prerequisites

| Tool | Minimum Version | Install |
|---|---|---|
| Docker | 24.x | [docs.docker.com](https://docs.docker.com/get-docker/) |
| Docker Compose | v2 | Bundled with Docker Desktop |
| Git | Any | [git-scm.com](https://git-scm.com) |
| NVIDIA drivers | 525+ (GPU only) | [nvidia.com/drivers](https://www.nvidia.com/drivers) |
| CUDA toolkit | 12.x (GPU only) | [developer.nvidia.com/cuda](https://developer.nvidia.com/cuda-downloads) |

---

## Step 1 — Firebase Setup

1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Create a new project (or use existing)
3. **Enable Authentication:**
   - Authentication → Sign-in method → Enable **Email/Password** and **Google**
4. **Create Firestore database:**
   - Firestore Database → Create database → Production mode → select region
5. **Deploy security rules:**
   ```bash
   npm install -g firebase-tools
   firebase login
   firebase use your-project-id
   firebase deploy --only firestore:rules,firestore:indexes
   ```
6. **Get Admin SDK credentials:**
   - Project Settings → Service accounts → Generate new private key
   - Save as `firebase-admin-key.json` in project root
7. **Get Web SDK config:**
   - Project Settings → Your apps → Add app (Web `</>`)
   - Copy config values to `frontend/.env.local`

---

## Step 2 — Configure Environment Files

```bash
# Root (production domain + Redis password)
cp .env.example .env
nano .env

# Backend (Firebase Admin, payments, Redis)
cp backend/.env.example backend/.env
nano backend/.env

# AI Services (model settings)
cp ai-services/.env.example ai-services/.env
nano ai-services/.env

# Frontend (Firebase Web SDK, Stripe public key)
cp frontend/.env.local.example frontend/.env.local
nano frontend/.env.local
```

---

## Step 3 — Start Development

```bash
# GPU server:
docker compose up -d

# CPU-only VPS:
docker compose -f docker-compose.yml -f docker-compose.cpu.yml up -d
```

Check all containers are healthy:
```bash
docker compose ps
```

---

## Step 4 — Pull AI Models

```bash
# Minimum (free tier only — qwen2.5:7b):
./scripts/pull-models.sh --minimal

# All standard models (recommended):
./scripts/pull-models.sh

# All models including large GPU variants (24GB+ VRAM):
./scripts/pull-models.sh --gpu
```

---

## Step 5 — Verify Installation

Open [http://localhost:3000](http://localhost:3000)

Test each feature:
- Register/login
- Send a chat message
- Generate an image
- Record voice (STT)
- Execute code

---

## Production Deployment

### Server Requirements

| Component | Minimum | Recommended |
|---|---|---|
| CPU | 4 cores | 8+ cores |
| RAM | 16 GB | 32 GB |
| Storage | 100 GB SSD | 500 GB NVMe |
| GPU (optional) | NVIDIA RTX 3080 10GB | A100 40GB |
| OS | Ubuntu 22.04 | Ubuntu 22.04 |

### Deploy

```bash
# 1. Set domain + Redis password
nano .env

# 2. Configure all services
nano backend/.env
nano frontend/.env.local

# 3. Add Firebase credentials
cp your-firebase-key.json firebase-admin-key.json

# 4. Full automated deploy
./scripts/deploy.sh
```

---

## Payment Provider Setup

### Stripe
1. Create account at [stripe.com](https://stripe.com)
2. **Create products:** Dashboard → Products → + Add product
   - Create: Basic, Premium, Pro — each with Monthly + Yearly prices
   - Copy each `price_XXXX` ID to `backend/.env`
3. **Set up webhook:**
   - Dashboard → Developers → Webhooks → + Add endpoint
   - URL: `https://yourdomain.com/api/payment/stripe/webhook`
   - Events: `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`, `invoice.payment_failed`, `invoice.payment_succeeded`
   - Copy signing secret to `STRIPE_WEBHOOK_SECRET`
4. For local testing: `stripe listen --forward-to localhost:4000/api/payment/stripe/webhook`

### PayPal
1. Go to [developer.paypal.com](https://developer.paypal.com)
2. My Apps & Credentials → Create App
3. Copy Client ID and Secret to `backend/.env`
4. **Create subscription plans:**
   - Go to [paypal.com/billing/plans](https://www.paypal.com/billing/plans)
   - Create plans for Basic/Premium/Pro (monthly + yearly)
   - Copy Plan IDs (`P-XXXX`) to `backend/.env`
5. **Add webhook:**
   - Developer Dashboard → Webhooks → Add Webhook
   - URL: `https://yourdomain.com/api/payment/paypal/webhook`
   - Events: `BILLING.SUBSCRIPTION.ACTIVATED`, `BILLING.SUBSCRIPTION.CANCELLED`

### JazzCash (Pakistan)
1. Visit [jazzcash.com.pk](https://jazzcash.com.pk) → Become a Merchant
2. Complete merchant registration
3. You will receive via email: Merchant ID, Password, Integrity Salt
4. For sandbox testing: [sandbox.jazzcash.com.pk](https://sandbox.jazzcash.com.pk)
5. Set `JAZZCASH_RETURN_URL` to your callback URL

### EasyPaisa (Pakistan)
1. Contact EasyPaisa merchant support at [easypaisa.com.pk](https://easypaisa.com.pk)
2. Request API credentials (Store ID, Secret Key, Hash Key)
3. For testing: request sandbox credentials from EasyPaisa support

---

## Troubleshooting

### Services won't start
```bash
docker compose logs redis       # Redis issues
docker compose logs ai-service  # Model loading issues
docker compose logs backend     # Firebase/Redis connection issues
docker compose logs frontend    # Build issues
```

### AI models not responding
```bash
# Check Ollama is running
docker exec wolfgpt-ollama ollama list

# Pull the default model
docker exec wolfgpt-ollama ollama pull qwen2.5:7b

# Check GPU is detected
docker exec wolfgpt-ollama nvidia-smi
```

### Firebase authentication errors
- Verify `firebase-admin-key.json` is present in root
- Check `FIREBASE_STORAGE_BUCKET` matches your project
- Ensure Firestore is in the same region as your backend

### Payment webhooks not working
- Use `stripe listen --forward-to localhost:4000/api/payment/stripe/webhook` for local testing
- Check webhook signing secrets match `.env` values
- Verify HTTPS is working in production (required for PayPal and JazzCash)
