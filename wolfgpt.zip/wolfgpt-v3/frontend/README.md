# WolfGPT Frontend

Next.js 14 · TypeScript · Tailwind CSS · Framer Motion

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.local.example .env.local
# Edit .env.local with your Firebase and API credentials

# 3. Start dev server
npm run dev
```

Open → http://localhost:3000

## Environment Variables

Copy `.env.local.example` to `.env.local` and fill in:

| Variable | Description |
|---|---|
| `NEXT_PUBLIC_API_URL` | Backend URL (default: http://localhost:4000) |
| `NEXT_PUBLIC_FIREBASE_*` | Firebase Web SDK config |
| `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` | Stripe public key (optional) |
| `NEXT_PUBLIC_PAYPAL_CLIENT_ID` | PayPal client ID (optional) |

## Structure

```
src/
├── app/                    # Next.js App Router pages
│   ├── page.tsx            # Landing page
│   ├── login/page.tsx      # Login
│   ├── register/page.tsx   # Register
│   └── dashboard/          # Protected dashboard
│       ├── layout.tsx      # Auth guard + layout
│       ├── page.tsx        # → redirects to /chat
│       ├── chat/           # Streaming AI chat
│       ├── images/         # Image generation
│       ├── voice/          # STT + TTS
│       ├── code/           # Code execution
│       ├── music/          # MusicGen
│       ├── documents/      # Document chat
│       ├── analytics/      # Usage analytics
│       ├── api-keys/       # API key management
│       ├── billing/        # Plans + payments
│       └── settings/       # Profile + preferences
├── components/
│   ├── ui/                 # Radix UI primitives
│   ├── chat/               # ChatInterface, ModelSelector
│   ├── layout/             # Sidebar, DashboardLayout
│   └── shared/             # Logo, LoadingSpinner, etc.
├── constants/index.ts      # All models, routes, config
├── lib/
│   ├── api.ts              # API client (axios + fetch SSE)
│   ├── firebase.ts         # Firebase Web SDK
│   └── utils.ts            # cn, formatters
├── store/auth.ts           # Zustand auth state
└── types/index.ts          # TypeScript types
```

## Payments

- **Stripe** — international cards, redirects to Stripe Checkout
- **PayPal** — handled via `@paypal/react-paypal-js`
- **JazzCash** — POST redirect to JazzCash portal (Pakistan)
- **EasyPaisa** — mobile OTP payment (Pakistan)

## Scripts

```bash
npm run dev          # Development server
npm run build        # Production build
npm run start        # Start production server
npm run lint         # ESLint
npm run type-check   # TypeScript check
```
