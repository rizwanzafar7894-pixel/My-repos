import axios, { AxiosInstance, AxiosError } from 'axios';
import { API_CONFIG } from '@/constants';
import { getAuth } from 'firebase/auth';

class APIClient {
  private readonly http: AxiosInstance;
  private apiKey: string | null = null;

  constructor() {
    this.http = axios.create({
      baseURL: API_CONFIG.baseURL,
      timeout: API_CONFIG.timeout,
      headers: { 'Content-Type': 'application/json' },
    });

    this.http.interceptors.request.use(async config => {
      const token = await this.getToken();
      if (token)       config.headers.Authorization = `Bearer ${token}`;
      if (this.apiKey) config.headers['X-API-Key']  = this.apiKey;
      return config;
    });

    this.http.interceptors.response.use(
      res => res,
      (err: AxiosError) => {
        if (err.response?.status === 401 && typeof window !== 'undefined') {
          if (!window.location.pathname.startsWith('/login') &&
              !window.location.pathname.startsWith('/register')) {
            window.location.href = '/login';
          }
        }
        return Promise.reject(err);
      }
    );
  }

  private async getToken(): Promise<string | null> {
    if (typeof window === 'undefined') return null;
    try {
      const user = getAuth().currentUser;
      return user ? await user.getIdToken() : null;
    } catch { return null; }
  }

  private async authHeaders(): Promise<Record<string, string>> {
    const token = await this.getToken();
    const h: Record<string, string> = {};
    if (token)       h['Authorization'] = `Bearer ${token}`;
    if (this.apiKey) h['X-API-Key']     = this.apiKey;
    return h;
  }

  setApiKey(key: string)  { this.apiKey = key; }
  clearApiKey()           { this.apiKey = null; }

  async get<T = any>(path: string, params?: Record<string, any>): Promise<T> {
    const res = await this.http.get<T>(path, { params });
    return (res.data as any)?.data ?? res.data;
  }

  async post<T = any>(path: string, body?: any): Promise<T> {
    const res = await this.http.post<T>(path, body);
    return res.data as T;
  }

  async patch<T = any>(path: string, body?: any): Promise<T> {
    const res = await this.http.patch<T>(path, body);
    return res.data as T;
  }

  async delete<T = any>(path: string): Promise<T> {
    const res = await this.http.delete<T>(path);
    return res.data as T;
  }

  // ── Chat ────────────────────────────────────────────────────────────────────
  chat(messages: any[], model = 'qwen-2.5-7b', opts: Record<string, any> = {}) {
    return this.post('/api/v1/chat/completions', { messages, model, ...opts });
  }

  async chatStream(
    messages:  any[],
    model:     string = 'qwen-2.5-7b',
    onChunk:   (chunk: string) => void,
    opts:      Record<string, any> = {},
    signal?:   AbortSignal,
  ): Promise<void> {
    const headers = await this.authHeaders();
    const response = await fetch(`${API_CONFIG.baseURL}/api/v1/chat/completions/stream`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json', ...headers },
      body:    JSON.stringify({ messages, model, ...opts }),
      signal,
    });
    if (!response.ok) {
      const err = await response.json().catch(() => ({}));
      throw new Error((err as any)?.error?.message || `HTTP ${response.status}`);
    }
    const reader  = response.body?.getReader();
    if (!reader)  throw new Error('No readable stream');
    const decoder = new TextDecoder();
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        for (const line of decoder.decode(value, { stream: true }).split('\n')) {
          if (!line.startsWith('data: ')) continue;
          const data = line.slice(6).trim();
          if (data === '[DONE]') return;
          try {
            const parsed = JSON.parse(data);
            if (parsed.error) throw new Error(parsed.error);
            if (parsed.content) onChunk(parsed.content);
          } catch { /* skip malformed */ }
        }
      }
    } finally {
      reader.releaseLock();
    }
  }

  getConversations(limit = 50)       { return this.get('/api/v1/chat/conversations', { limit }); }
  getConversation(id: string)         { return this.get(`/api/v1/chat/conversations/${id}`); }
  updateConversation(id: string, data: any) { return this.patch(`/api/v1/chat/conversations/${id}`, data); }
  deleteConversation(id: string)      { return this.delete(`/api/v1/chat/conversations/${id}`); }
  clearConversations()                { return this.delete('/api/v1/chat/conversations'); }

  // ── Images ──────────────────────────────────────────────────────────────────
  generateImage(req: any)       { return this.post('/api/v1/images/generate', req); }
  imageToImage(req: any)        { return this.post('/api/v1/images/img2img', req); }
  inpaintImage(req: any)        { return this.post('/api/v1/images/inpaint', req); }
  upscaleImage(image: string)   { return this.post('/api/v1/images/upscale', { image }); }
  getImageGallery(p?: any)      { return this.get('/api/v1/images/gallery', p); }

  async imageToImageUpload(formData: FormData) {
    const headers = await this.authHeaders();
    const res = await fetch(`${API_CONFIG.baseURL}/api/v1/images/img2img/upload`, {
      method: 'POST', headers, body: formData,
    });
    return res.json();
  }

  // ── Voice ───────────────────────────────────────────────────────────────────
  async speechToText(audioBlob: Blob, language = 'en'): Promise<any> {
    const fd = new FormData();
    fd.append('audio', audioBlob);
    fd.append('language', language);
    const headers = await this.authHeaders();
    const res = await fetch(`${API_CONFIG.baseURL}/api/v1/voice/stt`, {
      method: 'POST', headers, body: fd,
    });
    return res.json();
  }

  textToSpeech(text: string, voice = 'en-US-female-1', speed = 1.0) {
    return this.http
      .post('/api/v1/voice/tts', { text, voice, speed }, { responseType: 'blob' })
      .then(r => r.data);
  }

  // ── Music ───────────────────────────────────────────────────────────────────
  generateMusic(req: any)   { return this.post('/api/v1/music/generate', req); }
  melodyMusic(req: any)     { return this.post('/api/v1/music/melody', req); }
  continueMusic(req: any)   { return this.post('/api/v1/music/continuation', req); }

  // ── Code ────────────────────────────────────────────────────────────────────
  executeCode(code: string, language: string, stdin = '') {
    return this.post('/api/v1/code/execute', { code, language, stdin });
  }

  // ── Documents ───────────────────────────────────────────────────────────────
  async uploadDocument(file: File): Promise<any> {
    const fd = new FormData();
    fd.append('document', file);
    const headers = await this.authHeaders();
    const res = await fetch(`${API_CONFIG.baseURL}/api/v1/documents/upload`, {
      method: 'POST', headers, body: fd,
    });
    return res.json();
  }

  chatWithDocument(docId: string, question: string) {
    return this.post(`/api/v1/documents/${docId}/chat`, { question });
  }

  // ── Translate & Summarize ───────────────────────────────────────────────────
  translate(text: string, targetLanguage: string, sourceLanguage?: string) {
    return this.post('/api/v1/translate', { text, targetLanguage, sourceLanguage });
  }

  summarize(text: string, maxLength = 500, style = 'paragraph') {
    return this.post('/api/v1/summarize', { text, maxLength, style });
  }

  // ── Auth / User ─────────────────────────────────────────────────────────────
  getMe()             { return this.get('/api/auth/me'); }
  getUsage()          { return this.get('/api/auth/usage'); }
  updateMe(data: any) { return this.patch('/api/auth/me', data); }

  // ── API Keys ────────────────────────────────────────────────────────────────
  getApiKeys()               { return this.get('/api/auth/api-keys'); }
  createApiKey(name: string) { return this.post('/api/auth/api-keys', { name }); }
  revokeApiKey(id: string)   { return this.patch(`/api/auth/api-keys/${id}/revoke`); }
  deleteApiKey(id: string)   { return this.delete(`/api/auth/api-keys/${id}`); }

  // ── Analytics ───────────────────────────────────────────────────────────────
  getAnalytics(days = 30) { return this.get('/api/v1/analytics', { days }); }

  // ── Payments ────────────────────────────────────────────────────────────────
  stripeCheckout(tier: string, period = 'yearly') {
    return this.post('/api/payment/stripe/checkout', { tier, period });
  }
  stripeBillingPortal() { return this.post('/api/payment/stripe/portal'); }

  jazzCashInitiate(tier: string, period = 'yearly') {
    return this.post('/api/payment/jazzcash/initiate', { tier, period });
  }

  easyPaisaInitiate(tier: string, mobileNumber: string, period = 'yearly') {
    return this.post('/api/payment/easypaisa/initiate', { tier, period, mobileNumber });
  }

  // PayPal: handled via @paypal/react-paypal-js SDK on client; subscription IDs via:
  paypalGetPlanId(tier: string, period = 'monthly') {
    return this.get('/api/payment/paypal/plan-id', { tier, period });
  }

  paypalActivateSubscription(subscriptionId: string, tier: string) {
    return this.post('/api/payment/paypal/activate', { subscriptionId, tier });
  }
}

export const apiClient = new APIClient();
export const setApiKey = (key: string) => apiClient.setApiKey(key);
