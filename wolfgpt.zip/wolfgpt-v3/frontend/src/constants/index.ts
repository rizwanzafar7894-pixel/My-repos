import type { FeatureLimits, UserTier } from '@/types';

export const FIREBASE_CONFIG = {
  apiKey:            process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain:        process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId:         process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket:     process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId:             process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
  measurementId:     process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID,
};

export const STRIPE_CONFIG = {
  publishableKey: process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || '',
};

export const PAYPAL_CONFIG = {
  clientId: process.env.NEXT_PUBLIC_PAYPAL_CLIENT_ID || '',
};

export const API_CONFIG = {
  baseURL:  process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000',
  timeout:  30_000,
};

// ── Pricing (USD) ─────────────────────────────────────────────────────────────
export const PRICING = {
  free:    { monthly: 0,     yearly: 0    },
  basic:   { monthly: 9.99,  yearly: 99   },
  premium: { monthly: 19.99, yearly: 199  },
  pro:     { monthly: 39.99, yearly: 399  },
} as const;

// JazzCash / EasyPaisa PKR pricing
export const PRICING_PKR = {
  basic:   { yearly: 27_800  },
  premium: { yearly: 55_600  },
  pro:     { yearly: 111_200 },
} as const;

// ── Tier Limits ───────────────────────────────────────────────────────────────
export const TIER_LIMITS: Record<UserTier, FeatureLimits> = {
  free: {
    tier: 'free',
    chat:      { unlimited: true, model: ['qwen-2.5-7b', 'llama-3.2-3b'], contextWindow: 32_000 },
    images:    { daily: 5,   models: ['flux-schnell'], maxResolution: 1024 },
    code:      { daily: 50,  languages: ['python','javascript','bash'], timeout: 30 },
    voice:     { unlimited: true, minutesPerMonth: 60 },
    api:       { enabled: false, requestsPerMonth: 0, rateLimit: 0, keys: 0 },
    storage:   { gb: 0.5 },
    projects:  { max: 3 },
    documents: { max: 5 },
    features:  ['chat','voice','summarize','translate','document_chat','code'],
  },
  basic: {
    tier: 'basic',
    chat:      { unlimited: true, model: ['qwen-2.5-7b','llama-3.2-3b','mistral-7b','gemma-2-9b'], contextWindow: 64_000 },
    images:    { daily: 25,  models: ['flux-schnell','flux-dev'], maxResolution: 1024 },
    code:      { daily: 200, languages: ['python','javascript','typescript','bash','go'], timeout: 60 },
    voice:     { unlimited: true, minutesPerMonth: 100 },
    api:       { enabled: true, requestsPerMonth: 1_000, rateLimit: 10, keys: 1 },
    storage:   { gb: 5 },
    projects:  { max: 10 },
    documents: { max: 50 },
    features:  ['chat','voice','summarize','translate','document_chat','code','api_access','analytics'],
  },
  premium: {
    tier: 'premium',
    chat:      { unlimited: true, model: ['qwen-2.5-7b','qwen-2.5-32b','llama-3.1-8b','mistral-7b','gemma-2-9b','deepseek-r1-7b','llava-13b'], contextWindow: 128_000 },
    images:    { daily: 100, models: ['flux-schnell','flux-dev','sdxl-base','sdxl-refiner'], maxResolution: 2048 },
    code:      { daily: 500, languages: ['python','javascript','typescript','bash','go','rust','java'], timeout: 120 },
    voice:     { unlimited: true, minutesPerMonth: 500 },
    api:       { enabled: true, requestsPerMonth: 50_000, rateLimit: 60, keys: 5 },
    storage:   { gb: 20 },
    projects:  { max: -1 },
    documents: { max: -1 },
    features:  ['chat','voice','summarize','translate','document_chat','code','api_access','analytics','music','priority_queue','custom_prompts'],
  },
  pro: {
    tier: 'pro',
    chat:      { unlimited: true, model: ['qwen-2.5-7b','qwen-2.5-32b','qwen-2.5-72b','llama-3.1-8b','llama-3.1-70b','mistral-7b','gemma-2-9b','deepseek-r1-7b','deepseek-coder-v2','llava-13b','llava-34b','codellama-7b'], contextWindow: 200_000 },
    images:    { daily: -1, models: ['flux-schnell','flux-dev','flux-pro','sdxl-base','sdxl-refiner'], maxResolution: 4096 },
    code:      { daily: -1, languages: ['python','javascript','typescript','bash','go','rust','java','cpp','ruby'], timeout: 300 },
    voice:     { unlimited: true, minutesPerMonth: undefined },
    api:       { enabled: true, requestsPerMonth: -1, rateLimit: -1, keys: -1 },
    storage:   { gb: 100 },
    projects:  { max: -1 },
    documents: { max: -1 },
    features:  ['chat','voice','summarize','translate','document_chat','code','api_access','analytics','music','priority_queue','custom_prompts','beta_features','dedicated_support'],
  },
};

// ── FIX #17: All models including Llama 3, Mistral, Gemma, DeepSeek ──────────
export const MODELS = {
  chat: {
    // Qwen
    'qwen-2.5-7b':  { name: 'Qwen 2.5 7B',   provider: 'Alibaba', desc: 'Fast, efficient — great for everyday tasks',      ctx: 32_000,  tier: ['free','basic','premium','pro'] as UserTier[] },
    'qwen-2.5-32b': { name: 'Qwen 2.5 32B',  provider: 'Alibaba', desc: 'Smarter responses for complex reasoning',          ctx: 128_000, tier: ['premium','pro'] as UserTier[] },
    'qwen-2.5-72b': { name: 'Qwen 2.5 72B',  provider: 'Alibaba', desc: 'Most capable Qwen — advanced analysis',            ctx: 200_000, tier: ['pro'] as UserTier[] },
    // Llama 3 (FIX #17)
    'llama-3.2-3b': { name: 'Llama 3.2 3B',  provider: 'Meta',    desc: "Meta's compact, blazing-fast model",              ctx: 128_000, tier: ['free','basic','premium','pro'] as UserTier[] },
    'llama-3.1-8b': { name: 'Llama 3.1 8B',  provider: 'Meta',    desc: "Meta's instruction model — strong reasoning",     ctx: 128_000, tier: ['basic','premium','pro'] as UserTier[] },
    'llama-3.1-70b':{ name: 'Llama 3.1 70B', provider: 'Meta',    desc: "Meta's flagship — near-GPT-4 quality",            ctx: 128_000, tier: ['pro'] as UserTier[] },
    // Mistral (FIX #17)
    'mistral-7b':   { name: 'Mistral 7B',     provider: 'Mistral', desc: 'Strong European model — superb instruction following', ctx: 32_000,  tier: ['basic','premium','pro'] as UserTier[] },
    // Gemma (FIX #17)
    'gemma-2-9b':   { name: 'Gemma 2 9B',     provider: 'Google',  desc: "Google's open model — balanced and capable",     ctx: 8_192,   tier: ['basic','premium','pro'] as UserTier[] },
    // DeepSeek (FIX #17)
    'deepseek-r1-7b':     { name: 'DeepSeek R1 7B',    provider: 'DeepSeek', desc: 'Reasoning specialist — complex logic & math', ctx: 32_000, tier: ['premium','pro'] as UserTier[] },
    'deepseek-coder-v2':  { name: 'DeepSeek Coder V2', provider: 'DeepSeek', desc: 'State-of-the-art code generation',          ctx: 128_000, tier: ['premium','pro'] as UserTier[] },
    // Code Llama (FIX #17)
    'codellama-7b': { name: 'Code Llama 7B',  provider: 'Meta',    desc: 'Llama-based code model — polyglot programming',   ctx: 16_000,  tier: ['pro'] as UserTier[] },
  },
  vision: {
    'llava-7b':  { name: 'LLaVA 7B',  desc: 'Basic image understanding',        tier: ['free','basic'] as UserTier[] },
    'llava-13b': { name: 'LLaVA 13B', desc: 'Advanced vision + language',        tier: ['premium','pro'] as UserTier[] },
    'llava-34b': { name: 'LLaVA 34B', desc: 'Best-in-class multimodal analysis', tier: ['pro'] as UserTier[] },
  },
  image: {
    'flux-schnell':  { name: 'FLUX Schnell',         desc: 'Fast (2-4 steps) — great for drafts',       tier: ['free','basic','premium','pro'] as UserTier[], steps: [2, 4]    },
    'flux-dev':      { name: 'FLUX Dev',             desc: 'Balanced quality and speed',                 tier: ['basic','premium','pro'] as UserTier[],        steps: [20, 50]  },
    'flux-pro':      { name: 'FLUX Pro',             desc: 'Professional quality',                       tier: ['pro'] as UserTier[],                          steps: [50, 100] },
    'sdxl-base':     { name: 'Stable Diffusion XL',  desc: 'High quality, versatile',                   tier: ['premium','pro'] as UserTier[],                steps: [30, 50]  },
    'sdxl-refiner':  { name: 'SDXL Refiner',         desc: 'Detail enhancement pass',                   tier: ['premium','pro'] as UserTier[],                steps: [50, 100] },
  },
  music: {
    'musicgen-small':        { name: 'MusicGen Small',         desc: 'Fast, 300M — good for quick samples',  vram: 2 },
    'musicgen-medium':       { name: 'MusicGen Medium',        desc: 'Balanced, 1.5B — recommended default', vram: 4 },
    'musicgen-large':        { name: 'MusicGen Large',         desc: 'Best quality, 3.3B — needs 8GB VRAM',  vram: 8 },
    'musicgen-melody':       { name: 'MusicGen Melody',        desc: 'Melody-conditioned generation',        vram: 4 },
    'musicgen-stereo-small': { name: 'MusicGen Stereo Small',  desc: 'Stereo output variant',                vram: 2 },
  },
} as const;

export const VOICE_CONFIG = {
  stt: { model: 'whisper-large-v3', languages: ['en','es','fr','de','zh','ja','ar','hi','ur','pt','ru','tr','ko'] },
  tts: {
    voices: [
      { id: 'en-US-female-1', name: 'Emma (US)',    language: 'en-US', gender: 'female' },
      { id: 'en-US-male-1',   name: 'James (US)',   language: 'en-US', gender: 'male'   },
      { id: 'en-GB-female-1', name: 'Sophie (UK)',  language: 'en-GB', gender: 'female' },
      { id: 'en-GB-male-1',   name: 'Oliver (UK)',  language: 'en-GB', gender: 'male'   },
      { id: 'ur-PK-female-1', name: 'Ayesha (PK)',  language: 'ur-PK', gender: 'female' },
      { id: 'ur-PK-male-1',   name: 'Ahmed (PK)',   language: 'ur-PK', gender: 'male'   },
    ],
  },
};

export const LANGUAGES = [
  { code: 'en', name: 'English',    native: 'English'    },
  { code: 'ur', name: 'Urdu',       native: 'اردو'       },
  { code: 'ar', name: 'Arabic',     native: 'العربية'    },
  { code: 'zh', name: 'Chinese',    native: '中文'        },
  { code: 'es', name: 'Spanish',    native: 'Español'    },
  { code: 'fr', name: 'French',     native: 'Français'   },
  { code: 'de', name: 'German',     native: 'Deutsch'    },
  { code: 'hi', name: 'Hindi',      native: 'हिन्दी'     },
  { code: 'ja', name: 'Japanese',   native: '日本語'      },
  { code: 'pt', name: 'Portuguese', native: 'Português'  },
  { code: 'ru', name: 'Russian',    native: 'Русский'    },
  { code: 'tr', name: 'Turkish',    native: 'Türkçe'     },
  { code: 'ko', name: 'Korean',     native: '한국어'      },
] as const;

export const IMAGE_ASPECT_RATIOS = [
  { label: '1:1 Square',     width: 1024, height: 1024 },
  { label: '16:9 Landscape', width: 1344, height: 768  },
  { label: '9:16 Portrait',  width: 768,  height: 1344 },
  { label: '4:3 Standard',   width: 1152, height: 864  },
  { label: '3:2 Photo',      width: 1216, height: 832  },
] as const;

export const ROUTES = {
  HOME:       '/',
  LOGIN:      '/login',
  REGISTER:   '/register',
  CHAT:       '/dashboard/chat',
  VOICE:      '/dashboard/voice',
  MUSIC:      '/dashboard/music',
  IMAGES:     '/dashboard/images',
  CODE:       '/dashboard/code',
  DOCUMENTS:  '/dashboard/documents',
  API_KEYS:   '/dashboard/api-keys',
  SETTINGS:   '/dashboard/settings',
  BILLING:    '/dashboard/billing',
  ANALYTICS:  '/dashboard/analytics',
} as const;

export const CODE_LANGUAGES: { value: string; label: string }[] = [
  { value: 'python',     label: 'Python'     },
  { value: 'javascript', label: 'JavaScript' },
  { value: 'typescript', label: 'TypeScript' },
  { value: 'bash',       label: 'Bash'       },
  { value: 'go',         label: 'Go'         },
  { value: 'rust',       label: 'Rust'       },
  { value: 'java',       label: 'Java'       },
  { value: 'cpp',        label: 'C++'        },
  { value: 'ruby',       label: 'Ruby'       },
];
