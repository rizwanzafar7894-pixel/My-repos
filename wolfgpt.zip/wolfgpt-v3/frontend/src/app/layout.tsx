import type { Metadata, Viewport } from 'next';
import { Outfit, JetBrains_Mono } from 'next/font/google';
import { ThemeProvider } from '@/components/shared/ThemeProvider';
import { Toaster } from 'sonner';
import './globals.css';

const outfit = Outfit({
  subsets: ['latin'],
  variable: '--font-geist-sans',
  display: 'swap',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-geist-mono',
  display: 'swap',
});

export const metadata: Metadata = {
  title: { default: 'WolfGPT', template: '%s | WolfGPT' },
  description: 'AI-powered platform for chat, images, voice, code, and music generation.',
  keywords: ['AI', 'chat', 'image generation', 'voice', 'code', 'music', 'WolfGPT'],
  authors: [{ name: 'WolfGPT' }],
  creator: 'WolfGPT',
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'),
  openGraph: {
    type: 'website',
    locale: 'en_US',
    title: 'WolfGPT — AI Platform',
    description: 'AI-powered platform for chat, images, voice, code, and music.',
    siteName: 'WolfGPT',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'WolfGPT — AI Platform',
    description: 'AI-powered platform for chat, images, voice, code, and music.',
  },
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon-16x16.png',
    apple: '/apple-touch-icon.png',
  },
  manifest: '/site.webmanifest',
};

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#f9f9fb' },
    { media: '(prefers-color-scheme: dark)',  color: '#060913' },
  ],
  width: 'device-width',
  initialScale: 1,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${outfit.variable} ${jetbrainsMono.variable} font-sans antialiased`}>
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem disableTransitionOnChange>
          {children}
          <Toaster richColors position="top-right" expand={false} />
        </ThemeProvider>
      </body>
    </html>
  );
}
