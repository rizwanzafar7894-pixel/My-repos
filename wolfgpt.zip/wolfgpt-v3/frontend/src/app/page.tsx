'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  MessageSquare, Image, Mic, Code2, Music, FileText,
  ArrowRight, Zap, Shield, Globe, ChevronRight, Star
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const features = [
  { icon: MessageSquare, label: 'AI Chat',          color: 'text-blue-400',   desc: 'Stream conversations with Llama, Mistral, Qwen & more' },
  { icon: Image,         label: 'Image Generation', color: 'text-violet-400', desc: 'FLUX & Stable Diffusion — txt2img, img2img, inpaint' },
  { icon: Mic,           label: 'Voice AI',         color: 'text-emerald-400',desc: 'Whisper STT + Coqui TTS with multi-language support' },
  { icon: Code2,         label: 'Code Execution',   color: 'text-amber-400',  desc: 'Run Python, JS, Go & more in a secure sandbox' },
  { icon: Music,         label: 'Music Generation', color: 'text-pink-400',   desc: 'MusicGen — create full tracks from text descriptions' },
  { icon: FileText,      label: 'Document AI',      color: 'text-cyan-400',   desc: 'Upload PDFs, chat with documents, summarize instantly' },
];

const stats = [
  { value: '100%',  label: 'Open Source Models' },
  { value: '0',     label: 'Third-party AI APIs' },
  { value: '4',     label: 'Payment Gateways' },
  { value: '∞',     label: 'Self-hosted' },
];

const container = { hidden: {}, show: { transition: { staggerChildren: 0.08 } } };
const item = {
  hidden: { opacity: 0, y: 20 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' } },
};

export default function HomePage() {
  return (
    <div className="min-h-screen bg-mesh overflow-hidden">

      {/* Nav */}
      <header className="fixed top-0 inset-x-0 z-50 border-b border-border/40 bg-background/80 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center shadow-glow-sm">
              <span className="text-primary-foreground font-bold text-sm">W</span>
            </div>
            <span className="font-bold text-lg tracking-tight">WolfGPT</span>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm text-muted-foreground">
            <Link href="#features" className="hover:text-foreground transition-colors">Features</Link>
            <Link href="#pricing"  className="hover:text-foreground transition-colors">Pricing</Link>
            <Link href="/login"    className="hover:text-foreground transition-colors">Sign in</Link>
          </nav>
          <div className="flex items-center gap-2">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/login">Sign in</Link>
            </Button>
            <Button size="sm" asChild className="shadow-glow-sm">
              <Link href="/register">Get started <ArrowRight className="ml-1 h-3.5 w-3.5" /></Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="pt-32 pb-20 px-4 sm:px-6">
        <div className="max-w-5xl mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <Badge variant="secondary" className="mb-6 gap-1.5 px-3 py-1 text-xs font-medium border border-primary/20 bg-primary/5 text-primary">
              <Zap className="h-3 w-3" /> 100% Open-source · Self-hosted
            </Badge>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-5xl sm:text-7xl font-bold tracking-tight mb-6 leading-tight"
          >
            Your AI platform,{' '}
            <span className="gradient-text">your infrastructure</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-xl text-muted-foreground max-w-2xl mx-auto mb-10 leading-relaxed"
          >
            Chat, generate images, clone voices, run code, compose music — all powered by
            free open-source models running on your own GPU server.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-3"
          >
            <Button size="lg" asChild className="px-8 shadow-glow">
              <Link href="/register">Start for free <ArrowRight className="ml-2 h-4 w-4" /></Link>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <Link href="/login">Sign in to dashboard</Link>
            </Button>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="grid grid-cols-2 sm:grid-cols-4 gap-6 mt-20 max-w-2xl mx-auto"
          >
            {stats.map((s) => (
              <div key={s.label} className="text-center">
                <div className="text-3xl font-bold text-foreground mb-1">{s.value}</div>
                <div className="text-xs text-muted-foreground">{s.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="py-20 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Everything in one platform</h2>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">
              Six powerful AI capabilities, all running locally on your GPU — no API keys, no vendor lock-in.
            </p>
          </div>

          <motion.div
            variants={container}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true }}
            className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4"
          >
            {features.map((f) => (
              <motion.div key={f.label} variants={item}>
                <div className="glass-card-hover p-6 h-full group cursor-default">
                  <div className={`${f.color} mb-4 transition-transform duration-200 group-hover:scale-110`}>
                    <f.icon className="h-7 w-7" />
                  </div>
                  <h3 className="font-semibold text-foreground mb-2">{f.label}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{f.desc}</p>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-20 px-4 sm:px-6 bg-grid">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Simple pricing</h2>
            <p className="text-muted-foreground">Start free. Upgrade when you need more.</p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { name: 'Free',    price: '$0',     period: '/forever', badge: null,          features: ['Unlimited chat','5 images/day','Qwen 2.5 7B','Voice AI', 'Community support'] },
              { name: 'Basic',   price: '$9.99',  period: '/month',   badge: null,          features: ['Everything free','25 images/day','2 chat models','100 voice mins/mo','API access (1 key)'] },
              { name: 'Premium', price: '$19.99', period: '/month',   badge: 'Most Popular', features: ['Everything basic','100 images/day','5 chat models','500 voice mins/mo','Priority queue','Analytics'] },
              { name: 'Pro',     price: '$39.99', period: '/month',   badge: 'Best Value',  features: ['Everything premium','Unlimited images','All models','Unlimited voice','Unlimited API','Dedicated support'] },
            ].map((plan) => (
              <div key={plan.name} className={`glass-card p-6 relative ${plan.badge ? 'border-primary/40 shadow-glow-sm' : ''}`}>
                {plan.badge && (
                  <Badge className="absolute -top-2.5 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground text-xs">
                    {plan.badge}
                  </Badge>
                )}
                <div className="mb-4">
                  <div className="font-semibold text-foreground mb-1">{plan.name}</div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl font-bold">{plan.price}</span>
                    <span className="text-sm text-muted-foreground">{plan.period}</span>
                  </div>
                </div>
                <ul className="space-y-2 mb-6">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <ChevronRight className="h-3.5 w-3.5 text-primary flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Button
                  variant={plan.badge ? 'default' : 'outline'}
                  size="sm"
                  className="w-full"
                  asChild
                >
                  <Link href="/register">Get started</Link>
                </Button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-10 px-4 sm:px-6">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-xs">W</span>
            </div>
            <span className="font-semibold text-sm">WolfGPT</span>
          </div>
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} WolfGPT. Open-source AI platform.
          </p>
          <div className="flex items-center gap-4 text-sm text-muted-foreground">
            <Link href="#" className="hover:text-foreground transition-colors">Privacy</Link>
            <Link href="#" className="hover:text-foreground transition-colors">Terms</Link>
            <Link href="#" className="hover:text-foreground transition-colors">GitHub</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
