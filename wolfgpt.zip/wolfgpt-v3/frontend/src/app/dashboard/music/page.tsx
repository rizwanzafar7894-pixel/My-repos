'use client';

import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Music, Loader2, Play, Pause, Download, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { apiClient } from '@/lib/api';
import { MODELS } from '@/constants';
import type { MusicModel } from '@/types';
import { toast } from 'sonner';

const EXAMPLES = [
  'Upbeat electronic dance music with heavy bass and synth leads',
  'Calm acoustic guitar melody for meditation, peaceful and soothing',
  'Epic orchestral score for a fantasy battle scene with drums and brass',
  'Lo-fi hip hop beat with vinyl crackle and mellow piano chords',
];

export default function MusicPage() {
  const [prompt, setPrompt]   = useState('');
  const [model, setModel]     = useState<MusicModel>('musicgen-small');
  const [duration, setDuration] = useState(10);
  const [loading, setLoading] = useState(false);
  const [tracks, setTracks]   = useState<{ url: string; prompt: string; model: string }[]>([]);
  const [playing, setPlaying] = useState<number | null>(null);
  const audioRefs = useRef<Record<number, HTMLAudioElement>>({});

  const generate = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    try {
      const res = await apiClient.generateMusic({ prompt, model, duration }) as any;
      const audio = res?.data?.audio || res?.audio || '';
      if (audio) {
        setTracks(prev => [{ url: audio, prompt, model }, ...prev.slice(0, 7)]);
      } else toast.error('No audio returned');
    } catch (e: any) {
      toast.error(e?.response?.data?.error?.message || 'Music generation failed');
    } finally { setLoading(false); }
  };

  const togglePlay = (i: number, url: string) => {
    if (playing === i) {
      audioRefs.current[i]?.pause();
      setPlaying(null);
    } else {
      Object.values(audioRefs.current).forEach(a => a.pause());
      if (!audioRefs.current[i]) {
        const a = new Audio(`data:audio/wav;base64,${url}`);
        a.onended = () => setPlaying(null);
        audioRefs.current[i] = a;
      }
      audioRefs.current[i].play();
      setPlaying(i);
    }
  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="mb-6">
        <h1 className="text-xl font-bold flex items-center gap-2">
          <Music className="h-5 w-5 text-pink-400" /> Music Generation
        </h1>
        <p className="text-sm text-muted-foreground mt-1">Powered by Meta MusicGen — text-to-music, fully local</p>
      </div>

      <div className="space-y-5 mb-8">
        <div className="space-y-1.5">
          <Label>Describe your music</Label>
          <Textarea
            placeholder="A calm piano melody with soft strings, perfect for studying..."
            value={prompt}
            onChange={e => setPrompt(e.target.value)}
            className="min-h-[100px] resize-none text-sm"
          />
          <div className="flex flex-wrap gap-1.5 mt-2">
            {EXAMPLES.map(ex => (
              <button
                key={ex}
                onClick={() => setPrompt(ex)}
                className="text-[11px] px-2.5 py-1 rounded-full border border-border text-muted-foreground hover:border-primary/40 hover:text-foreground transition-all"
              >
                {ex.slice(0, 40)}…
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label>Model</Label>
            <Select value={model} onValueChange={v => setModel(v as MusicModel)}>
              <SelectTrigger className="text-sm"><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.entries(MODELS.music).map(([id, m]) => (
                  <SelectItem key={id} value={id}>
                    <div>
                      <span className="font-medium">{m.name}</span>
                      <span className="text-xs text-muted-foreground ml-2">{m.vram}GB VRAM</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Duration: {duration}s</Label>
            <input type="range" min={5} max={30} step={5} value={duration}
              onChange={e => setDuration(Number(e.target.value))} className="w-full accent-primary mt-2" />
          </div>
        </div>

        <Button onClick={generate} disabled={loading || !prompt.trim()} className="w-full gap-2 shadow-glow-sm">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
          {loading ? 'Composing…' : 'Generate Music'}
        </Button>
      </div>

      {/* Tracks */}
      {tracks.length > 0 && (
        <div className="space-y-3">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">Generated Tracks</h2>
          {tracks.map((t, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-3 p-4 rounded-xl border border-border bg-card/50 hover:border-primary/30 transition-all"
            >
              <button
                onClick={() => togglePlay(i, t.url)}
                className="shrink-0 w-10 h-10 rounded-full bg-primary/10 border border-primary/20 flex items-center justify-center hover:bg-primary/20 transition-colors"
              >
                {playing === i ? <Pause className="h-4 w-4 text-primary" /> : <Play className="h-4 w-4 text-primary ml-0.5" />}
              </button>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{t.prompt}</p>
                <div className="flex items-center gap-2 mt-0.5">
                  <Badge variant="secondary" className="text-[10px]">{t.model}</Badge>
                  <div className="flex-1 h-1 rounded-full bg-muted overflow-hidden">
                    {playing === i && <motion.div className="h-full bg-primary rounded-full" animate={{ width: ['0%', '100%'] }} transition={{ duration: 10, ease: 'linear' }} />}
                  </div>
                </div>
              </div>
              <a href={`data:audio/wav;base64,${t.url}`} download={`wolfgpt-music-${i + 1}.wav`}>
                <Button variant="ghost" size="icon-sm"><Download className="h-4 w-4" /></Button>
              </a>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
