'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Code2, Play, Loader2, Terminal, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { apiClient } from '@/lib/api';
import { CODE_LANGUAGES } from '@/constants';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';

const STARTERS: Record<string, string> = {
  python:     'print("Hello, WolfGPT!")\n\n# Fibonacci\ndef fib(n):\n    a, b = 0, 1\n    for _ in range(n):\n        print(a, end=" ")\n        a, b = b, a + b\n\nfib(10)',
  javascript: 'console.log("Hello, WolfGPT!");\n\n// Fibonacci\nfunction fib(n) {\n  let [a, b] = [0, 1];\n  for (let i = 0; i < n; i++) {\n    process.stdout.write(a + " ");\n    [a, b] = [b, a + b];\n  }\n}\nfib(10);',
  bash:       '#!/bin/bash\necho "Hello, WolfGPT!"\nfor i in {1..5}; do echo "Line $i"; done',
};

export default function CodePage() {
  const [language, setLanguage] = useState('python');
  const [code, setCode]         = useState(STARTERS.python);
  const [stdin, setStdin]       = useState('');
  const [output, setOutput]     = useState<{ text: string; exitCode: number; duration: number } | null>(null);
  const [loading, setLoading]   = useState(false);

  const run = async () => {
    if (!code.trim()) return;
    setLoading(true);
    setOutput(null);
    try {
      const res = await apiClient.executeCode(code, language, stdin) as any;
      const d   = res?.data || res;
      setOutput({ text: d.output || '', exitCode: d.exitCode ?? 0, duration: d.duration ?? 0 });
    } catch (e: any) {
      toast.error(e?.response?.data?.error?.message || 'Execution failed');
    } finally { setLoading(false); }
  };

  const onLangChange = (l: string) => {
    setLanguage(l);
    if (STARTERS[l]) setCode(STARTERS[l]);
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-3 border-b border-border shrink-0">
        <div className="flex items-center gap-3">
          <Code2 className="h-5 w-5 text-amber-400" />
          <h1 className="font-bold">Code Executor</h1>
          <Select value={language} onValueChange={onLangChange}>
            <SelectTrigger className="h-7 w-36 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              {CODE_LANGUAGES.map(l => <SelectItem key={l.value} value={l.value}>{l.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="outline" onClick={() => { setCode(''); setOutput(null); }}>
            <Trash2 className="h-3.5 w-3.5" />
          </Button>
          <Button size="sm" onClick={run} disabled={loading || !code.trim()} className="gap-1.5 shadow-glow-sm">
            {loading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Play className="h-3.5 w-3.5" />}
            Run
          </Button>
        </div>
      </div>

      {/* Editor + Output */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Editor */}
        <div className="flex-1 flex flex-col border-b lg:border-b-0 lg:border-r border-border">
          <div className="px-3 py-1.5 border-b border-border bg-muted/30 flex items-center justify-between">
            <span className="text-xs text-muted-foreground font-mono">editor.{language === 'javascript' ? 'js' : language === 'typescript' ? 'ts' : language}</span>
          </div>
          <textarea
            value={code}
            onChange={e => setCode(e.target.value)}
            spellCheck={false}
            className="flex-1 p-4 bg-[#0d1117] text-[#e6edf3] font-mono text-sm resize-none outline-none leading-relaxed"
            style={{ fontFamily: 'var(--font-geist-mono)' }}
            onKeyDown={e => {
              if (e.key === 'Tab') { e.preventDefault(); const s = e.currentTarget.selectionStart; const v = code; setCode(v.slice(0, s) + '  ' + v.slice(e.currentTarget.selectionEnd)); setTimeout(() => e.currentTarget.setSelectionRange(s + 2, s + 2), 0); }
            }}
          />
          <div className="px-3 py-2 border-t border-border bg-muted/20">
            <Label className="text-xs mb-1 block text-muted-foreground">Stdin (optional)</Label>
            <Textarea
              value={stdin}
              onChange={e => setStdin(e.target.value)}
              placeholder="Enter input for your program…"
              className="h-12 text-xs font-mono resize-none bg-background/50"
            />
          </div>
        </div>

        {/* Output */}
        <div className="w-full lg:w-96 xl:w-[480px] flex flex-col shrink-0">
          <div className="px-3 py-1.5 border-b border-border bg-muted/30 flex items-center gap-2">
            <Terminal className="h-3.5 w-3.5 text-muted-foreground" />
            <span className="text-xs text-muted-foreground">Output</span>
            {output && (
              <>
                <Badge variant={output.exitCode === 0 ? 'success' : 'destructive'} className="text-[10px] ml-auto">
                  Exit {output.exitCode}
                </Badge>
                <span className="text-[10px] text-muted-foreground">{output.duration}ms</span>
              </>
            )}
          </div>
          <div className="flex-1 overflow-auto p-4 bg-[#0d1117]">
            {loading ? (
              <div className="flex items-center gap-2 text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                <span className="text-sm font-mono">Running…</span>
              </div>
            ) : output ? (
              <motion.pre
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className={cn(
                  'text-sm font-mono whitespace-pre-wrap leading-relaxed',
                  output.exitCode === 0 ? 'text-[#7ee787]' : 'text-[#ff7b72]'
                )}
                style={{ fontFamily: 'var(--font-geist-mono)' }}
              >
                {output.text || '(no output)'}
              </motion.pre>
            ) : (
              <p className="text-sm text-muted-foreground/40 font-mono">
                Click Run to execute your code…
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
