'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Image as ImageIcon, Sparkles, Download, RefreshCw, Loader2, Settings2, Lock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiClient } from '@/lib/api';
import { useAuthStore } from '@/store/auth';
import { MODELS, IMAGE_ASPECT_RATIOS, TIER_LIMITS } from '@/constants';
import type { ImageModel } from '@/types';
import { toast } from 'sonner';

export const metadata = { title: 'Images' };

const tierRank: Record<string, number> = { free: 0, basic: 1, premium: 2, pro: 3 };

export default function ImagesPage() {
  const { user } = useAuthStore();
  const rank = tierRank[user?.tier || 'free'];
  const limits = TIER_LIMITS[user?.tier || 'free'];

  const [prompt, setPrompt]           = useState('');
  const [negPrompt, setNegPrompt]     = useState('');
  const [model, setModel]             = useState<ImageModel>('flux-schnell');
  const [aspectRatio, setAspectRatio] = useState(IMAGE_ASPECT_RATIOS[0]);
  const [steps, setSteps]             = useState(4);
  const [loading, setLoading]         = useState(false);
  const [images, setImages]           = useState<{ url: string; prompt: string }[]>([]);
  const [showSettings, setShowSettings] = useState(false);

  const availableModels = Object.entries(MODELS.image).filter(([_, m]) =>
    m.tier.some(t => tierRank[t] <= rank)
  );

  const generate = async () => {
    if (!prompt.trim()) return;
    setLoading(true);
    try {
      const res = await apiClient.generateImage({
        prompt, negative_prompt: negPrompt,
        model, steps,
        width: aspectRatio.width, height: aspectRatio.height,
      }) as any;
      const url = res?.data?.image || res?.image || '';
      if (url) setImages(prev => [{ url, prompt }, ...prev.slice(0, 11)]);
      else toast.error('No image returned');
    } catch (e: any) {
      toast.error(e?.response?.data?.error?.message || 'Generation failed');
    } finally {
      setLoading(false);
    }
  };

  const download = (url: string, i: number) => {
    const a = document.createElement('a');
    a.href = url.startsWith('data:') ? url : `data:image/png;base64,${url}`;
    a.download = `wolfgpt-image-${i + 1}.png`;
    a.click();
  };

  return (
    <div className="h-full flex flex-col lg:flex-row">
      {/* Controls panel */}
      <div className="w-full lg:w-80 xl:w-96 border-b lg:border-b-0 lg:border-r border-border p-5 space-y-5 overflow-y-auto shrink-0">
        <div>
          <h1 className="text-lg font-bold flex items-center gap-2">
            <ImageIcon className="h-5 w-5 text-violet-400" /> Image Generation
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {limits.images.daily === -1 ? 'Unlimited' : `${limits.images.daily} images/day`} · {model}
          </p>
        </div>

        {/* Prompt */}
        <div className="space-y-1.5">
          <Label>Prompt</Label>
          <Textarea
            placeholder="A cinematic photo of a lone wolf standing on a mountain peak at golden hour, dramatic lighting, 8k..."
            value={prompt}
            onChange={e => setPrompt(e.target.value)}
            className="min-h-[110px] resize-none text-sm"
          />
        </div>

        {/* Model */}
        <div className="space-y-1.5">
          <Label>Model</Label>
          <Select value={model} onValueChange={v => setModel(v as ImageModel)}>
            <SelectTrigger className="text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(MODELS.image).map(([id, m]) => {
                const locked = !m.tier.some(t => tierRank[t] <= rank);
                return (
                  <SelectItem key={id} value={id} disabled={locked}>
                    <div className="flex items-center gap-2">
                      {locked && <Lock className="h-3 w-3 text-muted-foreground/50" />}
                      <span>{m.name}</span>
                      <span className="text-xs text-muted-foreground ml-1">{m.desc}</span>
                    </div>
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        </div>

        {/* Aspect ratio */}
        <div className="space-y-1.5">
          <Label>Aspect Ratio</Label>
          <div className="grid grid-cols-2 gap-1.5">
            {IMAGE_ASPECT_RATIOS.map(r => (
              <button
                key={r.label}
                onClick={() => setAspectRatio(r)}
                className={`text-xs px-2 py-1.5 rounded-lg border transition-all ${
                  aspectRatio.label === r.label
                    ? 'border-primary bg-primary/10 text-primary'
                    : 'border-border text-muted-foreground hover:border-primary/40'
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>
        </div>

        {/* Advanced toggle */}
        <button
          onClick={() => setShowSettings(!showSettings)}
          className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
        >
          <Settings2 className="h-3.5 w-3.5" />
          Advanced settings
        </button>

        <AnimatePresence>
          {showSettings && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="space-y-3"
            >
              <div className="space-y-1.5">
                <Label>Negative Prompt</Label>
                <Textarea
                  placeholder="blurry, low quality, deformed..."
                  value={negPrompt}
                  onChange={e => setNegPrompt(e.target.value)}
                  className="min-h-[70px] resize-none text-sm"
                />
              </div>
              <div className="space-y-1.5">
                <Label>Steps: {steps}</Label>
                <input
                  type="range" min={1} max={50} value={steps}
                  onChange={e => setSteps(Number(e.target.value))}
                  className="w-full accent-primary"
                />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <Button onClick={generate} disabled={loading || !prompt.trim()} className="w-full shadow-glow-sm gap-2">
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
          {loading ? 'Generating…' : 'Generate Image'}
        </Button>
      </div>

      {/* Gallery */}
      <div className="flex-1 p-5 overflow-y-auto">
        {images.length === 0 && !loading ? (
          <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
            <ImageIcon className="h-12 w-12 mb-4 opacity-20" />
            <p className="font-medium">No images yet</p>
            <p className="text-sm mt-1">Enter a prompt and click Generate</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
            {loading && (
              <div className="aspect-square rounded-xl bg-muted border border-border flex items-center justify-center">
                <div className="text-center">
                  <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-2" />
                  <p className="text-xs text-muted-foreground">Generating…</p>
                </div>
              </div>
            )}
            <AnimatePresence>
              {images.map((img, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="group relative aspect-square rounded-xl overflow-hidden border border-border bg-muted"
                >
                  <img
                    src={img.url.startsWith('data:') ? img.url : `data:image/png;base64,${img.url}`}
                    alt={img.prompt}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-white/80 line-clamp-2">{img.prompt}</p>
                    </div>
                    <button
                      onClick={() => download(img.url, i)}
                      className="ml-2 p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
                    >
                      <Download className="h-4 w-4" />
                    </button>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
