'use client';

import { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { motion, AnimatePresence } from 'framer-motion';
import { FileText, Upload, MessageSquare, Loader2, X, File } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { apiClient } from '@/lib/api';
import { formatBytes } from '@/lib/utils';
import { toast } from 'sonner';

interface Doc { id: string; name: string; size: number; }

export default function DocumentsPage() {
  const [docs, setDocs]       = useState<Doc[]>([]);
  const [activeDoc, setActiveDoc] = useState<Doc | null>(null);
  const [question, setQuestion]   = useState('');
  const [answer, setAnswer]       = useState('');
  const [uploading, setUploading] = useState(false);
  const [asking, setAsking]       = useState(false);

  const onDrop = useCallback(async (files: File[]) => {
    for (const file of files) {
      setUploading(true);
      try {
        const res = await apiClient.uploadDocument(file) as any;
        const id  = res?.data?.id || res?.id || Date.now().toString();
        setDocs(prev => [...prev, { id, name: file.name, size: file.size }]);
        toast.success(`${file.name} uploaded`);
      } catch { toast.error(`Failed to upload ${file.name}`); }
      finally { setUploading(false); }
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop, accept: { 'application/pdf': ['.pdf'], 'application/vnd.openxmlformats-officedocument.wordprocessingml.document': ['.docx'], 'text/plain': ['.txt'], 'text/csv': ['.csv'] },
    maxSize: 50 * 1024 * 1024,
  });

  const askQuestion = async () => {
    if (!question.trim() || !activeDoc) return;
    setAsking(true);
    try {
      const res = await apiClient.chatWithDocument(activeDoc.id, question) as any;
      setAnswer(res?.data?.answer || res?.answer || '');
    } catch { toast.error('Failed to get answer'); }
    finally { setAsking(false); }
  };

  return (
    <div className="flex h-full">
      {/* Doc list */}
      <div className="w-72 border-r border-border p-4 flex flex-col gap-4 shrink-0">
        <div>
          <h1 className="font-bold flex items-center gap-2">
            <FileText className="h-4 w-4 text-cyan-400" /> Documents
          </h1>
          <p className="text-xs text-muted-foreground mt-0.5">Upload PDFs, DOCX, TXT, CSV</p>
        </div>

        {/* Drop zone */}
        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all ${isDragActive ? 'border-primary bg-primary/5' : 'border-border hover:border-primary/40'}`}
        >
          <input {...getInputProps()} />
          {uploading ? (
            <Loader2 className="h-6 w-6 animate-spin text-primary mx-auto mb-1" />
          ) : (
            <Upload className="h-6 w-6 text-muted-foreground mx-auto mb-1" />
          )}
          <p className="text-xs text-muted-foreground">{isDragActive ? 'Drop here' : 'Drop files or click'}</p>
        </div>

        {/* Docs list */}
        <div className="flex-1 space-y-1.5 overflow-y-auto">
          <AnimatePresence>
            {docs.map(doc => (
              <motion.button
                key={doc.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                onClick={() => { setActiveDoc(doc); setAnswer(''); }}
                className={`w-full flex items-center gap-2.5 p-2.5 rounded-lg text-left transition-all ${activeDoc?.id === doc.id ? 'bg-primary/10 border border-primary/20' : 'hover:bg-accent'}`}
              >
                <File className="h-4 w-4 text-cyan-400 shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium truncate">{doc.name}</p>
                  <p className="text-[10px] text-muted-foreground">{formatBytes(doc.size)}</p>
                </div>
              </motion.button>
            ))}
          </AnimatePresence>
          {docs.length === 0 && <p className="text-xs text-muted-foreground text-center py-4">No documents yet</p>}
        </div>
      </div>

      {/* Chat area */}
      <div className="flex-1 flex flex-col p-5">
        {activeDoc ? (
          <>
            <div className="mb-4">
              <div className="flex items-center gap-2">
                <File className="h-4 w-4 text-cyan-400" />
                <span className="font-medium text-sm">{activeDoc.name}</span>
                <Badge variant="secondary" className="text-[10px]">{formatBytes(activeDoc.size)}</Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-1">Ask questions about this document</p>
            </div>

            {answer && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex-1 p-4 rounded-xl border border-border bg-secondary/30 text-sm leading-relaxed overflow-y-auto mb-4"
              >
                {answer}
              </motion.div>
            )}

            <div className="flex gap-2 mt-auto">
              <Input
                value={question}
                onChange={e => setQuestion(e.target.value)}
                placeholder="What is the main topic of this document?"
                onKeyDown={e => e.key === 'Enter' && askQuestion()}
                className="text-sm"
              />
              <Button onClick={askQuestion} disabled={asking || !question.trim()} className="gap-1.5 shrink-0">
                {asking ? <Loader2 className="h-4 w-4 animate-spin" /> : <MessageSquare className="h-4 w-4" />}
                Ask
              </Button>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
            <FileText className="h-12 w-12 mb-4 opacity-20" />
            <p className="font-medium">No document selected</p>
            <p className="text-sm mt-1">Upload a document and select it to start chatting</p>
          </div>
        )}
      </div>
    </div>
  );
}
