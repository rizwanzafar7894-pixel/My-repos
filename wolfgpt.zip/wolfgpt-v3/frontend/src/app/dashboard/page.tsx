import { redirect } from 'next/navigation';

// FIX #3: This page was missing, causing 404 on /dashboard
// Now redirects to the main chat interface
export default function DashboardPage() {
  redirect('/dashboard/chat');
}
