'use client';

import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { Mic, MicOff, Volume2, Loader2, Play, Square, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { apiClient } from '@/lib/api';
import { VOICE_CONFIG } from '@/constants';
import { toast } from 'sonner';
import { cn } from '@/lib/utils';

export default function VoicePage() {
  // STT
  const [recording, setRecording]   = useState(false);
  const [transcript, setTranscript] = useState('');
  const [sttLang, setSttLang]       = useState('en');
  const [sttLoading, setSttLoading] = useState(false);
  const mediaRef  = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  // TTS
  const [ttsText, setTtsText]   = useState('');
  const [voice, setVoice]       = useState('en-US-female-1');
  const [speed, setSpeed]       = useState(1.0);
  const [ttsLoading, setTtsLoading] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      chunksRef.current = [];
      const mr = new MediaRecorder(stream);
      mr.ondataavailable = e => chunksRef.current.push(e.data);
      mr.onstop = async () => {
        stream.getTracks().forEach(t => t.stop());
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        setSttLoading(true);
        try {
          const res = await apiClient.speechToText(blob, sttLang) as any;
          setTranscript(res?.data?.text || res?.text || '');
        } catch { toast.error('Transcription failed'); }
        finally { setSttLoading(false); }
      };
      mr.start();
      mediaRef.current = mr;
      setRecording(true);
    } catch { toast.error('Microphone access denied'); }
  };

  const stopRecording = () => {
    mediaRef.current?.stop();
    setRecording(false);
  };

  const synthesize = async () => {
    if (!ttsText.trim()) return;
    setTtsLoading(true);
    try {
      const blob = await apiClient.textToSpeech(ttsText, voice, speed) as Blob;
      const url = URL.createObjectURL(blob);
      setAudioUrl(url);
      audioRef.current = new Audio(url);
      audioRef.current.play();
    } catch { toast.error('Speech synthesis failed'); }
    finally { setTtsLoading(false); }
  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="mb-6">
        <h1 className="text-xl font-bold flex items-center gap-2">
          <Mic className="h-5 w-5 text-emerald-400" /> Voice AI
        </h1>
        <p className="text-sm text-muted-foreground mt-1">Speech-to-text with Whisper · Text-to-speech with Coqui TTS</p>
      </div>

      <Tabs defaultValue="stt">
        <TabsList className="mb-6">
          <TabsTrigger value="stt">Speech → Text</TabsTrigger>
          <TabsTrigger value="tts">Text → Speech</TabsTrigger>
        </TabsList>

        {/* STT */}
        <TabsContent value="stt" className="space-y-5">
          <div className="space-y-1.5">
            <Label>Language</Label>
            <Select value={sttLang} onValueChange={setSttLang}>
              <SelectTrigger className="w-48 text-sm"><SelectValue /></SelectTrigger>
              <SelectContent>
                {VOICE_CONFIG.stt.languages.map(l => (
                  <SelectItem key={l} value={l}>{l.toUpperCase()}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex flex-col items-center gap-5 py-8">
            <motion.button
              whileTap={{ scale: 0.95 }}
              onClick={recording ? stopRecording : startRecording}
              disabled={sttLoading}
              className={cn(
                'w-20 h-20 rounded-full flex items-center justify-center transition-all shadow-lg',
                recording
                  ? 'bg-destructive text-white shadow-red-500/30 animate-pulse'
                  : 'bg-primary text-primary-foreground shadow-glow hover:shadow-glow-lg'
              )}
            >
              {sttLoading ? <Loader2 className="h-8 w-8 animate-spin" /> :
               recording  ? <MicOff className="h-8 w-8" /> : <Mic className="h-8 w-8" />}
            </motion.button>
            <p className="text-sm text-muted-foreground">
              {sttLoading ? 'Transcribing…' : recording ? 'Recording… tap to stop' : 'Tap to start recording'}
            </p>
          </div>

          {transcript && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
              <Label className="mb-1.5 block">Transcript</Label>
              <div className="p-4 rounded-xl border border-border bg-secondary/30 text-sm leading-relaxed min-h-[80px]">
                {transcript}
              </div>
            </motion.div>
          )}
        </TabsContent>

        {/* TTS */}
        <TabsContent value="tts" className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label>Voice</Label>
              <Select value={voice} onValueChange={setVoice}>
                <SelectTrigger className="text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {VOICE_CONFIG.tts.voices.map(v => (
                    <SelectItem key={v.id} value={v.id}>{v.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Speed: {speed}x</Label>
              <input type="range" min={0.5} max={2} step={0.25} value={speed}
                onChange={e => setSpeed(Number(e.target.value))} className="w-full accent-primary mt-2" />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Text to speak</Label>
            <Textarea
              placeholder="Enter text to convert to speech…"
              value={ttsText}
              onChange={e => setTtsText(e.target.value)}
              className="min-h-[140px] resize-none text-sm"
              maxLength={5000}
            />
            <p className="text-xs text-muted-foreground text-right">{ttsText.length}/5000</p>
          </div>

          <div className="flex gap-3">
            <Button onClick={synthesize} disabled={ttsLoading || !ttsText.trim()} className="gap-2 shadow-glow-sm">
              {ttsLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Volume2 className="h-4 w-4" />}
              {ttsLoading ? 'Synthesizing…' : 'Generate Speech'}
            </Button>
            {audioUrl && (
              <>
                <Button variant="outline" onClick={() => audioRef.current?.play()} className="gap-2">
                  <Play className="h-4 w-4" /> Play
                </Button>
                <a href={audioUrl} download="wolfgpt-speech.wav">
                  <Button variant="outline" size="icon"><Download className="h-4 w-4" /></Button>
                </a>
              </>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
