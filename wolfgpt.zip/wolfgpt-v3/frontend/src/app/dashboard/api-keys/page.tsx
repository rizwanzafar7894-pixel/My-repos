'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Key, Plus, Copy, Trash2, CheckCircle, AlertCircle, Loader2, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { apiClient } from '@/lib/api';
import { useAuthStore } from '@/store/auth';
import { TIER_LIMITS } from '@/constants';
import { formatDate } from '@/lib/utils';
import type { ApiKey } from '@/types';
import { toast } from 'sonner';

export default function ApiKeysPage() {
  const { user }  = useAuthStore();
  const limits    = TIER_LIMITS[user?.tier || 'free'];
  const [keys, setKeys]       = useState<ApiKey[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [newKeyValue, setNewKeyValue] = useState<string | null>(null);
  const [showCreate, setShowCreate]   = useState(false);
  const [newName, setNewName]         = useState('');
  const [copied, setCopied]   = useState(false);

  useEffect(() => { loadKeys(); }, []);

  const loadKeys = async () => {
    setLoading(true);
    try {
      const res = await apiClient.getApiKeys() as any;
      setKeys(res?.data || res || []);
    } catch { toast.error('Failed to load API keys'); }
    finally { setLoading(false); }
  };

  const create = async () => {
    if (!newName.trim()) return;
    setCreating(true);
    try {
      const res = await apiClient.createApiKey(newName) as any;
      const key = res?.data?.key || res?.key || '';
      setNewKeyValue(key);
      setShowCreate(false);
      setNewName('');
      loadKeys();
      toast.success('API key created');
    } catch { toast.error('Failed to create key'); }
    finally { setCreating(false); }
  };

  const revoke = async (id: string) => {
    try {
      await apiClient.revokeApiKey(id);
      setKeys(prev => prev.map(k => k.id === id ? { ...k, active: false } : k));
      toast.success('Key revoked');
    } catch { toast.error('Failed to revoke key'); }
  };

  const copyKey = async (val: string) => {
    await navigator.clipboard.writeText(val);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const canCreate = limits.api.enabled && (limits.api.keys === -1 || keys.length < limits.api.keys);

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold flex items-center gap-2">
            <Key className="h-5 w-5 text-cyan-400" /> API Keys
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            {limits.api.enabled ? `${keys.length}/${limits.api.keys === -1 ? '∞' : limits.api.keys} keys` : 'Upgrade to access API'}
          </p>
        </div>
        <Button onClick={() => setShowCreate(true)} disabled={!canCreate} size="sm" className="gap-1.5">
          <Plus className="h-4 w-4" /> New Key
        </Button>
      </div>

      {!limits.api.enabled && (
        <Card className="mb-5 border-amber-500/20 bg-amber-500/5">
          <CardContent className="py-4 flex items-center gap-3">
            <AlertCircle className="h-5 w-5 text-amber-400 shrink-0" />
            <div>
              <p className="text-sm font-medium">API access requires Basic plan or higher</p>
              <p className="text-xs text-muted-foreground">Upgrade to use the WolfGPT API in your applications.</p>
            </div>
            <Button size="sm" variant="outline" className="ml-auto shrink-0" asChild>
              <a href="/dashboard/billing">Upgrade</a>
            </Button>
          </CardContent>
        </Card>
      )}

      {/* New key reveal */}
      {newKeyValue && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }}
          className="mb-5 p-4 rounded-xl border border-emerald-500/30 bg-emerald-500/5"
        >
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle className="h-4 w-4 text-emerald-400" />
            <span className="text-sm font-semibold text-emerald-400">Key created — copy it now!</span>
          </div>
          <p className="text-xs text-muted-foreground mb-2">This key won't be shown again.</p>
          <div className="flex gap-2">
            <code className="flex-1 text-xs bg-background border border-border rounded px-3 py-2 font-mono truncate">
              {newKeyValue}
            </code>
            <Button size="sm" variant="outline" onClick={() => copyKey(newKeyValue)}>
              {copied ? <CheckCircle className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setNewKeyValue(null)}>
              Dismiss
            </Button>
          </div>
        </motion.div>
      )}

      {/* Keys list */}
      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="h-6 w-6 animate-spin text-primary" /></div>
      ) : keys.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Key className="h-10 w-10 mx-auto mb-3 opacity-20" />
          <p className="font-medium">No API keys yet</p>
          <p className="text-sm mt-1">Create your first key to start building</p>
        </div>
      ) : (
        <div className="space-y-3">
          <AnimatePresence>
            {keys.map(k => (
              <motion.div key={k.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
                <Card className={!k.active ? 'opacity-60' : ''}>
                  <CardContent className="py-3 flex items-center gap-3">
                    <Key className="h-4 w-4 text-muted-foreground shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">{k.name}</span>
                        <Badge variant={k.active ? 'success' : 'secondary'} className="text-[10px]">
                          {k.active ? 'Active' : 'Revoked'}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground font-mono">{k.prefix}••••••••</p>
                      <div className="flex items-center gap-3 mt-0.5 text-[10px] text-muted-foreground">
                        <span>Created {formatDate(k.createdAt)}</span>
                        {k.lastUsed && <span>Last used {formatDate(k.lastUsed)}</span>}
                        <span>{k.usage} requests</span>
                      </div>
                    </div>
                    {k.active && (
                      <Button size="sm" variant="ghost" onClick={() => revoke(k.id)} className="text-destructive hover:text-destructive">
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    )}
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      {/* Create dialog */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create API Key</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <Label htmlFor="key-name">Key name</Label>
            <Input
              id="key-name"
              placeholder="e.g. Production App, My Script"
              value={newName}
              onChange={e => setNewName(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && create()}
              autoFocus
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowCreate(false)}>Cancel</Button>
            <Button onClick={create} disabled={creating || !newName.trim()}>
              {creating ? <Loader2 className="h-4 w-4 animate-spin" /> : 'Create Key'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
