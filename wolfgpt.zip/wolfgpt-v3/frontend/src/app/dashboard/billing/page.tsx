'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { CreditCard, Check, Loader2, Crown, ChevronRight, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { apiClient } from '@/lib/api';
import { useAuthStore } from '@/store/auth';
import { PRICING, PRICING_PKR } from '@/constants';
import type { UserTier } from '@/types';
import { toast } from 'sonner';

const PLANS = [
  { tier: 'free'    as UserTier, name: 'Free',    price: 0,     features: ['Unlimited chat','5 images/day','Qwen 2.5 7B only','Community support'] },
  { tier: 'basic'   as UserTier, name: 'Basic',   price: 9.99,  features: ['25 images/day','4 chat models','100 voice mins','API access (1 key)','Analytics'] },
  { tier: 'premium' as UserTier, name: 'Premium', price: 19.99, features: ['100 images/day','7 chat models','500 voice mins','Music generation','5 API keys','Priority queue'] },
  { tier: 'pro'     as UserTier, name: 'Pro',     price: 39.99, features: ['Unlimited everything','All models','Unlimited voice','Unlimited API','Dedicated support','Beta features'] },
];

const tierRank: Record<UserTier, number> = { free: 0, basic: 1, premium: 2, pro: 3 };

export default function BillingPage() {
  const { user }          = useAuthStore();
  const currentTier       = user?.tier || 'free';
  const currentRank       = tierRank[currentTier];
  const [period, setPeriod]       = useState<'monthly' | 'yearly'>('yearly');
  const [loading, setLoading]     = useState<string | null>(null);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [activePayTab, setActivePayTab] = useState('stripe');

  // Stripe checkout
  const stripeCheckout = async (tier: UserTier) => {
    setLoading(`stripe-${tier}`);
    try {
      const res = await apiClient.stripeCheckout(tier, period) as any;
      const url = res?.data?.url || res?.url;
      if (url) window.location.href = url;
      else toast.error('Failed to create Stripe session');
    } catch (e: any) {
      toast.error(e?.response?.data?.error?.message || 'Stripe checkout failed');
    } finally { setLoading(null); }
  };

  // Manage existing subscription
  const manageStripe = async () => {
    setLoading('portal');
    try {
      const res = await apiClient.stripeBillingPortal() as any;
      const url = res?.data?.url || res?.url;
      if (url) window.location.href = url;
    } catch { toast.error('Failed to open billing portal'); }
    finally { setLoading(null); }
  };

  // JazzCash
  const jazzCashCheckout = async (tier: UserTier) => {
    setLoading(`jazzcash-${tier}`);
    try {
      const res  = await apiClient.jazzCashInitiate(tier, 'yearly') as any;
      const data = res?.data;
      if (!data?.paymentUrl) { toast.error('JazzCash initiation failed'); return; }
      // Build and submit a form to JazzCash
      const form = document.createElement('form');
      form.method = 'POST'; form.action = data.paymentUrl;
      Object.entries(data.params || {}).forEach(([k, v]) => {
        const i = document.createElement('input');
        i.type = 'hidden'; i.name = k; i.value = v as string;
        form.appendChild(i);
      });
      document.body.appendChild(form); form.submit();
    } catch { toast.error('JazzCash checkout failed'); }
    finally { setLoading(null); }
  };

  // EasyPaisa
  const easyPaisaCheckout = async (tier: UserTier) => {
    if (!phoneNumber.match(/^03\d{9}$/)) { toast.error('Enter a valid Pakistani mobile number (03XXXXXXXXX)'); return; }
    setLoading(`easypaisa-${tier}`);
    try {
      const res = await apiClient.easyPaisaInitiate(tier, phoneNumber, 'yearly') as any;
      toast.success('EasyPaisa request sent. Check your phone for payment prompt.');
    } catch { toast.error('EasyPaisa checkout failed'); }
    finally { setLoading(null); }
  };

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-xl font-bold flex items-center gap-2">
            <CreditCard className="h-5 w-5 text-primary" /> Billing & Plans
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Current plan: <span className="text-foreground font-medium capitalize">{currentTier}</span>
            {user?.subscription?.status === 'active' && (
              <Badge variant="success" className="ml-2 text-[10px]">Active</Badge>
            )}
          </p>
        </div>
        {currentTier !== 'free' && (
          <Button variant="outline" size="sm" onClick={manageStripe} disabled={loading === 'portal'}>
            {loading === 'portal' ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Manage Subscription'}
          </Button>
        )}
      </div>

      {/* Period toggle */}
      <div className="flex items-center justify-center gap-3 mb-8">
        <button onClick={() => setPeriod('monthly')} className={`text-sm font-medium transition-colors ${period === 'monthly' ? 'text-foreground' : 'text-muted-foreground'}`}>Monthly</button>
        <button
          onClick={() => setPeriod(p => p === 'monthly' ? 'yearly' : 'monthly')}
          className={`relative w-11 h-6 rounded-full transition-colors ${period === 'yearly' ? 'bg-primary' : 'bg-muted'}`}
        >
          <span className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all ${period === 'yearly' ? 'left-6' : 'left-1'}`} />
        </button>
        <button onClick={() => setPeriod('yearly')} className={`text-sm font-medium transition-colors ${period === 'yearly' ? 'text-foreground' : 'text-muted-foreground'}`}>
          Yearly <Badge variant="success" className="ml-1 text-[10px]">Save 17%</Badge>
        </button>
      </div>

      {/* Plan cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {PLANS.map((plan) => {
          const isCurrent  = plan.tier === currentTier;
          const isUpgrade  = tierRank[plan.tier] > currentRank;
          const price      = period === 'yearly' ? PRICING[plan.tier].yearly : PRICING[plan.tier].monthly;
          const isPro      = plan.tier === 'pro';

          return (
            <motion.div key={plan.tier} whileHover={!isCurrent ? { y: -3 } : {}}>
              <Card className={`relative h-full flex flex-col ${isPro ? 'border-primary/50 shadow-glow-sm' : ''} ${isCurrent ? 'border-primary/30 bg-primary/3' : ''}`}>
                {isPro && <div className="absolute -top-3 left-1/2 -translate-x-1/2"><Badge className="gap-1 text-[10px]"><Crown className="h-2.5 w-2.5" /> Best Value</Badge></div>}
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">{plan.name}</CardTitle>
                  <div className="flex items-baseline gap-1 mt-1">
                    <span className="text-3xl font-bold">${price}</span>
                    <span className="text-xs text-muted-foreground">/{period === 'yearly' ? 'yr' : 'mo'}</span>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col">
                  <ul className="space-y-2 mb-5 flex-1">
                    {plan.features.map(f => (
                      <li key={f} className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Check className="h-3.5 w-3.5 text-primary shrink-0" />{f}
                      </li>
                    ))}
                  </ul>
                  {isCurrent ? (
                    <Button variant="outline" size="sm" disabled className="w-full text-xs">Current Plan</Button>
                  ) : plan.tier === 'free' ? (
                    <Button variant="outline" size="sm" disabled className="w-full text-xs">Always Free</Button>
                  ) : (
                    <Button
                      size="sm"
                      variant={isPro ? 'default' : 'outline'}
                      className={`w-full text-xs ${isPro ? 'shadow-glow-sm' : ''}`}
                      onClick={() => stripeCheckout(plan.tier)}
                      disabled={!!loading}
                    >
                      {loading === `stripe-${plan.tier}` ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : isUpgrade ? 'Upgrade' : 'Switch'}
                    </Button>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>

      {/* Pakistan payment methods */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Zap className="h-4 w-4 text-amber-400" /> Pakistan Payment Methods
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activePayTab} onValueChange={setActivePayTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="jazzcash">JazzCash</TabsTrigger>
              <TabsTrigger value="easypaisa">EasyPaisa</TabsTrigger>
            </TabsList>

            <TabsContent value="jazzcash">
              <p className="text-sm text-muted-foreground mb-4">Pay via JazzCash mobile wallet. Yearly plans only (PKR).</p>
              <div className="grid grid-cols-3 gap-3">
                {(['basic','premium','pro'] as UserTier[]).map(tier => (
                  <Card key={tier} className="p-3">
                    <p className="text-sm font-semibold capitalize mb-1">{tier}</p>
                    <p className="text-lg font-bold">Rs.{PRICING_PKR[tier as keyof typeof PRICING_PKR]?.yearly?.toLocaleString()}</p>
                    <p className="text-[10px] text-muted-foreground mb-3">/year</p>
                    <Button size="sm" variant="outline" className="w-full text-xs"
                      onClick={() => jazzCashCheckout(tier)} disabled={tier === currentTier || !!loading}>
                      {loading === `jazzcash-${tier}` ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Pay with JazzCash'}
                    </Button>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="easypaisa">
              <p className="text-sm text-muted-foreground mb-4">Pay via EasyPaisa mobile account. Enter your registered number.</p>
              <div className="space-y-3 mb-4">
                <Label htmlFor="phone">Mobile Number</Label>
                <Input id="phone" placeholder="03XXXXXXXXX" value={phoneNumber} onChange={e => setPhoneNumber(e.target.value)} className="max-w-xs" />
              </div>
              <div className="grid grid-cols-3 gap-3">
                {(['basic','premium','pro'] as UserTier[]).map(tier => (
                  <Card key={tier} className="p-3">
                    <p className="text-sm font-semibold capitalize mb-1">{tier}</p>
                    <p className="text-lg font-bold">Rs.{PRICING_PKR[tier as keyof typeof PRICING_PKR]?.yearly?.toLocaleString()}</p>
                    <p className="text-[10px] text-muted-foreground mb-3">/year</p>
                    <Button size="sm" variant="outline" className="w-full text-xs"
                      onClick={() => easyPaisaCheckout(tier)} disabled={tier === currentTier || !!loading}>
                      {loading === `easypaisa-${tier}` ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : 'Pay with EasyPaisa'}
                    </Button>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
