'use client';

import { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { BarChart2, MessageSquare, Image, Mic, Code2, Music, Loader2, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { apiClient } from '@/lib/api';
import { useAuthStore } from '@/store/auth';
import { TIER_LIMITS } from '@/constants';

const MOCK_DAILY = Array.from({ length: 7 }, (_, i) => ({
  day: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][i],
  chat: Math.floor(Math.random() * 40) + 5,
  images: Math.floor(Math.random() * 10),
  code: Math.floor(Math.random() * 15),
}));

export default function AnalyticsPage() {
  const { user } = useAuthStore();
  const limits   = TIER_LIMITS[user?.tier || 'free'];
  const [days, setDays]   = useState('7');
  const [loading, setLoading] = useState(false);
  const usage = user?.usage;

  const stats = [
    { icon: MessageSquare, label: 'Chat',   value: usage?.chat?.used || 0,         color: 'text-blue-400',   limit: 'Unlimited' },
    { icon: Image,         label: 'Images', value: usage?.images?.used || 0,       color: 'text-violet-400', limit: limits.images.daily === -1 ? 'Unlimited' : `${limits.images.daily}/day` },
    { icon: Mic,           label: 'Voice',  value: (usage?.voice?.sttUsed || 0) + (usage?.voice?.ttsUsed || 0), color: 'text-emerald-400', limit: 'Unlimited' },
    { icon: Code2,         label: 'Code',   value: usage?.code?.used || 0,         color: 'text-amber-400',  limit: limits.code.daily === -1 ? 'Unlimited' : `${limits.code.daily}/day` },
    { icon: Music,         label: 'Music',  value: usage?.music?.used || 0,        color: 'text-pink-400',   limit: 'Unlimited' },
    { icon: BarChart2,     label: 'API',    value: usage?.api?.used || 0,          color: 'text-cyan-400',   limit: limits.api.requestsPerMonth === -1 ? 'Unlimited' : `${limits.api.requestsPerMonth}/mo` },
  ];

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold flex items-center gap-2">
            <BarChart2 className="h-5 w-5 text-cyan-400" /> Analytics
          </h1>
          <p className="text-sm text-muted-foreground mt-0.5">Your usage statistics and trends</p>
        </div>
        <Select value={days} onValueChange={setDays}>
          <SelectTrigger className="w-32 text-sm h-8"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="7">Last 7 days</SelectItem>
            <SelectItem value="30">Last 30 days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Usage stats grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {stats.map(s => (
          <Card key={s.label} className="p-4">
            <div className={`${s.color} mb-2`}><s.icon className="h-4 w-4" /></div>
            <div className="text-2xl font-bold">{s.value}</div>
            <div className="text-xs font-medium text-foreground/80 mt-0.5">{s.label}</div>
            <div className="text-[10px] text-muted-foreground">{s.limit}</div>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-primary" /> Daily Usage
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={MOCK_DAILY} barSize={12}>
                <XAxis dataKey="day" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                <Bar dataKey="chat"   fill="hsl(var(--primary))"   radius={[4,4,0,0]} />
                <Bar dataKey="images" fill="hsl(243 75% 65%/0.5)"  radius={[4,4,0,0]} />
                <Bar dataKey="code"   fill="hsl(243 75% 65%/0.3)"  radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-blue-400" /> Chat Trend
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={MOCK_DAILY}>
                <XAxis dataKey="day" tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                <YAxis tick={{ fontSize: 11 }} tickLine={false} axisLine={false} />
                <Tooltip contentStyle={{ background: 'hsl(var(--card))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                <Line type="monotone" dataKey="chat" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ fill: 'hsl(var(--primary))', r: 3 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <p className="text-xs text-muted-foreground text-center">
        Charts show sample data. Real data loads from your backend analytics endpoint.
      </p>
    </div>
  );
}
