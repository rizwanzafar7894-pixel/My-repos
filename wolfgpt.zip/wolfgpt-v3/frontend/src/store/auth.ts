import { create } from 'zustand';
import type { User } from '@/types';
import {
  signIn as fbSignIn,
  signUp as fbSignUp,
  signInWithGoogle as fbGoogle,
  logOut as fbLogOut,
  onAuthChange,
} from '@/lib/firebase';

async function syncWithBackend(fbUser: any): Promise<User | null> {
  try {
    const token = await fbUser.getIdToken();
    const res   = await fetch(`${process.env.NEXT_PUBLIC_API_URL || ''}/api/auth/verify`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ token }),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.data as User;
  } catch { return null; }
}

interface AuthState {
  user:        User | null;
  loading:     boolean;
  error:       string | null;
  initialized: boolean;

  initialize:       () => () => void;
  signIn:           (email: string, password: string) => Promise<void>;
  signUp:           (email: string, password: string, displayName: string) => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  logOut:           () => Promise<void>;
  updateUser:       (partial: Partial<User>) => void;
  refreshUser:      () => Promise<void>;
  clearError:       () => void;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user:        null,
  loading:     true,
  error:       null,
  initialized: false,

  initialize: () => {
    const unsub = onAuthChange(async (fbUser) => {
      if (fbUser) {
        const user = await syncWithBackend(fbUser);
        set({ user, loading: false, initialized: true });
      } else {
        set({ user: null, loading: false, initialized: true });
      }
    });
    return unsub;
  },

  signIn: async (email, password) => {
    set({ loading: true, error: null });
    const { user: fbUser, error } = await fbSignIn(email, password);
    if (error || !fbUser) {
      set({ loading: false, error: error || 'Sign in failed' });
      return;
    }
    const user = await syncWithBackend(fbUser);
    set({ user, loading: false });
  },

  signUp: async (email, password, displayName) => {
    set({ loading: true, error: null });
    const { user: fbUser, error } = await fbSignUp(email, password, displayName);
    if (error || !fbUser) {
      set({ loading: false, error: error || 'Sign up failed' });
      return;
    }
    const user = await syncWithBackend(fbUser);
    set({ user, loading: false });
  },

  signInWithGoogle: async () => {
    set({ loading: true, error: null });
    const { user: fbUser, error } = await fbGoogle();
    if (error || !fbUser) {
      set({ loading: false, error: error || 'Google sign in failed' });
      return;
    }
    const user = await syncWithBackend(fbUser);
    set({ user, loading: false });
  },

  logOut: async () => {
    await fbLogOut();
    set({ user: null });
  },

  updateUser: (partial) => {
    set(state => ({ user: state.user ? { ...state.user, ...partial } : null }));
  },

  refreshUser: async () => {
    const { auth } = await import('@/lib/firebase');
    const fbUser = auth.currentUser;
    if (!fbUser) return;
    await fbUser.reload();
    const user = await syncWithBackend(fbUser);
    set({ user });
  },

  clearError: () => set({ error: null }),
}));
