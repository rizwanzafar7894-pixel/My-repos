// ── User & Auth ───────────────────────────────────────────────────────────────
export type UserTier = 'free' | 'basic' | 'premium' | 'pro';

export interface User {
  uid:         string;
  email:       string;
  displayName: string;
  photoURL?:   string;
  tier:        UserTier;
  usage:       UsageStats;
  subscription?: Subscription;
  createdAt:   Date | string;
  updatedAt:   Date | string;
}

export interface UsageStats {
  chat:  { used: number };
  images:{ used: number };
  code:  { used: number };
  voice: { sttUsed: number; ttsUsed: number };
  music: { used: number };
  api:   { used: number };
}

export interface Subscription {
  status:    'active' | 'cancelled' | 'paused' | 'past_due';
  provider:  'stripe' | 'paypal' | 'jazzcash' | 'easypaisa';
  planId:    string;
  expiresAt?: Date | string;
}

export interface FeatureLimits {
  tier:      UserTier;
  chat:      { unlimited: boolean; model: string[]; contextWindow: number };
  images:    { daily: number; models: string[]; maxResolution: number };
  code:      { daily: number; languages: string[]; timeout: number };
  voice:     { unlimited: boolean; minutesPerMonth?: number };
  api:       { enabled: boolean; requestsPerMonth: number; rateLimit: number; keys: number };
  storage:   { gb: number };
  projects:  { max: number };
  documents: { max: number };
  features:  string[];
}

// ── Chat ─────────────────────────────────────────────────────────────────────
export interface Message {
  id?:       string;
  role:      'user' | 'assistant' | 'system';
  content:   string;
  createdAt?: Date | string;
}

export interface Conversation {
  id:        string;
  userId:    string;
  title?:    string;
  messages:  Message[];
  model:     string;
  archived?: boolean;
  pinned?:   boolean;
  createdAt: Date | string;
  updatedAt: Date | string;
}

export type ChatModel =
  | 'qwen-2.5-7b' | 'qwen-2.5-32b' | 'qwen-2.5-72b'
  | 'llama-3.2-3b' | 'llama-3.1-8b' | 'llama-3.1-70b'
  | 'mistral-7b' | 'gemma-2-9b'
  | 'deepseek-r1-7b' | 'deepseek-coder-v2'
  | 'llava-7b' | 'llava-13b' | 'llava-34b'
  | 'codellama-7b';

// ── Images ────────────────────────────────────────────────────────────────────
export type ImageModel = 'flux-schnell' | 'flux-dev' | 'flux-pro' | 'sdxl-base' | 'sdxl-refiner';

export interface ImageGenerationRequest {
  prompt:          string;
  negative_prompt?: string;
  model?:          ImageModel;
  width?:          number;
  height?:         number;
  steps?:          number;
  guidance_scale?: number;
  seed?:           number;
}

export interface GeneratedImage {
  id:        string;
  url:       string;
  base64?:   string;
  prompt:    string;
  model:     string;
  width:     number;
  height:    number;
  createdAt: Date | string;
}

// ── Voice ─────────────────────────────────────────────────────────────────────
export interface STTResult {
  text:       string;
  language:   string;
  duration?:  number;
  confidence: number;
}

export interface TTSRequest {
  text:   string;
  voice?: string;
  speed?: number;
}

// ── Code ─────────────────────────────────────────────────────────────────────
export type CodeLanguage = 'python' | 'javascript' | 'typescript' | 'bash' | 'go' | 'rust' | 'java' | 'cpp' | 'ruby';

export interface CodeExecutionResult {
  output:   string;
  error?:   string;
  exitCode: number;
  duration: number;
}

// ── Music ─────────────────────────────────────────────────────────────────────
export type MusicModel = 'musicgen-small' | 'musicgen-medium' | 'musicgen-large' | 'musicgen-melody' | 'musicgen-stereo-small';

export interface MusicGenerationRequest {
  prompt:    string;
  model?:    MusicModel;
  duration?: number;
}

// ── API Keys ──────────────────────────────────────────────────────────────────
export interface ApiKey {
  id:        string;
  name:      string;
  prefix:    string;
  lastUsed?: Date | string;
  createdAt: Date | string;
  active:    boolean;
  usage:     number;
}

// ── Payments ──────────────────────────────────────────────────────────────────
export type PaymentProvider = 'stripe' | 'paypal' | 'jazzcash' | 'easypaisa';
export type BillingPeriod   = 'monthly' | 'yearly';

export interface PlanSelection {
  tier:     UserTier;
  period:   BillingPeriod;
  provider: PaymentProvider;
}

// ── UI ────────────────────────────────────────────────────────────────────────
export interface NavItem {
  label:     string;
  href:      string;
  icon:      React.ComponentType<{ className?: string }>;
  badge?:    string;
  tier?:     UserTier;
}

export interface ToastOptions {
  title:       string;
  description?: string;
  variant?:    'default' | 'destructive' | 'success';
}
