'use client';

import { Bot, ChevronDown, Lock } from 'lucide-react';
import { Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { MODELS } from '@/constants';
import type { UserTier } from '@/types';
import { cn } from '@/lib/utils';

interface Props {
  value: string;
  onChange: (v: string) => void;
  userTier: UserTier;
}

const tierRank: Record<UserTier, number> = { free: 0, basic: 1, premium: 2, pro: 3 };

const providerColors: Record<string, string> = {
  Alibaba:  'text-orange-400',
  Meta:     'text-blue-400',
  Mistral:  'text-violet-400',
  Google:   'text-emerald-400',
  DeepSeek: 'text-cyan-400',
};

export default function ModelSelector({ value, onChange, userTier }: Props) {
  const rank = tierRank[userTier];

  const allModels = Object.entries(MODELS.chat).map(([id, m]) => ({
    id,
    ...m,
    locked: !m.tier.some((t: UserTier) => tierRank[t] <= rank),
  }));

  const current = MODELS.chat[value as keyof typeof MODELS.chat];

  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger className="w-[210px] h-8 text-xs border-border/60 bg-background gap-1.5">
        <Bot className="h-3.5 w-3.5 text-primary shrink-0" />
        <SelectValue>
          <span className="font-medium">{current?.name || value}</span>
        </SelectValue>
      </SelectTrigger>
      <SelectContent className="max-h-[380px]">
        {/* Group by provider */}
        {['Alibaba', 'Meta', 'Mistral', 'Google', 'DeepSeek'].map(provider => {
          const models = allModels.filter(m => m.provider === provider);
          if (!models.length) return null;
          return (
            <SelectGroup key={provider}>
              <SelectLabel className={cn('text-[10px]', providerColors[provider])}>
                {provider}
              </SelectLabel>
              {models.map(m => (
                <SelectItem
                  key={m.id}
                  value={m.id}
                  disabled={m.locked}
                  className="text-xs py-2"
                >
                  <div className="flex items-center gap-2 w-full">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-medium">{m.name}</span>
                        {m.locked && <Lock className="h-3 w-3 text-muted-foreground/50" />}
                      </div>
                      <p className="text-[10px] text-muted-foreground truncate max-w-[200px]">{m.desc}</p>
                    </div>
                    {m.tier.includes('free' as UserTier) && (
                      <Badge variant="secondary" className="text-[9px] px-1.5 py-0 ml-auto">Free</Badge>
                    )}
                  </div>
                </SelectItem>
              ))}
            </SelectGroup>
          );
        })}
      </SelectContent>
    </Select>
  );
}
