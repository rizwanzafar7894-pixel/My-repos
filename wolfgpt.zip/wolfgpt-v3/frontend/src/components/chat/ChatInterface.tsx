'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Send, StopCircle, Trash2, Plus, Bot, User, Copy, Check, Sparkles } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import ModelSelector from './ModelSelector';
import { apiClient } from '@/lib/api';
import { useAuthStore } from '@/store/auth';
import { cn } from '@/lib/utils';
import type { Message } from '@/types';
import { toast } from 'sonner';

const SUGGESTIONS = [
  'Explain quantum computing in simple terms',
  'Write a Python script to parse CSV files',
  'What are the best practices for REST API design?',
  'Help me debug this TypeScript error',
];

export default function ChatInterface() {
  const { user } = useAuthStore();
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [model, setModel] = useState('qwen-2.5-7b');
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = useCallback(async () => {
    const text = input.trim();
    if (!text || loading) return;

    const userMsg: Message = { id: Date.now().toString(), role: 'user', content: text };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    const assistantId = (Date.now() + 1).toString();
    setMessages(prev => [...prev, { id: assistantId, role: 'assistant', content: '' }]);

    abortRef.current = new AbortController();

    try {
      await apiClient.chatStream(
        [...messages, userMsg].map(({ role, content }) => ({ role, content })),
        model,
        (chunk) => {
          setMessages(prev =>
            prev.map(m => m.id === assistantId ? { ...m, content: m.content + chunk } : m)
          );
        },
        {},
        abortRef.current.signal,
      );
    } catch (err: any) {
      if (err.name === 'AbortError') return;
      toast.error('Failed to get response. Please try again.');
      setMessages(prev => prev.filter(m => m.id !== assistantId));
    } finally {
      setLoading(false);
      abortRef.current = null;
    }
  }, [input, loading, messages, model]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const copyMessage = async (content: string, id: string) => {
    await navigator.clipboard.writeText(content);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const clearChat = () => {
    setMessages([]);
    abortRef.current?.abort();
  };

  const isEmpty = messages.length === 0;

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-border shrink-0 bg-background/95 backdrop-blur sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <ModelSelector value={model} onChange={setModel} userTier={user?.tier || 'free'} />
        </div>
        {messages.length > 0 && (
          <Button variant="ghost" size="icon-sm" onClick={clearChat} title="Clear chat">
            <Trash2 className="h-4 w-4 text-muted-foreground" />
          </Button>
        )}
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6">
        {isEmpty ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center h-full text-center max-w-md mx-auto"
          >
            <div className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mb-5 shadow-glow-sm">
              <Sparkles className="h-8 w-8 text-primary" />
            </div>
            <h2 className="text-2xl font-bold mb-2">How can I help?</h2>
            <p className="text-muted-foreground mb-8 text-sm leading-relaxed">
              Ask me anything — I can write code, explain concepts, analyze data, and much more.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full">
              {SUGGESTIONS.map((s) => (
                <button
                  key={s}
                  onClick={() => setInput(s)}
                  className="text-left text-sm px-3 py-2.5 rounded-xl border border-border hover:border-primary/30 hover:bg-accent/50 transition-all text-muted-foreground hover:text-foreground"
                >
                  {s}
                </button>
              ))}
            </div>
          </motion.div>
        ) : (
          <AnimatePresence initial={false}>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.25 }}
                className={cn('flex gap-3', msg.role === 'user' ? 'flex-row-reverse' : 'flex-row')}
              >
                {/* Avatar */}
                <div className={cn(
                  'shrink-0 w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold',
                  msg.role === 'user'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-secondary border border-border text-foreground'
                )}>
                  {msg.role === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                </div>

                {/* Bubble */}
                <div className={cn('group relative max-w-[78%]', msg.role === 'user' ? 'items-end' : 'items-start')}>
                  <div className={cn(
                    'px-4 py-3 rounded-2xl text-sm leading-relaxed',
                    msg.role === 'user'
                      ? 'bg-primary text-primary-foreground rounded-tr-sm'
                      : 'bg-secondary border border-border/60 rounded-tl-sm'
                  )}>
                    {msg.role === 'assistant' ? (
                      <div className={cn('prose-wolf', !msg.content && 'typing-cursor')}>
                        {msg.content ? (
                          <ReactMarkdown
                            components={{
                              code({ node, inline, className, children, ...props }: any) {
                                const match = /language-(\w+)/.exec(className || '');
                                return !inline && match ? (
                                  <div className="code-block my-3 not-prose">
                                    <div className="flex items-center justify-between px-3 py-1.5 border-b border-border bg-muted/50">
                                      <span className="text-[11px] text-muted-foreground font-mono">{match[1]}</span>
                                    </div>
                                    <SyntaxHighlighter style={oneDark} language={match[1]} PreTag="div" {...props}>
                                      {String(children).replace(/\n$/, '')}
                                    </SyntaxHighlighter>
                                  </div>
                                ) : (
                                  <code className={className} {...props}>{children}</code>
                                );
                              },
                            }}
                          >
                            {msg.content}
                          </ReactMarkdown>
                        ) : (
                          <span className="text-muted-foreground">▋</span>
                        )}
                      </div>
                    ) : (
                      <p className="whitespace-pre-wrap">{msg.content}</p>
                    )}
                  </div>

                  {/* Copy button */}
                  {msg.content && (
                    <button
                      onClick={() => copyMessage(msg.content, msg.id!)}
                      className="absolute -bottom-6 right-0 opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded text-muted-foreground hover:text-foreground"
                    >
                      {copiedId === msg.id ? <Check className="h-3 w-3 text-emerald-500" /> : <Copy className="h-3 w-3" />}
                    </button>
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="px-4 pb-4 pt-2 shrink-0 border-t border-border/50 bg-background/95 backdrop-blur">
        <div className="relative flex items-end gap-2 bg-secondary/50 border border-border rounded-2xl px-4 py-3 focus-within:border-primary/50 focus-within:ring-1 focus-within:ring-primary/20 transition-all">
          <Textarea
            ref={textareaRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Message WolfGPT… (Enter to send, Shift+Enter for new line)"
            className="flex-1 min-h-[24px] max-h-[200px] border-0 bg-transparent p-0 resize-none focus-visible:ring-0 placeholder:text-muted-foreground/50 text-sm"
            rows={1}
          />
          <div className="flex items-center gap-1.5 shrink-0">
            {loading ? (
              <Button size="icon-sm" variant="ghost" onClick={() => abortRef.current?.abort()} title="Stop">
                <StopCircle className="h-4 w-4 text-destructive" />
              </Button>
            ) : (
              <Button
                size="icon-sm"
                onClick={sendMessage}
                disabled={!input.trim()}
                className={cn('transition-all', input.trim() ? 'shadow-glow-sm' : '')}
              >
                <Send className="h-3.5 w-3.5" />
              </Button>
            )}
          </div>
        </div>
        <p className="text-center text-[10px] text-muted-foreground/50 mt-2">
          WolfGPT can make mistakes. Verify important information.
        </p>
      </div>
    </div>
  );
}
