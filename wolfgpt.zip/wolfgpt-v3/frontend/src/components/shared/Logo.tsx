import { cn } from '@/lib/utils';

interface Props {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  className?: string;
}

const sizes = {
  sm: { icon: 'w-6 h-6 text-xs', text: 'text-sm' },
  md: { icon: 'w-8 h-8 text-sm', text: 'text-base' },
  lg: { icon: 'w-12 h-12 text-xl', text: 'text-xl' },
};

export default function Logo({ size = 'md', showText = true, className }: Props) {
  const s = sizes[size];
  return (
    <div className={cn('flex items-center gap-2', className)}>
      <div className={cn('rounded-xl bg-primary flex items-center justify-center shadow-glow-sm flex-shrink-0', s.icon)}>
        <span className="text-primary-foreground font-bold">W</span>
      </div>
      {showText && (
        <span className={cn('font-bold tracking-tight', s.text)}>WolfGPT</span>
      )}
    </div>
  );
}
