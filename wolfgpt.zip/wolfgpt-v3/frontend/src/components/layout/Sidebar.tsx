'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion } from 'framer-motion';
import {
  MessageSquare, Image, Mic, Code2, Music, FileText,
  BarChart2, Key, Settings, CreditCard, LogOut,
  ChevronRight, Zap, Crown
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { useAuthStore } from '@/store/auth';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { getInitials } from '@/lib/utils';
import { ROUTES } from '@/constants';

const navItems = [
  { label: 'Chat',        href: ROUTES.CHAT,      icon: MessageSquare },
  { label: 'Images',      href: ROUTES.IMAGES,    icon: Image         },
  { label: 'Voice',       href: ROUTES.VOICE,     icon: Mic           },
  { label: 'Code',        href: ROUTES.CODE,      icon: Code2         },
  { label: 'Music',       href: ROUTES.MUSIC,     icon: Music         },
  { label: 'Documents',   href: ROUTES.DOCUMENTS, icon: FileText      },
];

const bottomItems = [
  { label: 'Analytics',   href: ROUTES.ANALYTICS, icon: BarChart2  },
  { label: 'API Keys',    href: ROUTES.API_KEYS,  icon: Key        },
  { label: 'Billing',     href: ROUTES.BILLING,   icon: CreditCard },
  { label: 'Settings',    href: ROUTES.SETTINGS,  icon: Settings   },
];

const tierColors: Record<string, string> = {
  free:    'text-muted-foreground',
  basic:   'text-blue-400',
  premium: 'text-violet-400',
  pro:     'text-amber-400',
};

const tierBadge: Record<string, string> = {
  free:    'secondary',
  basic:   'secondary',
  premium: 'secondary',
  pro:     'secondary',
};

interface SidebarProps {
  onClose?: () => void;
}

export default function Sidebar({ onClose }: SidebarProps) {
  const pathname = usePathname();
  const { user, logOut } = useAuthStore();

  return (
    <aside className="flex h-full w-64 flex-col bg-sidebar border-r border-sidebar-border">
      {/* Logo */}
      <div className="flex items-center gap-2.5 px-4 h-14 border-b border-sidebar-border shrink-0">
        <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center shadow-glow-sm">
          <span className="text-primary-foreground font-bold text-sm">W</span>
        </div>
        <span className="font-bold text-lg tracking-tight text-sidebar-foreground">WolfGPT</span>
        {user?.tier === 'pro' && <Crown className="h-3.5 w-3.5 text-amber-400 ml-auto" />}
      </div>

      {/* Main nav */}
      <nav className="flex-1 overflow-y-auto p-3 space-y-0.5">
        <p className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-widest text-sidebar-foreground/40 mb-1">
          AI Tools
        </p>
        {navItems.map((item) => {
          const active = pathname === item.href || pathname.startsWith(item.href + '/');
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onClose}
              className={cn(
                'flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-150',
                active
                  ? 'bg-sidebar-accent text-sidebar-foreground shadow-inner-glow'
                  : 'text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent/60'
              )}
            >
              <item.icon className={cn('h-4 w-4 shrink-0', active ? 'text-primary' : '')} />
              {item.label}
              {active && (
                <motion.div
                  layoutId="sidebar-active"
                  className="ml-auto h-1.5 w-1.5 rounded-full bg-primary"
                />
              )}
            </Link>
          );
        })}

        <div className="pt-3 mt-2 border-t border-sidebar-border">
          <p className="px-3 py-1.5 text-[10px] font-semibold uppercase tracking-widest text-sidebar-foreground/40 mb-1">
            Account
          </p>
          {bottomItems.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={onClose}
                className={cn(
                  'flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-150',
                  active
                    ? 'bg-sidebar-accent text-sidebar-foreground'
                    : 'text-sidebar-foreground/60 hover:text-sidebar-foreground hover:bg-sidebar-accent/60'
                )}
              >
                <item.icon className={cn('h-4 w-4 shrink-0', active ? 'text-primary' : '')} />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>

      {/* Upgrade banner (free/basic only) */}
      {user && ['free', 'basic'].includes(user.tier) && (
        <div className="px-3 pb-3">
          <div className="rounded-xl bg-primary/5 border border-primary/15 p-3">
            <div className="flex items-center gap-2 mb-2">
              <Zap className="h-3.5 w-3.5 text-primary" />
              <span className="text-xs font-semibold text-foreground">Upgrade to Pro</span>
            </div>
            <p className="text-[11px] text-muted-foreground mb-2.5 leading-relaxed">
              Unlock unlimited images, all models, and priority access.
            </p>
            <Link href={ROUTES.BILLING} onClick={onClose}>
              <Button size="sm" className="w-full h-7 text-xs">
                View plans <ChevronRight className="h-3 w-3 ml-1" />
              </Button>
            </Link>
          </div>
        </div>
      )}

      {/* User profile */}
      <div className="p-3 border-t border-sidebar-border">
        <div className="flex items-center gap-3 px-2 py-1.5 rounded-lg">
          <Avatar className="h-8 w-8">
            <AvatarImage src={user?.photoURL || ''} />
            <AvatarFallback className="text-xs">{getInitials(user?.displayName || user?.email || 'U')}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate text-sidebar-foreground">{user?.displayName || 'User'}</p>
            <p className={cn('text-[11px] capitalize font-medium', tierColors[user?.tier || 'free'])}>
              {user?.tier || 'free'} plan
            </p>
          </div>
          <button
            onClick={logOut}
            className="shrink-0 p-1.5 rounded-md text-sidebar-foreground/40 hover:text-destructive hover:bg-destructive/10 transition-colors"
            title="Sign out"
          >
            <LogOut className="h-3.5 w-3.5" />
          </button>
        </div>
      </div>
    </aside>
  );
}
