// WolfGPT v3 — PM2 Ecosystem Config
// Usage:  pm2 start ecosystem.config.js
//         pm2 start ecosystem.config.js --env production

module.exports = {
  apps: [
    // ── Backend ──────────────────────────────────────────────────────────────
    {
      name: 'wolfgpt-backend',
      script: './backend/dist/server.js',
      cwd: '.',
      instances: 'max',  // cluster mode — one per CPU core
      exec_mode: 'cluster',
      autorestart: true,
      watch: false,
      max_memory_restart: '512M',
      env: {
        NODE_ENV: 'development',
        PORT: 4000,
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 4000,
      },
      error_file: './backend/logs/pm2-error.log',
      out_file:   './backend/logs/pm2-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
    },

    // ── Frontend (Next.js standalone) ────────────────────────────────────────
    {
      name: 'wolfgpt-frontend',
      script: './frontend/.next/standalone/server.js',
      cwd: '.',
      instances: 2,
      exec_mode: 'cluster',
      autorestart: true,
      watch: false,
      max_memory_restart: '768M',
      env: {
        NODE_ENV: 'development',
        PORT: 3000,
      },
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
        HOSTNAME: '0.0.0.0',
      },
      error_file: './frontend/logs/pm2-error.log',
      out_file:   './frontend/logs/pm2-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
      merge_logs: true,
    },

    // ── AI Service (Python/uvicorn) ───────────────────────────────────────────
    // Note: Use Docker for AI service in production for GPU isolation
    {
      name: 'wolfgpt-ai',
      script: 'uvicorn',
      interpreter: 'python3',
      args: 'main:app --host 0.0.0.0 --port 8000 --workers 1 --log-level info',
      cwd: './ai-services',
      autorestart: true,
      watch: false,
      max_memory_restart: '4G',
      env: {
        PORT: 8000,
        DEBUG: 'false',
      },
      error_file: './ai-services/logs/pm2-error.log',
      out_file:   './ai-services/logs/pm2-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss Z',
    },
  ],
};
