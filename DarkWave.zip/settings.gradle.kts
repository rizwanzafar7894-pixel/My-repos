pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://jitpack.io") }
    }
}

rootProject.name = "DarkWave"

include(":app")
include(":core:common")
include(":core:domain")
include(":core:data")
include(":feature:home")
include(":feature:media")
include(":feature:player")
include(":feature:musicplayer")
include(":feature:browser")
include(":feature:settings")
include(":feature:vault")
include(":feature:organizer")
include(":feature:converter")
include(":feature:bookmark")
include(":feature:editor")
include(":feature:analytics")
include(":feature:remote")
include(":feature:focus")
include(":feature:accessibility")
