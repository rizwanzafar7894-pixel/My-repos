package com.darkwave.app.ui.navigation

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darkwave.common.ui.theme.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences

@HiltViewModel
class SplashViewModel @Inject constructor(
    private val dataStore: DataStore<Preferences>
) : ViewModel() {

    private val _isOnboardingDone = MutableStateFlow<Boolean?>(null)
    val isOnboardingDone = _isOnboardingDone.asStateFlow()

    init {
        viewModelScope.launch {
            dataStore.data.collect { prefs ->
                _isOnboardingDone.value =
                    prefs[booleanPreferencesKey("onboarding_complete")] ?: false
            }
        }
    }
}

@Composable
fun SplashScreen(
    onNavigateToOnboarding: () -> Unit,
    onNavigateToHome: () -> Unit,
    viewModel: SplashViewModel = hiltViewModel()
) {
    val isOnboardingDone by viewModel.isOnboardingDone.collectAsState()

    // Progress animation
    val progress = remember { Animatable(0f) }
    val scale    = remember { Animatable(0.8f) }

    LaunchedEffect(Unit) {
        launch {
            scale.animateTo(1f, animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy))
        }
        launch {
            progress.animateTo(
                1f,
                animationSpec = tween(2200, easing = LinearEasing)
            )
        }
        delay(2500)
        when (isOnboardingDone) {
            true  -> onNavigateToHome()
            false -> onNavigateToOnboarding()
            null  -> onNavigateToOnboarding()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(White),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Purple circle play button — exact from screenshot
            Box(
                modifier = Modifier
                    .scale(scale.value)
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = listOf(Purple400, Purple600)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    tint = White,
                    modifier = Modifier.size(56.dp)
                )
            }

            Spacer(Modifier.height(32.dp))

            // DarkWave title
            Text(
                text = "DarkWave",
                fontSize = 36.sp,
                fontWeight = FontWeight.Bold,
                color = Purple500
            )

            Spacer(Modifier.height(6.dp))

            Text(
                text = "Complete Edition",
                fontSize = 16.sp,
                fontWeight = FontWeight.Normal,
                color = TextSecondary
            )

            Spacer(Modifier.height(40.dp))

            // Loading progress bar
            LinearProgressIndicator(
                progress = { progress.value },
                modifier = Modifier
                    .width(200.dp)
                    .height(3.dp),
                color = Purple500,
                trackColor = Purple100
            )

            Spacer(Modifier.height(12.dp))

            Text(
                text = "Loading amazing features...",
                fontSize = 13.sp,
                color = TextTertiary
            )
        }
    }
}
