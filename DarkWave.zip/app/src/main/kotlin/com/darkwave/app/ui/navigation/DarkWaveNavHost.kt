package com.darkwave.app.ui.navigation

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.*
import androidx.navigation.navArgument
import com.darkwave.analytics.AnalyticsScreen
import com.darkwave.accessibility.AccessibilityScreen
import com.darkwave.bookmark.BookmarkScreen
import com.darkwave.browser.BrowserScreen
import com.darkwave.common.animation.*
import com.darkwave.common.ui.theme.Background
import com.darkwave.converter.ConverterScreen
import com.darkwave.editor.EditorScreen
import com.darkwave.focus.FocusScreen
import com.darkwave.home.HomeScreen
import com.darkwave.media.VideoScreen
import com.darkwave.media.MusicScreen
import com.darkwave.musicplayer.NowPlayingScreen
import com.darkwave.musicplayer.ui.MiniPlayerBar
import com.darkwave.musicplayer.viewmodel.MusicPlayerViewModel
import com.darkwave.organizer.OrganizerScreen
import com.darkwave.player.VideoPlayerScreen
import com.darkwave.remote.RemoteScreen
import com.darkwave.settings.SettingsScreen
import com.darkwave.settings.tools.*
import com.darkwave.vault.VaultScreen

// Screens that show bottom nav
private val bottomNavRoutes = setOf(
    Screen.Home.route,
    Screen.Video.route,
    Screen.Music.route,
    Screen.Browser.route,
    Screen.Settings.route
)

// Screens that show MiniPlayer bar (all main screens except player screens)
private val miniPlayerRoutes = setOf(
    Screen.Home.route,
    Screen.Video.route,
    Screen.Music.route,
    Screen.Browser.route,
    Screen.Settings.route
)

@Composable
fun DarkWaveNavHost() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val showBottomBar  = currentRoute in bottomNavRoutes
    val showMiniPlayer = currentRoute in miniPlayerRoutes

    // Shared MusicPlayerViewModel - lives at NavHost level so MiniPlayer is always connected
    val musicPlayerViewModel: MusicPlayerViewModel = hiltViewModel()
    val musicState by musicPlayerViewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = Background,
        bottomBar = {
            Column {
                // FIX: MiniPlayer shown above bottom nav when music is playing
                if (showMiniPlayer && musicState.currentSong != null) {
                    MiniPlayerBar(
                        song       = musicState.currentSong,
                        isPlaying  = musicState.isPlaying,
                        onPlayPause = musicPlayerViewModel::togglePlayPause,
                        onNext      = musicPlayerViewModel::playNext,
                        onExpand    = { navController.navigate(Screen.NowPlaying.route) }
                    )
                }
                if (showBottomBar) {
                    DWBottomNavBar(navController = navController)
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController    = navController,
            startDestination = Screen.Splash.route,
            modifier         = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            enterTransition  = { fadeInAnim },
            exitTransition   = { fadeOutAnim },
            popEnterTransition  = { fadeInAnim },
            popExitTransition   = { fadeOutAnim }
        ) {
            // ── Splash ───────────────────────────────────────────────
            composable(Screen.Splash.route) {
                SplashScreen(
                    onNavigateToOnboarding = {
                        navController.navigate(Screen.Onboarding.route) {
                            popUpTo(Screen.Splash.route) { inclusive = true }
                        }
                    },
                    onNavigateToHome = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Splash.route) { inclusive = true }
                        }
                    }
                )
            }

            // ── Onboarding ───────────────────────────────────────────
            composable(
                route           = Screen.Onboarding.route,
                enterTransition = { slideInFromRight },
                exitTransition  = { slideOutToRight }
            ) {
                OnboardingScreen(
                    onComplete = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Onboarding.route) { inclusive = true }
                        }
                    }
                )
            }

            // ── Main tabs ────────────────────────────────────────────
            composable(Screen.Home.route) {
                HomeScreen(
                    onVideoClick     = { uri, title ->
                        navController.navigate(Screen.VideoPlayer.createRoute(uri, title))
                    },
                    onAudioClick      = { navController.navigate(Screen.NowPlaying.route) },
                    onOrganizerClick  = { navController.navigate(Screen.Organizer.route) },
                    onConverterClick  = { navController.navigate(Screen.Converter.route) },
                    onVaultClick      = { navController.navigate(Screen.Vault.route) },
                    onDownloadsClick  = { navController.navigate(Screen.Downloads.route) }
                )
            }

            composable(Screen.Video.route) {
                VideoScreen(
                    onVideoClick    = { uri, title ->
                        navController.navigate(Screen.VideoPlayer.createRoute(uri, title))
                    },
                    onBookmarkClick = { navController.navigate(Screen.Bookmarks.route) }
                )
            }

            composable(Screen.Music.route) {
                MusicScreen(
                    onAudioClick      = { navController.navigate(Screen.NowPlaying.route) },
                    onNowPlayingClick = { navController.navigate(Screen.NowPlaying.route) }
                )
            }

            composable(Screen.Browser.route) {
                BrowserScreen()
            }

            composable(Screen.Settings.route) {
                SettingsScreen(
                    onProfileClick       = { navController.navigate(Screen.ProfileEdit.route) },
                    onPlaybackClick      = { navController.navigate(Screen.Playback.route) },
                    onAppearanceClick    = { navController.navigate(Screen.Appearance.route) },
                    onAccessibilityClick = { navController.navigate(Screen.Accessibility.route) },
                    onPrivacyClick       = { navController.navigate(Screen.Privacy.route) },
                    onAnalyticsClick     = { navController.navigate(Screen.Analytics.route) },
                    onDownloadsClick     = { navController.navigate(Screen.Downloads.route) },
                    onStorageClick       = { navController.navigate(Screen.Storage.route) },
                    onNetworkClick       = { navController.navigate(Screen.Network.route) },
                    onBpmClick           = { navController.navigate(Screen.BpmDetector.route) },
                    onMetronomeClick     = { navController.navigate(Screen.Metronome.route) },
                    onTunerClick         = { navController.navigate(Screen.Tuner.route) },
                    onRecorderClick      = { navController.navigate(Screen.Recorder.route) },
                    onAnalyzerClick      = { navController.navigate(Screen.Analyzer.route) },
                    onEqualizerClick     = { navController.navigate(Screen.Equalizer.route) },
                    onRemoteClick        = { navController.navigate(Screen.Remote.route) },
                    onFocusClick         = { navController.navigate(Screen.Focus.route) }
                )
            }

            // ── Video Player ─────────────────────────────────────────
            composable(
                route = Screen.VideoPlayer.route,
                arguments = listOf(
                    navArgument("uri")   { type = NavType.StringType },
                    navArgument("title") { type = NavType.StringType }
                ),
                enterTransition  = { slideInFromBottom },
                exitTransition   = { slideOutToBottom },
                popExitTransition = { slideOutToBottom }
            ) { backStackEntry ->
                val uri   = Screen.decode(backStackEntry.arguments?.getString("uri") ?: "")
                val title = Screen.decode(backStackEntry.arguments?.getString("title") ?: "")
                VideoPlayerScreen(
                    uri   = uri,
                    title = title,
                    onBack = { navController.popBackStack() }
                )
            }

            // ── Now Playing ───────────────────────────────────────────
            composable(
                route           = Screen.NowPlaying.route,
                enterTransition = { slideInFromBottom },
                exitTransition  = { slideOutToBottom },
                popExitTransition = { slideOutToBottom }
            ) {
                NowPlayingScreen(onBack = { navController.popBackStack() })
            }

            // ── Tools ─────────────────────────────────────────────────
            composable(Screen.BpmDetector.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                BpmDetectorScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Metronome.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                MetronomeScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Tuner.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                TunerScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Recorder.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                RecorderScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Analyzer.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                AnalyzerScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Equalizer.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                EqualizerScreen(onBack = { navController.popBackStack() })
            }

            // ── Features ──────────────────────────────────────────────
            composable(Screen.Vault.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                VaultScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Organizer.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                OrganizerScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Converter.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                ConverterScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Bookmarks.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                BookmarkScreen(
                    onVideoBookmarkClick = { uri, title ->
                        navController.navigate(Screen.VideoPlayer.createRoute(uri, title))
                    },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.Editor.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                EditorScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Analytics.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                AnalyticsScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Remote.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                RemoteScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Focus.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                FocusScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Accessibility.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                AccessibilityScreen(onBack = { navController.popBackStack() })
            }

            // ── Settings sub-screens ──────────────────────────────────
            // FIX: These 4 composables were missing from original NavHost
            composable(Screen.ProfileEdit.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                ProfileEditScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Playback.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                PlaybackSettingsScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Appearance.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                AppearanceSettingsScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Privacy.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                PrivacySettingsScreen(onBack = { navController.popBackStack() })
            }

            composable(Screen.Downloads.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                DownloadSettingsScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Storage.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                StorageScreen(onBack = { navController.popBackStack() })
            }
            composable(Screen.Network.route,
                enterTransition = { slideInFromRight }, exitTransition = { slideOutToRight }) {
                NetworkSettingsScreen(onBack = { navController.popBackStack() })
            }
        }
    }
}
