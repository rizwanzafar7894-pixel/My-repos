package com.darkwave.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.widget.RemoteViews
import com.darkwave.app.MainActivity
import com.darkwave.app.R

/**
 * 4×1 compact now-playing widget.
 * Controls: SkipPrev | Play/Pause | SkipNext
 * Shows: album art thumbnail + song title + artist
 *
 * Update flow:
 *   MusicPlayerViewModel → sendBroadcast(ACTION_WIDGET_UPDATE) with extras
 *   ↓
 *   DarkWaveMiniWidget.onReceive → RemoteViews update
 */
class DarkWaveMiniWidget : AppWidgetProvider() {

    companion object {
        const val ACTION_PLAY_PAUSE = "com.darkwave.widget.PLAY_PAUSE"
        const val ACTION_NEXT       = "com.darkwave.widget.NEXT"
        const val ACTION_PREV       = "com.darkwave.widget.PREV"
        const val ACTION_UPDATE     = "com.darkwave.widget.UPDATE"

        const val EXTRA_TITLE       = "extra_title"
        const val EXTRA_ARTIST      = "extra_artist"
        const val EXTRA_IS_PLAYING  = "extra_is_playing"
        const val EXTRA_ALBUM_ART   = "extra_album_art"   // Uri string

        /** Call from MusicPlayerViewModel whenever track/state changes */
        fun push(
            context: Context,
            title: String,
            artist: String,
            isPlaying: Boolean,
            albumArtUri: String? = null
        ) {
            val intent = Intent(context, DarkWaveMiniWidget::class.java).apply {
                action = ACTION_UPDATE
                putExtra(EXTRA_TITLE,      title)
                putExtra(EXTRA_ARTIST,     artist)
                putExtra(EXTRA_IS_PLAYING, isPlaying)
                putExtra(EXTRA_ALBUM_ART,  albumArtUri)
            }
            context.sendBroadcast(intent)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { id -> updateWidget(context, appWidgetManager, id, null, null, false, null) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)

        when (intent.action) {
            ACTION_PLAY_PAUSE -> forwardToService(context, ACTION_PLAY_PAUSE)
            ACTION_NEXT       -> forwardToService(context, ACTION_NEXT)
            ACTION_PREV       -> forwardToService(context, ACTION_PREV)
            ACTION_UPDATE     -> {
                val mgr    = AppWidgetManager.getInstance(context)
                val ids    = mgr.getAppWidgetIds(ComponentName(context, DarkWaveMiniWidget::class.java))
                val title  = intent.getStringExtra(EXTRA_TITLE)
                val artist = intent.getStringExtra(EXTRA_ARTIST)
                val isPlay = intent.getBooleanExtra(EXTRA_IS_PLAYING, false)
                val artUri = intent.getStringExtra(EXTRA_ALBUM_ART)
                ids.forEach { id -> updateWidget(context, mgr, id, title, artist, isPlay, artUri) }
            }
        }
    }

    private fun updateWidget(
        context: Context,
        mgr: AppWidgetManager,
        id: Int,
        title: String?,
        artist: String?,
        isPlaying: Boolean,
        albumArtUri: String?
    ) {
        val views = RemoteViews(context.packageName, R.layout.widget_mini)

        // ── Text ──────────────────────────────────────────────────────
        views.setTextViewText(R.id.widget_title,  title  ?: "DarkWave")
        views.setTextViewText(R.id.widget_artist, artist ?: "Not playing")

        // ── Play/Pause icon ───────────────────────────────────────────
        val playIcon = if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        views.setImageViewResource(R.id.widget_btn_play_pause, playIcon)

        // ── Album art ─────────────────────────────────────────────────
        val art = loadAlbumArt(context, albumArtUri)
        if (art != null) views.setImageViewBitmap(R.id.widget_album_art, art)
        else             views.setImageViewResource(R.id.widget_album_art, R.drawable.ic_music_note_placeholder)

        // ── Tap → open app ────────────────────────────────────────────
        val openApp = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).apply { action = "com.darkwave.ACTION_OPEN_NOW_PLAYING" },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_album_art, openApp)
        views.setOnClickPendingIntent(R.id.widget_title,     openApp)
        views.setOnClickPendingIntent(R.id.widget_artist,    openApp)

        // ── Control buttons ───────────────────────────────────────────
        views.setOnClickPendingIntent(R.id.widget_btn_prev,       broadcastPi(context, ACTION_PREV,       10))
        views.setOnClickPendingIntent(R.id.widget_btn_play_pause, broadcastPi(context, ACTION_PLAY_PAUSE, 11))
        views.setOnClickPendingIntent(R.id.widget_btn_next,       broadcastPi(context, ACTION_NEXT,       12))

        mgr.updateAppWidget(id, views)
    }

    private fun broadcastPi(context: Context, action: String, requestCode: Int): PendingIntent =
        PendingIntent.getBroadcast(
            context, requestCode,
            Intent(context, DarkWaveMiniWidget::class.java).apply { this.action = action },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun forwardToService(context: Context, action: String) {
        // Forward control actions to PlaybackService via broadcast
        context.sendBroadcast(Intent("com.darkwave.playback.$action"))
    }

    private fun loadAlbumArt(context: Context, uriString: String?): Bitmap? {
        uriString ?: return null
        return try {
            val uri = Uri.parse(uriString)
            context.contentResolver.openInputStream(uri)?.use { input ->
                val opts = BitmapFactory.Options().apply { inSampleSize = 2 }
                BitmapFactory.decodeStream(input, null, opts)
            }
        } catch (e: Exception) { null }
    }
}
