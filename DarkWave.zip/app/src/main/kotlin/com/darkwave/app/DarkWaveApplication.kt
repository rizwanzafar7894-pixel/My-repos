package com.darkwave.app

import android.app.Application
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import com.darkwave.data.worker.DiscoverWeeklyWorker
import com.darkwave.data.worker.MediaScanWorker
import com.yausername.youtubedl_android.YoutubeDL
import dagger.hilt.android.HiltAndroidApp
import timber.log.Timber
import javax.inject.Inject

@HiltAndroidApp
class DarkWaveApplication : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.DEBUG) Timber.plant(Timber.DebugTree())

        // Initialize yt-dlp binary (required before any download/format fetch)
        try {
            YoutubeDL.getInstance().init(this)
        } catch (e: Exception) {
            Timber.e(e, "YoutubeDL init failed — browser download will be unavailable")
        }

        MediaScanWorker.runNow(this)
        DiscoverWeeklyWorker.schedule(this)
    }
}
