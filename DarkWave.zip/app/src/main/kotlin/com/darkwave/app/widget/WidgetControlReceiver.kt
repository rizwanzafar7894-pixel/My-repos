package com.darkwave.app.widget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Receives internal playback control broadcasts from widgets
 * and forwards them to PlaybackService / ExoPlayer.
 *
 * Register in MusicPlayerViewModel with:
 *   LocalBroadcastManager.getInstance(context).registerReceiver(
 *       widgetReceiver,
 *       IntentFilter().apply {
 *           addAction("com.darkwave.playback.PLAY_PAUSE")
 *           addAction("com.darkwave.playback.NEXT")
 *           addAction("com.darkwave.playback.PREV")
 *           addAction("com.darkwave.ACTION_LIKE_CURRENT")
 *       }
 *   )
 */
class WidgetControlReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // These intents are caught by MusicPlayerViewModel via a registered receiver.
        // This class exists only for documentation / manifest wiring.
        // Real handling is in MusicPlayerViewModel's broadcastReceiver block.
    }
}

/**
 * Call this extension from MusicPlayerViewModel to push state to both widgets.
 * Place this file in the same package so it can see both widget classes.
 */
fun Context.pushWidgetUpdate(
    title: String,
    artist: String,
    album: String = "",
    isPlaying: Boolean,
    albumArtUri: String? = null,
    progressPct: Int = 0,
    position: String = "0:00",
    duration: String = "0:00"
) {
    DarkWaveMiniWidget.push(
        context     = this,
        title       = title,
        artist      = artist,
        isPlaying   = isPlaying,
        albumArtUri = albumArtUri
    )
    DarkWaveLargeWidget.push(
        context     = this,
        title       = title,
        artist      = artist,
        album       = album,
        isPlaying   = isPlaying,
        albumArtUri = albumArtUri,
        progress    = progressPct,
        position    = position,
        duration    = duration
    )
}
