package com.darkwave.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.view.KeyEvent
import androidx.media3.session.MediaButtonReceiver

/**
 * Receives media button events from:
 *  - Lock screen hardware buttons
 *  - Bluetooth headset controls (play/pause/next/prev)
 *  - Android Automotive / Wear OS
 *
 * Register in AndroidManifest with:
 *   <receiver android:name=".service.DWMediaButtonReceiver" ...>
 *     <intent-filter>
 *       <action android:name="android.intent.action.MEDIA_BUTTON"/>
 *     </intent-filter>
 *   </receiver>
 */
class DWMediaButtonReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // Delegate to Media3's built-in handler — routes to PlaybackService
        MediaButtonReceiver.handleIntent(
            context,
            PlaybackService::class.java,
            intent
        )
    }
}
