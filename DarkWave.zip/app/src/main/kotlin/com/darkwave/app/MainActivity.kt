package com.darkwave.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.darkwave.app.ui.navigation.DarkWaveNavHost
import com.darkwave.common.ui.theme.DarkWaveTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            // FIX: was hardcoded darkTheme = false
            DarkWaveTheme(darkTheme = isSystemInDarkTheme()) {
                DarkWaveNavHost()
            }
        }
    }
}
