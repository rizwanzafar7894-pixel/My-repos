package com.darkwave.app.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.RemoteViews
import com.darkwave.app.MainActivity
import com.darkwave.app.R

/**
 * 4×2 expanded now-playing widget.
 * Adds: progress bar + duration labels on top of mini widget features.
 */
class DarkWaveLargeWidget : AppWidgetProvider() {

    companion object {
        const val ACTION_UPDATE = "com.darkwave.widget.large.UPDATE"

        const val EXTRA_TITLE       = "extra_title"
        const val EXTRA_ARTIST      = "extra_artist"
        const val EXTRA_ALBUM       = "extra_album"
        const val EXTRA_IS_PLAYING  = "extra_is_playing"
        const val EXTRA_ALBUM_ART   = "extra_album_art"
        const val EXTRA_PROGRESS    = "extra_progress"       // 0–100
        const val EXTRA_DURATION    = "extra_duration"       // formatted "3:42"
        const val EXTRA_POSITION    = "extra_position"       // formatted "1:15"

        fun push(
            context: Context,
            title: String,
            artist: String,
            album: String,
            isPlaying: Boolean,
            albumArtUri: String? = null,
            progress: Int = 0,
            position: String = "0:00",
            duration: String = "0:00"
        ) {
            context.sendBroadcast(
                Intent(context, DarkWaveLargeWidget::class.java).apply {
                    action = ACTION_UPDATE
                    putExtra(EXTRA_TITLE,      title)
                    putExtra(EXTRA_ARTIST,     artist)
                    putExtra(EXTRA_ALBUM,      album)
                    putExtra(EXTRA_IS_PLAYING, isPlaying)
                    putExtra(EXTRA_ALBUM_ART,  albumArtUri)
                    putExtra(EXTRA_PROGRESS,   progress)
                    putExtra(EXTRA_POSITION,   position)
                    putExtra(EXTRA_DURATION,   duration)
                }
            )
        }
    }

    override fun onUpdate(context: Context, mgr: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateWidget(context, mgr, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_UPDATE) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, DarkWaveLargeWidget::class.java))
            ids.forEach { id ->
                updateWidget(
                    context, mgr, id,
                    title     = intent.getStringExtra(EXTRA_TITLE),
                    artist    = intent.getStringExtra(EXTRA_ARTIST),
                    album     = intent.getStringExtra(EXTRA_ALBUM),
                    isPlaying = intent.getBooleanExtra(EXTRA_IS_PLAYING, false),
                    artUri    = intent.getStringExtra(EXTRA_ALBUM_ART),
                    progress  = intent.getIntExtra(EXTRA_PROGRESS, 0),
                    position  = intent.getStringExtra(EXTRA_POSITION) ?: "0:00",
                    duration  = intent.getStringExtra(EXTRA_DURATION) ?: "0:00"
                )
            }
        }
        when (intent.action) {
            DarkWaveMiniWidget.ACTION_PLAY_PAUSE -> context.sendBroadcast(Intent("com.darkwave.playback.PLAY_PAUSE"))
            DarkWaveMiniWidget.ACTION_NEXT       -> context.sendBroadcast(Intent("com.darkwave.playback.NEXT"))
            DarkWaveMiniWidget.ACTION_PREV       -> context.sendBroadcast(Intent("com.darkwave.playback.PREV"))
        }
    }

    private fun updateWidget(
        context: Context, mgr: AppWidgetManager, id: Int,
        title: String? = null, artist: String? = null, album: String? = null,
        isPlaying: Boolean = false, artUri: String? = null,
        progress: Int = 0, position: String = "0:00", duration: String = "0:00"
    ) {
        val views = RemoteViews(context.packageName, R.layout.widget_large)

        views.setTextViewText(R.id.widget_large_title,    title  ?: "DarkWave")
        views.setTextViewText(R.id.widget_large_artist,   artist ?: "Not playing")
        views.setTextViewText(R.id.widget_large_album,    album  ?: "")
        views.setTextViewText(R.id.widget_large_position, position)
        views.setTextViewText(R.id.widget_large_duration, duration)
        views.setProgressBar(R.id.widget_large_progress, 100, progress, false)

        val playIcon = if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        views.setImageViewResource(R.id.widget_large_btn_play_pause, playIcon)

        loadAlbumArt(context, artUri)?.let { views.setImageViewBitmap(R.id.widget_large_album_art, it) }
            ?: views.setImageViewResource(R.id.widget_large_album_art, R.drawable.ic_music_note_placeholder)

        val openApp = PendingIntent.getActivity(
            context, 0,
            Intent(context, MainActivity::class.java).apply { action = "com.darkwave.ACTION_OPEN_NOW_PLAYING" },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_large_album_art, openApp)

        fun broadcastPi(action: String, code: Int) = PendingIntent.getBroadcast(
            context, code,
            Intent(context, DarkWaveLargeWidget::class.java).apply { this.action = action },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        views.setOnClickPendingIntent(R.id.widget_large_btn_prev,       broadcastPi(DarkWaveMiniWidget.ACTION_PREV,       20))
        views.setOnClickPendingIntent(R.id.widget_large_btn_play_pause, broadcastPi(DarkWaveMiniWidget.ACTION_PLAY_PAUSE, 21))
        views.setOnClickPendingIntent(R.id.widget_large_btn_next,       broadcastPi(DarkWaveMiniWidget.ACTION_NEXT,       22))

        mgr.updateAppWidget(id, views)
    }

    private fun loadAlbumArt(context: Context, uriString: String?): Bitmap? {
        uriString ?: return null
        return try {
            context.contentResolver.openInputStream(Uri.parse(uriString))?.use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 2 })
            }
        } catch (e: Exception) { null }
    }
}
