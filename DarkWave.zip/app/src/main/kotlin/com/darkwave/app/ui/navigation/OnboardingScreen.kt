package com.darkwave.app.ui.navigation

import android.Manifest
import android.os.Build
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darkwave.common.ui.theme.*
import com.google.accompanist.permissions.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class OnboardingViewModel @Inject constructor(
    private val dataStore: DataStore<Preferences>
) : ViewModel() {
    fun markOnboardingDone() {
        viewModelScope.launch {
            dataStore.edit { prefs ->
                prefs[booleanPreferencesKey("onboarding_complete")] = true
            }
        }
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun OnboardingScreen(
    onComplete: () -> Unit,
    viewModel: OnboardingViewModel = hiltViewModel()
) {
    var step by remember { mutableIntStateOf(0) }

    val mediaPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        rememberMultiplePermissionsState(
            listOf(
                Manifest.permission.READ_MEDIA_VIDEO,
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.POST_NOTIFICATIONS,
                Manifest.permission.RECORD_AUDIO
            )
        )
    } else {
        rememberMultiplePermissionsState(
            listOf(
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.RECORD_AUDIO
            )
        )
    }

    AnimatedContent(
        targetState = step,
        transitionSpec = {
            slideInHorizontally { it } + fadeIn() togetherWith
            slideOutHorizontally { -it } + fadeOut()
        },
        label = "onboarding"
    ) { currentStep ->
        when (currentStep) {
            0 -> WelcomePage(onNext = { step = 1 })
            1 -> PermissionsPage(
                permissions = mediaPermissions,
                onNext = {
                    mediaPermissions.launchMultiplePermissionRequest()
                    step = 2
                }
            )
            2 -> DonePage(onFinish = {
                viewModel.markOnboardingDone()
                onComplete()
            })
        }
    }
}

@Composable
private fun WelcomePage(onNext: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize().background(White),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(32.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(Brush.radialGradient(listOf(Purple400, Purple600))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.PlayArrow, null, tint = White, modifier = Modifier.size(48.dp))
            }
            Spacer(Modifier.height(32.dp))
            Text("Welcome to DarkWave", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = TextPrimary, textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Text("Your all-in-one media player with powerful tools for video, music, and more.", fontSize = 15.sp, color = TextSecondary, textAlign = TextAlign.Center)
            Spacer(Modifier.height(48.dp))
            Button(
                onClick = onNext,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Purple500),
                shape = ShapeButton
            ) {
                Text("Get Started", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = White)
            }
        }
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
private fun PermissionsPage(
    permissions: MultiplePermissionsState,
    onNext: () -> Unit
) {
    val items = listOf(
        Triple(Icons.Default.VideoLibrary, "Media Access", "Read your videos & music"),
        Triple(Icons.Default.Mic, "Microphone", "For BPM Detector, Tuner & Recorder"),
        Triple(Icons.Default.Notifications, "Notifications", "Playback controls & reminders")
    )

    Box(
        modifier = Modifier.fillMaxSize().background(White),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Permissions", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(Modifier.height(8.dp))
            Text("DarkWave needs these to work properly", fontSize = 14.sp, color = TextSecondary, textAlign = TextAlign.Center)
            Spacer(Modifier.height(32.dp))
            items.forEach { (icon, title, desc) ->
                PermissionRow(icon, title, desc)
                Spacer(Modifier.height(16.dp))
            }
            Spacer(Modifier.height(32.dp))
            Button(
                onClick = onNext,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Purple500),
                shape = ShapeButton
            ) {
                Text("Grant Permissions", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = White)
            }
            Spacer(Modifier.height(12.dp))
            TextButton(onClick = onNext) {
                Text("Skip for now", color = TextSecondary)
            }
        }
    }
}

@Composable
private fun PermissionRow(icon: ImageVector, title: String, desc: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(48.dp).clip(CircleShape).background(Purple100),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = Purple500, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(16.dp))
        Column {
            Text(title, fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 15.sp)
            Text(desc, color = TextSecondary, fontSize = 13.sp)
        }
    }
}

@Composable
private fun DonePage(onFinish: () -> Unit) {
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(1500)
        onFinish()
    }
    Box(
        modifier = Modifier.fillMaxSize().background(White),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            Box(
                modifier = Modifier.size(100.dp).clip(CircleShape).background(Purple100),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Check, null, tint = Purple500, modifier = Modifier.size(52.dp))
            }
            Spacer(Modifier.height(24.dp))
            Text("All set!", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(Modifier.height(12.dp))
            Text("DarkWave is ready. Enjoy your media.", fontSize = 15.sp, color = TextSecondary, textAlign = TextAlign.Center)
        }
    }
}
