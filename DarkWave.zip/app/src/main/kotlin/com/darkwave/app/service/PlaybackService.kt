package com.darkwave.app.service

import android.app.PendingIntent
import android.content.Intent
import android.os.Bundle
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.*
import com.darkwave.app.MainActivity
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import javax.inject.Named

/**
 * MediaSessionService for MUSIC playback.
 * Provides background play, lock-screen controls, notification bar transport controls.
 */
@AndroidEntryPoint
class PlaybackService : MediaSessionService() {

    @field:Named("music") @Inject lateinit var player: ExoPlayer
    private var mediaSession: MediaSession? = null

    companion object {
        const val ACTION_OPEN_NOW_PLAYING = "com.darkwave.ACTION_OPEN_NOW_PLAYING"
        const val CUSTOM_CMD_LIKE         = "com.darkwave.LIKE"
        const val CUSTOM_CMD_SHUFFLE      = "com.darkwave.SHUFFLE"
    }

    override fun onCreate() {
        super.onCreate()
        player.setAudioAttributes(
            AudioAttributes.Builder()
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .setUsage(C.USAGE_MEDIA)
                .build(), true
        )
        player.pauseAtEndOfMediaItems = false

        val sessionIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).apply {
                action = ACTION_OPEN_NOW_PLAYING
                flags  = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val likeBtn = CommandButton.Builder()
            .setDisplayName("Like")
            .setIconResId(androidx.media3.ui.R.drawable.exo_icon_repeat_all)
            .setSessionCommand(SessionCommand(CUSTOM_CMD_LIKE, Bundle.EMPTY))
            .build()

        val shuffleBtn = CommandButton.Builder()
            .setDisplayName("Shuffle")
            .setIconResId(androidx.media3.ui.R.drawable.exo_icon_shuffle)
            .setSessionCommand(SessionCommand(CUSTOM_CMD_SHUFFLE, Bundle.EMPTY))
            .build()

        mediaSession = MediaSession.Builder(this, player)
            .setSessionActivity(sessionIntent)
            .setCallback(SessionCallback())
            .setCustomLayout(ImmutableList.of(likeBtn, shuffleBtn))
            .build()

        setMediaNotificationProvider(
            DefaultMediaNotificationProvider.Builder(this)
                .setNotificationId(1001)
                .setChannelId("dw_playback")
                .setChannelName(0)
                .build()
                .apply { setSmallIcon(android.R.drawable.ic_media_play) }
        )
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo) = mediaSession

    override fun onTaskRemoved(rootIntent: android.content.Intent?) {
        val p = mediaSession?.player ?: return
        if (!p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        mediaSession?.run { player.release(); release(); mediaSession = null }
        super.onDestroy()
    }

    private inner class SessionCallback : MediaSession.Callback {
        override fun onConnect(session: MediaSession, controller: MediaSession.ControllerInfo): MediaSession.ConnectionResult {
            val cmds = MediaSession.ConnectionResult.DEFAULT_SESSION_AND_LIBRARY_COMMANDS.buildUpon()
                .add(SessionCommand(CUSTOM_CMD_LIKE,    Bundle.EMPTY))
                .add(SessionCommand(CUSTOM_CMD_SHUFFLE, Bundle.EMPTY))
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(cmds).build()
        }

        override fun onCustomCommand(session: MediaSession, controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand, args: Bundle): ListenableFuture<SessionResult> {
            when (customCommand.customAction) {
                CUSTOM_CMD_SHUFFLE -> player.shuffleModeEnabled = !player.shuffleModeEnabled
                CUSTOM_CMD_LIKE    -> sendBroadcast(Intent("com.darkwave.ACTION_LIKE_CURRENT"))
            }
            return Futures.immediateFuture(SessionResult(SessionResult.RESULT_SUCCESS))
        }
    }
}
