package com.darkwave.app.di

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.preferencesDataStore
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Named
import javax.inject.Singleton

private val Context.dataStore: DataStore<Preferences>
    by preferencesDataStore(name = "darkwave_prefs")

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides @Singleton
    fun provideDataStore(@ApplicationContext ctx: Context): DataStore<Preferences> = ctx.dataStore

    // ── Music ExoPlayer ──────────────────────────────────────────────────────
    // Lightweight audio-only instance. Handles gapless playback, audio focus,
    // and headset unplug pause automatically.
    @Provides @Singleton @Named("music")
    fun provideMusicExoPlayer(@ApplicationContext ctx: Context): ExoPlayer =
        ExoPlayer.Builder(ctx)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()

    // ── Video ExoPlayer ──────────────────────────────────────────────────────
    // Full-featured instance with:
    //   • DefaultTrackSelector — no SD cap, prefers H.265 > H.264 > AV1
    //   • EXTENSION_RENDERER_MODE_ON — FFmpeg software fallback for exotic codecs
    //   • Larger buffers for smooth 4K/HDR
    //   • Audio focus type MOVIE (ducks music apps automatically)
    @Provides @Singleton @Named("video")
    fun provideVideoExoPlayer(@ApplicationContext ctx: Context): ExoPlayer {
        val trackSelector = DefaultTrackSelector(ctx).apply {
            setParameters(
                buildUponParameters()
                    .clearVideoSizeConstraints()
                    .setMaxVideoSize(Int.MAX_VALUE, Int.MAX_VALUE)
                    .setMaxVideoBitrate(Int.MAX_VALUE)
                    .setPreferredVideoMimeTypes(
                        MimeTypes.VIDEO_H265,
                        MimeTypes.VIDEO_H264,
                        MimeTypes.VIDEO_AV1
                    )
                    .setAllowVideoMixedMimeTypeAdaptiveness(true)
                    .setAllowAudioMixedMimeTypeAdaptiveness(true)
            )
        }

        val renderersFactory = DefaultRenderersFactory(ctx).apply {
            // Try hardware first; fall back to FFmpeg extension for unsupported codecs
            setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            setEnableDecoderFallback(true)
        }

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(
                /* minBufferMs                        */ 15_000,
                /* maxBufferMs                        */ 60_000,
                /* bufferForPlaybackMs                */ 2_500,
                /* bufferForPlaybackAfterRebufferMs   */ 5_000
            )
            .build()

        return ExoPlayer.Builder(ctx, renderersFactory)
            .setTrackSelector(trackSelector)
            .setLoadControl(loadControl)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true)
            .build()
    }

    @Provides @Singleton
    fun provideWidgetPusher(@ApplicationContext ctx: Context): com.darkwave.common.widget.WidgetPusher =
        com.darkwave.app.widget.WidgetPusherImpl(ctx)
}
