package com.darkwave.app.ui.navigation

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.darkwave.common.ui.theme.*

data class BottomNavTab(
    val route: String,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

val bottomNavTabs = listOf(
    BottomNavTab(Screen.Home.route,     "Home",     Icons.Filled.Home,     Icons.Outlined.Home),
    BottomNavTab(Screen.Video.route,    "Video",    Icons.Filled.VideoLibrary, Icons.Outlined.VideoLibrary),
    BottomNavTab(Screen.Music.route,    "Music",    Icons.Filled.MusicNote, Icons.Outlined.MusicNote),
    BottomNavTab(Screen.Browser.route,  "Browser",  Icons.Filled.Language,  Icons.Outlined.Language),
    BottomNavTab(Screen.Settings.route, "Settings", Icons.Filled.Settings,  Icons.Outlined.Settings)
)

@Composable
fun DWBottomNavBar(
    navController: NavController,
    modifier: Modifier = Modifier
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    NavigationBar(
        modifier = modifier,
        containerColor = NavBackground,
        tonalElevation = 0.dp
    ) {
        bottomNavTabs.forEach { tab ->
            val selected = currentRoute == tab.route
            val iconColor by animateColorAsState(
                targetValue = if (selected) NavSelected else NavUnselected,
                animationSpec = tween(200),
                label = "navIconColor"
            )
            val labelColor by animateColorAsState(
                targetValue = if (selected) NavSelected else NavUnselected,
                animationSpec = tween(200),
                label = "navLabelColor"
            )

            NavigationBarItem(
                selected = selected,
                onClick = {
                    if (currentRoute != tab.route) {
                        navController.navigate(tab.route) {
                            popUpTo(Screen.Home.route) { saveState = true }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                icon = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        if (selected) {
                            // Pill background for selected tab matching screenshots
                            Surface(
                                shape = androidx.compose.foundation.shape.RoundedCornerShape(50),
                                color = Purple100,
                                modifier = Modifier.padding(bottom = 2.dp)
                            ) {
                                Icon(
                                    imageVector = tab.selectedIcon,
                                    contentDescription = tab.label,
                                    tint = iconColor,
                                    modifier = Modifier
                                        .padding(horizontal = 16.dp, vertical = 4.dp)
                                        .size(22.dp)
                                )
                            }
                        } else {
                            Icon(
                                imageVector = tab.unselectedIcon,
                                contentDescription = tab.label,
                                tint = iconColor,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                },
                label = {
                    Text(
                        text = tab.label,
                        fontSize = 11.sp,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                        color = labelColor
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor   = NavSelected,
                    unselectedIconColor = NavUnselected,
                    indicatorColor      = Color.Transparent
                )
            )
        }
    }
}
