package com.darkwave.app.ui.navigation

sealed class Screen(val route: String) {
    // Splash / Onboarding
    object Splash       : Screen("splash")
    object Onboarding   : Screen("onboarding")

    // Main tabs
    object Home         : Screen("home")
    object Video        : Screen("video")
    object Music        : Screen("music")
    object Browser      : Screen("browser")
    object Settings     : Screen("settings")

    // Video
    object VideoPlayer  : Screen("video_player/{uri}/{title}") {
        fun createRoute(uri: String, title: String) =
            "video_player/${encode(uri)}/${encode(title)}"
    }

    // Music
    object NowPlaying   : Screen("now_playing")

    // Tools from Settings
    object BpmDetector  : Screen("bpm_detector")
    object Metronome    : Screen("metronome")
    object Tuner        : Screen("tuner")
    object Recorder     : Screen("recorder")
    object Analyzer     : Screen("analyzer")
    object Equalizer    : Screen("equalizer")

    // Feature screens
    object Vault        : Screen("vault")
    object Organizer    : Screen("organizer")
    object Converter    : Screen("converter")
    object Bookmarks    : Screen("bookmarks")
    object Editor       : Screen("editor")
    object Analytics    : Screen("analytics")
    object Remote       : Screen("remote")
    object Focus        : Screen("focus")
    object Accessibility: Screen("accessibility_settings")

    // Settings sub-screens
    object ProfileEdit  : Screen("profile_edit")
    object Playback     : Screen("playback_settings")
    object Appearance   : Screen("appearance_settings")
    object Privacy      : Screen("privacy_settings")
    object Downloads    : Screen("download_settings")
    object Storage      : Screen("storage_settings")
    object Network      : Screen("network_settings")

    companion object {
        fun encode(value: String) =
            java.net.URLEncoder.encode(value, "UTF-8")
        fun decode(value: String) =
            java.net.URLDecoder.decode(value, "UTF-8")
    }
}

// Bottom nav items matching screenshots exactly
enum class BottomNavItem(
    val screen: Screen,
    val label: String,
    val iconRes: Int
) {
    HOME(Screen.Home, "Home", 0),
    VIDEO(Screen.Video, "Video", 1),
    MUSIC(Screen.Music, "Music", 2),
    BROWSER(Screen.Browser, "Browser", 3),
    SETTINGS(Screen.Settings, "Settings", 4)
}
