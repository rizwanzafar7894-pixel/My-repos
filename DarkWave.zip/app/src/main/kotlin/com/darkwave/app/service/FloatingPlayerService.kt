package com.darkwave.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import androidx.core.app.NotificationCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.darkwave.app.MainActivity
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class FloatingPlayerService : Service() {

    private var windowManager: WindowManager? = null
    private var floatingView: FrameLayout? = null
    private var player: ExoPlayer? = null

    private var initialX = 0; private var initialY = 0
    private var initialTouchX = 0f; private var initialTouchY = 0f

    inner class LocalBinder : Binder() {
        fun getService(): FloatingPlayerService = this@FloatingPlayerService
    }

    override fun onBind(intent: Intent?): IBinder = LocalBinder()

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(NOTIF_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_PLAY -> {
                val uri = intent.getStringExtra(EXTRA_URI) ?: return START_NOT_STICKY
                startFloating(uri)
            }
            ACTION_STOP -> stopFloating()
            ACTION_CLOSE -> { stopFloating(); stopSelf() }
        }
        return START_STICKY
    }

    private fun startFloating(uri: String) {
        stopFloating()

        // Build compact floating layout programmatically
        val ctx = this
        val containerSize  = (200 * resources.displayMetrics.density).toInt()
        val controlsHeight = (36 * resources.displayMetrics.density).toInt()

        floatingView = FrameLayout(ctx).apply {
            val surface = SurfaceView(ctx).apply {
                layoutParams = FrameLayout.LayoutParams(containerSize, containerSize - controlsHeight)
            }

            val controls = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, controlsHeight,
                    Gravity.BOTTOM
                ).apply { setBackgroundColor(0xCC000000.toInt()) }

                fun iconBtn(label: String, onClick: () -> Unit) = ImageButton(ctx).apply {
                    contentDescription = label
                    setOnClickListener { onClick() }
                    setBackgroundColor(0x00000000)
                }
                addView(iconBtn("⏮") { player?.seekTo(0) })
                addView(iconBtn("⏯") { if (player?.isPlaying == true) player?.pause() else player?.play() })
                addView(iconBtn("⏭") { player?.seekToNextMediaItem() })
                addView(iconBtn("✕") {
                    stopFloating(); stopSelf()
                })
            }

            addView(surface)
            addView(controls)

            // Drag gesture
            setOnTouchListener(object : View.OnTouchListener {
                private val params get() = layoutParams as WindowManager.LayoutParams
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> {
                            initialX = params.x; initialY = params.y
                            initialTouchX = e.rawX; initialTouchY = e.rawY
                        }
                        MotionEvent.ACTION_MOVE -> {
                            params.x = initialX + (e.rawX - initialTouchX).toInt()
                            params.y = initialY + (e.rawY - initialTouchY).toInt()
                            windowManager?.updateViewLayout(v, params)
                        }
                    }
                    return false
                }
            })

            // ExoPlayer attached to SurfaceView
            player = ExoPlayer.Builder(ctx).build().also { exo ->
                exo.addListener(object : Player.Listener {
                    override fun onRenderedFirstFrame() {
                        // Player ready
                    }
                })
                surface.holder.addCallback(object : SurfaceHolder.Callback {
                    override fun surfaceCreated(h: SurfaceHolder) { exo.setVideoSurfaceHolder(h) }
                    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, ht: Int) {}
                    override fun surfaceDestroyed(h: SurfaceHolder) { exo.clearVideoSurface() }
                })
                exo.setMediaItem(MediaItem.fromUri(uri))
                exo.prepare()
                exo.playWhenReady = true
            }
        }

        val params = WindowManager.LayoutParams(
            containerSize, containerSize,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100; y = 200
        }

        windowManager?.addView(floatingView, params)
    }

    private fun stopFloating() {
        player?.stop()
        player?.release()
        player = null
        floatingView?.let {
            try { windowManager?.removeView(it) } catch (_: Exception) {}
        }
        floatingView = null
    }

    override fun onDestroy() {
        stopFloating()
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val channelId = "floating_player"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(channelId, "Floating Player", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val closeIntent = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingPlayerService::class.java).apply { action = ACTION_CLOSE },
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("DarkWave — Floating Player")
            .setContentText("Playing in floating window")
            .setContentIntent(openIntent)
            .addAction(android.R.drawable.ic_delete, "Close", closeIntent)
            .setOngoing(true)
            .build()
    }

    companion object {
        const val ACTION_PLAY  = "com.darkwave.app.FLOATING_PLAY"
        const val ACTION_STOP  = "com.darkwave.app.FLOATING_STOP"
        const val ACTION_CLOSE = "com.darkwave.app.FLOATING_CLOSE"
        const val EXTRA_URI    = "uri"
        const val NOTIF_ID     = 9901

        fun startFloating(context: Context, uri: String) {
            val intent = Intent(context, FloatingPlayerService::class.java).apply {
                action = ACTION_PLAY
                putExtra(EXTRA_URI, uri)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopFloating(context: Context) {
            context.startService(
                Intent(context, FloatingPlayerService::class.java).apply { action = ACTION_STOP }
            )
        }
    }
}

