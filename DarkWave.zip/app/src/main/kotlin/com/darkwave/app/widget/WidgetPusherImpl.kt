package com.darkwave.app.widget

import android.content.Context
import com.darkwave.common.widget.WidgetPusher
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WidgetPusherImpl @Inject constructor(
    @ApplicationContext private val context: Context
) : WidgetPusher {

    override fun push(
        title: String,
        artist: String,
        album: String,
        isPlaying: Boolean,
        progress: Int,
        position: String,
        duration: String,
        albumArtUri: String?
    ) {
        DarkWaveMiniWidget.push(
            context     = context,
            title       = title,
            artist      = artist,
            isPlaying   = isPlaying,
            albumArtUri = albumArtUri
        )
        DarkWaveLargeWidget.push(
            context     = context,
            title       = title,
            artist      = artist,
            album       = album,
            isPlaying   = isPlaying,
            albumArtUri = albumArtUri,
            progress    = progress,
            position    = position,
            duration    = duration
        )
    }
}
