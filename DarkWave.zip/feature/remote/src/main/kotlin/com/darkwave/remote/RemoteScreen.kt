package com.darkwave.remote

import android.graphics.Bitmap
import android.graphics.Color as AColor
import androidx.compose.animation.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.darkwave.remote.viewmodel.*
import com.darkwave.common.ui.theme.*

@Composable
fun RemoteScreen(
    onBack: () -> Unit,
    viewModel: RemoteViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        // Top bar
        Row(
            modifier          = Modifier.fillMaxWidth().background(White).padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = TextPrimary) }
            Text("Remote Control", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, modifier = Modifier.weight(1f))
            // Status dot
            Box(
                modifier = Modifier.size(10.dp).clip(CircleShape)
                    .background(if (state.isServerRunning) Color(0xFF4CAF50) else Color(0xFFBDBDBD))
            )
            Spacer(Modifier.width(12.dp))
        }

        LazyColumn(
            contentPadding      = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier            = Modifier.fillMaxSize()
        ) {

            // ── Server card ───────────────────────────────────────────
            item {
                Card(
                    shape     = RoundedCornerShape(16.dp),
                    colors    = CardDefaults.cardColors(containerColor = White),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier  = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Purple100),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.SettingsRemote, null, tint = Purple500, modifier = Modifier.size(22.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("WebSocket Server", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                                Text(
                                    if (state.isServerRunning) "Listening on :${state.serverPort}" else "Not running",
                                    fontSize = 12.sp, color = if (state.isServerRunning) Color(0xFF4CAF50) else TextSecondary
                                )
                            }
                            Switch(
                                checked         = state.isServerRunning,
                                onCheckedChange = { if (it) viewModel.startServer() else viewModel.stopServer() },
                                colors          = SwitchDefaults.colors(checkedTrackColor = Purple500)
                            )
                        }

                        if (state.isServerRunning) {
                            Spacer(Modifier.height(12.dp))
                            Divider(color = DividerColor)
                            Spacer(Modifier.height(12.dp))
                            Row {
                                InfoChip("IP", state.serverIp)
                                Spacer(Modifier.width(8.dp))
                                InfoChip("Port", "${state.serverPort}")
                                Spacer(Modifier.width(8.dp))
                                InfoChip("Clients", "${state.connectedClients}")
                            }
                        }
                    }
                }
            }

            // ── QR code card ──────────────────────────────────────────
            if (state.isServerRunning && state.wsUrl.isNotBlank()) {
                item {
                    Card(
                        shape     = RoundedCornerShape(16.dp),
                        colors    = CardDefaults.cardColors(containerColor = White),
                        elevation = CardDefaults.cardElevation(2.dp),
                        modifier  = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier            = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("Scan to Connect", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            Spacer(Modifier.height(4.dp))
                            Text("Point your phone camera at this QR code", fontSize = 12.sp, color = TextSecondary, textAlign = TextAlign.Center)
                            Spacer(Modifier.height(16.dp))

                            QrCodeImage(content = state.wsUrl, sizeDp = 200)

                            Spacer(Modifier.height(12.dp))
                            Text(
                                state.wsUrl,
                                fontSize   = 11.sp,
                                color      = Purple500,
                                textAlign  = TextAlign.Center,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }

            // ── Last command card ─────────────────────────────────────
            if (state.lastCommand != null) {
                item {
                    Card(
                        shape     = RoundedCornerShape(16.dp),
                        colors    = CardDefaults.cardColors(containerColor = White),
                        elevation = CardDefaults.cardElevation(2.dp),
                        modifier  = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(40.dp).clip(CircleShape).background(Purple100),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(commandIcon(state.lastCommand!!), null, tint = Purple500, modifier = Modifier.size(20.dp))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Last Command", fontSize = 11.sp, color = TextSecondary)
                                Text(state.lastCommand!!.name.replace("_", " ").lowercase().replaceFirstChar { it.uppercase() }, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            }
                            Text(formatElapsed(state.lastCommandTime), fontSize = 11.sp, color = TextSecondary)
                        }
                    }
                }
            }

            // ── How to use ────────────────────────────────────────────
            if (!state.isServerRunning) {
                item {
                    Card(
                        shape     = RoundedCornerShape(16.dp),
                        colors    = CardDefaults.cardColors(containerColor = White),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("How to use", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            HowToRow("1", "Toggle the server switch above")
                            HowToRow("2", "Scan the QR code with any WebSocket client")
                            HowToRow("3", "Send JSON commands: {\"cmd\":\"play\"}")
                            HowToRow("4", "Supported: play, pause, next, previous, volume_up/down, seek_forward/back")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QrCodeImage(content: String, sizeDp: Int) {
    val bitmap = remember(content) { generateQrBitmap(content, sizeDp * 3) }
    if (bitmap != null) {
        Image(
            bitmap             = bitmap.asImageBitmap(),
            contentDescription = "QR Code",
            modifier           = Modifier.size(sizeDp.dp).clip(RoundedCornerShape(8.dp))
        )
    } else {
        Box(
            Modifier.size(sizeDp.dp).clip(RoundedCornerShape(8.dp)).background(SurfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Text("QR unavailable", fontSize = 12.sp, color = TextSecondary)
        }
    }
}

private fun generateQrBitmap(content: String, size: Int): Bitmap? = try {
    val hints = mapOf(EncodeHintType.MARGIN to 1)
    val bits  = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
    val bmp   = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
    for (x in 0 until size) for (y in 0 until size) {
        bmp.setPixel(x, y, if (bits[x, y]) AColor.BLACK else AColor.WHITE)
    }
    bmp
} catch (e: Exception) { null }

@Composable
private fun InfoChip(label: String, value: String) {
    Surface(shape = RoundedCornerShape(8.dp), color = SurfaceVariant) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontSize = 10.sp, color = TextSecondary)
            Text(value, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
        }
    }
}

@Composable
private fun HowToRow(step: String, text: String) {
    Row(verticalAlignment = Alignment.Top) {
        Box(Modifier.size(22.dp).clip(CircleShape).background(Purple100), contentAlignment = Alignment.Center) {
            Text(step, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Purple500)
        }
        Spacer(Modifier.width(10.dp))
        Text(text, fontSize = 13.sp, color = TextPrimary, lineHeight = 18.sp)
    }
}

private fun commandIcon(cmd: RemoteCommand) = when (cmd) {
    RemoteCommand.PLAY          -> Icons.Default.PlayArrow
    RemoteCommand.PAUSE         -> Icons.Default.Pause
    RemoteCommand.NEXT          -> Icons.Default.SkipNext
    RemoteCommand.PREVIOUS      -> Icons.Default.SkipPrevious
    RemoteCommand.VOLUME_UP     -> Icons.Default.VolumeUp
    RemoteCommand.VOLUME_DOWN   -> Icons.Default.VolumeDown
    RemoteCommand.SEEK_FORWARD  -> Icons.Default.FastForward
    RemoteCommand.SEEK_BACK     -> Icons.Default.FastRewind
}

private fun formatElapsed(ts: Long): String {
    val diff = System.currentTimeMillis() - ts
    return when {
        diff < 5_000   -> "Just now"
        diff < 60_000  -> "${diff/1000}s ago"
        else           -> "${diff/60_000}m ago"
    }
}
