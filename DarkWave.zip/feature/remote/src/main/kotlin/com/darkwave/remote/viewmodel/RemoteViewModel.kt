package com.darkwave.remote.viewmodel

import android.content.Context
import android.net.wifi.WifiManager
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket
import javax.inject.Inject

enum class RemoteCommand { PLAY, PAUSE, NEXT, PREVIOUS, VOLUME_UP, VOLUME_DOWN, SEEK_FORWARD, SEEK_BACK }

data class RemoteUiState(
    val isServerRunning: Boolean = false,
    val serverPort: Int = 8765,
    val serverIp: String = "",
    val wsUrl: String = "",
    val connectedClients: Int = 0,
    val lastCommand: RemoteCommand? = null,
    val lastCommandTime: Long = 0L,
    val errorMessage: String? = null
)

@HiltViewModel
class RemoteViewModel @Inject constructor(
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _uiState = MutableStateFlow(RemoteUiState())
    val uiState: StateFlow<RemoteUiState> = _uiState.asStateFlow()

    private var serverSocket: ServerSocket? = null

    init { detectIpAddress() }

    private fun detectIpAddress() {
        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val ipInt = wifiManager.connectionInfo.ipAddress
        val ip = "%d.%d.%d.%d".format(
            ipInt and 0xFF,
            (ipInt shr 8) and 0xFF,
            (ipInt shr 16) and 0xFF,
            (ipInt shr 24) and 0xFF
        )
        _uiState.update { it.copy(serverIp = ip, wsUrl = "ws://$ip:${it.serverPort}") }
    }

    fun startServer() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val port = _uiState.value.serverPort
                serverSocket = ServerSocket(port)
                _uiState.update { it.copy(isServerRunning = true) }
                Timber.d("Remote server listening on port $port")

                while (serverSocket?.isClosed == false) {
                    val client = serverSocket?.accept() ?: break
                    handleClient(client)
                }
            } catch (e: Exception) {
                if (_uiState.value.isServerRunning) {
                    Timber.e(e, "Remote server error")
                    _uiState.update { it.copy(isServerRunning = false, errorMessage = "Server error: ${e.message}") }
                }
            }
        }
    }

    fun stopServer() {
        serverSocket?.close()
        serverSocket = null
        _uiState.update { it.copy(isServerRunning = false, connectedClients = 0) }
    }

    private fun handleClient(client: Socket) {
        viewModelScope.launch(Dispatchers.IO) {
            _uiState.update { it.copy(connectedClients = it.connectedClients + 1) }
            try {
                val reader = BufferedReader(InputStreamReader(client.getInputStream()))
                val writer = PrintWriter(client.getOutputStream(), true)
                writer.println("{\"status\":\"connected\",\"version\":\"1.0\"}")

                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    val cmd = parseCommand(line ?: "") ?: continue
                    _uiState.update { it.copy(lastCommand = cmd, lastCommandTime = System.currentTimeMillis()) }
                    writer.println("{\"ack\":\"${cmd.name}\"}")
                }
            } catch (e: Exception) {
                Timber.d("Client disconnected: ${e.message}")
            } finally {
                client.close()
                _uiState.update { it.copy(connectedClients = (it.connectedClients - 1).coerceAtLeast(0)) }
            }
        }
    }

    private fun parseCommand(json: String): RemoteCommand? = try {
        when {
            json.contains("\"play\"")         -> RemoteCommand.PLAY
            json.contains("\"pause\"")        -> RemoteCommand.PAUSE
            json.contains("\"next\"")         -> RemoteCommand.NEXT
            json.contains("\"previous\"")     -> RemoteCommand.PREVIOUS
            json.contains("\"volume_up\"")    -> RemoteCommand.VOLUME_UP
            json.contains("\"volume_down\"")  -> RemoteCommand.VOLUME_DOWN
            json.contains("\"seek_forward\"") -> RemoteCommand.SEEK_FORWARD
            json.contains("\"seek_back\"")    -> RemoteCommand.SEEK_BACK
            else                              -> null
        }
    } catch (e: Exception) { null }

    fun clearError() { _uiState.update { it.copy(errorMessage = null) } }

    override fun onCleared() { stopServer(); super.onCleared() }
}
