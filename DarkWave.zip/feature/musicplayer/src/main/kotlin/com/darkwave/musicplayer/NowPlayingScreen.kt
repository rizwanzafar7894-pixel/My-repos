package com.darkwave.musicplayer

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darkwave.common.ui.theme.*
import com.darkwave.musicplayer.ui.*
import com.darkwave.musicplayer.viewmodel.MusicPlayerViewModel
import com.darkwave.musicplayer.viewmodel.NowPlayingTab

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NowPlayingScreen(
    onBack: () -> Unit,
    viewModel: MusicPlayerViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    // Swipe-down-to-dismiss
    var swipeOffsetY by remember { mutableStateOf(0f) }
    val dismissThreshold = 200f

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .offset { androidx.compose.ui.unit.IntOffset(0, swipeOffsetY.toInt().coerceAtLeast(0)) }
            .pointerInput(Unit) {
                androidx.compose.foundation.gestures.detectDragGestures(
                    onDragEnd = {
                        if (swipeOffsetY > dismissThreshold) onBack()
                        else swipeOffsetY = 0f
                    },
                    onDragCancel = { swipeOffsetY = 0f }
                ) { _, dragAmount ->
                    if (dragAmount.y > 0 || swipeOffsetY > 0) {
                        swipeOffsetY = (swipeOffsetY + dragAmount.y).coerceAtLeast(0f)
                    }
                }
            }
            .graphicsLayer {
                alpha = (1f - swipeOffsetY / (dismissThreshold * 2f)).coerceIn(0.3f, 1f)
            }
    ) {
        Column(modifier = Modifier.fillMaxSize()) {

            NowPlayingTopBar(
                title             = state.currentSong?.title ?: "Not Playing",
                onBack            = onBack,
                onSleepTimer      = viewModel::showMusicSleepTimer,
                onSpeed           = viewModel::showSpeedPicker,
                sleepTimerActive  = state.sleepTimerRemainingMs > 0,
                onMoreClick  = {},
                onQueueClick = viewModel::toggleQueue
            )

            NowPlayingTabRow(
                selectedTab = state.currentTab,
                onTabSelect = viewModel::onTabSelected
            )

            AnimatedContent(
                targetState = state.currentTab,
                transitionSpec = {
                    fadeIn(androidx.compose.animation.core.tween(200)) togetherWith
                    fadeOut(androidx.compose.animation.core.tween(200))
                },
                label = "nowPlayingTab",
                modifier = Modifier.weight(1f)
            ) { tab ->
                when (tab) {
                    NowPlayingTab.PLAYING -> NowPlayingPlayingTab(
                        state       = state,
                        onPlayPause = viewModel::togglePlayPause,
                        onNext      = viewModel::playNext,
                        onPrevious  = viewModel::playPrevious,
                        onSeekTo    = viewModel::seekTo,
                        onShuffle   = viewModel::toggleShuffle,
                        onRepeat    = viewModel::cycleRepeat,
                        onLike      = viewModel::toggleFavorite,
                        onFavorite  = viewModel::toggleFavorite,
                        onAddToPlaylist = viewModel::showAddToPlaylist,
                        onShare     = { state.currentSong?.let { viewModel.shareSong(it) } }
                    )
                    NowPlayingTab.LYRICS -> NowPlayingLyricsTab(
                        song            = state.currentSong,
                        lyrics          = state.lyrics,
                        isFetching      = state.isFetchingLyrics,
                        onFetchLyrics   = viewModel::fetchLyrics
                    )
                    NowPlayingTab.QUEUE -> NowPlayingQueueTab(
                        queue       = state.queue,
                        currentSong = state.currentSong,
                        onSongClick = { song -> viewModel.playSong(song) }
                    )
                }
            }
        }

        // Queue bottom sheet
        if (state.showQueue) {
            ModalBottomSheet(
                onDismissRequest = viewModel::hideQueue,
                containerColor   = Color.White
            ) {
                NowPlayingQueueTab(
                    queue       = state.queue,
                    currentSong = state.currentSong,
                    onSongClick = { song -> viewModel.playSong(song) },
                    modifier    = Modifier.fillMaxHeight(0.75f)
                )
            }
        }

        // ── Add to Playlist bottom sheet ──────────────────────────────────
        if (state.showAddToPlaylist) {
            ModalBottomSheet(
                onDismissRequest = viewModel::dismissAddToPlaylist,
                containerColor   = Color.White
            ) {
                var showNewPlaylist by remember { mutableStateOf(false) }
                var newName by remember { mutableStateOf("") }

                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Add to Playlist", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = TextPrimary)
                    Spacer(Modifier.height(12.dp))

                    if (showNewPlaylist) {
                        OutlinedTextField(
                            value = newName,
                            onValueChange = { newName = it },
                            label = { Text("Playlist name") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                            TextButton(onClick = { showNewPlaylist = false }) { Text("Cancel") }
                            Spacer(Modifier.width(8.dp))
                            Button(onClick = {
                                if (newName.isNotBlank()) viewModel.createPlaylistAndAdd(newName.trim())
                            }) { Text("Create") }
                        }
                    } else {
                        TextButton(
                            onClick = { showNewPlaylist = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Add, null, tint = Purple500)
                            Spacer(Modifier.width(8.dp))
                            Text("New Playlist", color = Purple500)
                        }
                        Divider()
                        if (state.availablePlaylists.isEmpty()) {
                            Text(
                                "No playlists yet — create one above",
                                color = TextSecondary, fontSize = 13.sp,
                                modifier = Modifier.padding(16.dp)
                            )
                        } else {
                            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                                items(state.availablePlaylists) { playlist ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { viewModel.addCurrentSongToPlaylist(playlist.id) }
                                            .padding(16.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Default.QueueMusic, null, tint = Purple500, modifier = Modifier.size(20.dp))
                                        Spacer(Modifier.width(12.dp))
                                        Column {
                                            Text(playlist.name, fontWeight = FontWeight.Medium, color = TextPrimary)
                                            Text("${playlist.songCount} songs", fontSize = 12.sp, color = TextSecondary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
        // Music Sleep Timer picker
        if (state.showSleepTimerPicker) {
            MusicSleepTimerSheet(
                currentRemainingMs = state.sleepTimerRemainingMs,
                onSet    = viewModel::setMusicSleepTimer,
                onDismiss = viewModel::dismissMusicSleepTimer
            )
        }

        // Music Speed picker
        if (state.showSpeedPicker) {
            MusicSpeedSheet(
                currentSpeed = state.musicSpeed,
                onSpeedSet   = viewModel::setMusicSpeed,
                onDismiss    = viewModel::dismissSpeedPicker
            )
        }

        // Sleep timer badge (top of screen)
        if (state.sleepTimerRemainingMs > 0 && !state.showSleepTimerPicker) {
            MusicSleepTimerBadge(
                remainingMs = state.sleepTimerRemainingMs,
                onCancel    = { viewModel.setMusicSleepTimer(0L) },
                modifier    = Modifier.align(Alignment.TopCenter).padding(top = 72.dp)
            )
        }
    }
}