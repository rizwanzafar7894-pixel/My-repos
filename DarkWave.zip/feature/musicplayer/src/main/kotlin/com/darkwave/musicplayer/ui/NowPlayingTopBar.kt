package com.darkwave.musicplayer.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.theme.*
import com.darkwave.musicplayer.viewmodel.NowPlayingTab

@Composable
fun NowPlayingTopBar(
    title: String,
    onBack: () -> Unit,
    onMoreClick: () -> Unit,
    onQueueClick: () -> Unit,
    onSleepTimer: () -> Unit = {},
    onSpeed: () -> Unit = {},
    sleepTimerActive: Boolean = false,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 4.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Default.KeyboardArrowDown, "Back", tint = TextPrimary, modifier = Modifier.size(28.dp))
        }
        Column(
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Now Playing", fontSize = 12.sp, color = TextSecondary)
            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        IconButton(onClick = onQueueClick) {
            Icon(Icons.Default.QueueMusic, "Queue", tint = TextSecondary, modifier = Modifier.size(22.dp))
        }
        // Sleep timer button (highlight if active)
        IconButton(onClick = onSleepTimer) {
            Icon(
                Icons.Default.Bedtime,
                "Sleep Timer",
                tint = if (sleepTimerActive) Purple500 else TextSecondary,
                modifier = Modifier.size(22.dp)
            )
        }
        // Speed button
        IconButton(onClick = onSpeed) {
            Icon(Icons.Default.Speed, "Speed", tint = TextSecondary, modifier = Modifier.size(22.dp))
        }
        IconButton(onClick = onMoreClick) {
            Icon(Icons.Default.MoreVert, "More", tint = TextSecondary, modifier = Modifier.size(22.dp))
        }
    }
}

@Composable
fun NowPlayingTabRow(
    selectedTab: NowPlayingTab,
    onTabSelect: (NowPlayingTab) -> Unit,
    modifier: Modifier = Modifier
) {
    TabRow(
        selectedTabIndex = selectedTab.ordinal,
        containerColor   = White,
        contentColor     = Purple500,
        indicator = { tabPositions ->
            TabRowDefaults.SecondaryIndicator(
                modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab.ordinal]),
                color    = Purple500
            )
        },
        divider = {}
    ) {
        NowPlayingTab.entries.forEach { tab ->
            Tab(
                selected = selectedTab == tab,
                onClick  = { onTabSelect(tab) },
                text = {
                    Text(
                        text  = tab.name.lowercase().replaceFirstChar { it.uppercase() },
                        style = MaterialTheme.typography.labelLarge,
                        color = if (selectedTab == tab) Purple500 else TextSecondary
                    )
                }
            )
        }
    }
}
