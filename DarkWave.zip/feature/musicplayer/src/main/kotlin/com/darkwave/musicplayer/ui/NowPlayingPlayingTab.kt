package com.darkwave.musicplayer.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.darkwave.common.util.toFormattedDuration
import com.darkwave.common.ui.theme.*
import com.darkwave.musicplayer.viewmodel.MusicPlayerUiState
import com.darkwave.musicplayer.viewmodel.RepeatMode

@Composable
fun NowPlayingPlayingTab(
    state: MusicPlayerUiState,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onShuffle: () -> Unit,
    onRepeat: () -> Unit,
    onLike: () -> Unit,
    onFavorite: () -> Unit,
    onAddToPlaylist: () -> Unit = {},
    onShare: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(16.dp))

        // ── Disc art ────────────────────────────────────────────────────
        DiscArt(
            albumArtUri = state.currentSong?.albumArtUri ?: "",
            isPlaying   = state.isPlaying,
            modifier    = Modifier.size(240.dp)
        )

        Spacer(Modifier.height(24.dp))

        // ── Waveform visualizer ─────────────────────────────────────────
        WaveformVisualizer(
            waveformData     = state.waveformData,
            currentFraction  = if (state.durationMs > 0) state.currentPositionMs.toFloat() / state.durationMs else 0f,
            isPlaying        = state.isPlaying,
            modifier         = Modifier
                .fillMaxWidth()
                .height(48.dp)
        )

        Spacer(Modifier.height(16.dp))

        // ── Song title + artist ─────────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = state.currentSong?.title ?: "No song",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = state.currentSong?.artist ?: "Unknown Artist",
                    fontSize = 14.sp,
                    color = TextSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            // Like button
            IconButton(onClick = onLike) {
                Icon(
                    imageVector = if (state.isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Like",
                    tint = if (state.isLiked) PinkAccent else TextSecondary,
                    modifier = Modifier.size(24.dp)
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        // ── Seek bar + times ────────────────────────────────────────────
        MusicSeekBar(
            position = state.currentPositionMs,
            duration = state.durationMs,
            onSeekTo = onSeekTo,
            modifier = Modifier.fillMaxWidth()
        )
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
        ) {
            Text(state.currentPositionMs.toFormattedDuration(), fontSize = 12.sp, color = TextSecondary)
            Spacer(Modifier.weight(1f))
            Text(state.durationMs.toFormattedDuration(), fontSize = 12.sp, color = TextSecondary)
        }

        Spacer(Modifier.height(16.dp))

        // ── Playback controls ───────────────────────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            // Shuffle
            IconButton(onClick = onShuffle) {
                Icon(
                    imageVector = Icons.Default.Shuffle,
                    contentDescription = "Shuffle",
                    tint = if (state.shuffleEnabled) Purple500 else TextSecondary,
                    modifier = Modifier.size(22.dp)
                )
            }

            // Previous
            IconButton(
                onClick  = onPrevious,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(Icons.Default.SkipPrevious, "Previous", tint = TextPrimary, modifier = Modifier.size(32.dp))
            }

            // Play / Pause — main large button
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Purple400, Purple600))),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = onPlayPause, modifier = Modifier.fillMaxSize()) {
                    if (state.isBuffering) {
                        CircularProgressIndicator(
                            color = White,
                            modifier = Modifier.size(28.dp),
                            strokeWidth = 2.5.dp
                        )
                    } else {
                        Icon(
                            imageVector = if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = White,
                            modifier = Modifier.size(34.dp)
                        )
                    }
                }
            }

            // Next
            IconButton(
                onClick  = onNext,
                modifier = Modifier.size(48.dp)
            ) {
                Icon(Icons.Default.SkipNext, "Next", tint = TextPrimary, modifier = Modifier.size(32.dp))
            }

            // Repeat
            IconButton(onClick = onRepeat) {
                Icon(
                    imageVector = when (state.repeatMode) {
                        RepeatMode.ONE -> Icons.Default.RepeatOne
                        else           -> Icons.Default.Repeat
                    },
                    contentDescription = "Repeat",
                    tint = if (state.repeatMode != RepeatMode.OFF) Purple500 else TextSecondary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        // ── Bottom row — Add to playlist, Share ─────────────────────────
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            TextButton(onClick = onAddToPlaylist) {
                Icon(Icons.Default.Add, null, tint = Purple500, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Add to Playlist", fontSize = 13.sp, color = Purple500)
            }
            TextButton(onClick = onShare) {
                Icon(Icons.Default.Share, null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Share", fontSize = 13.sp, color = TextSecondary)
            }
        }

        Spacer(Modifier.height(16.dp))
    }
}
