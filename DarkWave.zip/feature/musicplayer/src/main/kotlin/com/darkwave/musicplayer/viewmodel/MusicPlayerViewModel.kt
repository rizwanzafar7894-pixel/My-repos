package com.darkwave.musicplayer.viewmodel

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.darkwave.common.widget.WidgetPusher
import com.darkwave.domain.model.AudioItem
import com.darkwave.domain.repository.MediaRepository
import com.darkwave.domain.repository.PlaylistRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Named

enum class RepeatMode { OFF, ONE, ALL }
enum class NowPlayingTab { PLAYING, LYRICS, QUEUE }

data class MusicPlayerUiState(
    val currentSong: AudioItem?    = null,
    val queue: List<AudioItem>     = emptyList(),
    val currentIndex: Int          = 0,
    val isPlaying: Boolean         = false,
    val isBuffering: Boolean       = false,
    val positionMs: Long           = 0L,
    val currentPositionMs: Long    = 0L,
    val durationMs: Long           = 0L,
    val repeatMode: RepeatMode     = RepeatMode.OFF,
    val isShuffled: Boolean        = false,
    val shuffleEnabled: Boolean    = false,
    val currentTab: NowPlayingTab  = NowPlayingTab.PLAYING,
    val showQueue: Boolean         = false,
    val isLoading: Boolean         = false,
    val isLiked: Boolean           = false,
    val waveformData: List<Float>  = emptyList(),
    // Playlist dialog
    val showAddToPlaylist: Boolean = false,
    val availablePlaylists: List<com.darkwave.domain.model.Playlist> = emptyList(),
    // Lyrics
    val lyrics: String             = "",
    val isFetchingLyrics: Boolean  = false,

    // Sleep timer
    val sleepTimerRemainingMs: Long = 0L,
    val showSleepTimerPicker: Boolean = false,

    // Crossfade
    val crossfadeDurationMs: Int = 0,   // 0 = off, 2000-12000 = 2-12s

    // Speed
    val musicSpeed: Float = 1f,
    val showSpeedPicker: Boolean = false,

    // Timer display badge
    val showTimerBadge: Boolean = false
)

@HiltViewModel
class MusicPlayerViewModel @Inject constructor(
    application: Application,
    @Named("music") val player: ExoPlayer,
    private val mediaRepository: MediaRepository,
    private val playlistRepository: PlaylistRepository,
    private val widgetPusher: WidgetPusher
) : AndroidViewModel(application) {

    private val ctx: Context get() = getApplication<Application>().applicationContext

    private val _uiState = MutableStateFlow(MusicPlayerUiState())
    val uiState: StateFlow<MusicPlayerUiState> = _uiState.asStateFlow()

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _uiState.update { it.copy(isPlaying = isPlaying) }
            if (isPlaying) {
                // Attach visualizer now that audio session is valid
                val sessionId = player.audioSessionId
                if (sessionId != androidx.media3.common.C.AUDIO_SESSION_ID_UNSET) {
                    attachVisualizer(sessionId)
                }
            } else {
                detachVisualizer()
            }
            pushWidgets()
        }

        override fun onPlaybackStateChanged(state: Int) {
            _uiState.update {
                it.copy(
                    isBuffering = state == Player.STATE_BUFFERING,
                    durationMs  = player.duration.coerceAtLeast(0L)
                )
            }
        }

        override fun onMediaItemTransition(mediaItem: android.media3.common.MediaItem?, reason: Int) {
            val idx = player.currentMediaItemIndex
            val queue = _uiState.value.queue
            if (idx in queue.indices) {
                val song = queue[idx]
                _uiState.update {
                    it.copy(
                        currentSong  = song,
                        currentIndex = idx,
                        durationMs   = player.duration.coerceAtLeast(0L),
                        isLiked      = song.isLiked,
                        lyrics       = ""  // clear on track change
                    )
                }
                pushWidgets()
                // Apply crossfade on auto-transition (not on user seek/skip)
                val fadeDuration = _uiState.value.crossfadeDurationMs
                if (fadeDuration > 0 && reason == androidx.media3.common.Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
                    applyCrossfade(fadeDuration)
                }
            }
        }
    }

    private var progressJob: Job? = null

    init {
        player.addListener(playerListener)
        player.prepare()
        startProgressTracking()
    }

    private fun startProgressTracking() {
        progressJob = viewModelScope.launch {
            while (isActive) {
                val pos = player.currentPosition.coerceAtLeast(0L)
                _uiState.update { it.copy(positionMs = pos, currentPositionMs = pos) }
                delay(500)
            }
        }
    }

    fun playQueue(songs: List<AudioItem>, startIndex: Int = 0) {
        val items = songs.map { audio ->
            MediaItem.Builder()
                .setUri(Uri.parse(audio.uri))
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(audio.title)
                        .setArtist(audio.artist)
                        .setAlbumTitle(audio.album)
                        .setArtworkUri(Uri.parse(audio.albumArtUri))
                        .build()
                )
                .build()
        }
        val startSong = songs.getOrNull(startIndex)
        _uiState.update {
            it.copy(
                queue        = songs,
                currentIndex = startIndex,
                currentSong  = startSong,
                isLiked      = startSong?.isLiked ?: false,
                waveformData = List(60) { 0.08f },  // flat line until Visualizer attaches
                lyrics       = ""
            )
        }
        player.setMediaItems(items, startIndex, 0L)
        player.prepare()
        player.playWhenReady = true
        pushWidgets()

        startSong?.let { song ->
            viewModelScope.launch {
                mediaRepository.updateAudioPlayCount(
                    song.id, song.playCount + 1, System.currentTimeMillis()
                )
            }
        }
    }

    fun togglePlayPause() {
        if (player.isPlaying) player.pause() else player.play()
        pushWidgets()
    }

    fun playNext() {
        if (player.hasNextMediaItem()) {
            player.seekToNextMediaItem()
        }
        pushWidgets()
    }

    fun playPrevious() {
        if (player.currentPosition > 3000L) {
            player.seekTo(0L)
        } else if (player.hasPreviousMediaItem()) {
            player.seekToPreviousMediaItem()
        }
        pushWidgets()
    }

    fun seekTo(positionMs: Long) {
        player.seekTo(positionMs)
        _uiState.update { it.copy(positionMs = positionMs) }
    }

    fun toggleRepeat() {
        val next = when (_uiState.value.repeatMode) {
            RepeatMode.OFF -> RepeatMode.ALL
            RepeatMode.ALL -> RepeatMode.ONE
            RepeatMode.ONE -> RepeatMode.OFF
        }
        _uiState.update { it.copy(repeatMode = next) }
        player.repeatMode = when (next) {
            RepeatMode.OFF -> Player.REPEAT_MODE_OFF
            RepeatMode.ALL -> Player.REPEAT_MODE_ALL
            RepeatMode.ONE -> Player.REPEAT_MODE_ONE
        }
    }

    // Alias used by NowPlayingScreen
    fun cycleRepeat() = toggleRepeat()

    // Alias — favorite = like in this context
    fun toggleFavorite() {
        val song = _uiState.value.currentSong ?: return
        toggleLike(song)
    }

    fun hideQueue() { _uiState.update { it.copy(showQueue = false) } }

    fun playSong(song: AudioItem) {
        val queue = _uiState.value.queue
        val idx = queue.indexOfFirst { it.id == song.id }
        if (idx >= 0) {
            player.seekToMediaItem(idx)
            player.play()
        }
    }

    fun toggleShuffle() {
        val newVal = !_uiState.value.isShuffled
        player.shuffleModeEnabled = newVal
        _uiState.update { it.copy(isShuffled = newVal, shuffleEnabled = newVal) }
    }

    fun toggleQueue() {
        _uiState.update { it.copy(showQueue = !it.showQueue) }
    }

    fun onTabSelected(tab: NowPlayingTab) {
        _uiState.update { it.copy(currentTab = tab) }
    }

    fun toggleLike(song: AudioItem) {
        val newLiked = !song.isLiked
        _uiState.update { it.copy(isLiked = newLiked) }
        viewModelScope.launch {
            mediaRepository.toggleAudioLiked(song.id, newLiked)
        }
    }

    // ── Add to Playlist ───────────────────────────────────────────────────
    fun showAddToPlaylist() {
        viewModelScope.launch {
            playlistRepository.getAllPlaylists()
                .take(1)
                .collect { playlists ->
                    _uiState.update { it.copy(showAddToPlaylist = true, availablePlaylists = playlists) }
                }
        }
    }

    fun dismissAddToPlaylist() {
        _uiState.update { it.copy(showAddToPlaylist = false) }
    }

    fun addCurrentSongToPlaylist(playlistId: Long) {
        val song = _uiState.value.currentSong ?: return
        viewModelScope.launch {
            playlistRepository.addSongToPlaylist(playlistId, song.id)
            _uiState.update { it.copy(showAddToPlaylist = false) }
        }
    }

    fun createPlaylistAndAdd(name: String) {
        val song = _uiState.value.currentSong ?: return
        viewModelScope.launch {
            val id = playlistRepository.createPlaylist(name)
            playlistRepository.addSongToPlaylist(id, song.id)
            _uiState.update { it.copy(showAddToPlaylist = false) }
        }
    }

    // ── Share ─────────────────────────────────────────────────────────────
    fun shareSong(song: AudioItem) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, "Listening to: ${song.title} by ${song.artist}\n${song.uri}")
        }
        ctx.startActivity(Intent.createChooser(intent, "Share song").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    // ── Lyrics ────────────────────────────────────────────────────────────
    fun fetchLyrics() {
        val song = _uiState.value.currentSong ?: return
        _uiState.update { it.copy(isFetchingLyrics = true) }
        viewModelScope.launch(Dispatchers.IO) {
            // Try to read embedded lyrics tag from file
            val embedded = tryReadEmbeddedLyrics(song.uri)
            if (embedded != null) {
                _uiState.update { it.copy(lyrics = embedded, isFetchingLyrics = false) }
            } else {
                // No embedded lyrics — show helpful message
                _uiState.update {
                    it.copy(
                        lyrics = "No embedded lyrics found for \"${song.title}\".\n\n" +
                            "You can add lyrics using a tag editor app, or sync lyrics files (.lrc) " +
                            "with the same filename as the audio file.",
                        isFetchingLyrics = false
                    )
                }
            }
        }
    }

    private fun tryReadEmbeddedLyrics(uri: String): String? {
        return try {
            val retriever = android.media.MediaMetadataRetriever()
            retriever.setDataSource(ctx, Uri.parse(uri))
            val lyrics = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                // API 26+: METADATA_KEY_LYRICS reads ID3 USLT / Vorbis LYRICS tag
                retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_LYRICS)
            } else {
                null
            }
            retriever.release()
            lyrics?.takeIf { it.isNotBlank() }
        } catch (_: Exception) { null }
    }

    // ── Waveform from Android Visualizer API (real FFT) ──────────────────
    private var visualizer: android.media.audiofx.Visualizer? = null

    // generateFakeWaveform removed — replaced with flat-line init

    fun attachVisualizer(audioSessionId: Int) {
        if (audioSessionId == androidx.media3.common.C.AUDIO_SESSION_ID_UNSET) return
        try {
            visualizer?.release()
            visualizer = android.media.audiofx.Visualizer(audioSessionId).apply {
                captureSize = android.media.audiofx.Visualizer.getCaptureSizeRange()[1]
                setDataCaptureListener(object : android.media.audiofx.Visualizer.OnDataCaptureListener {
                    override fun onWaveFormDataCapture(vis: android.media.audiofx.Visualizer, waveform: ByteArray, samplingRate: Int) {}
                    override fun onFftDataCapture(vis: android.media.audiofx.Visualizer, fft: ByteArray, samplingRate: Int) {
                        val bars = List(60) { i ->
                            val idx = (i * fft.size / 60).coerceIn(0, fft.size - 1)
                            val mag = (fft[idx].toInt() and 0xFF) / 255f
                            mag.coerceIn(0.05f, 1f)
                        }
                        viewModelScope.launch(Dispatchers.Main) {
                            _uiState.update { it.copy(waveformData = bars) }
                        }
                    }
                }, android.media.audiofx.Visualizer.MAX_CAPTURE_RATE / 2, false, true)
                enabled = true
            }
        } catch (_: Exception) { /* Visualizer unavailable */ }
    }

    private fun detachVisualizer() {
        visualizer?.enabled = false
        visualizer?.release()
        visualizer = null
    }

    // ── Widget push ───────────────────────────────────────────────────────────
    private fun pushWidgets() {
        val state = _uiState.value
        val song  = state.currentSong ?: return
        val durationStr  = formatDuration(state.durationMs)
        val positionStr  = formatDuration(state.positionMs)
        val progressInt  = if (state.durationMs > 0)
            ((state.positionMs.toFloat() / state.durationMs) * 100).toInt().coerceIn(0, 100)
        else 0

        viewModelScope.launch(Dispatchers.IO) {
            widgetPusher.push(
                title       = song.title,
                artist      = song.artist,
                album       = song.album,
                isPlaying   = state.isPlaying,
                progress    = progressInt,
                position    = positionStr,
                duration    = durationStr,
                albumArtUri = song.albumArtUri
            )
        }
    }

    private fun formatDuration(ms: Long): String {
        val totalSec = ms / 1000
        val min = totalSec / 60
        val sec = totalSec % 60
        return "%d:%02d".format(min, sec)
    }

    // ── Music Sleep Timer ──────────────────────────────────────────────────
    private var musicSleepJob: kotlinx.coroutines.Job? = null

    fun showMusicSleepTimer() { _uiState.update { it.copy(showSleepTimerPicker = true) } }
    fun dismissMusicSleepTimer() { _uiState.update { it.copy(showSleepTimerPicker = false) } }

    fun setMusicSleepTimer(ms: Long) {
        musicSleepJob?.cancel()
        _uiState.update { it.copy(showSleepTimerPicker = false, showTimerBadge = ms > 0) }
        if (ms <= 0L) {
            _uiState.update { it.copy(sleepTimerRemainingMs = 0L, showTimerBadge = false) }
            return
        }
        musicSleepJob = viewModelScope.launch {
            var remaining = ms
            while (remaining > 0) {
                kotlinx.coroutines.delay(1000)
                remaining -= 1000
                _uiState.update { it.copy(sleepTimerRemainingMs = remaining) }
            }
            // Gracefully fade out and pause
            player.pause()
            _uiState.update { it.copy(sleepTimerRemainingMs = 0L, showTimerBadge = false) }
        }
    }

    // ── Crossfade ─────────────────────────────────────────────────────────
    fun setCrossfade(durationMs: Int) {
        _uiState.update { it.copy(crossfadeDurationMs = durationMs) }
    }

    // ── Real crossfade on media item transition ───────────────────────────
    // Called from onMediaItemTransition in playerListener
    private var crossfadeJob: kotlinx.coroutines.Job? = null

    internal fun applyCrossfade(fadeDurationMs: Int) {
        if (fadeDurationMs <= 0) return
        crossfadeJob?.cancel()
        crossfadeJob = viewModelScope.launch {
            val steps    = 30
            val interval = (fadeDurationMs / steps).toLong().coerceAtLeast(16L)
            // Fade out old track (already transitioned, so we fade in new)
            // Fade volume from 0 → 1 for incoming track
            for (i in 0..steps) {
                val vol = i.toFloat() / steps
                try { player.volume = vol } catch (_: Exception) {}
                delay(interval)
            }
            try { player.volume = 1f } catch (_: Exception) {}
        }
    }

    // ── Music Playback Speed ──────────────────────────────────────────────
    fun showSpeedPicker() { _uiState.update { it.copy(showSpeedPicker = true) } }
    fun dismissSpeedPicker() { _uiState.update { it.copy(showSpeedPicker = false) } }

    fun setMusicSpeed(speed: Float) {
        player.setPlaybackSpeed(speed)
        _uiState.update { it.copy(musicSpeed = speed, showSpeedPicker = false) }
    }

    override fun onCleared() {
        progressJob?.cancel()
        musicSleepJob?.cancel()
        detachVisualizer()
        player.removeListener(playerListener)
        // Don't release player here — it's a Singleton managed by Hilt
        super.onCleared()
    }
}
