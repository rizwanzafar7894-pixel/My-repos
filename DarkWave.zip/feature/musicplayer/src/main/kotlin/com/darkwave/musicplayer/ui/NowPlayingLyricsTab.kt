package com.darkwave.musicplayer.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.domain.model.AudioItem
import com.darkwave.common.ui.theme.*

@Composable
fun NowPlayingLyricsTab(
    song: AudioItem?,
    lyrics: String = "",
    isFetching: Boolean = false,
    onFetchLyrics: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    if (song == null) {
        Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No song playing", color = TextSecondary, fontSize = 15.sp)
        }
        return
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Song chip
        Surface(shape = RoundedCornerShape(50), color = Purple100) {
            Row(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.MusicNote, null, tint = Purple500, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    "${song.title} · ${song.artist}",
                    fontSize = 13.sp, color = Purple500, fontWeight = FontWeight.Medium
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        if (isFetching) {
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Purple500)
            }
        } else if (lyrics.isNotBlank()) {
            // Show lyrics scrollable
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = lyrics,
                    fontSize = 16.sp,
                    color = TextPrimary,
                    textAlign = TextAlign.Center,
                    lineHeight = 28.sp,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(32.dp))
            }
        } else {
            // No lyrics yet — placeholder
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("♪  ──  ──  ──  ──  ──  ──  ──  ♪", color = TextSecondary, fontSize = 14.sp)
                    Spacer(Modifier.height(16.dp))
                    Text("Lyrics not available", color = TextSecondary, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(4.dp))
                    Text("Tap below to check embedded tags", color = TextTertiary, fontSize = 13.sp)
                    Spacer(Modifier.height(16.dp))
                    Text("♪  ──  ──  ──  ──  ──  ──  ──  ♪", color = TextSecondary, fontSize = 14.sp)
                }
            }
        }

        // Fetch button
        TextButton(onClick = onFetchLyrics, enabled = !isFetching) {
            if (isFetching) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = Purple500)
                Spacer(Modifier.width(6.dp))
                Text("Fetching...", color = Purple500, fontSize = 14.sp)
            } else {
                Icon(Icons.Default.Refresh, null, tint = Purple500, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Fetch Lyrics", color = Purple500, fontSize = 14.sp)
            }
        }
    }
}
