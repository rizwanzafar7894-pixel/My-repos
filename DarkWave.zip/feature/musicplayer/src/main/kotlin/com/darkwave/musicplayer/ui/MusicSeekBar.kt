package com.darkwave.musicplayer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.darkwave.common.ui.theme.*

@Composable
fun MusicSeekBar(
    position: Long,
    duration: Long,
    onSeekTo: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    var isDragging   by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }
    var trackWidthPx by remember { mutableIntStateOf(1) }
    val density      = LocalDensity.current

    val fraction = when {
        isDragging   -> dragFraction
        duration > 0 -> position.toFloat() / duration
        else          -> 0f
    }

    val thumbOffsetDp = with(density) { (fraction * trackWidthPx).toDp() }

    Box(
        modifier = modifier
            .height(28.dp)
            .onSizeChanged { trackWidthPx = it.width }
            .pointerInput(duration) {
                detectTapGestures { offset ->
                    val frac = (offset.x / trackWidthPx).coerceIn(0f, 1f)
                    onSeekTo((frac * duration).toLong())
                }
            }
            .pointerInput(duration) {
                detectHorizontalDragGestures(
                    onDragStart   = { isDragging = true },
                    onDragEnd     = { isDragging = false; onSeekTo((dragFraction * duration).toLong()) },
                    onDragCancel  = { isDragging = false },
                    onHorizontalDrag = { change, dragAmount ->
                        change.consume()
                        dragFraction = (dragFraction + dragAmount / trackWidthPx).coerceIn(0f, 1f)
                    }
                )
            },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(Color(0xFFE0E0E0))
        ) {
            Box(Modifier.fillMaxWidth(fraction).fillMaxHeight().background(Purple500))
        }

        val thumbSize = if (isDragging) 18.dp else 14.dp
        Box(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .padding(start = (thumbOffsetDp - thumbSize / 2).coerceAtLeast(0.dp))
                    .size(thumbSize)
                    .clip(CircleShape)
                    .background(Purple500)
                    .align(Alignment.CenterStart)
            )
        }
    }
}
