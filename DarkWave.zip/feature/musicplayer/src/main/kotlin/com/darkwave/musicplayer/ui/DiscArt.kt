package com.darkwave.musicplayer.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.darkwave.common.ui.theme.*

@Composable
fun DiscArt(
    albumArtUri: String,
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "discSpin")
    val rotation by infiniteTransition.animateFloat(
        initialValue   = 0f,
        targetValue    = 360f,
        animationSpec  = infiniteRepeatable(
            animation  = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "discRotation"
    )

    // Only rotate when playing — hold position when paused via pauseResumeAnimation
    var currentRotation by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(isPlaying, rotation) {
        if (isPlaying) currentRotation = rotation
    }

    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        // Outer ring shadow
        Box(
            modifier = Modifier
                .fillMaxSize()
                .shadow(24.dp, CircleShape)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        listOf(Color(0xFF3D3D3D), Color(0xFF1A1A1A))
                    )
                )
                .rotate(if (isPlaying) rotation else currentRotation)
        ) {
            // Grooves — concentric rings
            for (i in 1..4) {
                val fraction = 0.55f + i * 0.08f
                Box(
                    modifier = Modifier
                        .fillMaxSize(fraction)
                        .clip(CircleShape)
                        .background(Color.Transparent)
                        .align(Alignment.Center)
                ) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        shape    = CircleShape,
                        color    = Color.Transparent,
                        border   = androidx.compose.foundation.BorderStroke(
                            width = 1.dp,
                            color = Color.White.copy(alpha = 0.06f)
                        )
                    ) {}
                }
            }

            // Center album art circle
            Box(
                modifier = Modifier
                    .fillMaxSize(0.52f)
                    .clip(CircleShape)
                    .background(Color(0xFF2A2A2A))
                    .align(Alignment.Center)
            ) {
                if (albumArtUri.isNotBlank()) {
                    AsyncImage(
                        model          = albumArtUri,
                        contentDescription = "Album Art",
                        contentScale   = ContentScale.Crop,
                        modifier       = Modifier.fillMaxSize()
                    )
                } else {
                    // Fallback gradient
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.radialGradient(
                                    listOf(Purple400.copy(alpha = 0.8f), Purple600)
                                )
                            )
                    )
                }

                // Center hole
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1A1A1A))
                        .align(Alignment.Center)
                )
            }
        }

        // Needle hint — faint line at top
        Box(
            modifier = Modifier
                .width(2.dp)
                .height(40.dp)
                .background(
                    Brush.verticalGradient(
                        listOf(Purple500.copy(alpha = 0.6f), Color.Transparent)
                    )
                )
                .align(Alignment.TopCenter)
        )
    }
}
