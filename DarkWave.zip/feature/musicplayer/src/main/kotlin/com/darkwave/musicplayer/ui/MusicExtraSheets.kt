package com.darkwave.musicplayer.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.theme.*

private val AccentPurple = Purple500
private val SheetBg = Color(0xFFFAFAFA)

// ── Music Sleep Timer Sheet ───────────────────────────────────────────────
@Composable
fun MusicSleepTimerSheet(
    currentRemainingMs: Long,
    onSet: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    val options = listOf(
        "5 min"       to 5 * 60_000L,
        "10 min"      to 10 * 60_000L,
        "15 min"      to 15 * 60_000L,
        "30 min"      to 30 * 60_000L,
        "45 min"      to 45 * 60_000L,
        "1 hour"      to 60 * 60_000L,
        "90 min"      to 90 * 60_000L,
        "End of song" to -1L
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        color    = SheetBg
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Bedtime, null, tint = AccentPurple, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Sleep Timer", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, null, tint = TextSecondary)
                }
            }
            Spacer(Modifier.height(8.dp))

            // Cancel if timer is active
            if (currentRemainingMs > 0) {
                val m = currentRemainingMs / 60000
                val s = (currentRemainingMs % 60000) / 1000
                Card(
                    colors = CardDefaults.cardColors(containerColor = AccentPurple.copy(alpha = 0.1f)),
                    shape  = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                ) {
                    Row(
                        Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("${m}m ${s}s remaining", color = AccentPurple, fontWeight = FontWeight.SemiBold)
                        TextButton(onClick = { onSet(0L); onDismiss() }) {
                            Text("Cancel", color = Color(0xFFEF5350))
                        }
                    }
                }
            }

            options.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { (label, ms) ->
                        OutlinedButton(
                            onClick  = { onSet(ms); onDismiss() },
                            modifier = Modifier.weight(1f),
                            shape    = RoundedCornerShape(10.dp),
                            colors   = ButtonDefaults.outlinedButtonColors(contentColor = AccentPurple)
                        ) { Text(label, fontSize = 13.sp) }
                    }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

// ── Music Sleep Timer Badge ───────────────────────────────────────────────
@Composable
fun MusicSleepTimerBadge(
    remainingMs: Long,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    val m = remainingMs / 60000
    val s = (remainingMs % 60000) / 1000
    Surface(
        modifier = modifier,
        shape    = RoundedCornerShape(20.dp),
        color    = AccentPurple.copy(alpha = 0.1f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(Icons.Default.Bedtime, null, tint = AccentPurple, modifier = Modifier.size(14.dp))
            Text(
                if (m > 0) "${m}m ${s}s" else "${s}s",
                color = AccentPurple, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
            )
            TextButton(
                onClick = onCancel,
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.height(20.dp)
            ) {
                Text("Cancel", color = Color(0xFFEF5350), fontSize = 11.sp)
            }
        }
    }
}

// ── Music Speed Sheet ─────────────────────────────────────────────────────
@Composable
fun MusicSpeedSheet(
    currentSpeed: Float,
    onSpeedSet: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 1.75f, 2.0f)

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        color    = SheetBg
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Speed, null, tint = AccentPurple, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Playback Speed", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, null, tint = TextSecondary) }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally)) {
                speeds.forEach { speed ->
                    val selected = currentSpeed == speed
                    Surface(
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)),
                        color = if (selected) AccentPurple else AccentPurple.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        TextButton(
                            onClick = { onSpeedSet(speed); onDismiss() },
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Text(
                                if (speed == 1.0f) "1×" else "${speed}×",
                                color = if (selected) Color.White else AccentPurple,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
