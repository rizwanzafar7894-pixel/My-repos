package com.darkwave.musicplayer.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.darkwave.common.util.toFormattedDuration
import com.darkwave.domain.model.AudioItem
import com.darkwave.common.ui.theme.*

@Composable
fun NowPlayingQueueTab(
    queue: List<AudioItem>,
    currentSong: AudioItem?,
    onSongClick: (AudioItem) -> Unit,
    onReorder: (from: Int, to: Int) -> Unit = { _, _ -> },
    onRemove: (Int) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState()
    val currentIndex = queue.indexOfFirst { it.id == currentSong?.id }

    // Auto-scroll to current song
    LaunchedEffect(currentIndex) {
        if (currentIndex >= 0) listState.animateScrollToItem(currentIndex)
    }

    Column(modifier = modifier.fillMaxSize()) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Queue",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.weight(1f)
            )
            Text(
                "${queue.size} songs",
                fontSize = 13.sp,
                color = TextSecondary
            )
        }

        if (queue.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("Queue is empty", color = TextSecondary, fontSize = 15.sp)
            }
        } else {
            LazyColumn(
                state          = listState,
                contentPadding = PaddingValues(bottom = 16.dp),
                modifier       = Modifier.fillMaxSize()
            ) {
                itemsIndexed(queue) { index, song ->
                    val isCurrent = song.id == currentSong?.id
                    QueueSongRow(
                        song      = song,
                        index     = index + 1,
                        isCurrent = isCurrent,
                        onClick   = { onSongClick(song) }
                    )
                }
            }
        }
    }
}

@Composable
private fun QueueSongRow(
    song: AudioItem,
    index: Int,
    isCurrent: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isCurrent) Purple100 else androidx.compose.ui.graphics.Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Current indicator or index
        Box(modifier = Modifier.width(24.dp), contentAlignment = Alignment.Center) {
            if (isCurrent) {
                Icon(
                    Icons.Default.VolumeUp,
                    "Now Playing",
                    tint    = Purple500,
                    modifier = Modifier.size(18.dp)
                )
            } else {
                Text(
                    text     = index.toString(),
                    fontSize = 13.sp,
                    color    = TextTertiary
                )
            }
        }

        Spacer(Modifier.width(10.dp))

        // Album art
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Purple100)
        ) {
            if (song.albumArtUri.isNotBlank()) {
                AsyncImage(
                    model        = song.albumArtUri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier     = Modifier.fillMaxSize()
                )
            }
        }

        Spacer(Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text       = song.title,
                fontSize   = 13.sp,
                fontWeight = if (isCurrent) FontWeight.SemiBold else FontWeight.Normal,
                color      = if (isCurrent) Purple500 else TextPrimary,
                maxLines   = 1,
                overflow   = TextOverflow.Ellipsis
            )
            Text(
                text     = song.artist,
                fontSize = 11.sp,
                color    = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        Text(
            text     = song.duration.toFormattedDuration(),
            fontSize = 12.sp,
            color    = TextSecondary
        )

        Spacer(Modifier.width(4.dp))

        // Drag handle with vertical drag for reorder
        var dragging by remember { mutableStateOf(false) }
        Icon(
            Icons.Default.DragHandle,
            "Drag to reorder",
            tint     = if (dragging) Purple500 else TextTertiary,
            modifier = Modifier
                .size(20.dp)
                .pointerInput(index) {
                    detectVerticalDragGestures(
                        onDragStart = { dragging = true },
                        onDragEnd   = { dragging = false },
                        onDragCancel = { dragging = false }
                    ) { _, dragAmount ->
                        val steps = (dragAmount / 60f).toInt()
                        if (steps != 0) {
                            val newIdx = (index + steps).coerceIn(0, queue.size - 1)
                            if (newIdx != index) onReorder(index, newIdx)
                        }
                    }
                }
        )

        // Swipe-to-remove indicator (dismiss button appears on long press)
        IconButton(
            onClick = { onRemove(index) },
            modifier = Modifier.size(28.dp)
        ) {
            Icon(Icons.Default.Close, "Remove", tint = TextTertiary, modifier = Modifier.size(14.dp))
        }
    }
}
