package com.darkwave.musicplayer.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.darkwave.common.ui.theme.*

@Composable
fun WaveformVisualizer(
    waveformData: List<Float>,
    currentFraction: Float,
    isPlaying: Boolean,
    modifier: Modifier = Modifier
) {
    // Animate bar heights when playing
    val infiniteTransition = rememberInfiniteTransition(label = "waveform")
    val animOffset by infiniteTransition.animateFloat(
        initialValue  = 0f,
        targetValue   = 1f,
        animationSpec = infiniteRepeatable(
            animation  = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "waveAnim"
    )

    Canvas(modifier = modifier) {
        if (waveformData.isEmpty()) return@Canvas

        val barCount  = waveformData.size
        val totalWidth = size.width
        val barWidth  = (totalWidth / barCount) * 0.65f
        val gap       = (totalWidth / barCount) * 0.35f
        val maxHeight = size.height
        val centerY   = size.height / 2f

        waveformData.forEachIndexed { index, amplitude ->
            val x = index * (barWidth + gap)
            val isPlayed = (index.toFloat() / barCount) <= currentFraction

            // Animate amplitude slightly when playing
            val animAmplitude = if (isPlaying) {
                val phase = (index.toFloat() / barCount + animOffset) % 1f
                (amplitude * (0.5f + 0.5f * kotlin.math.sin(phase * 2 * kotlin.math.PI.toFloat()))).coerceIn(0.05f, 1f)
            } else {
                amplitude * 0.6f
            }

            val barHeight = (animAmplitude * maxHeight).coerceAtLeast(4.dp.toPx())

            val barColor = when {
                isPlayed -> Purple500
                else     -> Color(0xFFE0E0E0)
            }

            drawRoundRect(
                color       = barColor,
                topLeft     = Offset(x, centerY - barHeight / 2),
                size        = Size(barWidth, barHeight),
                cornerRadius = CornerRadius(barWidth / 2)
            )
        }
    }
}
