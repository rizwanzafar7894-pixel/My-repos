package com.darkwave.browser.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.theme.*

@Composable
fun BrowserAddressBar(
    url: String,
    urlBarText: String,
    isEditing: Boolean,
    isLoading: Boolean,
    progress: Int,
    canGoBack: Boolean,
    canGoForward: Boolean,
    onTextChanged: (String) -> Unit,
    onSubmit: (String) -> Unit,
    onStartEditing: () -> Unit,
    onStopEditing: () -> Unit,
    onGoBack: () -> Unit,
    onGoForward: () -> Unit,
    onRefresh: () -> Unit,
    onMenuClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val focusRequester = remember { FocusRequester() }

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Back button
            IconButton(
                onClick  = onGoBack,
                enabled  = canGoBack,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    Icons.Default.ArrowBack, "Back",
                    tint = if (canGoBack) TextPrimary else TextTertiary,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Forward
            IconButton(
                onClick  = onGoForward,
                enabled  = canGoForward,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    Icons.Default.ArrowForward, "Forward",
                    tint = if (canGoForward) TextPrimary else TextTertiary,
                    modifier = Modifier.size(20.dp)
                )
            }

            // URL bar
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(SurfaceVariant)
                    .border(
                        width = if (isEditing) 1.5.dp else 0.dp,
                        color = if (isEditing) Purple500 else Color.Transparent,
                        shape = RoundedCornerShape(20.dp)
                    )
            ) {
                if (isEditing) {
                    TextField(
                        value         = urlBarText,
                        onValueChange = onTextChanged,
                        modifier      = Modifier
                            .fillMaxSize()
                            .focusRequester(focusRequester),
                        placeholder   = { Text("Search or enter URL", color = TextTertiary, fontSize = 13.sp) },
                        singleLine    = true,
                        textStyle     = LocalTextStyle.current.copy(fontSize = 13.sp),
                        colors        = TextFieldDefaults.colors(
                            focusedContainerColor   = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor   = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                        keyboardActions = KeyboardActions(onGo = { onSubmit(urlBarText) }),
                        trailingIcon = {
                            if (urlBarText.isNotEmpty()) {
                                IconButton(onClick = { onTextChanged("") }, modifier = Modifier.size(28.dp)) {
                                    Icon(Icons.Default.Close, "Clear", tint = TextSecondary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    )
                    LaunchedEffect(Unit) { focusRequester.requestFocus() }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .clickable(onClick = onStartEditing)
                            .padding(horizontal = 14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Lock / globe icon
                        Icon(
                            imageVector = if (url.startsWith("https")) Icons.Default.Lock else Icons.Default.Language,
                            contentDescription = null,
                            tint = if (url.startsWith("https")) GreenAccent else TextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = url.removePrefix("https://").removePrefix("http://").ifBlank { "Search or enter URL" },
                            fontSize  = 13.sp,
                            color     = if (url.isBlank() || url == "about:blank") TextTertiary else TextPrimary,
                            maxLines  = 1,
                            overflow  = TextOverflow.Ellipsis,
                            modifier  = Modifier.weight(1f)
                        )
                    }
                }
            }

            Spacer(Modifier.width(4.dp))

            // Refresh / Stop
            IconButton(
                onClick  = if (isLoading) ({}) else onRefresh,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = if (isLoading) Icons.Default.Close else Icons.Default.Refresh,
                    contentDescription = if (isLoading) "Stop" else "Refresh",
                    tint = TextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Menu
            IconButton(onClick = onMenuClick, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.MoreVert, "Menu", tint = TextSecondary, modifier = Modifier.size(20.dp))
            }
        }

        // Loading progress bar
        AnimatedVisibility(visible = isLoading) {
            LinearProgressIndicator(
                progress  = { progress / 100f },
                modifier  = Modifier.fillMaxWidth().height(2.dp),
                color     = Purple500,
                trackColor = Color.Transparent
            )
        }
    }
}
