package com.darkwave.browser.download

import android.content.Context
import android.os.Environment
import com.yausername.youtubedl_android.YoutubeDL
import com.darkwave.browser.model.DownloadFormat
import com.darkwave.browser.model.DownloadState
import com.darkwave.browser.model.DownloadTask
import com.darkwave.browser.model.FormatType
import com.darkwave.browser.ytdlp.YtDlpEngine
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DownloadManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val engine: YtDlpEngine
) {
    // Own scope so downloads survive ViewModel recreation
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _tasks = MutableStateFlow<List<DownloadTask>>(emptyList())
    val tasks: StateFlow<List<DownloadTask>> = _tasks.asStateFlow()

    /** Start a download. Returns task ID immediately; download runs in background. */
    fun startDownload(url: String, title: String, format: DownloadFormat): String {
        val id     = UUID.randomUUID().toString()
        val outDir = outputDir(format)

        upsert(DownloadTask(id = id, url = url, title = title, format = format,
            outputPath = outDir.absolutePath, state = DownloadState.DOWNLOADING))

        scope.launch {
            try {
                val req = engine.buildDownloadRequest(url, format, outDir.absolutePath) { _, _, _ -> }

                YoutubeDL.getInstance().execute(req, id) { pct, eta, line ->
                    val state = when {
                        line.contains("Merging", ignoreCase = true)     -> DownloadState.MERGING
                        line.contains("[ExtractAudio]", ignoreCase=true) -> DownloadState.MERGING
                        else                                             -> DownloadState.DOWNLOADING
                    }
                    upsert(id) { t -> t.copy(
                        progressPercent = pct,
                        etaLabel        = if (eta > 0) formatEta(eta) else t.etaLabel,
                        speedLabel      = extractSpeed(line).ifEmpty { t.speedLabel },
                        state           = state
                    )}
                }

                // Find completed file (most recently modified in output dir)
                val done = outDir.listFiles()?.filter { it.isFile }?.maxByOrNull { it.lastModified() }
                upsert(id) { t -> t.copy(
                    state = DownloadState.COMPLETED,
                    progressPercent = 100f,
                    completedFilePath = done?.absolutePath,
                    speedLabel = "", etaLabel = ""
                )}

                // Scan file into MediaStore so it appears in gallery/music apps
                done?.let { android.media.MediaScannerConnection.scanFile(context, arrayOf(it.absolutePath), null, null) }

            } catch (e: Exception) {
                val isCancelled = e.message?.contains("cancel", ignoreCase = true) == true ||
                                  e is CancellationException
                upsert(id) { t -> t.copy(
                    state        = if (isCancelled) DownloadState.CANCELLED else DownloadState.FAILED,
                    errorMessage = if (isCancelled) null else e.message?.take(200)
                )}
            }
        }
        return id
    }

    fun cancelDownload(id: String) {
        try { YoutubeDL.getInstance().destroyProcessById(id) } catch (_: Exception) {}
        upsert(id) { it.copy(state = DownloadState.CANCELLED) }
    }

    fun removeTask(id: String) { _tasks.update { list -> list.filter { it.id != id } } }

    // ── Private helpers ──────────────────────────────────────────────────────

    private fun outputDir(fmt: DownloadFormat): File {
        val base = Environment.getExternalStoragePublicDirectory(
            if (fmt.type == FormatType.AUDIO_ONLY) Environment.DIRECTORY_MUSIC
            else Environment.DIRECTORY_MOVIES
        )
        return File(base, "DarkWave").also { if (!it.exists()) it.mkdirs() }
    }

    private fun upsert(task: DownloadTask) {
        _tasks.update { list ->
            if (list.any { it.id == task.id }) list.map { if (it.id == task.id) task else it }
            else list + task
        }
    }

    private fun upsert(id: String, transform: (DownloadTask) -> DownloadTask) {
        _tasks.update { list -> list.map { if (it.id == id) transform(it) else it } }
    }

    private fun extractSpeed(line: String): String =
        Regex("""(\d+\.?\d*\s?[KMG]iB/s)""").find(line)?.groupValues?.get(1) ?: ""

    private fun formatEta(s: Long): String = if (s >= 60) "${s/60}m ${s%60}s" else "${s}s"
}
