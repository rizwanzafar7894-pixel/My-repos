package com.darkwave.browser.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darkwave.browser.download.DownloadManager
import com.darkwave.browser.model.DownloadFormat
import com.darkwave.browser.model.DownloadTask
import com.darkwave.browser.model.MediaFormats
import com.darkwave.browser.ytdlp.YtDlpEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class BrowserTab(
    val id: Int,
    val url: String = "about:blank",
    val title: String = "New Tab",
    val isLoading: Boolean = false,
    val progress: Int = 0,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val favicon: String = ""
)

data class HistoryEntry(
    val url: String,
    val title: String,
    val visitedAt: Long = System.currentTimeMillis()
)

data class BrowserBookmark(
    val url: String,
    val title: String,
    val favicon: String = ""
)

data class BrowserUiState(
    // Navigation
    val tabs: List<BrowserTab> = listOf(BrowserTab(id = 0)),
    val activeTabIndex: Int = 0,
    val urlBarText: String = "",
    val isEditingUrl: Boolean = false,
    val showTabDrawer: Boolean = false,
    val showBookmarks: Boolean = false,
    val showHistory: Boolean = false,
    val showMenu: Boolean = false,
    val history: List<HistoryEntry> = emptyList(),
    val bookmarks: List<BrowserBookmark> = defaultBookmarks,
    val isFullscreen: Boolean = false,

    // ── Download / Video detection ─────────────────────────────────
    val showDownloadFab: Boolean = false,
    val videoDetectedUrl: String? = null,
    val videoDetectedTitle: String = "",
    val showFormatSheet: Boolean = false,
    val isFetchingFormats: Boolean = false,
    val fetchError: String? = null,
    val mediaFormats: MediaFormats? = null,
    val selectedFormatTab: FormatTab = FormatTab.VIDEO,
    val showDownloadDrawer: Boolean = false,
    val snackbarMessage: String? = null
) {
    val activeTab: BrowserTab get() = tabs.getOrElse(activeTabIndex) { tabs.first() }
}

enum class FormatTab { VIDEO, AUDIO }

val defaultBookmarks = listOf(
    BrowserBookmark("https://youtube.com",   "YouTube"),
    BrowserBookmark("https://google.com",    "Google"),
    BrowserBookmark("https://reddit.com",    "Reddit"),
    BrowserBookmark("https://github.com",    "GitHub"),
    BrowserBookmark("https://twitter.com",   "X (Twitter)"),
    BrowserBookmark("https://instagram.com", "Instagram"),
    BrowserBookmark("https://wikipedia.org", "Wikipedia"),
    BrowserBookmark("https://netflix.com",   "Netflix")
)

val quickAccessSites = listOf(
    Triple("YouTube",   "https://youtube.com",   "YT"),
    Triple("Google",    "https://google.com",    "G"),
    Triple("Reddit",    "https://reddit.com",    "R"),
    Triple("GitHub",    "https://github.com",    "GH"),
    Triple("Twitter",   "https://twitter.com",   "X"),
    Triple("Instagram", "https://instagram.com", "IG"),
    Triple("Wikipedia", "https://wikipedia.org", "W"),
    Triple("Netflix",   "https://netflix.com",   "N")
)

@HiltViewModel
class BrowserViewModel @Inject constructor(
    private val ytDlpEngine: YtDlpEngine,
    private val downloadManager: DownloadManager
) : ViewModel() {

    private val _uiState = MutableStateFlow(BrowserUiState())
    val uiState: StateFlow<BrowserUiState> = _uiState.asStateFlow()

    val downloadTasks: StateFlow<List<DownloadTask>> = downloadManager.tasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private var formatFetchJob: Job? = null

    init {
        viewModelScope.launch { ytDlpEngine.initialize() }
    }

    // ── URL navigation ────────────────────────────────────────────────
    fun navigateTo(url: String) {
        val resolved = resolveUrl(url)
        updateActiveTab { it.copy(url = resolved, title = resolved, isLoading = true) }
        _uiState.update { it.copy(
            urlBarText = resolved,
            isEditingUrl = false,
            showDownloadFab = false,
            videoDetectedUrl = null
        ) }
        addToHistory(resolved, resolved)
    }

    fun onUrlBarTextChanged(text: String) { _uiState.update { it.copy(urlBarText = text) } }

    fun onUrlBarSubmit(text: String) {
        val query = text.trim()
        if (query.isBlank()) return
        val url = when {
            query.startsWith("http://") || query.startsWith("https://") -> query
            query.contains(".") && !query.contains(" ") -> "https://$query"
            else -> "https://www.google.com/search?q=${query.replace(" ", "+")}"
        }
        navigateTo(url)
    }

    fun startEditingUrl() {
        _uiState.update { state ->
            state.copy(isEditingUrl = true, urlBarText = state.activeTab.url.takeIf { it != "about:blank" } ?: "")
        }
    }
    fun stopEditingUrl() { _uiState.update { it.copy(isEditingUrl = false) } }

    // ── Page events (called from WebViewClient) ───────────────────────
    fun onPageStarted(url: String) {
        updateActiveTab { it.copy(url = url, isLoading = true, progress = 10) }
        _uiState.update { it.copy(urlBarText = url, showDownloadFab = false, videoDetectedUrl = null) }
    }

    fun onPageFinished(url: String, title: String) {
        updateActiveTab { it.copy(url = url, title = title, isLoading = false, progress = 100) }
        addToHistory(url, title)
        _uiState.update { it.copy(urlBarText = url) }
    }

    fun onProgressChanged(progress: Int) { updateActiveTab { it.copy(progress = progress) } }
    fun onCanGoBack(can: Boolean)        { updateActiveTab { it.copy(canGoBack = can) } }
    fun onCanGoForward(can: Boolean)     { updateActiveTab { it.copy(canGoForward = can) } }

    // ── Video detection (JS Bridge callback) ─────────────────────────
    fun onVideoDetected(pageUrl: String, pageTitle: String) {
        _uiState.update { it.copy(
            showDownloadFab    = true,
            videoDetectedUrl   = pageUrl,
            videoDetectedTitle = pageTitle
        ) }
    }

    fun onVideoStopped() {
        // Keep FAB visible — user may want to download even after pause
    }

    // ── Format sheet ──────────────────────────────────────────────────
    fun onDownloadFabClicked() {
        val url = _uiState.value.videoDetectedUrl ?: _uiState.value.activeTab.url
        _uiState.update { it.copy(
            showFormatSheet   = true,
            isFetchingFormats = true,
            fetchError        = null,
            mediaFormats      = null
        ) }
        formatFetchJob?.cancel()
        formatFetchJob = viewModelScope.launch {
            val formats = ytDlpEngine.getFormats(url)
            if (formats == null || !formats.hasAny) {
                _uiState.update { it.copy(
                    isFetchingFormats = false,
                    fetchError = "No downloadable media found on this page.\nPlay a video first, then tap the download button."
                ) }
            } else {
                _uiState.update { it.copy(isFetchingFormats = false, mediaFormats = formats) }
            }
        }
    }

    fun onFormatTabSelected(tab: FormatTab) { _uiState.update { it.copy(selectedFormatTab = tab) } }

    fun onDismissFormatSheet() {
        formatFetchJob?.cancel()
        _uiState.update { it.copy(showFormatSheet = false, isFetchingFormats = false, fetchError = null, mediaFormats = null) }
    }

    // ── Download ──────────────────────────────────────────────────────
    fun startDownload(format: DownloadFormat) {
        val state = _uiState.value
        val url   = state.videoDetectedUrl ?: state.activeTab.url
        val title = state.mediaFormats?.title ?: state.activeTab.title
        _uiState.update { it.copy(showFormatSheet = false, snackbarMessage = "Download started: ${format.label}") }
        // DownloadManager manages its own CoroutineScope — no need for viewModelScope here
        downloadManager.startDownload(url, title, format)
    }

    fun cancelDownload(taskId: String)  { downloadManager.cancelDownload(taskId) }
    fun removeDownload(taskId: String)  { downloadManager.removeTask(taskId) }
    fun onToggleDownloadDrawer()        { _uiState.update { it.copy(showDownloadDrawer = !it.showDownloadDrawer) } }
    fun onDismissSnackbar()             { _uiState.update { it.copy(snackbarMessage = null) } }

    // ── Tabs ──────────────────────────────────────────────────────────
    fun openNewTab(url: String = "about:blank") {
        _uiState.update { state ->
            val newId  = (state.tabs.maxOfOrNull { it.id } ?: 0) + 1
            val newTab = BrowserTab(id = newId, url = url)
            state.copy(tabs = state.tabs + newTab, activeTabIndex = state.tabs.size, urlBarText = if (url != "about:blank") url else "", showTabDrawer = false)
        }
    }

    fun switchToTab(index: Int) {
        _uiState.update { state ->
            state.copy(activeTabIndex = index.coerceIn(0, state.tabs.lastIndex), urlBarText = state.tabs.getOrNull(index)?.url ?: "", showTabDrawer = false)
        }
    }

    fun closeTab(index: Int) {
        _uiState.update { state ->
            val newTabs = state.tabs.toMutableList().apply { removeAt(index) }
            if (newTabs.isEmpty()) {
                state.copy(tabs = listOf(BrowserTab(id = 0)), activeTabIndex = 0, urlBarText = "")
            } else {
                val newIdx = (index - 1).coerceAtLeast(0)
                state.copy(tabs = newTabs, activeTabIndex = newIdx, urlBarText = newTabs[newIdx].url)
            }
        }
    }

    // ── History ───────────────────────────────────────────────────────
    private fun addToHistory(url: String, title: String) {
        if (url == "about:blank") return
        _uiState.update { state ->
            val updated = (listOf(HistoryEntry(url, title)) + state.history).distinctBy { it.url }.take(50)
            state.copy(history = updated)
        }
    }
    fun clearHistory() { _uiState.update { it.copy(history = emptyList()) } }

    // ── Bookmarks ─────────────────────────────────────────────────────
    fun addBookmark(url: String, title: String) {
        _uiState.update { state -> state.copy(bookmarks = state.bookmarks + BrowserBookmark(url, title)) }
    }
    fun removeBookmark(url: String) {
        _uiState.update { state -> state.copy(bookmarks = state.bookmarks.filter { it.url != url }) }
    }

    // ── UI toggles ────────────────────────────────────────────────────
    fun showTabDrawer()  { _uiState.update { it.copy(showTabDrawer = true) } }
    fun hideTabDrawer()  { _uiState.update { it.copy(showTabDrawer = false) } }
    fun showBookmarks()  { _uiState.update { it.copy(showBookmarks = true) } }
    fun hideBookmarks()  { _uiState.update { it.copy(showBookmarks = false) } }
    fun showHistory()    { _uiState.update { it.copy(showHistory = true) } }
    fun hideHistory()    { _uiState.update { it.copy(showHistory = false) } }
    fun toggleMenu()     { _uiState.update { it.copy(showMenu = !it.showMenu) } }
    fun hideMenu()       { _uiState.update { it.copy(showMenu = false) } }

    // ── Helpers ───────────────────────────────────────────────────────
    private fun updateActiveTab(transform: (BrowserTab) -> BrowserTab) {
        _uiState.update { state ->
            val tabs = state.tabs.toMutableList()
            val idx  = state.activeTabIndex
            if (idx in tabs.indices) tabs[idx] = transform(tabs[idx])
            state.copy(tabs = tabs)
        }
    }

    private fun resolveUrl(input: String): String {
        val t = input.trim()
        return when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(".") && !t.contains(" ") -> "https://$t"
            else -> "https://www.google.com/search?q=${t.replace(" ", "+")}"
        }
    }
}
