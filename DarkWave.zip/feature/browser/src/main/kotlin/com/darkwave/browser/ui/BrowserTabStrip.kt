package com.darkwave.browser.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.browser.viewmodel.BrowserTab
import com.darkwave.common.ui.theme.*

@Composable
fun BrowserTabStrip(
    tabs: List<BrowserTab>,
    activeTabIndex: Int,
    onTabClick: (Int) -> Unit,
    onTabClose: (Int) -> Unit,
    onNewTab: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(40.dp)
            .padding(start = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LazyRow(
            modifier      = Modifier.weight(1f),
            contentPadding = PaddingValues(end = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            itemsIndexed(tabs) { index, tab ->
                val isActive = index == activeTabIndex
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                        .background(if (isActive) Background else Color(0xFFF0F0F0))
                        .clickable { onTabClick(index) }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                        .widthIn(min = 80.dp, max = 160.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = tab.title.ifBlank { "New Tab" },
                        fontSize = 11.sp,
                        fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (isActive) TextPrimary else TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close tab",
                        tint = TextSecondary,
                        modifier = Modifier
                            .size(14.dp)
                            .clickable { onTabClose(index) }
                    )
                }
            }
        }

        // New Tab button
        IconButton(
            onClick  = onNewTab,
            modifier = Modifier.size(36.dp)
        ) {
            Icon(Icons.Default.Add, "New Tab", tint = TextSecondary, modifier = Modifier.size(18.dp))
        }
    }
}
