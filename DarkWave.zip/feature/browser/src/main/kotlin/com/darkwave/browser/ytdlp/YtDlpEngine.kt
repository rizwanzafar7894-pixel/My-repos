package com.darkwave.browser.ytdlp

import android.content.Context
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.mapper.VideoInfo
import com.darkwave.browser.model.DownloadFormat
import com.darkwave.browser.model.FormatType
import com.darkwave.browser.model.MediaFormats
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class YtDlpEngine @Inject constructor(
    @ApplicationContext private val context: Context
) {
    @Volatile private var isInitialized = false

    suspend fun initialize() = withContext(Dispatchers.IO) {
        if (isInitialized) return@withContext
        try {
            YoutubeDL.getInstance().init(context)
            isInitialized = true
            // Non-blocking update check in background
            try { YoutubeDL.getInstance().updateYoutubeDL(context, YoutubeDL.UpdateChannel.STABLE) }
            catch (_: Exception) {}
        } catch (_: Exception) { isInitialized = false }
    }

    /**
     * Fetch all downloadable formats for a URL.
     * Supports YouTube, Vimeo, Twitter/X, Instagram, TikTok, Facebook, Dailymotion, 1000+ sites.
     */
    suspend fun getFormats(url: String): MediaFormats? = withContext(Dispatchers.IO) {
        if (!isInitialized) initialize()
        if (!isInitialized) return@withContext null

        return@withContext try {
            val request = YoutubeDLRequest(url).apply {
                addOption("--no-playlist")
                addOption("--no-warnings")
                addOption("--socket-timeout", "30")
                addOption("--retries", "3")
                addOption("--user-agent",
                    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                )
            }
            val info: VideoInfo = YoutubeDL.getInstance().getInfo(request)

            val videoFormats = mutableListOf<DownloadFormat>()
            val audioFormats = mutableListOf<DownloadFormat>()

            info.formats?.forEach { fmt ->
                val fmtId    = fmt.formatId ?: return@forEach
                val hasVideo = fmt.vcodec?.lowercase()?.let { it != "none" && it.isNotBlank() } == true
                val hasAudio = fmt.acodec?.lowercase()?.let { it != "none" && it.isNotBlank() } == true

                when {
                    hasVideo && hasAudio -> videoFormats.add(DownloadFormat(
                        formatId   = fmtId,
                        label      = videoLabel(fmt.height),
                        ext        = fmt.ext ?: "mp4",
                        resolution = fmt.height?.let { "${fmt.width}x$it" },
                        heightPx   = fmt.height,
                        filesize   = fmt.filesize ?: fmt.filesizeApprox,
                        vcodec     = fmt.vcodec, acodec = fmt.acodec,
                        tbr        = fmt.tbr,
                        type       = FormatType.VIDEO_AUDIO
                    ))
                    hasVideo -> videoFormats.add(DownloadFormat(
                        formatId   = fmtId,
                        label      = "${videoLabel(fmt.height)} + best audio",
                        ext        = fmt.ext ?: "mp4",
                        resolution = fmt.height?.let { "${fmt.width}x$it" },
                        heightPx   = fmt.height,
                        filesize   = fmt.filesize ?: fmt.filesizeApprox,
                        vcodec     = fmt.vcodec, acodec = null,
                        tbr        = fmt.tbr,
                        type       = FormatType.VIDEO_ONLY
                    ))
                    hasAudio -> audioFormats.add(DownloadFormat(
                        formatId   = fmtId,
                        label      = audioLabel(fmt.ext, fmt.abr?.toInt(), fmt.acodec),
                        ext        = fmt.ext ?: "m4a",
                        resolution = null, heightPx = null,
                        filesize   = fmt.filesize ?: fmt.filesizeApprox,
                        vcodec     = null, acodec = fmt.acodec,
                        tbr        = fmt.abr,
                        type       = FormatType.AUDIO_ONLY
                    ))
                }
            }

            // Sort: highest quality first; deduplicate same resolution
            val videos = videoFormats
                .sortedWith(compareByDescending<DownloadFormat> { it.heightPx ?: 0 }
                    .thenByDescending { it.tbr ?: 0.0 })
                .distinctBy { "${it.heightPx}_${it.type}" }

            val audios = audioFormats
                .sortedByDescending { it.tbr ?: 0.0 }
                .distinctBy { "${it.ext}_${it.tbr?.toInt()}" }

            MediaFormats(
                pageUrl      = url,
                title        = info.title?.take(120) ?: url.substringAfterLast("/"),
                thumbnail    = info.thumbnail,
                duration     = info.duration?.toLong(),
                videoFormats = videos,
                audioFormats = audios
            )
        } catch (e: Exception) { null }
    }

    /**
     * Build a robust download request.
     * yt-dlp bundled inside youtubedl-android handles ffmpeg merging internally.
     */
    fun buildDownloadRequest(
        url: String,
        format: DownloadFormat,
        outputPath: String,
        @Suppress("UNUSED_PARAMETER") onProgress: (Float, Long, String) -> Unit
    ): YoutubeDLRequest = YoutubeDLRequest(url).apply {
        addOption("--no-playlist")
        addOption("--no-warnings")
        addOption("--retries", "5")
        addOption("--fragment-retries", "10")
        addOption("--socket-timeout", "30")
        addOption("--concurrent-fragments", "4")
        addOption("-o", "$outputPath/%(title).100B.%(ext)s")
        addOption("--user-agent",
            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        )
        when (format.type) {
            FormatType.VIDEO_AUDIO -> addOption("-f", format.formatId)
            FormatType.VIDEO_ONLY  -> {
                addOption("-f", "${format.formatId}+bestaudio[ext=m4a]/bestaudio")
                addOption("--merge-output-format", "mp4")
            }
            FormatType.AUDIO_ONLY  -> {
                addOption("-f", format.formatId)
                addOption("--extract-audio")
                addOption("--audio-format", when (format.ext) {
                    "opus", "vorbis", "webm" -> "mp3"
                    else -> format.ext
                })
                addOption("--audio-quality", "0")
                addOption("--embed-thumbnail")
                addOption("--add-metadata")
            }
        }
        // Download auto-subtitles alongside video if available
        if (format.type != FormatType.AUDIO_ONLY) {
            addOption("--write-auto-subs")
            addOption("--sub-langs", "en.*")
            addOption("--convert-subs", "srt")
        }
    }

    // ── Labels ─────────────────────────────────────────────────────────────
    private fun videoLabel(h: Int?): String = when {
        h == null  -> "Best Quality"
        h >= 4320  -> "8K (${h}p)"
        h >= 2160  -> "4K (${h}p)"
        h >= 1440  -> "2K (${h}p)"
        h >= 1080  -> "Full HD (${h}p)"
        h >= 720   -> "HD (${h}p)"
        else       -> "${h}p"
    }

    private fun audioLabel(ext: String?, abr: Int?, codec: String?): String {
        val f = ext?.uppercase() ?: "Audio"
        val q = when { abr == null -> "Best"; abr >= 320 -> "${abr}kbps (HQ)"; else -> "${abr}kbps" }
        val c = when {
            codec?.contains("opus",   ignoreCase = true) == true -> " · Opus"
            codec?.contains("aac",    ignoreCase = true) == true -> " · AAC"
            codec?.contains("mp3",    ignoreCase = true) == true -> " · MP3"
            codec?.contains("flac",   ignoreCase = true) == true -> " · FLAC"
            else -> ""
        }
        return "$f · $q$c"
    }
}
