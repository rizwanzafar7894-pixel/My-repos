package com.darkwave.browser.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import com.darkwave.browser.viewmodel.BrowserBookmark
import com.darkwave.browser.viewmodel.HistoryEntry
import com.darkwave.common.ui.theme.*

// ── Overflow popup menu ──────────────────────────────────────────────────
@Composable
fun BrowserMenu(
    isBookmarked: Boolean,
    onNewTab: () -> Unit,
    onBookmark: () -> Unit,
    onHistory: () -> Unit,
    onBookmarks: () -> Unit,
    onDismiss: () -> Unit
) {
    Popup(onDismissRequest = onDismiss) {
        Surface(
            shape  = RoundedCornerShape(12.dp),
            color  = White,
            shadowElevation = 8.dp,
            modifier = Modifier
                .padding(top = 56.dp, end = 12.dp)
                .width(200.dp)
        ) {
            Column(modifier = Modifier.padding(vertical = 6.dp)) {
                MenuRow(Icons.Default.AddCircleOutline, "New Tab",    onNewTab)
                MenuRow(
                    if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    if (isBookmarked) "Remove Bookmark" else "Bookmark Page",
                    onBookmark,
                    tint = if (isBookmarked) Purple500 else TextPrimary
                )
                MenuRow(Icons.Default.Bookmarks, "Bookmarks", onBookmarks)
                MenuRow(Icons.Default.History,   "History",   onHistory)
                Divider(color = DividerColor, modifier = Modifier.padding(vertical = 4.dp))
                MenuRow(Icons.Default.Share,     "Share",     {})
                MenuRow(Icons.Default.OpenInBrowser, "Open in Browser", {})
                MenuRow(Icons.Default.FindInPage,    "Find in Page",    {})
            }
        }
    }
}

@Composable
private fun MenuRow(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    tint: Color = TextPrimary
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(12.dp))
        Text(label, fontSize = 14.sp, color = tint)
    }
}

// ── Bookmarks bottom sheet ───────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookmarksSheet(
    bookmarks: List<BrowserBookmark>,
    onBookmarkClick: (BrowserBookmark) -> Unit,
    onRemove: (BrowserBookmark) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor   = White,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(modifier = Modifier.padding(bottom = 32.dp)) {
            Text(
                "Bookmarks",
                fontSize   = 18.sp,
                fontWeight = FontWeight.Bold,
                color      = TextPrimary,
                modifier   = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
            )
            if (bookmarks.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No bookmarks yet", color = TextSecondary)
                }
            } else {
                LazyColumn {
                    items(bookmarks) { bm ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onBookmarkClick(bm) }
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier.size(36.dp).clip(CircleShape).background(Purple100),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    (bm.title.firstOrNull() ?: "B").toString().uppercase(),
                                    fontWeight = FontWeight.Bold,
                                    color = Purple500,
                                    fontSize = 16.sp
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(bm.title, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(bm.url.removePrefix("https://"), fontSize = 11.sp, color = TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            IconButton(onClick = { onRemove(bm) }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Delete, "Remove", tint = TextSecondary, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

// ── History bottom sheet ─────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistorySheet(
    history: List<HistoryEntry>,
    onItemClick: (HistoryEntry) -> Unit,
    onClear: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor   = White,
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
    ) {
        Column(modifier = Modifier.padding(bottom = 32.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("History", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary, modifier = Modifier.weight(1f))
                if (history.isNotEmpty()) {
                    TextButton(onClick = onClear) {
                        Text("Clear All", color = Error, fontSize = 13.sp)
                    }
                }
            }
            if (history.isEmpty()) {
                Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                    Text("No history", color = TextSecondary)
                }
            } else {
                LazyColumn {
                    items(history) { entry ->
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable { onItemClick(entry) }.padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.History, null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(entry.title.ifBlank { entry.url }, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(entry.url.removePrefix("https://"), fontSize = 11.sp, color = TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }
}
