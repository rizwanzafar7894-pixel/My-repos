package com.darkwave.browser

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darkwave.browser.model.*
import com.darkwave.browser.ui.*
import com.darkwave.browser.viewmodel.BrowserViewModel
import com.darkwave.browser.viewmodel.FormatTab
import com.darkwave.browser.viewmodel.quickAccessSites
import com.darkwave.common.ui.theme.Background
import com.darkwave.common.ui.theme.White
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BrowserScreen(
    viewModel: BrowserViewModel = hiltViewModel()
) {
    val state     by viewModel.uiState.collectAsStateWithLifecycle()
    val downloads by viewModel.downloadTasks.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var webViewRef by remember { mutableStateOf<android.webkit.WebView?>(null) }

    // Back press: navigate WebView first
    BackHandler(enabled = state.activeTab.canGoBack) { webViewRef?.goBack() }

    // Snackbar
    LaunchedEffect(state.snackbarMessage) {
        state.snackbarMessage?.let { msg ->
            scope.launch { snackbarHostState.showSnackbar(msg); viewModel.onDismissSnackbar() }
        }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Background)
                .padding(paddingValues)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {

                // ── Tab strip ─────────────────────────────────────────────
                BrowserTabStrip(
                    tabs           = state.tabs,
                    activeTabIndex = state.activeTabIndex,
                    onTabClick     = viewModel::switchToTab,
                    onTabClose     = viewModel::closeTab,
                    onNewTab       = { viewModel.openNewTab() },
                    modifier       = Modifier.background(White)
                )

                // ── Address bar ───────────────────────────────────────────
                BrowserAddressBar(
                    url               = state.activeTab.url,
                    urlBarText        = state.urlBarText,
                    isEditing         = state.isEditingUrl,
                    isLoading         = state.activeTab.isLoading,
                    progress          = state.activeTab.progress,
                    canGoBack         = state.activeTab.canGoBack,
                    canGoForward      = state.activeTab.canGoForward,
                    onTextChanged     = viewModel::onUrlBarTextChanged,
                    onSubmit          = viewModel::onUrlBarSubmit,
                    onStartEditing    = viewModel::startEditingUrl,
                    onStopEditing     = viewModel::stopEditingUrl,
                    onGoBack          = { webViewRef?.goBack() },
                    onGoForward       = { webViewRef?.goForward() },
                    onRefresh         = { webViewRef?.reload() },
                    onMenuClick       = viewModel::toggleMenu,
                    modifier          = Modifier.background(White)
                )

                // ── WebView / New Tab ─────────────────────────────────────
                Box(modifier = Modifier.weight(1f)) {
                    if (state.activeTab.url == "about:blank" || state.activeTab.url.isBlank()) {
                        BrowserNewTabPage(
                            quickAccessSites = quickAccessSites,
                            history          = state.history,
                            onSiteClick      = viewModel::navigateTo,
                            onHistoryClick   = viewModel::navigateTo,
                            onClearHistory   = viewModel::clearHistory
                        )
                    } else {
                        BrowserWebView(
                            url               = state.activeTab.url,
                            onPageStarted     = viewModel::onPageStarted,
                            onPageFinished    = viewModel::onPageFinished,
                            onProgressChanged = viewModel::onProgressChanged,
                            onCanGoBack       = viewModel::onCanGoBack,
                            onCanGoForward    = viewModel::onCanGoForward,
                            onVideoDetected   = { url, title -> viewModel.onVideoDetected(url, title) },
                            onVideoStopped    = { viewModel.onVideoStopped() },
                            onWebViewCreated  = { webViewRef = it }
                        )
                    }

                    // ── Download FAB (bottom-right, when video detected) ──
                    val activeDownloads = downloads.count {
                        it.state == DownloadState.DOWNLOADING || it.state == DownloadState.MERGING
                    }
                    AnimatedVisibility(
                        visible  = state.showDownloadFab,
                        enter    = slideInHorizontally { it } + fadeIn(),
                        exit     = slideOutHorizontally { it } + fadeOut(),
                        modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.End,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Download queue badge button
                            if (downloads.isNotEmpty()) {
                                BadgedBox(
                                    badge = {
                                        if (activeDownloads > 0) Badge { Text("$activeDownloads") }
                                    }
                                ) {
                                    SmallFloatingActionButton(
                                        onClick = viewModel::onToggleDownloadDrawer,
                                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                                    ) {
                                        Icon(Icons.Outlined.List, contentDescription = "Downloads")
                                    }
                                }
                            }

                            // Main download FAB
                            FloatingActionButton(
                                onClick        = viewModel::onDownloadFabClicked,
                                containerColor = MaterialTheme.colorScheme.primary,
                                shape          = CircleShape
                            ) {
                                Icon(Icons.Outlined.Download, contentDescription = "Download video")
                            }
                        }
                    }

                    // ── Download drawer ───────────────────────────────────
                    AnimatedVisibility(
                        visible  = state.showDownloadDrawer,
                        enter    = slideInVertically { it } + fadeIn(),
                        exit     = slideOutVertically { it } + fadeOut(),
                        modifier = Modifier.align(Alignment.BottomCenter)
                    ) {
                        DownloadDrawer(
                            tasks     = downloads,
                            onCancel  = viewModel::cancelDownload,
                            onRemove  = viewModel::removeDownload,
                            onDismiss = viewModel::onToggleDownloadDrawer
                        )
                    }
                }
            }

            // ── Overflow menu ─────────────────────────────────────────────
            if (state.showMenu) {
                BrowserMenu(
                    isBookmarked = state.bookmarks.any { it.url == state.activeTab.url },
                    onNewTab     = { viewModel.openNewTab(); viewModel.hideMenu() },
                    onBookmark   = {
                        val tab = state.activeTab
                        if (state.bookmarks.any { it.url == tab.url }) viewModel.removeBookmark(tab.url)
                        else viewModel.addBookmark(tab.url, tab.title)
                        viewModel.hideMenu()
                    },
                    onHistory    = { viewModel.showHistory(); viewModel.hideMenu() },
                    onBookmarks  = { viewModel.showBookmarks(); viewModel.hideMenu() },
                    onDismiss    = viewModel::hideMenu
                )
            }

            if (state.showBookmarks) {
                BookmarksSheet(
                    bookmarks       = state.bookmarks,
                    onBookmarkClick = { bm -> viewModel.navigateTo(bm.url); viewModel.hideBookmarks() },
                    onRemove        = { bm -> viewModel.removeBookmark(bm.url) },
                    onDismiss       = viewModel::hideBookmarks
                )
            }

            if (state.showHistory) {
                HistorySheet(
                    history     = state.history,
                    onItemClick = { entry -> viewModel.navigateTo(entry.url); viewModel.hideHistory() },
                    onClear     = viewModel::clearHistory,
                    onDismiss   = viewModel::hideHistory
                )
            }
        }
    }

    // ── Format Bottom Sheet ───────────────────────────────────────────────
    if (state.showFormatSheet) {
        FormatBottomSheet(
            mediaFormats      = state.mediaFormats,
            isFetchingFormats = state.isFetchingFormats,
            fetchError        = state.fetchError,
            selectedTab       = state.selectedFormatTab,
            onTabSelect       = viewModel::onFormatTabSelected,
            onFormatClick     = viewModel::startDownload,
            onDismiss         = viewModel::onDismissFormatSheet
        )
    }
}

// ── Format Bottom Sheet ───────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormatBottomSheet(
    mediaFormats: MediaFormats?,
    isFetchingFormats: Boolean,
    fetchError: String?,
    selectedTab: FormatTab,
    onTabSelect: (FormatTab) -> Unit,
    onFormatClick: (DownloadFormat) -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 32.dp)
        ) {
            Text(
                text       = mediaFormats?.title ?: "Select Format to Download",
                style      = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                maxLines   = 2,
                overflow   = TextOverflow.Ellipsis,
                modifier   = Modifier.padding(bottom = 12.dp)
            )

            when {
                isFetchingFormats -> {
                    Column(
                        modifier            = Modifier.fillMaxWidth().padding(vertical = 40.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(16.dp))
                        Text("Fetching available formats…")
                    }
                }
                fetchError != null -> {
                    Column(
                        modifier            = Modifier.fillMaxWidth().padding(vertical = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Outlined.ErrorOutline, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(48.dp))
                        Spacer(Modifier.height(12.dp))
                        Text(fetchError, color = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.height(16.dp))
                        TextButton(onClick = onDismiss) { Text("Close") }
                    }
                }
                mediaFormats != null -> {
                    TabRow(selectedTabIndex = selectedTab.ordinal) {
                        Tab(selected = selectedTab == FormatTab.VIDEO, onClick = { onTabSelect(FormatTab.VIDEO) },
                            text = { Text("📹 Video (${mediaFormats.videoFormats.size})") })
                        Tab(selected = selectedTab == FormatTab.AUDIO, onClick = { onTabSelect(FormatTab.AUDIO) },
                            text = { Text("🎵 Audio (${mediaFormats.audioFormats.size})") })
                    }
                    Spacer(Modifier.height(8.dp))
                    val formats = if (selectedTab == FormatTab.VIDEO) mediaFormats.videoFormats else mediaFormats.audioFormats
                    if (formats.isEmpty()) {
                        Box(Modifier.fillMaxWidth().padding(32.dp), Alignment.Center) {
                            Text("No ${selectedTab.name.lowercase()} formats available")
                        }
                    } else {
                        LazyColumn(modifier = Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            items(formats) { fmt -> FormatRow(format = fmt, onClick = { onFormatClick(fmt) }) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FormatRow(format: DownloadFormat, onClick: () -> Unit) {
    val qualityColor = when {
        format.heightPx != null && format.heightPx >= 2160 -> Color(0xFFFFD700)
        format.heightPx != null && format.heightPx >= 1080 -> MaterialTheme.colorScheme.primary
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(qualityColor.copy(alpha = 0.15f)).padding(horizontal = 8.dp, vertical = 4.dp)) {
                Text(format.ext.uppercase(), color = qualityColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(format.label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val sub = listOfNotNull(format.resolution, format.filesizeLabel.takeIf { it.isNotEmpty() }).joinToString(" · ")
                if (sub.isNotEmpty()) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(if (format.type == FormatType.AUDIO_ONLY) Icons.Outlined.MusicNote else Icons.Outlined.VideoFile, null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Icon(Icons.Default.Download, "Download", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        }
    }
}

// ── Download Drawer ───────────────────────────────────────────────────────────
@Composable
fun DownloadDrawer(tasks: List<DownloadTask>, onCancel: (String) -> Unit, onRemove: (String) -> Unit, onDismiss: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().heightIn(max = 380.dp), shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp), elevation = CardDefaults.cardElevation(8.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Downloads", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, null) }
            }
            if (tasks.isEmpty()) {
                Box(Modifier.fillMaxWidth().padding(vertical = 24.dp), Alignment.Center) {
                    Text("No downloads yet", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(tasks) { task ->
                        DownloadTaskRow(task, onCancel = { onCancel(task.id) }, onRemove = { onRemove(task.id) })
                    }
                }
            }
        }
    }
}

@Composable
fun DownloadTaskRow(task: DownloadTask, onCancel: () -> Unit, onRemove: () -> Unit) {
    val stateColor = when (task.state) {
        DownloadState.COMPLETED -> Color(0xFF4CAF50)
        DownloadState.FAILED    -> MaterialTheme.colorScheme.error
        else                    -> MaterialTheme.colorScheme.primary
    }
    val stateLabel = when (task.state) {
        DownloadState.QUEUED          -> "Queued"
        DownloadState.FETCHING_FORMATS -> "Fetching…"
        DownloadState.DOWNLOADING     -> "${task.progressPercent.toInt()}%${if (task.speedLabel.isNotEmpty()) " · ${task.speedLabel}" else ""}"
        DownloadState.MERGING         -> "Merging…"
        DownloadState.COMPLETED       -> "Done ✓"
        DownloadState.FAILED          -> "Failed"
        DownloadState.CANCELLED       -> "Cancelled"
    }
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(task.title, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text("${task.format.label} · $stateLabel", style = MaterialTheme.typography.labelSmall, color = stateColor)
                if (task.etaLabel.isNotEmpty()) Text("ETA: ${task.etaLabel}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            when (task.state) {
                DownloadState.DOWNLOADING, DownloadState.MERGING, DownloadState.QUEUED ->
                    IconButton(onClick = onCancel) { Icon(Icons.Default.Cancel, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp)) }
                DownloadState.COMPLETED, DownloadState.FAILED, DownloadState.CANCELLED ->
                    IconButton(onClick = onRemove) { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp)) }
                else -> {}
            }
        }
        if (task.state == DownloadState.DOWNLOADING || task.state == DownloadState.MERGING) {
            LinearProgressIndicator(
                progress = { task.progressPercent / 100f },
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp).height(3.dp).clip(RoundedCornerShape(2.dp))
            )
        }
    }
}
