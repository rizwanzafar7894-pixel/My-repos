package com.darkwave.browser.ytdlp

import android.webkit.JavascriptInterface
import android.webkit.WebView

/**
 * Injected into every WebView page via addJavascriptInterface.
 * Detects when a <video> element starts playing and notifies the host.
 */
class VideoDetectionBridge(
    private val onVideoDetected: (url: String, title: String) -> Unit,
    private val onVideoStopped: () -> Unit
) {

    @JavascriptInterface
    fun onVideoPlaying(pageUrl: String, pageTitle: String) {
        onVideoDetected(pageUrl, pageTitle)
    }

    @JavascriptInterface
    fun onVideoPaused() {
        onVideoStopped()
    }

    companion object {
        const val BRIDGE_NAME = "DWDownload"

        /**
         * JavaScript to inject on every page load.
         * Monitors all <video> elements for play/pause events.
         */
        val DETECTION_JS = """
(function() {
    var _notified = false;
    var _observer = null;

    function attachListeners(video) {
        video.addEventListener('play', function() {
            if (!_notified) {
                _notified = true;
                try {
                    window.$BRIDGE_NAME.onVideoPlaying(
                        window.location.href,
                        document.title || ''
                    );
                } catch(e) {}
            }
        });
        video.addEventListener('pause', function() {
            // Only signal stopped if ALL videos are paused
            var allPaused = Array.from(document.querySelectorAll('video'))
                .every(function(v) { return v.paused || v.ended; });
            if (allPaused) {
                _notified = false;
                try { window.$BRIDGE_NAME.onVideoPaused(); } catch(e) {}
            }
        });
        video.addEventListener('ended', function() {
            _notified = false;
            try { window.$BRIDGE_NAME.onVideoPaused(); } catch(e) {}
        });
    }

    // Attach to existing videos
    document.querySelectorAll('video').forEach(attachListeners);

    // Watch for dynamically added videos (YouTube, Netflix, etc. load video async)
    _observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(m) {
            m.addedNodes.forEach(function(node) {
                if (node.nodeName === 'VIDEO') {
                    attachListeners(node);
                } else if (node.querySelectorAll) {
                    node.querySelectorAll('video').forEach(attachListeners);
                }
            });
        });
    });

    _observer.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true
    });
})();
""".trimIndent()

        fun inject(webView: WebView) {
            webView.evaluateJavascript(DETECTION_JS, null)
        }
    }
}
