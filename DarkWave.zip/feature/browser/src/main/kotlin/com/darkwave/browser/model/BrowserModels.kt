package com.darkwave.browser.model

/**
 * All available video and audio formats for a given page URL.
 */
data class MediaFormats(
    val pageUrl: String,
    val title: String,
    val thumbnail: String?,
    val duration: Long?,          // seconds
    val videoFormats: List<DownloadFormat>,
    val audioFormats: List<DownloadFormat>
) {
    val hasVideo: Boolean get() = videoFormats.isNotEmpty()
    val hasAudio: Boolean get() = audioFormats.isNotEmpty()
    val hasAny:   Boolean get() = hasVideo || hasAudio
}

/**
 * A single downloadable stream (video, audio, or combined).
 */
data class DownloadFormat(
    val formatId: String,
    val label: String,            // e.g. "Full HD (1080p)", "MP3 · 320kbps · HQ"
    val ext: String,              // mp4, webm, m4a, mp3, opus …
    val resolution: String?,      // "1920x1080" or null for audio
    val heightPx: Int?,           // for sorting
    val filesize: Long?,          // bytes, may be null
    val vcodec: String?,
    val acodec: String?,
    val tbr: Double?,             // total bitrate (video) or audio bitrate
    val type: FormatType
) {
    val filesizeLabel: String get() = when {
        filesize == null       -> ""
        filesize >= 1_073_741_824 -> "%.1f GB".format(filesize / 1_073_741_824.0)
        filesize >= 1_048_576  -> "%.1f MB".format(filesize / 1_048_576.0)
        filesize >= 1_024      -> "%.0f KB".format(filesize / 1_024.0)
        else                   -> "$filesize B"
    }
}

enum class FormatType {
    VIDEO_AUDIO,   // combined stream (e.g. YouTube 360p/480p)
    VIDEO_ONLY,    // high-res video — yt-dlp will merge best audio
    AUDIO_ONLY     // audio-only extract
}

/**
 * State of an active or completed download.
 */
data class DownloadTask(
    val id: String,                // UUID
    val url: String,
    val title: String,
    val format: DownloadFormat,
    val outputPath: String,
    val state: DownloadState = DownloadState.QUEUED,
    val progressPercent: Float = 0f,
    val speedLabel: String = "",
    val etaLabel: String = "",
    val errorMessage: String? = null,
    val completedFilePath: String? = null
)

enum class DownloadState {
    QUEUED,
    FETCHING_FORMATS,
    DOWNLOADING,
    MERGING,
    COMPLETED,
    FAILED,
    CANCELLED
}

/**
 * Signals the BrowserViewModel that a video is detected on the current page.
 */
data class VideoDetectedEvent(
    val pageUrl: String,
    val pageTitle: String
)
