package com.darkwave.browser.ui

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.darkwave.browser.ytdlp.VideoDetectionBridge

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserWebView(
    url: String,
    onPageStarted: (String) -> Unit,
    onPageFinished: (String, String) -> Unit,
    onProgressChanged: (Int) -> Unit,
    onCanGoBack: (Boolean) -> Unit,
    onCanGoForward: (Boolean) -> Unit,
    // New: video detection callbacks
    onVideoDetected: (pageUrl: String, pageTitle: String) -> Unit = { _, _ -> },
    onVideoStopped: () -> Unit = {},
    onWebViewCreated: (WebView) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    AndroidView(
        factory = { context ->
            WebView(context).apply {
                settings.apply {
                    javaScriptEnabled                = true
                    domStorageEnabled                = true
                    loadWithOverviewMode             = true
                    useWideViewPort                  = true
                    setSupportZoom(true)
                    builtInZoomControls              = true
                    displayZoomControls              = false
                    allowFileAccess                  = false
                    allowContentAccess               = false
                    mediaPlaybackRequiresUserGesture = false
                    // Better UA for site compatibility
                    userAgentString = "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }

                // JS Bridge for video detection
                val bridge = VideoDetectionBridge(
                    onVideoDetected = onVideoDetected,
                    onVideoStopped  = onVideoStopped
                )
                addJavascriptInterface(bridge, VideoDetectionBridge.BRIDGE_NAME)

                webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                        super.onPageStarted(view, url, favicon)
                        onPageStarted(url)
                        onCanGoBack(view.canGoBack())
                        onCanGoForward(view.canGoForward())
                    }

                    override fun onPageFinished(view: WebView, url: String) {
                        super.onPageFinished(view, url)
                        // Inject video detection JS on every page load
                        VideoDetectionBridge.inject(view)
                        onPageFinished(url, view.title ?: url)
                        onCanGoBack(view.canGoBack())
                        onCanGoForward(view.canGoForward())
                    }

                    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                        val scheme = request.url.scheme ?: ""
                        return scheme !in listOf("http", "https", "data", "blob")
                    }
                }

                webChromeClient = object : WebChromeClient() {
                    override fun onProgressChanged(view: WebView, newProgress: Int) {
                        onProgressChanged(newProgress)
                    }
                }

                webViewRef = this
                onWebViewCreated(this)
                loadUrl(url)
            }
        },
        update = { view ->
            if (view.url != url && url != "about:blank") {
                view.loadUrl(url)
            }
        },
        modifier = modifier
    )

    DisposableEffect(Unit) {
        onDispose { webViewRef?.destroy() }
    }
}
