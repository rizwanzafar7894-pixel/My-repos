package com.darkwave.browser.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.browser.viewmodel.HistoryEntry
import com.darkwave.common.ui.theme.*

// Favicon letter colors for Quick Access grid
private val siteColors = listOf(
    Color(0xFFFF0000), // YouTube
    Color(0xFF4285F4), // Google
    Color(0xFFFF4500), // Reddit
    Color(0xFF24292E), // GitHub
    Color(0xFF000000), // X
    Color(0xFFE91E63), // Instagram
    Color(0xFF636363), // Wikipedia
    Color(0xFFE50914)  // Netflix
)

@Composable
fun BrowserNewTabPage(
    quickAccessSites: List<Triple<String, String, String>>,
    history: List<HistoryEntry>,
    onSiteClick: (String) -> Unit,
    onHistoryClick: (String) -> Unit,
    onClearHistory: () -> Unit
) {
    LazyColumn(
        modifier       = Modifier.fillMaxSize().background(Background),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Search bar hint at top of new tab
        item {
            Spacer(Modifier.height(24.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(50))
                    .background(White)
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Search, null, tint = TextSecondary, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Text("Search or enter URL", fontSize = 15.sp, color = TextTertiary)
            }
            Spacer(Modifier.height(24.dp))
        }

        // Quick Access heading
        item {
            Text(
                "Quick Access",
                fontSize   = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color      = TextPrimary,
                modifier   = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
            Spacer(Modifier.height(8.dp))
        }

        // Quick Access grid (4 columns × 2 rows)
        item {
            LazyVerticalGrid(
                columns            = GridCells.Fixed(4),
                userScrollEnabled  = false,
                modifier           = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 220.dp)
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement   = Arrangement.spacedBy(12.dp)
            ) {
                items(quickAccessSites) { (name, url, letter) ->
                    val colorIndex = quickAccessSites.indexOfFirst { it.first == name }.coerceIn(0, siteColors.lastIndex)
                    QuickAccessTile(
                        name    = name,
                        letter  = letter,
                        color   = siteColors[colorIndex],
                        onClick = { onSiteClick(url) }
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }

        // Recent history heading
        if (history.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Recent",
                        fontSize   = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        color      = TextPrimary,
                        modifier   = Modifier.weight(1f)
                    )
                    TextButton(onClick = onClearHistory) {
                        Text("Clear All", fontSize = 13.sp, color = TextSecondary)
                    }
                }
            }

            items(history.take(8)) { entry ->
                HistoryRow(
                    title   = entry.title,
                    url     = entry.url,
                    onClick = { onHistoryClick(entry.url) }
                )
            }
        }
    }
}

@Composable
private fun QuickAccessTile(
    name: String,
    letter: String,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        modifier            = Modifier.clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(color),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text       = letter,
                fontSize   = 20.sp,
                fontWeight = FontWeight.Bold,
                color      = Color.White,
                textAlign  = TextAlign.Center
            )
        }
        Spacer(Modifier.height(5.dp))
        Text(
            text     = name,
            fontSize = 11.sp,
            color    = TextSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun HistoryRow(
    title: String,
    url: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(SurfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.History, null, tint = TextSecondary, modifier = Modifier.size(18.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text     = title.ifBlank { url },
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color    = TextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text     = url.removePrefix("https://").removePrefix("http://"),
                fontSize = 11.sp,
                color    = TextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Icon(Icons.Default.NorthWest, "Open", tint = TextTertiary, modifier = Modifier.size(16.dp))
    }
}
