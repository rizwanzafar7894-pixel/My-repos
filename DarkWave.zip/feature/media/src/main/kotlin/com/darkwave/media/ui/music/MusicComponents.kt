package com.darkwave.media.ui.music

import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.darkwave.common.util.toFormattedDuration
import com.darkwave.common.util.toHoursMinutes
import com.darkwave.domain.model.AudioItem
import com.darkwave.common.ui.theme.*

@Composable
fun MusicDiscoverWeeklyBanner(
    songCount: Int,
    totalDurationMs: Long,
    onPlay: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(DiscoverCardStart, DiscoverCardEnd)))
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = White.copy(alpha = 0.7f)
                ) {
                    Text(
                        "DISCOVER WEEKLY",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Purple600,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Your personalized mix · Updated every Monday",
                    fontSize = 12.sp,
                    color = TextSecondary
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("$songCount", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Purple500)
                    Spacer(Modifier.width(4.dp))
                    Text(
                        if (totalDurationMs > 0) "songs · ${totalDurationMs.toHoursMinutes()}" else "songs",
                        fontSize = 12.sp, color = TextSecondary,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                }
            }
            IconButton(
                onClick  = onPlay,
                modifier = Modifier.size(48.dp).clip(CircleShape).background(Purple500)
            ) {
                Icon(Icons.Default.PlayArrow, null, tint = White, modifier = Modifier.size(26.dp))
            }
        }
    }
}

@Composable
fun MusicSectionHeader(title: String, action: String = "", onAction: () -> Unit = {}, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary, modifier = Modifier.weight(1f))
        if (action.isNotBlank()) {
            TextButton(onClick = onAction) {
                Text(action, fontSize = 13.sp, color = Purple500, fontWeight = FontWeight.Medium)
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MusicSongRow(
    song: AudioItem,
    index: Int,
    onClick: () -> Unit,
    onMore: () -> Unit,
    onLongClick: () -> Unit = {},
    isSelected: Boolean = false,
    isSelectionMode: Boolean = false,
    modifier: Modifier = Modifier
) {
    val bgColor = if (isSelected) Purple100 else androidx.compose.ui.graphics.Color.Transparent
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(bgColor, androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(vertical = 7.dp, horizontal = if (isSelected) 6.dp else 0.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Index number OR checkbox
        AnimatedContent(targetState = isSelectionMode, label = "indexOrCheck") { inSelect ->
            if (inSelect) {
                Box(modifier = Modifier.size(22.dp), contentAlignment = Alignment.Center) {
                    if (isSelected) {
                        Icon(Icons.Default.CheckCircle, null, tint = Purple500, modifier = Modifier.size(22.dp))
                    } else {
                        Icon(Icons.Default.RadioButtonUnchecked, null, tint = TextTertiary, modifier = Modifier.size(20.dp))
                    }
                }
            } else {
                Text(index.toString(), fontSize = 13.sp, color = TextTertiary, modifier = Modifier.width(22.dp))
            }
        }
        Spacer(Modifier.width(8.dp))
        Box(modifier = Modifier.size(48.dp).clip(RoundedCornerShape(8.dp)).background(Purple100)) {
            if (song.albumArtUri.isNotBlank()) {
                AsyncImage(model = song.albumArtUri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
            // Selection overlay
            AnimatedVisibility(visible = isSelected, enter = fadeIn(), exit = fadeOut()) {
                Box(modifier = Modifier.fillMaxSize().background(Purple500.copy(alpha = 0.25f)))
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(song.title, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = if (isSelected) Purple700 else TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(song.artist, fontSize = 11.sp, color = TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Text(song.duration.toFormattedDuration(), fontSize = 12.sp, color = TextSecondary)
        Spacer(Modifier.width(4.dp))
        AnimatedVisibility(visible = !isSelectionMode) {
            IconButton(onClick = onMore, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.MoreVert, null, tint = TextSecondary, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
fun MusicCuratedCard(name: String, coverUri: String, songCount: Int, onClick: () -> Unit) {
    Column(modifier = Modifier.width(130.dp).clickable(onClick = onClick)) {
        Box(modifier = Modifier.fillMaxWidth().height(90.dp).clip(RoundedCornerShape(12.dp)).background(Purple100)) {
            if (coverUri.isNotBlank()) {
                AsyncImage(model = coverUri, contentDescription = name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("$songCount songs", fontSize = 10.sp, color = TextSecondary)
    }
}

@Composable
fun MusicAlbumCard(song: AudioItem, onClick: () -> Unit) {
    Column(modifier = Modifier.width(100.dp).clickable(onClick = onClick)) {
        Box(modifier = Modifier.fillMaxWidth().height(100.dp).clip(RoundedCornerShape(10.dp)).background(Purple100)) {
            if (song.albumArtUri.isNotBlank()) {
                AsyncImage(model = song.albumArtUri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
        }
        Spacer(Modifier.height(5.dp))
        Text(song.title, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(song.artist, fontSize = 10.sp, color = TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
fun MusicForYouCard(song: AudioItem?, onClick: () -> Unit, modifier: Modifier = Modifier) {
    if (song == null) return
    Card(modifier = modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = White), elevation = CardDefaults.cardElevation(2.dp)) {
        Row(modifier = Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(modifier = Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)).background(Purple100)) {
                if (song.albumArtUri.isNotBlank()) AsyncImage(model = song.albumArtUri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Explore the Best", fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text("The original slow instrumental best playlists", fontSize = 11.sp, color = TextSecondary, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = onClick, modifier = Modifier.size(34.dp).clip(CircleShape).background(Purple100)) {
                Icon(Icons.Default.PlayArrow, null, tint = Purple500, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun MusicPlaylistRow(name: String, songCount: Int, coverUri: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Row(modifier = modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(modifier = Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)).background(Purple100), contentAlignment = Alignment.Center) {
            if (coverUri.isNotBlank()) AsyncImage(model = coverUri, contentDescription = null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            else Icon(Icons.Default.QueueMusic, null, tint = Purple500, modifier = Modifier.size(24.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(name, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
            Text("$songCount songs", fontSize = 12.sp, color = TextSecondary)
        }
        Icon(Icons.Default.ChevronRight, null, tint = TextSecondary, modifier = Modifier.size(20.dp))
    }
}
