package com.darkwave.media.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.theme.*

/**
 * Animated top bar that replaces the normal top bar during selection mode.
 * Shows: ✕ | N selected | Select All | Delete | Share | Rename | Hide | Copy
 */
@Composable
fun MultiSelectActionBar(
    selectedCount: Int,
    totalCount: Int,
    onClose: () -> Unit,
    onSelectAll: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit,
    onRename: () -> Unit,       // only active when selectedCount == 1
    onHide: () -> Unit,
    onCopyPath: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier   = modifier.fillMaxWidth(),
        color      = Purple700,
        shadowElevation = 4.dp
    ) {
        Column {
            // ── Top row: close + count + select-all ─────────────────────
            Row(
                modifier            = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment   = Alignment.CenterVertically
            ) {
                IconButton(onClick = onClose) {
                    Icon(Icons.Default.Close, contentDescription = "Cancel selection", tint = Color.White)
                }
                Text(
                    text       = "$selectedCount selected",
                    color      = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize   = 16.sp,
                    modifier   = Modifier.weight(1f)
                )
                TextButton(onClick = onSelectAll) {
                    Text(
                        if (selectedCount == totalCount) "Deselect All" else "Select All",
                        color    = Color.White.copy(alpha = 0.9f),
                        fontSize = 13.sp
                    )
                }
            }

            // ── Action icons row ─────────────────────────────────────────
            Row(
                modifier              = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                SelectionActionBtn(Icons.Default.Delete, "Delete", Color(0xFFFF5252), enabled = selectedCount > 0, onClick = onDelete)
                SelectionActionBtn(Icons.Default.Share,  "Share",  Color.White, enabled = selectedCount > 0, onClick = onShare)
                SelectionActionBtn(
                    icon    = Icons.Default.DriveFileRenameOutline,
                    label   = "Rename",
                    tint    = if (selectedCount == 1) Color.White else Color.White.copy(alpha = 0.35f),
                    enabled = selectedCount == 1,
                    onClick = onRename
                )
                SelectionActionBtn(Icons.Default.VisibilityOff, "Hide",      Color.White, enabled = selectedCount > 0, onClick = onHide)
                SelectionActionBtn(Icons.Default.ContentCopy,   "Copy Path", Color.White, enabled = selectedCount > 0, onClick = onCopyPath)
            }
        }
    }
}

@Composable
private fun SelectionActionBtn(
    icon: ImageVector,
    label: String,
    tint: Color,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(bottom = 4.dp)
    ) {
        IconButton(onClick = onClick, enabled = enabled, modifier = Modifier.size(40.dp)) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(22.dp))
        }
        Text(label, fontSize = 10.sp, color = tint, maxLines = 1)
    }
}

// ── Bulk delete confirm dialog ────────────────────────────────────────────────
@Composable
fun BulkDeleteDialog(
    count: Int,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon  = { Icon(Icons.Default.DeleteForever, null, tint = Color(0xFFFF5252)) },
        title = { Text("Delete $count file(s)?") },
        text  = { Text("This will permanently delete $count file(s) from your device. This cannot be undone.") },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors  = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252))
            ) { Text("Delete", color = Color.White) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
