package com.darkwave.media

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darkwave.common.ui.components.*
import com.darkwave.common.ui.theme.*
import com.darkwave.media.ui.BulkDeleteDialog
import com.darkwave.media.ui.MultiSelectActionBar
import com.darkwave.media.ui.video.RenameDialog
import com.darkwave.media.viewmodel.MusicViewModel
import com.darkwave.media.viewmodel.musicTabLabels
import com.darkwave.media.ui.music.*
import kotlinx.coroutines.launch

@Composable
fun MusicScreen(
    onAudioClick: () -> Unit,
    onNowPlayingClick: () -> Unit,
    viewModel: MusicViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    // Back press exits selection mode first
    BackHandler(enabled = state.isSelectionMode) { viewModel.clearSelection() }

    // Snackbar
    LaunchedEffect(state.snackbarMessage) {
        state.snackbarMessage?.let { msg ->
            scope.launch { snackbarHostState.showSnackbar(msg) }
            viewModel.onDismissSnackbar()
        }
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { paddingValues ->
        Column(modifier = Modifier.fillMaxSize().background(Background).padding(paddingValues)) {

            // ── Animated header: tabs OR multi-select bar ────────────────
            AnimatedContent(
                targetState = state.isSelectionMode,
                transitionSpec = { slideInVertically { -it } + fadeIn() togetherWith slideOutVertically { -it } + fadeOut() },
                label = "musicSelectionBar"
            ) { inSelectionMode ->
                if (inSelectionMode) {
                    MultiSelectActionBar(
                        selectedCount = state.selectedCount,
                        totalCount    = when (state.selectedTabIndex) {
                            2 -> state.likedSongs.size
                            4 -> state.downloadedSongs.size
                            else -> state.allSongs.size
                        },
                        onClose       = viewModel::clearSelection,
                        onSelectAll   = viewModel::selectAll,
                        onDelete      = viewModel::showBulkDeleteDialog,
                        onShare       = viewModel::bulkShare,
                        onRename      = { viewModel.showRenameDialog() },
                        onHide        = viewModel::bulkHide,
                        onCopyPath    = viewModel::bulkCopyPath
                    )
                } else {
                    ScrollableTabRow(
                        selectedTabIndex = state.selectedTabIndex,
                        edgePadding      = 16.dp,
                        containerColor   = White,
                        contentColor     = Purple500,
                        indicator        = { tabPositions ->
                            if (state.selectedTabIndex < tabPositions.size) {
                                TabRowDefaults.SecondaryIndicator(
                                    modifier = Modifier.tabIndicatorOffset(tabPositions[state.selectedTabIndex]),
                                    color    = Purple500
                                )
                            }
                        },
                        divider = {}
                    ) {
                        musicTabLabels.forEachIndexed { index, label ->
                            Tab(
                                selected = state.selectedTabIndex == index,
                                onClick  = { viewModel.onTabSelected(index) },
                                text = {
                                    Text(
                                        text  = label,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (state.selectedTabIndex == index) Purple500 else TextSecondary
                                    )
                                }
                            )
                        }
                    }
                }
            }

            // ── Tab content ───────────────────────────────────────────────
            if (state.isLoading) {
                LoadingIndicator()
            } else {
                when (state.selectedTabIndex) {
                    0 -> MusicAllSongsTab(state, onAudioClick, viewModel)
                    1 -> MusicLibraryTab(state, onAudioClick, viewModel)
                    2 -> MusicLikedTab(state, onAudioClick, viewModel)
                    3 -> MusicPlaylistsTab(state, onAudioClick)
                    4 -> MusicDownloadsTab(state, onAudioClick)
                    5 -> MusicArtistsTab(state)
                    6 -> MusicAlbumsTab(state)
                    7 -> MusicGenresTab(state)
                }
            }
        }
    }

    // ── Dialogs ───────────────────────────────────────────────────────────────

    // Bulk delete
    if (state.showBulkDeleteDialog) {
        BulkDeleteDialog(count = state.selectedCount, onConfirm = viewModel::bulkDelete, onDismiss = viewModel::hideBulkDeleteDialog)
    }

    // Rename (single selected song)
    if (state.showRenameDialog) {
        val currentName = state.allSongs.firstOrNull { it.id == state.selectedIds.firstOrNull() }?.title ?: ""
        RenameDialog(currentName = currentName, onConfirm = viewModel::renameSelected, onDismiss = viewModel::hideRenameDialog)
    }

    // Create Playlist dialog
    if (state.showCreatePlaylist) {
        var newPlaylistName by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = viewModel::dismissCreatePlaylistDialog,
            title   = { Text("New Playlist") },
            text    = {
                OutlinedTextField(
                    value         = newPlaylistName,
                    onValueChange = { newPlaylistName = it },
                    label         = { Text("Playlist name") },
                    singleLine    = true
                )
            },
            confirmButton = {
                TextButton(onClick = { viewModel.createPlaylist(newPlaylistName) }, enabled = newPlaylistName.isNotBlank()) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = viewModel::dismissCreatePlaylistDialog) { Text("Cancel") } }
        )
    }
}
