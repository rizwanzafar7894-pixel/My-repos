package com.darkwave.media.ui.music

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.darkwave.common.ui.components.EmptyState
import com.darkwave.common.util.toFormattedDuration
import com.darkwave.domain.model.AudioItem
import com.darkwave.common.ui.theme.*
import com.darkwave.media.viewmodel.MusicUiState
import com.darkwave.media.viewmodel.MusicViewModel

// ── Tab 0: All Songs ─────────────────────────────────────────────────────
@Composable
fun MusicAllSongsTab(
    state: MusicUiState,
    onAudioClick: () -> Unit,
    viewModel: MusicViewModel
) {
    LazyColumn(
        contentPadding = PaddingValues(bottom = 16.dp),
        modifier       = Modifier.fillMaxSize()
    ) {
        // Discover Weekly banner
        item {
            MusicDiscoverWeeklyBanner(
                songCount      = state.discoverWeeklySongs.size,
                totalDurationMs = state.discoverWeeklySongs.sumOf { it.duration },
                onPlay         = onAudioClick,
                modifier       = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
            )
        }

        // Curated & Trending
        if (state.curatedPlaylists.isNotEmpty()) {
            item {
                MusicSectionHeader("Curated & Trending", "See All")
            }
            item {
                LazyRow(
                    contentPadding        = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier              = Modifier.padding(bottom = 16.dp)
                ) {
                    items(state.curatedPlaylists.take(6)) { playlist ->
                        MusicCuratedCard(
                            name       = playlist.name,
                            coverUri   = playlist.coverArtUri,
                            songCount  = playlist.songs.size,
                            onClick    = onAudioClick
                        )
                    }
                }
            }
        }

        // For You
        if (state.forYouSongs.isNotEmpty()) {
            item { MusicSectionHeader("For You", "See All") }
            item {
                MusicForYouCard(
                    song    = state.forYouSongs.firstOrNull(),
                    onClick = onAudioClick,
                    modifier = Modifier
                        .padding(horizontal = 16.dp)
                        .padding(bottom = 16.dp)
                )
            }
        }

        // Recommended
        if (state.recommendedSongs.isNotEmpty()) {
            item { MusicSectionHeader("Recommended", "Show All") }
            itemsIndexed(state.recommendedSongs.take(5)) { index, song ->
                MusicSongRow(
                    song    = song,
                    index   = index + 1,
                    onClick = onAudioClick,
                    onMore  = { viewModel.showContextMenu(song) },
                    modifier = Modifier.padding(horizontal = 16.dp)
                )
            }
        }

        // All Songs grid
        if (state.allSongs.isNotEmpty()) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("All Songs", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary, modifier = Modifier.weight(1f))
                    TextButton(onClick = { viewModel.showCreatePlaylistDialog() }) {
                        Icon(Icons.Default.Add, null, tint = Purple500, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Playlist", color = Purple500, fontSize = 13.sp)
                    }
                }
            }
            item {
                LazyRow(
                    contentPadding        = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier              = Modifier.padding(bottom = 16.dp)
                ) {
                    items(state.allSongs.take(10)) { song ->
                        MusicAlbumCard(song = song, onClick = onAudioClick)
                    }
                }
            }
        }
    }
}

// ── Tab 1: My Library ────────────────────────────────────────────────────
@Composable
fun MusicLibraryTab(state: MusicUiState, onAudioClick: () -> Unit, viewModel: MusicViewModel) {
    if (state.allSongs.isEmpty()) {
        EmptyState(Icons.Default.LibraryMusic, "No Library", "Add songs to your library", modifier = Modifier.fillMaxSize())
        return
    }
    LazyColumn(contentPadding = PaddingValues(vertical = 8.dp), modifier = Modifier.fillMaxSize()) {
        itemsIndexed(state.allSongs) { index, song ->
            val isSelected = song.id in state.selectedIds
            MusicSongRow(
                song            = song,
                index           = index + 1,
                onClick         = { if (state.isSelectionMode) viewModel.onItemSelectToggle(song) else onAudioClick() },
                onMore          = { viewModel.showContextMenu(song) },
                onLongClick     = { viewModel.onItemLongPress(song) },
                isSelected      = isSelected,
                isSelectionMode = state.isSelectionMode,
                modifier        = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}

// ── Tab 2: Liked Songs ───────────────────────────────────────────────────
@Composable
fun MusicLikedTab(state: MusicUiState, onAudioClick: () -> Unit, viewModel: MusicViewModel) {
    if (state.likedSongs.isEmpty()) {
        EmptyState(Icons.Default.FavoriteBorder, "No Liked Songs", "Like songs to see them here", modifier = Modifier.fillMaxSize())
        return
    }
    LazyColumn(contentPadding = PaddingValues(vertical = 8.dp), modifier = Modifier.fillMaxSize()) {
        itemsIndexed(state.likedSongs) { index, song ->
            val isSelected = song.id in state.selectedIds
            MusicSongRow(
                song            = song,
                index           = index + 1,
                onClick         = { if (state.isSelectionMode) viewModel.onItemSelectToggle(song) else onAudioClick() },
                onMore          = { viewModel.showContextMenu(song) },
                onLongClick     = { viewModel.onItemLongPress(song) },
                isSelected      = isSelected,
                isSelectionMode = state.isSelectionMode,
                modifier        = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}

// ── Tab 3: Playlists ─────────────────────────────────────────────────────
@Composable
fun MusicPlaylistsTab(state: MusicUiState, onAudioClick: () -> Unit) {
    if (state.playlists.isEmpty()) {
        EmptyState(Icons.Default.QueueMusic, "No Playlists", "Create your first playlist", modifier = Modifier.fillMaxSize())
        return
    }
    LazyColumn(contentPadding = PaddingValues(vertical = 8.dp), modifier = Modifier.fillMaxSize()) {
        items(state.playlists) { playlist ->
            MusicPlaylistRow(
                name        = playlist.name,
                songCount   = playlist.songCount,
                coverUri    = playlist.coverArtUri,
                onClick     = onAudioClick,
                modifier    = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }
    }
}

// ── Tab 4: Downloads ─────────────────────────────────────────────────────
@Composable
fun MusicDownloadsTab(state: MusicUiState, onAudioClick: () -> Unit) {
    if (state.downloadedSongs.isEmpty()) {
        EmptyState(Icons.Default.FileDownload, "No Downloads", "Downloaded songs will appear here", modifier = Modifier.fillMaxSize())
        return
    }
    LazyColumn(contentPadding = PaddingValues(vertical = 8.dp), modifier = Modifier.fillMaxSize()) {
        itemsIndexed(state.downloadedSongs) { index, song ->
            MusicSongRow(song, index + 1, onAudioClick, {}, modifier = Modifier.padding(horizontal = 16.dp))
        }
    }
}

// ── Tab 5: Artists ────────────────────────────────────────────────────────
@Composable
fun MusicArtistsTab(state: MusicUiState) {
    if (state.artists.isEmpty()) {
        EmptyState(Icons.Default.Person, "No Artists", "Artists will appear after scan", modifier = Modifier.fillMaxSize())
        return
    }
    LazyColumn(contentPadding = PaddingValues(vertical = 8.dp), modifier = Modifier.fillMaxSize()) {
        items(state.artists) { artist ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {}
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(44.dp).clip(RoundedCornerShape(50)).background(Purple100), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Person, null, tint = Purple500, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.width(12.dp))
                Text(artist, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
            }
        }
    }
}

// ── Tab 6: Albums ─────────────────────────────────────────────────────────
@Composable
fun MusicAlbumsTab(state: MusicUiState) {
    if (state.albums.isEmpty()) {
        EmptyState(Icons.Default.Album, "No Albums", "Albums will appear after scan", modifier = Modifier.fillMaxSize())
        return
    }
    LazyColumn(contentPadding = PaddingValues(vertical = 8.dp), modifier = Modifier.fillMaxSize()) {
        items(state.albums) { album ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {}
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(modifier = Modifier.size(44.dp).clip(RoundedCornerShape(8.dp)).background(Purple100), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Album, null, tint = Purple500, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.width(12.dp))
                Text(album, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
            }
        }
    }
}

// ── Tab 7: Genres ─────────────────────────────────────────────────────────
@Composable
fun MusicGenresTab(state: MusicUiState) {
    if (state.genres.isEmpty()) {
        EmptyState(Icons.Default.Audiotrack, "No Genres", "Genre data will appear after scan", modifier = Modifier.fillMaxSize())
        return
    }
    LazyColumn(contentPadding = PaddingValues(vertical = 8.dp), modifier = Modifier.fillMaxSize()) {
        items(state.genres) { genre ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {}
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.MusicNote, null, tint = Purple500, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(12.dp))
                Text(genre, fontSize = 14.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
            }
            Divider(modifier = Modifier.padding(horizontal = 16.dp), color = DividerColor)
        }
    }
}
