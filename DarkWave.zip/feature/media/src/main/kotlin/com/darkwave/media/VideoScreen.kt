package com.darkwave.media

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darkwave.common.ui.components.*
import com.darkwave.common.ui.theme.*
import com.darkwave.media.ui.MultiSelectActionBar
import com.darkwave.media.ui.BulkDeleteDialog
import com.darkwave.media.ui.video.RenameDialog
import com.darkwave.media.ui.video.DeleteConfirmDialog
import com.darkwave.media.ui.video.*
import com.darkwave.media.viewmodel.VideoViewModel
import com.darkwave.media.viewmodel.videoFilterLabels
import kotlinx.coroutines.launch

@Composable
fun VideoScreen(
    onVideoClick: (uri: String, title: String) -> Unit,
    onBookmarkClick: () -> Unit,
    viewModel: VideoViewModel = hiltViewModel()
) {
    val state  by viewModel.uiState.collectAsStateWithLifecycle()
    val scope  = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    var showNetworkDialog by remember { mutableStateOf(false) }

    // Back press exits selection mode first
    BackHandler(enabled = state.isSelectionMode) { viewModel.clearSelection() }

    // Snackbar
    LaunchedEffect(state.snackbarMessage) {
        state.snackbarMessage?.let { msg ->
            scope.launch { snackbarHostState.showSnackbar(msg) }
            viewModel.onDismissSnackbar()
        }
    }

    if (showNetworkDialog) {
        com.darkwave.player.ui.NetworkUrlDialog(
            onPlay = { url ->
                showNetworkDialog = false
                onVideoClick(url, url.substringAfterLast("/").substringBeforeLast(".").ifBlank { "Network Stream" })
            },
            onDismiss = { showNetworkDialog = false }
        )
    }

    Scaffold(snackbarHost = { SnackbarHost(snackbarHostState) }) { paddingValues ->
        Box(modifier = Modifier.fillMaxSize().background(Background).padding(paddingValues)) {
            Column(modifier = Modifier.fillMaxSize()) {

                // ── Animated header: normal top bar OR multi-select bar ──
                AnimatedContent(
                    targetState = state.isSelectionMode,
                    transitionSpec = {
                        slideInVertically { -it } + fadeIn() togetherWith slideOutVertically { -it } + fadeOut()
                    },
                    label = "selectionBar"
                ) { inSelectionMode ->
                    if (inSelectionMode) {
                        MultiSelectActionBar(
                            selectedCount = state.selectedCount,
                            totalCount    = state.videos.size,
                            onClose       = viewModel::clearSelection,
                            onSelectAll   = {
                                if (state.allSelected) viewModel.clearSelection()
                                else viewModel.selectAll()
                            },
                            onDelete      = viewModel::showBulkDeleteDialog,
                            onShare       = viewModel::bulkShare,
                            onRename      = { viewModel.showRenameDialog() },
                            onHide        = viewModel::bulkHide,
                            onCopyPath    = viewModel::bulkCopyPath
                        )
                    } else {
                        Column {
                            VideoTopBar(
                                isGridView    = state.isGridView,
                                onToggleView  = viewModel::toggleViewMode,
                                onFilterClick = viewModel::showSortDialog,
                                onSearchQuery = viewModel::onSearchQueryChanged,
                                searchQuery   = state.searchQuery,
                                onNetworkUrl  = { showNetworkDialog = true }
                            )
                            DWFilterChipRow(
                                items              = videoFilterLabels,
                                selectedIndex      = state.selectedFilter.ordinal,
                                onSelectionChanged = viewModel::onFilterSelected,
                                modifier           = Modifier.padding(vertical = 8.dp)
                            )
                        }
                    }
                }

                // ── Content ──────────────────────────────────────────────
                if (state.isLoading) {
                    LoadingIndicator()
                } else if (state.videos.isEmpty()) {
                    EmptyState(Icons.Default.VideoLibrary, "No Videos Found", "Your videos will appear here after scan", modifier = Modifier.fillMaxSize())
                } else {
                    AnimatedContent(
                        targetState  = state.isGridView,
                        transitionSpec = { fadeIn(androidx.compose.animation.core.tween(200)) togetherWith fadeOut(androidx.compose.animation.core.tween(200)) },
                        label = "viewToggle"
                    ) { isGrid ->
                        if (isGrid) {
                            LazyVerticalGrid(
                                columns                = GridCells.Fixed(2),
                                contentPadding         = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement  = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp),
                                verticalArrangement    = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp),
                                modifier               = Modifier.fillMaxSize()
                            ) {
                                items(state.videos, key = { it.id }) { video ->
                                    val isSelected = video.id in state.selectedIds
                                    VideoGridItem(
                                        video           = video,
                                        isSelected      = isSelected,
                                        isSelectionMode = state.isSelectionMode,
                                        onClick         = {
                                            if (state.isSelectionMode) viewModel.onItemSelectToggle(video)
                                            else onVideoClick(video.uri, video.title)
                                        },
                                        onLongClick     = { viewModel.onItemLongPress(video) },
                                        onMoreClick     = { viewModel.showContextMenu(video) }
                                    )
                                }
                            }
                        } else {
                            LazyColumn(
                                contentPadding      = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                                modifier            = Modifier.fillMaxSize()
                            ) {
                                items(state.videos, key = { it.id }) { video ->
                                    val isSelected = video.id in state.selectedIds
                                    VideoListItem(
                                        video           = video,
                                        isSelected      = isSelected,
                                        isSelectionMode = state.isSelectionMode,
                                        onClick         = {
                                            if (state.isSelectionMode) viewModel.onItemSelectToggle(video)
                                            else onVideoClick(video.uri, video.title)
                                        },
                                        onLongClick     = { viewModel.onItemLongPress(video) },
                                        onMoreClick     = { viewModel.showContextMenu(video) }
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ── Sort dialog ───────────────────────────────────────────────
            if (state.showSortDialog) {
                VideoSortDialog(current = state.sortOptions, onApply = viewModel::onSortChanged, onDismiss = viewModel::hideSortDialog)
            }

            // ── Single-item context menu ──────────────────────────────────
            state.contextMenuVideo?.let { video ->
                VideoContextMenu(
                    video         = video,
                    onPlay        = { onVideoClick(video.uri, video.title); viewModel.hideContextMenu() },
                    onAddToList   = { viewModel.hideContextMenu() },
                    onBookmark    = { viewModel.toggleBookmark(video) },
                    onShare       = { viewModel.hideContextMenu() },
                    onRename      = { viewModel.showRenameDialog() },
                    onFileInfo    = { viewModel.hideContextMenu() },
                    onCopyPath    = { viewModel.hideContextMenu() },
                    onDelete      = { viewModel.showDeleteDialog() },
                    onDismiss     = viewModel::hideContextMenu
                )
            }

            // ── Rename dialog (single via context menu OR selected 1) ─────
            if (state.showRenameDialog) {
                val currentName = if (state.isSelectionMode)
                    state.videos.firstOrNull { it.id == state.selectedIds.firstOrNull() }?.title ?: ""
                else
                    state.contextMenuVideo?.title ?: ""

                RenameDialog(
                    currentName = currentName,
                    onConfirm   = { newName ->
                        if (state.isSelectionMode) viewModel.renameSelected(newName)
                        else state.contextMenuVideo?.let { viewModel.renameVideo(it, newName) }
                    },
                    onDismiss   = viewModel::hideRenameDialog
                )
            }

            // ── Single delete dialog ──────────────────────────────────────
            if (state.showDeleteDialog && !state.isSelectionMode) {
                state.contextMenuVideo?.let { video ->
                    DeleteConfirmDialog(title = video.title, onConfirm = { viewModel.deleteVideo(video) }, onDismiss = viewModel::hideDeleteDialog)
                }
            }

            // ── Bulk delete dialog ────────────────────────────────────────
            if (state.showBulkDeleteDialog) {
                BulkDeleteDialog(count = state.selectedCount, onConfirm = viewModel::bulkDelete, onDismiss = viewModel::hideBulkDeleteDialog)
            }
        }
    }
}
