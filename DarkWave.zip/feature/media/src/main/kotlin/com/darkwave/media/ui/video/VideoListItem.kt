package com.darkwave.media.ui.video

import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.darkwave.common.util.toFormattedDuration
import com.darkwave.common.util.toFormattedSize
import com.darkwave.domain.model.VideoItem
import com.darkwave.common.ui.theme.*

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VideoListItem(
    video: VideoItem,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onMoreClick: () -> Unit,
    isSelected: Boolean = false,
    isSelectionMode: Boolean = false,
    modifier: Modifier = Modifier
) {
    val cardColor = if (isSelected) Purple100 else White
    val borderColor = if (isSelected) Purple500 else Color.Transparent

    Card(
        modifier  = modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick     = onClick,
                onLongClick = onLongClick
            ),
        shape     = RoundedCornerShape(12.dp),
        colors    = CardDefaults.cardColors(containerColor = cardColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 3.dp else 1.dp),
        border    = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, borderColor) else null
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Thumbnail with selection overlay
            Box(
                modifier = Modifier
                    .width(110.dp)
                    .height(68.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF1A1A1A))
            ) {
                AsyncImage(
                    model              = video.uri,
                    contentDescription = video.title,
                    contentScale       = ContentScale.Crop,
                    modifier           = Modifier.fillMaxSize()
                )
                QualityBadge(label = video.qualityLabel, modifier = Modifier.align(Alignment.TopStart).padding(4.dp))
                Surface(
                    modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp),
                    shape    = RoundedCornerShape(4.dp),
                    color    = Color(0xCC000000)
                ) {
                    Text(video.duration.toFormattedDuration(), fontSize = 10.sp, color = White, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                }

                // Selection overlay
                AnimatedVisibility(visible = isSelected, enter = fadeIn(), exit = fadeOut()) {
                    Box(modifier = Modifier.fillMaxSize().background(Purple500.copy(alpha = 0.3f)))
                }
                // Checkbox in corner
                AnimatedVisibility(
                    visible  = isSelectionMode,
                    enter    = scaleIn() + fadeIn(),
                    exit     = scaleOut() + fadeOut(),
                    modifier = Modifier.align(Alignment.TopEnd).padding(4.dp)
                ) {
                    if (isSelected) {
                        Icon(Icons.Default.CheckCircle, null, tint = Purple500, modifier = Modifier.size(22.dp))
                    } else {
                        Box(
                            modifier = Modifier
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.85f))
                                .padding(2.dp)
                        ) {
                            Box(modifier = Modifier.fillMaxSize().clip(CircleShape).background(Color(0xFFDDDDDD)))
                        }
                    }
                }
            }

            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(video.title, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = TextPrimary, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Text("${video.mimeType.substringAfter("/").uppercase()} · ${video.size.toFormattedSize()}", fontSize = 11.sp, color = TextSecondary)
            }

            // Hide MoreVert button in selection mode
            AnimatedVisibility(visible = !isSelectionMode) {
                IconButton(onClick = onMoreClick, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.MoreVert, "More", tint = TextSecondary, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}
