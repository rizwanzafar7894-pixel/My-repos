package com.darkwave.media.ui.video

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.darkwave.common.util.toFormattedDuration
import com.darkwave.common.util.toFormattedSize
import com.darkwave.domain.model.VideoItem
import com.darkwave.common.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoContextMenu(
    video: VideoItem,
    onPlay: () -> Unit,
    onAddToList: () -> Unit,
    onBookmark: () -> Unit,
    onShare: () -> Unit,
    onRename: () -> Unit,
    onFileInfo: () -> Unit,
    onCopyPath: () -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest  = onDismiss,
        sheetState        = rememberModalBottomSheetState(skipPartialExpansion = true),
        containerColor    = White,
        shape             = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(modifier = Modifier.padding(bottom = 32.dp)) {

            // Video info header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF1A1A1A))
                ) {
                    AsyncImage(
                        model = video.uri,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(
                        text = video.title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )
                    Text(
                        text = "${video.mimeType.substringAfter("/").uppercase()} · ${video.qualityLabel} · ${video.size.toFormattedSize()}",
                        fontSize = 12.sp,
                        color = TextSecondary
                    )
                }
            }

            Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
            Spacer(Modifier.height(8.dp))

            // Action icons row — Play / Add to List / Bookmark / Share
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ContextActionButton(Icons.Default.PlayArrow, "Play",       Purple500, onPlay)
                ContextActionButton(Icons.Default.QueueMusic, "Add to List", TextSecondary, onAddToList)
                ContextActionButton(
                    if (video.isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    "Bookmark",
                    if (video.isBookmarked) Purple500 else TextSecondary,
                    onBookmark
                )
                ContextActionButton(Icons.Default.Share, "Share", TextSecondary, onShare)
            }

            Spacer(Modifier.height(8.dp))
            Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
            Spacer(Modifier.height(4.dp))

            // Text actions
            ContextMenuItem(Icons.Default.Edit,    "Rename",           TextPrimary, onRename)
            ContextMenuItem(Icons.Default.Info,    "File Information",  TextPrimary, onFileInfo)
            ContextMenuItem(Icons.Default.ContentCopy, "Copy Path",    TextPrimary, onCopyPath)
            ContextMenuItem(Icons.Default.Delete,  "Delete",           Color(0xFFF44336), onDelete)
        }
    }
}

@Composable
private fun ContextActionButton(
    icon: ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(50))
                .background(SurfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(label, fontSize = 11.sp, color = TextSecondary)
    }
}

@Composable
private fun ContextMenuItem(
    icon: ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(16.dp))
        Text(label, fontSize = 15.sp, color = tint, fontWeight = FontWeight.Normal)
    }
}
