package com.darkwave.media.viewmodel

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darkwave.domain.model.*
import com.darkwave.domain.repository.MediaRepository
import com.darkwave.domain.usecase.media.GetLocalVideosUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

data class VideoUiState(
    val videos: List<VideoItem> = emptyList(),
    val isLoading: Boolean = true,
    val isGridView: Boolean = true,
    val selectedFilter: VideoFilter = VideoFilter.ALL,
    val sortOptions: SortOptions = SortOptions(),
    val searchQuery: String = "",
    val showSortDialog: Boolean = false,
    val contextMenuVideo: VideoItem? = null,
    val showRenameDialog: Boolean = false,
    val showDeleteDialog: Boolean = false,
    val errorMessage: String? = null,

    // ── Multi-select ───────────────────────────────────────────────
    val isSelectionMode: Boolean = false,
    val selectedIds: Set<Long> = emptySet(),
    val showBulkDeleteDialog: Boolean = false,
    val showMoveDialog: Boolean = false,
    val showCopyDialog: Boolean = false,
    val snackbarMessage: String? = null
) {
    val selectedCount: Int get() = selectedIds.size
    val allSelected: Boolean get() = videos.isNotEmpty() && selectedIds.size == videos.size
}

val videoFilterLabels = listOf("All", "Movies", "Clips", "Downloads", "4K")

@HiltViewModel
class VideoViewModel @Inject constructor(
    private val getLocalVideosUseCase: GetLocalVideosUseCase,
    private val mediaRepository: MediaRepository,
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _uiState = MutableStateFlow(VideoUiState())
    val uiState: StateFlow<VideoUiState> = _uiState.asStateFlow()

    private val _sortOptions = MutableStateFlow(SortOptions())
    private val _filter      = MutableStateFlow(VideoFilter.ALL)
    private val _searchQuery = MutableStateFlow("")

    init { observeVideos() }

    @OptIn(ExperimentalCoroutinesApi::class)
    private fun observeVideos() {
        viewModelScope.launch {
            combine(_sortOptions, _filter, _searchQuery) { sort, filter, query ->
                Triple(sort, filter, query)
            }.flatMapLatest { (sort, filter, query) ->
                getLocalVideosUseCase(sort, filter, query)
            }.collect { videos ->
                _uiState.update { it.copy(videos = videos, isLoading = false) }
            }
        }
    }

    // ── Filters / Sort ────────────────────────────────────────────────
    fun onFilterSelected(index: Int) {
        val filter = VideoFilter.entries[index]
        _filter.value = filter
        _uiState.update { it.copy(selectedFilter = filter) }
    }
    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
        _uiState.update { it.copy(searchQuery = query) }
    }
    fun toggleViewMode()              { _uiState.update { it.copy(isGridView = !it.isGridView) } }
    fun onSortChanged(options: SortOptions) {
        _sortOptions.value = options
        _uiState.update { it.copy(sortOptions = options, showSortDialog = false) }
    }
    fun showSortDialog()  { _uiState.update { it.copy(showSortDialog = true) } }
    fun hideSortDialog()  { _uiState.update { it.copy(showSortDialog = false) } }

    // ── Single-item context menu ──────────────────────────────────────
    fun showContextMenu(video: VideoItem) { _uiState.update { it.copy(contextMenuVideo = video) } }
    fun hideContextMenu()                 { _uiState.update { it.copy(contextMenuVideo = null) } }
    fun showRenameDialog()                { _uiState.update { it.copy(showRenameDialog = true) } }
    fun hideRenameDialog()                { _uiState.update { it.copy(showRenameDialog = false) } }
    fun showDeleteDialog()                { _uiState.update { it.copy(showDeleteDialog = true) } }
    fun hideDeleteDialog()                { _uiState.update { it.copy(showDeleteDialog = false) } }

    // ── Multi-select ──────────────────────────────────────────────────

    /** Long press on item → enter selection mode and select that item */
    fun onItemLongPress(video: VideoItem) {
        _uiState.update { it.copy(
            isSelectionMode = true,
            selectedIds     = it.selectedIds + video.id,
            contextMenuVideo = null
        ) }
    }

    /** Tap on item while in selection mode → toggle selection */
    fun onItemSelectToggle(video: VideoItem) {
        _uiState.update { state ->
            val newSelected = if (video.id in state.selectedIds)
                state.selectedIds - video.id
            else
                state.selectedIds + video.id
            // Auto-exit if nothing left selected
            state.copy(
                selectedIds     = newSelected,
                isSelectionMode = newSelected.isNotEmpty()
            )
        }
    }

    fun selectAll() {
        _uiState.update { it.copy(selectedIds = it.videos.map { v -> v.id }.toSet()) }
    }

    fun clearSelection() {
        _uiState.update { it.copy(isSelectionMode = false, selectedIds = emptySet()) }
    }

    // ── Bulk actions ──────────────────────────────────────────────────

    /** Delete all selected videos */
    fun bulkDelete() {
        val ids = _uiState.value.selectedIds.toList()
        viewModelScope.launch {
            ids.forEach { id -> mediaRepository.deleteVideo(id) }
        }
        _uiState.update { it.copy(
            isSelectionMode  = false,
            selectedIds      = emptySet(),
            showBulkDeleteDialog = false,
            snackbarMessage  = "${ids.size} video(s) deleted"
        ) }
    }

    /** Share selected videos via Android share sheet */
    fun bulkShare() {
        val selectedVideos = _uiState.value.let { state ->
            state.videos.filter { it.id in state.selectedIds }
        }
        if (selectedVideos.isEmpty()) return

        val uris = ArrayList<Uri>()
        selectedVideos.forEach { video ->
            try {
                val file = File(Uri.parse(video.uri).path ?: return@forEach)
                val uri  = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                uris.add(uri)
            } catch (e: Exception) {
                // Try raw URI if FileProvider fails
                uris.add(Uri.parse(video.uri))
            }
        }

        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = "video/*"
                putExtra(Intent.EXTRA_STREAM, uris[0])
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "video/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        context.startActivity(Intent.createChooser(intent, "Share ${uris.size} video(s)").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
        clearSelection()
    }

    /** Rename single selected video (only active when exactly 1 selected) */
    fun renameSelected(newName: String) {
        val id = _uiState.value.selectedIds.firstOrNull() ?: return
        viewModelScope.launch { mediaRepository.renameVideo(id, newName) }
        _uiState.update { it.copy(
            isSelectionMode = false,
            selectedIds     = emptySet(),
            showRenameDialog = false,
            snackbarMessage = "Renamed successfully"
        ) }
    }

    /** Hide selected videos (move to vault) */
    fun bulkHide() {
        val ids = _uiState.value.selectedIds.toList()
        viewModelScope.launch {
            ids.forEach { id -> mediaRepository.setVideoVault(id, true) }
        }
        _uiState.update { it.copy(
            isSelectionMode = false,
            selectedIds     = emptySet(),
            snackbarMessage = "${ids.size} video(s) moved to Vault"
        ) }
    }

    /** Copy path(s) to clipboard */
    fun bulkCopyPath() {
        val selectedVideos = _uiState.value.let { state ->
            state.videos.filter { it.id in state.selectedIds }
        }
        val paths = selectedVideos.joinToString("\n") { it.uri }
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("File paths", paths))
        _uiState.update { it.copy(snackbarMessage = "Path(s) copied to clipboard") }
        clearSelection()
    }

    // Keep single-item actions for context menu
    fun toggleFavorite(video: VideoItem) {
        viewModelScope.launch { mediaRepository.toggleVideoFavorite(video.id, !video.isFavorite) }
        hideContextMenu()
    }
    fun toggleBookmark(video: VideoItem) {
        viewModelScope.launch { mediaRepository.toggleVideoBookmark(video.id, !video.isBookmarked, 0L) }
        hideContextMenu()
    }
    fun renameVideo(video: VideoItem, newName: String) {
        viewModelScope.launch { mediaRepository.renameVideo(video.id, newName) }
        _uiState.update { it.copy(showRenameDialog = false, contextMenuVideo = null) }
    }
    fun deleteVideo(video: VideoItem) {
        viewModelScope.launch { mediaRepository.deleteVideo(video.id) }
        _uiState.update { it.copy(showDeleteDialog = false, contextMenuVideo = null) }
    }

    fun showBulkDeleteDialog() { _uiState.update { it.copy(showBulkDeleteDialog = true) } }
    fun hideBulkDeleteDialog() { _uiState.update { it.copy(showBulkDeleteDialog = false) } }
    fun onDismissSnackbar()    { _uiState.update { it.copy(snackbarMessage = null) } }
}
