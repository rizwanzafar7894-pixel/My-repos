package com.darkwave.media.viewmodel

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darkwave.domain.model.*
import com.darkwave.domain.repository.MediaRepository
import com.darkwave.domain.repository.PlaylistRepository
import com.darkwave.domain.usecase.media.GetLocalAudioUseCase
import com.darkwave.domain.usecase.recommendation.GetRecommendationsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

data class MusicUiState(
    val selectedTabIndex: Int = 0,
    val allSongs: List<AudioItem> = emptyList(),
    val likedSongs: List<AudioItem> = emptyList(),
    val downloadedSongs: List<AudioItem> = emptyList(),
    val artists: List<String> = emptyList(),
    val albums: List<String> = emptyList(),
    val genres: List<String> = emptyList(),
    val playlists: List<Playlist> = emptyList(),
    val discoverWeekly: Playlist? = null,
    val discoverWeeklySongs: List<AudioItem> = emptyList(),
    val curatedPlaylists: List<CuratedPlaylist> = emptyList(),
    val recommendedSongs: List<AudioItem> = emptyList(),
    val forYouSongs: List<AudioItem> = emptyList(),
    val searchQuery: String = "",
    val isLoading: Boolean = true,
    val contextMenuSong: AudioItem? = null,
    val showCreatePlaylist: Boolean = false,

    // ── Multi-select ───────────────────────────────────────────────────────
    val isSelectionMode: Boolean = false,
    val selectedIds: Set<Long> = emptySet(),
    val showBulkDeleteDialog: Boolean = false,
    val showRenameDialog: Boolean = false,
    val snackbarMessage: String? = null
) {
    val selectedCount: Int get() = selectedIds.size
    /** Current visible list based on tab — used for "Select All" */
    fun visibleSongs(tab: Int) = when (tab) {
        0 -> allSongs
        1 -> allSongs
        2 -> likedSongs
        4 -> downloadedSongs
        else -> allSongs
    }
    val allSelected: Boolean get() = false // computed per-tab in VM
}

val musicTabLabels = listOf(
    "All Songs", "My Library", "Liked Songs", "Playlists",
    "Downloads", "Artists", "Albums", "Genres"
)

@HiltViewModel
class MusicViewModel @Inject constructor(
    private val getLocalAudioUseCase: GetLocalAudioUseCase,
    private val mediaRepository: MediaRepository,
    private val playlistRepository: PlaylistRepository,
    private val recommendationsUseCase: GetRecommendationsUseCase,
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _uiState = MutableStateFlow(MusicUiState())
    val uiState: StateFlow<MusicUiState> = _uiState.asStateFlow()

    init {
        observeAllSongs()
        observePlaylists()
        observeRecommendations()
        observeForYou()
        observeCurated()
        observeArtistsAlbumsGenres()
    }

    private fun observeAllSongs() {
        viewModelScope.launch {
            getLocalAudioUseCase().collect { songs ->
                _uiState.update { it.copy(
                    allSongs        = songs,
                    likedSongs      = songs.filter { s -> s.isLiked },
                    downloadedSongs = songs.filter { s -> s.isDownloaded },
                    isLoading       = false
                ) }
            }
        }
    }

    private fun observePlaylists() {
        viewModelScope.launch {
            combine(playlistRepository.getAllPlaylists(), mediaRepository.getAllAudio()) { playlists, audio ->
                val dw = playlists.firstOrNull { it.name == "Discover Weekly" }
                Triple(playlists, dw, audio.shuffled().take(52))
            }.collect { (playlists, dw, dwSongs) ->
                _uiState.update { it.copy(playlists = playlists, discoverWeekly = dw, discoverWeeklySongs = dwSongs) }
            }
        }
    }

    private fun observeRecommendations() {
        viewModelScope.launch {
            recommendationsUseCase.getTopPlayed(20).collect { songs ->
                _uiState.update { it.copy(recommendedSongs = songs) }
            }
        }
    }

    private fun observeForYou() {
        viewModelScope.launch {
            recommendationsUseCase.getForYou(25).collect { songs ->
                _uiState.update { it.copy(forYouSongs = songs) }
            }
        }
    }

    private fun observeCurated() {
        viewModelScope.launch {
            recommendationsUseCase.getCuratedPlaylists().collect { curated ->
                _uiState.update { it.copy(curatedPlaylists = curated) }
            }
        }
    }

    private fun observeArtistsAlbumsGenres() {
        viewModelScope.launch {
            mediaRepository.getAllAudio().collect { songs ->
                _uiState.update { it.copy(
                    artists = songs.map { it.artist }.distinct().sorted(),
                    albums  = songs.map { it.album }.filter { it.isNotBlank() }.distinct().sorted(),
                    genres  = songs.map { it.genre }.filter { it.isNotBlank() }.distinct().sorted()
                ) }
            }
        }
    }

    // ── Navigation ─────────────────────────────────────────────────────────
    fun onTabSelected(index: Int) {
        _uiState.update { it.copy(selectedTabIndex = index, isSelectionMode = false, selectedIds = emptySet()) }
    }
    fun onSearchQueryChanged(query: String) { _uiState.update { it.copy(searchQuery = query) } }

    // ── Single-item context menu ────────────────────────────────────────────
    fun showContextMenu(song: AudioItem) { _uiState.update { it.copy(contextMenuSong = song) } }
    fun hideContextMenu()                { _uiState.update { it.copy(contextMenuSong = null) } }

    fun toggleLike(song: AudioItem) {
        viewModelScope.launch { mediaRepository.toggleAudioLiked(song.id, !song.isLiked) }
    }
    fun addToPlaylist(song: AudioItem, playlistId: Long) {
        viewModelScope.launch { playlistRepository.addSongToPlaylist(playlistId, song.id) }
    }
    fun showCreatePlaylistDialog()   { _uiState.update { it.copy(showCreatePlaylist = true) } }
    fun dismissCreatePlaylistDialog(){ _uiState.update { it.copy(showCreatePlaylist = false) } }
    fun createPlaylist(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            playlistRepository.createPlaylist(name.trim())
            _uiState.update { it.copy(showCreatePlaylist = false) }
        }
    }

    // ── Multi-select ────────────────────────────────────────────────────────

    fun onItemLongPress(song: AudioItem) {
        _uiState.update { it.copy(
            isSelectionMode = true,
            selectedIds     = it.selectedIds + song.id,
            contextMenuSong = null
        ) }
    }

    fun onItemSelectToggle(song: AudioItem) {
        _uiState.update { state ->
            val newSelected = if (song.id in state.selectedIds)
                state.selectedIds - song.id
            else
                state.selectedIds + song.id
            state.copy(
                selectedIds     = newSelected,
                isSelectionMode = newSelected.isNotEmpty()
            )
        }
    }

    fun selectAll() {
        val tab  = _uiState.value.selectedTabIndex
        val list = _uiState.value.visibleSongs(tab)
        _uiState.update { it.copy(selectedIds = list.map { s -> s.id }.toSet()) }
    }

    fun clearSelection() {
        _uiState.update { it.copy(isSelectionMode = false, selectedIds = emptySet()) }
    }

    // ── Bulk actions ────────────────────────────────────────────────────────

    fun bulkDelete() {
        val ids = _uiState.value.selectedIds.toList()
        viewModelScope.launch { ids.forEach { id -> mediaRepository.deleteAudio(id) } }
        _uiState.update { it.copy(
            isSelectionMode      = false,
            selectedIds          = emptySet(),
            showBulkDeleteDialog = false,
            snackbarMessage      = "${ids.size} song(s) deleted"
        ) }
    }

    fun bulkShare() {
        val state         = _uiState.value
        val selectedSongs = state.allSongs.filter { it.id in state.selectedIds }
        if (selectedSongs.isEmpty()) return

        val uris = ArrayList<Uri>()
        selectedSongs.forEach { song ->
            try {
                val file = File(Uri.parse(song.uri).path ?: return@forEach)
                val uri  = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                uris.add(uri)
            } catch (e: Exception) {
                uris.add(Uri.parse(song.uri))
            }
        }

        val intent = if (uris.size == 1) {
            Intent(Intent.ACTION_SEND).apply {
                type = "audio/*"
                putExtra(Intent.EXTRA_STREAM, uris[0])
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        } else {
            Intent(Intent.ACTION_SEND_MULTIPLE).apply {
                type = "audio/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
        context.startActivity(Intent.createChooser(intent, "Share ${uris.size} song(s)").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
        clearSelection()
    }

    fun bulkHide() {
        val ids = _uiState.value.selectedIds.toList()
        viewModelScope.launch { ids.forEach { id -> mediaRepository.setAudioVault(id, true) } }
        _uiState.update { it.copy(
            isSelectionMode = false,
            selectedIds     = emptySet(),
            snackbarMessage = "${ids.size} song(s) moved to Vault"
        ) }
    }

    fun renameSelected(newName: String) {
        val id = _uiState.value.selectedIds.firstOrNull() ?: return
        viewModelScope.launch { mediaRepository.renameAudio(id, newName) }
        _uiState.update { it.copy(
            isSelectionMode = false,
            selectedIds     = emptySet(),
            showRenameDialog = false,
            snackbarMessage = "Renamed successfully"
        ) }
    }

    fun bulkCopyPath() {
        val state         = _uiState.value
        val selectedSongs = state.allSongs.filter { it.id in state.selectedIds }
        val paths         = selectedSongs.joinToString("\n") { it.uri }
        val cb            = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("File paths", paths))
        _uiState.update { it.copy(snackbarMessage = "Path(s) copied to clipboard") }
        clearSelection()
    }

    fun showBulkDeleteDialog() { _uiState.update { it.copy(showBulkDeleteDialog = true) } }
    fun hideBulkDeleteDialog() { _uiState.update { it.copy(showBulkDeleteDialog = false) } }
    fun showRenameDialog()     { _uiState.update { it.copy(showRenameDialog = true) } }
    fun hideRenameDialog()     { _uiState.update { it.copy(showRenameDialog = false) } }
    fun onDismissSnackbar()    { _uiState.update { it.copy(snackbarMessage = null) } }
}
