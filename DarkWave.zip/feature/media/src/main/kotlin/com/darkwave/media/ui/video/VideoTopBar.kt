package com.darkwave.media.ui.video

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.theme.*

@Composable
fun VideoTopBar(
    isGridView: Boolean,
    onToggleView: () -> Unit,
    onFilterClick: () -> Unit,
    onSearchQuery: (String) -> Unit,
    searchQuery: String,
    onNetworkUrl: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var showSearch by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(White)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (!showSearch) {
                Text(
                    text = "Video Library",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary,
                    modifier = Modifier.weight(1f)
                )
            } else {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchQuery,
                    modifier = Modifier
                        .weight(1f)
                        .focusRequester(focusRequester),
                    placeholder = { Text("Search videos...", color = TextTertiary) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor   = Purple500,
                        unfocusedBorderColor = BorderColor
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { showSearch = false })
                )
                LaunchedEffect(Unit) { focusRequester.requestFocus() }
            }

            // Search icon
            IconButton(onClick = {
                showSearch = !showSearch
                if (!showSearch) onSearchQuery("")
            }) {
                Icon(
                    imageVector = if (showSearch) Icons.Default.Close else Icons.Default.Search,
                    contentDescription = "Search",
                    tint = TextSecondary,
                    modifier = Modifier.size(22.dp)
                )
            }

            // Network URL / open stream
            IconButton(onClick = onNetworkUrl) {
                Icon(
                    imageVector = Icons.Default.WifiTethering,
                    contentDescription = "Open network stream",
                    tint = TextSecondary,
                    modifier = Modifier.size(22.dp)
                )
            }

            // Filter icon
            IconButton(onClick = onFilterClick) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = "Filter",
                    tint = TextSecondary,
                    modifier = Modifier.size(22.dp)
                )
            }

            // Grid / List toggle
            IconButton(onClick = onToggleView) {
                Icon(
                    imageVector = if (isGridView) Icons.Default.ViewList else Icons.Default.GridView,
                    contentDescription = if (isGridView) "List view" else "Grid view",
                    tint = TextSecondary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}
