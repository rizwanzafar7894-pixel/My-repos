package com.darkwave.media.ui.video

import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.darkwave.common.util.toFormattedDuration
import com.darkwave.common.util.toFormattedSize
import com.darkwave.domain.model.VideoItem
import com.darkwave.common.ui.theme.*

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VideoGridItem(
    video: VideoItem,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onMoreClick: () -> Unit,
    isSelected: Boolean = false,
    isSelectionMode: Boolean = false,
    modifier: Modifier = Modifier
) {
    Card(
        modifier  = modifier
            .combinedClickable(onClick = onClick, onLongClick = onLongClick),
        shape     = RoundedCornerShape(12.dp),
        colors    = CardDefaults.cardColors(containerColor = if (isSelected) Purple100 else White),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 2.dp),
        border    = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, Purple500) else null
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                    .background(Color(0xFF1A1A1A))
            ) {
                AsyncImage(model = video.uri, contentDescription = video.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                QualityBadge(label = video.qualityLabel, modifier = Modifier.align(Alignment.TopStart).padding(6.dp))
                Surface(modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp), shape = RoundedCornerShape(4.dp), color = Color(0xCC000000)) {
                    Text(video.duration.toFormattedDuration(), fontSize = 11.sp, color = White, modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp))
                }

                // Selection overlay
                AnimatedVisibility(visible = isSelected, enter = fadeIn(), exit = fadeOut()) {
                    Box(modifier = Modifier.fillMaxSize().background(Purple500.copy(alpha = 0.25f)))
                }
                // Checkbox — top-right corner
                AnimatedVisibility(
                    visible  = isSelectionMode,
                    enter    = scaleIn() + fadeIn(),
                    exit     = scaleOut() + fadeOut(),
                    modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)
                ) {
                    if (isSelected) {
                        Icon(Icons.Default.CheckCircle, null, tint = Purple500, modifier = Modifier.size(24.dp))
                    } else {
                        Box(modifier = Modifier.size(24.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.85f)).padding(2.dp)) {
                            Box(modifier = Modifier.fillMaxSize().clip(CircleShape).background(Color(0xFFDDDDDD)))
                        }
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 8.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(video.title, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${video.mimeType.substringAfter("/").uppercase()} · ${video.size.toFormattedSize()}", fontSize = 10.sp, color = TextSecondary, maxLines = 1)
                }
                AnimatedVisibility(visible = !isSelectionMode) {
                    IconButton(onClick = onMoreClick, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.MoreVert, "More", tint = TextSecondary, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun QualityBadge(label: String, modifier: Modifier = Modifier) {
    val color = when (label) { "4K" -> Badge4K; "1080p" -> Badge1080p; "720p" -> Badge720p; else -> BadgeHD }
    Surface(modifier = modifier, shape = RoundedCornerShape(4.dp), color = color) {
        Text(label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = White, modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp))
    }
}
