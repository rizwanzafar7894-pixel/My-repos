package com.darkwave.media.ui.video

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.domain.model.SortBy
import com.darkwave.domain.model.SortOptions
import com.darkwave.domain.model.SortOrder
import com.darkwave.common.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoSortDialog(
    current: SortOptions,
    onApply: (SortOptions) -> Unit,
    onDismiss: () -> Unit
) {
    var sortBy    by remember { mutableStateOf(current.sortBy) }
    var order     by remember { mutableStateOf(current.order) }
    var showSize  by remember { mutableStateOf(current.showSize) }
    var showDur   by remember { mutableStateOf(current.showDuration) }
    var showRes   by remember { mutableStateOf(current.showResolution) }
    var showDate  by remember { mutableStateOf(current.showDateAdded) }
    var showPlays by remember { mutableStateOf(current.showPlayCount) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState       = rememberModalBottomSheetState(skipPartialExpansion = true),
        containerColor   = White,
        shape            = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Text("Sort & Filter", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
            Spacer(Modifier.height(16.dp))

            // Sort by section
            Text("Sort by", fontSize = 13.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(8.dp))

            val sortOptions = listOf(
                SortBy.NAME to "Name",
                SortBy.DATE_ADDED to "Date Added",
                SortBy.DATE_MODIFIED to "Date Modified",
                SortBy.SIZE to "File Size",
                SortBy.DURATION to "Duration",
                SortBy.PLAY_COUNT to "Play Count",
                SortBy.LAST_PLAYED to "Last Played",
                SortBy.RATING to "Rating",
                SortBy.RESOLUTION to "Resolution"
            )

            sortOptions.forEach { (option, label) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { sortBy = option }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = sortBy == option,
                        onClick  = { sortBy = option },
                        colors   = RadioButtonDefaults.colors(selectedColor = Purple500)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(label, fontSize = 14.sp, color = TextPrimary)
                }
            }

            Spacer(Modifier.height(12.dp))
            Divider(color = DividerColor)
            Spacer(Modifier.height(12.dp))

            // Order
            Text("Order", fontSize = 13.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(
                    selected = order == SortOrder.ASC,
                    onClick  = { order = SortOrder.ASC },
                    label    = { Text("Ascending") },
                    colors   = FilterChipDefaults.filterChipColors(selectedContainerColor = Purple100)
                )
                FilterChip(
                    selected = order == SortOrder.DESC,
                    onClick  = { order = SortOrder.DESC },
                    label    = { Text("Descending") },
                    colors   = FilterChipDefaults.filterChipColors(selectedContainerColor = Purple100)
                )
            }

            Spacer(Modifier.height(12.dp))
            Divider(color = DividerColor)
            Spacer(Modifier.height(12.dp))

            // Fields
            Text("Fields", fontSize = 13.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(8.dp))

            val fields = listOf(
                Triple("Size", showSize) { v: Boolean -> showSize = v },
                Triple("Duration", showDur) { v: Boolean -> showDur = v },
                Triple("Resolution", showRes) { v: Boolean -> showRes = v },
                Triple("Date Added", showDate) { v: Boolean -> showDate = v },
                Triple("Play Count", showPlays) { v: Boolean -> showPlays = v }
            )
            fields.forEach { (label, checked, onChange) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onChange(!checked) }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked         = checked,
                        onCheckedChange = onChange,
                        colors          = CheckboxDefaults.colors(checkedColor = Purple500)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(label, fontSize = 14.sp, color = TextPrimary)
                }
            }

            Spacer(Modifier.height(20.dp))

            Button(
                onClick = {
                    onApply(SortOptions(sortBy, order, showSize, showDur, showRes, showDate, showPlays))
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors   = ButtonDefaults.buttonColors(containerColor = Purple500),
                shape    = RoundedCornerShape(12.dp)
            ) {
                Text("Apply", fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = White)
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}
