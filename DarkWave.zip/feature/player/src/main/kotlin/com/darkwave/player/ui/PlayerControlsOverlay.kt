package com.darkwave.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import com.darkwave.common.util.toFormattedDuration
import com.darkwave.player.viewmodel.PlayerUiState

private val TopGradient    = Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent))
private val BottomGradient = Brush.verticalGradient(listOf(Color.Transparent, Color(0xCC000000)))
private val AccentColor    = Color(0xFF5C6BC0)

@Composable
fun PlayerControlsOverlay(
    state: PlayerUiState,
    onBack: () -> Unit,
    onPlayPause: () -> Unit,
    onSeekTo: (Long) -> Unit,
    onForward: () -> Unit,
    onBackward: () -> Unit,
    onToggleMute: () -> Unit,
    onToggleLock: () -> Unit,
    onCycleRepeat: () -> Unit,
    onToggleSpeed: () -> Unit,
    onToggleAspect: () -> Unit,
    onSubtitleClick: () -> Unit,
    onAudioTrackClick: () -> Unit,
    onVolumeBoostClick: () -> Unit,
    onPipClick: () -> Unit,
    onScreenshot: () -> Unit,
    onVideoInfo: () -> Unit,
    onSleepTimer: () -> Unit,
    onNetworkUrl: () -> Unit,
    onEqualizer: () -> Unit,
    onRotation: () -> Unit,
    onBookmark: () -> Unit,
    onStepForward: () -> Unit,
    onStepBackward: () -> Unit,
    onAudioOnlyMode: () -> Unit,
    onColorFilter: () -> Unit,
    onChapters: () -> Unit,
    onCast: () -> Unit,
    onToggleClock: () -> Unit,
    onFloatingPlayer: () -> Unit,
    onDismiss: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize().clickable(onClick = onDismiss)) {

        // ── TOP BAR ──────────────────────────────────────────────────────
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(TopGradient)
                .align(Alignment.TopCenter)
                .padding(horizontal = 4.dp, vertical = 8.dp)
                .height(56.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxSize()
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = Color.White, modifier = Modifier.size(24.dp))
                }
                Text(
                    text     = state.title,
                    color    = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier   = Modifier.weight(1f),
                    maxLines   = 1,
                    overflow   = TextOverflow.Ellipsis
                )

                // Speed chip
                Chip(text = "${state.playbackSpeed}x", onClick = onToggleSpeed)
                Spacer(Modifier.width(2.dp))

                // Volume% chip
                VolumeChip(volumePercent = state.volumePercent, onClick = onVolumeBoostClick)
                Spacer(Modifier.width(2.dp))

                // Video info
                IconButton(onClick = onVideoInfo) {
                    Icon(Icons.Default.Info, "Info", tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
                }

                // Screenshot
                IconButton(onClick = onScreenshot) {
                    Icon(Icons.Default.Screenshot, "Screenshot", tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
                }

                // Sleep timer (highlight if active)
                IconButton(onClick = onSleepTimer) {
                    Icon(
                        Icons.Default.Timer, "Sleep Timer",
                        tint = if (state.sleepTimerRemainingMs > 0) AccentColor else Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Open network URL
                IconButton(onClick = onNetworkUrl) {
                    Icon(Icons.Default.WifiTethering, "Network Stream",
                        tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
                }

                // Aspect ratio
                IconButton(onClick = onToggleAspect) {
                    Icon(Icons.Default.AspectRatio, "Aspect", tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
                }

                // Lock
                IconButton(onClick = onToggleLock) {
                    Icon(
                        if (state.isLocked) Icons.Default.Lock else Icons.Default.LockOpen, "Lock",
                        tint = if (state.isLocked) AccentColor else Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Mute
                IconButton(onClick = onToggleMute) {
                    Icon(
                        if (state.isMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp, "Mute",
                        tint = Color.White, modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        // ── CENTER CONTROLS ───────────────────────────────────────────────
        Row(
            modifier = Modifier.align(Alignment.Center),
            horizontalArrangement = Arrangement.spacedBy(32.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            PlayerCenterButton(Icons.Default.Replay10, "-10s", onBackward, 40.dp)

            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.15f))
                    .clickable(onClick = onPlayPause),
                contentAlignment = Alignment.Center
            ) {
                if (state.isBuffering) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(32.dp), strokeWidth = 3.dp)
                } else {
                    Icon(
                        if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, "Play/Pause",
                        tint = Color.White, modifier = Modifier.size(38.dp)
                    )
                }
            }

            PlayerCenterButton(Icons.Default.Forward10, "+10s", onForward, 40.dp)
        }

        // ── BOTTOM BAR ────────────────────────────────────────────────────
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BottomGradient)
                .align(Alignment.BottomCenter)
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(state.currentPositionMs.toFormattedDuration(), color = Color.White, fontSize = 12.sp)
                Spacer(Modifier.weight(1f))
                Text(state.durationMs.toFormattedDuration(), color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            }

            if (state.durationMs > 0L) {
                PlayerSeekBar(
                    position  = state.currentPositionMs,
                    buffered  = state.bufferedPositionMs,
                    duration  = state.durationMs,
                    videoUri  = state.uri,
                    onSeekTo  = onSeekTo,
                    modifier  = Modifier.fillMaxWidth()
                )
            }

            Spacer(Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Repeat
                IconButton(onClick = onCycleRepeat) {
                    Icon(
                        when (state.repeatMode) {
                            Player.REPEAT_MODE_ONE -> Icons.Default.RepeatOne
                            Player.REPEAT_MODE_ALL -> Icons.Default.Repeat
                            else                   -> Icons.Default.RepeatOne
                        },
                        "Repeat",
                        tint = if (state.repeatMode != Player.REPEAT_MODE_OFF) AccentColor else Color.White.copy(alpha = 0.5f),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(Modifier.weight(1f))

                // Audio track
                AudioTrackButton(
                    trackCount    = state.audioTracks.size,
                    selectedIndex = state.selectedAudioTrackIndex,
                    onClick       = onAudioTrackClick
                )

                Spacer(Modifier.width(4.dp))

                // Subtitles
                IconButton(onClick = onSubtitleClick) {
                    Icon(
                        if (state.subtitleTrackIndex >= 0) Icons.Default.Subtitles else Icons.Default.SubtitlesOff,
                        "Subtitles",
                        tint = if (state.subtitleTrackIndex >= 0) AccentColor else Color.White.copy(alpha = 0.5f),
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Equalizer
                IconButton(onClick = onEqualizer) {
                    Icon(Icons.Default.GraphicEq, "EQ", tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
                }

                // Rotation toggle
                IconButton(onClick = onRotation) {
                    Icon(Icons.Default.ScreenRotation, "Rotation", tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
                }

                // Bookmark at current position
                IconButton(onClick = onBookmark) {
                    Icon(Icons.Default.BookmarkAdd, "Add Bookmark", tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
                }

                // Audio-only mode (screen-off background play)
                IconButton(onClick = onAudioOnlyMode) {
                    Icon(
                        if (state.isAudioOnlyMode) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
                        "Audio Only",
                        tint = if (state.isAudioOnlyMode) AccentColor else Color.White.copy(alpha = 0.8f),
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Color Filter / Smart Enhance
                IconButton(onClick = onColorFilter) {
                    val enhanceActive = state.activeEnhanceProfile != com.darkwave.player.ui.SmartEnhanceProfile.OFF || !state.colorState.isNeutral
                    Icon(
                        if (enhanceActive) Icons.Default.AutoAwesome else Icons.Default.Palette,
                        "Video Enhancement",
                        tint = when {
                            state.showColorFilter -> AccentColor
                            enhanceActive         -> Color(0xFFCE93D8)
                            else                  -> Color.White.copy(alpha = 0.8f)
                        },
                        modifier = Modifier.size(20.dp)
                    )
                }

                // Chapters
                IconButton(onClick = onChapters) {
                    Icon(Icons.Default.MenuBook, "Chapters", tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
                }

                // Cast
                IconButton(onClick = onCast) {
                    Icon(Icons.Default.Cast, "Cast", tint = if (state.activeCastDeviceId != null) AccentColor else Color.White.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
                }

                // Clock overlay toggle
                IconButton(onClick = onToggleClock) {
                    Icon(Icons.Default.Schedule, "Clock", tint = if (state.showClock) AccentColor else Color.White.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
                }

                // Floating/Popup player
                IconButton(onClick = onFloatingPlayer) {
                    Icon(Icons.Default.OpenInNew, "Float", tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
                }

                // PiP (Picture in Picture)
                IconButton(onClick = onPipClick) {
                    Icon(Icons.Default.PictureInPictureAlt, "PiP", tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

// ── Small helpers ─────────────────────────────────────────────────────────

@Composable
private fun Chip(text: String, onClick: () -> Unit) {
    Surface(
        shape  = RoundedCornerShape(6.dp),
        color  = Color.White.copy(alpha = 0.18f),
        modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable(onClick = onClick)
    ) {
        Text(text, color = Color.White, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
    }
}

@Composable
private fun VolumeChip(volumePercent: Int, onClick: () -> Unit) {
    val isBoost = volumePercent > 100
    Surface(
        shape  = RoundedCornerShape(6.dp),
        color  = if (isBoost) Color(0xFFE53935).copy(alpha = 0.25f) else Color.White.copy(alpha = 0.18f),
        modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.VolumeUp, null,
                tint = if (isBoost) Color(0xFFE53935) else Color.White,
                modifier = Modifier.size(12.dp))
            Spacer(Modifier.width(3.dp))
            Text("$volumePercent%",
                color = if (isBoost) Color(0xFFE53935) else Color.White,
                fontSize = 12.sp,
                fontWeight = if (isBoost) FontWeight.Bold else FontWeight.Normal)
        }
    }
}

@Composable
private fun AudioTrackButton(trackCount: Int, selectedIndex: Int, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (trackCount > 1) AccentColor.copy(alpha = 0.2f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AudioTrack, "Audio Track",
                tint = if (trackCount > 1) AccentColor else Color.White.copy(alpha = 0.5f),
                modifier = Modifier.size(18.dp))
            if (trackCount > 1) {
                Spacer(Modifier.width(3.dp))
                Text("${selectedIndex + 1}/$trackCount", color = AccentColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun PlayerCenterButton(icon: ImageVector, description: String, onClick: () -> Unit, size: Dp) {
    IconButton(
        onClick  = onClick,
        modifier = Modifier.size(size).clip(CircleShape).background(Color.White.copy(alpha = 0.12f))
    ) {
        Icon(icon, description, tint = Color.White, modifier = Modifier.size(size * 0.55f))
    }
}
