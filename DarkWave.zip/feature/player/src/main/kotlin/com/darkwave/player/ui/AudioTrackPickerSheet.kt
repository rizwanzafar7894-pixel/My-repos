package com.darkwave.player.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.player.viewmodel.AudioTrackInfo

private val SheetBg     = Color(0xF2111120)
private val SelectedBg  = Color(0xFF1E1E35)
private val AccentColor = Color(0xFF5C6BC0)
private val TextPrim    = Color(0xFFFFFFFF)
private val TextSec     = Color(0xFFAAAAAA)

@Composable
fun AudioTrackPickerSheet(
    tracks: List<AudioTrackInfo>,
    selectedIndex: Int,
    onTrackSelected: (Int) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .background(SheetBg)
    ) {
        Column {
            // ── Handle ────────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(top = 10.dp)
                    .size(width = 40.dp, height = 4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.25f))
            )

            // ── Header ────────────────────────────────────────────────
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    Icons.Default.AudioTrack,
                    null,
                    tint = AccentColor,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    "Audio Track",
                    color = TextPrim,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    "${tracks.size} track${if (tracks.size != 1) "s" else ""}",
                    color = TextSec,
                    fontSize = 13.sp
                )
            }

            Divider(color = Color.White.copy(alpha = 0.08f))

            // ── Track list ────────────────────────────────────────────
            if (tracks.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            Icons.Default.HearingDisabled,
                            null,
                            tint = TextSec,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "No audio tracks found",
                            color = TextSec,
                            fontSize = 14.sp
                        )
                        Text(
                            "Video may have only one embedded track",
                            color = TextSec.copy(alpha = 0.6f),
                            fontSize = 12.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 360.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    itemsIndexed(tracks) { index, track ->
                        AudioTrackRow(
                            track    = track,
                            selected = selectedIndex == index,
                            onClick  = { onTrackSelected(index) }
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun AudioTrackRow(
    track: AudioTrackInfo,
    selected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .background(if (selected) SelectedBg else Color.Transparent)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // ── Language badge ────────────────────────────────────────────
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(
                    if (selected) AccentColor.copy(alpha = 0.25f)
                    else Color.White.copy(alpha = 0.07f)
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = track.language.uppercase().take(2),
                color = if (selected) AccentColor else TextSec,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }

        Spacer(Modifier.width(14.dp))

        // ── Track info ────────────────────────────────────────────────
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = track.label,
                color = if (selected) TextPrim else TextPrim.copy(alpha = 0.85f),
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            // Sub-info chips
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (track.channels > 0) {
                    TrackChip(
                        channelsToLabel(track.channels),
                        if (track.channels >= 6) AccentColor else TextSec
                    )
                }
                if (track.sampleRate > 0) {
                    TrackChip("${track.sampleRate / 1000}kHz", TextSec)
                }
                if (track.bitrate > 0) {
                    TrackChip("${track.bitrate / 1000}kbps", TextSec)
                }
            }
        }

        // ── Selected checkmark ────────────────────────────────────────
        if (selected) {
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(AccentColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Check,
                    null,
                    tint = Color.White,
                    modifier = Modifier.size(15.dp)
                )
            }
        } else {
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.08f))
            )
        }
    }
}

@Composable
private fun TrackChip(label: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(color.copy(alpha = 0.12f))
            .padding(horizontal = 5.dp, vertical = 2.dp)
    ) {
        Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.Medium)
    }
}

private fun channelsToLabel(ch: Int) = when (ch) {
    1    -> "Mono"
    2    -> "Stereo"
    6    -> "5.1"
    8    -> "7.1"
    else -> "${ch}ch"
}
