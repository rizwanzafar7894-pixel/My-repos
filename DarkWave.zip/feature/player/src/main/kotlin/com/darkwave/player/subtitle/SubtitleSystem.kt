package com.darkwave.player.subtitle

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

// ─────────────────────────────────────────────────────────────────────────────
// DATA MODEL
// ─────────────────────────────────────────────────────────────────────────────
data class SubtitleEntry(
    val startMs: Long,
    val endMs: Long,
    val text: String
)

// ─────────────────────────────────────────────────────────────────────────────
// PARSERS  (SRT + WebVTT + ASS/SSA basic support)
// ─────────────────────────────────────────────────────────────────────────────
object SubtitleParser {

    fun parse(file: File): List<SubtitleEntry> {
        val text = file.readText(Charsets.UTF_8)
        return when {
            file.extension.lowercase() == "srt"  -> parseSrt(text)
            file.extension.lowercase() == "vtt"  -> parseVtt(text)
            file.extension.lowercase() in listOf("ass", "ssa") -> parseAss(text)
            else -> parseSrt(text) // fallback
        }
    }

    fun parseSrt(content: String): List<SubtitleEntry> {
        val entries = mutableListOf<SubtitleEntry>()
        val blocks = content.trim().split(Regex("\\n\\s*\\n"))
        for (block in blocks) {
            val lines = block.trim().lines()
            if (lines.size < 3) continue
            val timeLine = lines.firstOrNull { it.contains("-->") } ?: continue
            val times = timeLine.split("-->")
            if (times.size < 2) continue
            val start = parseSrtTime(times[0].trim())
            val end   = parseSrtTime(times[1].trim().substringBefore(" "))
            val textLines = lines.dropWhile { !it.contains("-->") }.drop(1)
            val text = textLines.joinToString("\n")
                .replace(Regex("<[^>]+>"), "")  // strip HTML tags
                .trim()
            if (text.isNotEmpty()) entries.add(SubtitleEntry(start, end, text))
        }
        return entries
    }

    fun parseVtt(content: String): List<SubtitleEntry> {
        val entries = mutableListOf<SubtitleEntry>()
        val blocks = content.trim().split(Regex("\\n\\s*\\n"))
        for (block in blocks) {
            if (block.startsWith("WEBVTT") || block.startsWith("NOTE")) continue
            val lines = block.trim().lines()
            val timeLine = lines.firstOrNull { it.contains("-->") } ?: continue
            val times = timeLine.split("-->")
            if (times.size < 2) continue
            val start = parseVttTime(times[0].trim())
            val end   = parseVttTime(times[1].trim().substringBefore(" "))
            val textLines = lines.dropWhile { !it.contains("-->") }.drop(1)
            val text = textLines.joinToString("\n")
                .replace(Regex("<[^>]+>"), "")
                .trim()
            if (text.isNotEmpty()) entries.add(SubtitleEntry(start, end, text))
        }
        return entries
    }

    fun parseAss(content: String): List<SubtitleEntry> {
        val entries = mutableListOf<SubtitleEntry>()
        val lines = content.lines()
        var inEvents = false
        var formatLine = emptyList<String>()

        for (line in lines) {
            when {
                line.trim() == "[Events]" -> inEvents = true
                line.startsWith("Format:") && inEvents -> {
                    formatLine = line.removePrefix("Format:").split(",").map { it.trim() }
                }
                line.startsWith("Dialogue:") && inEvents -> {
                    val parts = line.removePrefix("Dialogue:").split(",", limit = formatLine.size)
                    if (parts.size < formatLine.size) continue
                    val startIdx = formatLine.indexOf("Start")
                    val endIdx   = formatLine.indexOf("End")
                    val textIdx  = formatLine.indexOf("Text")
                    if (startIdx < 0 || endIdx < 0 || textIdx < 0) continue
                    val start = parseAssTime(parts[startIdx].trim())
                    val end   = parseAssTime(parts[endIdx].trim())
                    val text  = parts[textIdx].trim()
                        .replace(Regex("\\{[^}]+\\}"), "")  // strip ASS tags
                        .replace("\\N", "\n")
                    if (text.isNotEmpty()) entries.add(SubtitleEntry(start, end, text))
                }
            }
        }
        return entries
    }

    // ── Time parsers ─────────────────────────────────────────────────────────
    private fun parseSrtTime(time: String): Long {
        // Format: HH:MM:SS,mmm
        return try {
            val (hms, ms) = time.split(",")
            val (h, m, s) = hms.split(":").map { it.toLong() }
            h * 3_600_000 + m * 60_000 + s * 1_000 + ms.toLong()
        } catch (e: Exception) { 0L }
    }

    private fun parseVttTime(time: String): Long {
        // Format: HH:MM:SS.mmm or MM:SS.mmm
        return try {
            val parts = time.split(":")
            val (sec, ms) = parts.last().split(".").map { it.toLong() }
            val minutes = if (parts.size >= 2) parts[parts.size - 2].toLong() else 0L
            val hours   = if (parts.size >= 3) parts[0].toLong() else 0L
            hours * 3_600_000 + minutes * 60_000 + sec * 1_000 + ms
        } catch (e: Exception) { 0L }
    }

    private fun parseAssTime(time: String): Long {
        // Format: H:MM:SS.cc (centiseconds)
        return try {
            val (hms, cs) = time.split(".")
            val (h, m, s) = hms.split(":").map { it.toLong() }
            h * 3_600_000 + m * 60_000 + s * 1_000 + cs.toLong() * 10
        } catch (e: Exception) { 0L }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// SUBTITLE MANAGER
// ─────────────────────────────────────────────────────────────────────────────
class SubtitleManager {
    private var entries: List<SubtitleEntry> = emptyList()
    private var delayMs: Long = 0L

    fun load(file: File) {
        entries = SubtitleParser.parse(file).sortedBy { it.startMs }
    }

    fun loadFromContent(content: String, format: String = "srt") {
        entries = when (format.lowercase()) {
            "vtt" -> SubtitleParser.parseVtt(content)
            "ass", "ssa" -> SubtitleParser.parseAss(content)
            else -> SubtitleParser.parseSrt(content)
        }.sortedBy { it.startMs }
    }

    fun setDelay(ms: Long) { delayMs = ms }

    fun getSubtitleAt(positionMs: Long): String? {
        val adjusted = positionMs - delayMs
        return entries.firstOrNull { adjusted in it.startMs..it.endMs }?.text
    }

    fun clear() { entries = emptyList() }

    fun hasSubtitles() = entries.isNotEmpty()
}

// ─────────────────────────────────────────────────────────────────────────────
// SUBTITLE OVERLAY COMPOSABLE
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun SubtitleOverlay(
    subtitle: String?,
    modifier: Modifier = Modifier,
    textSize: Float = 16f,
    textColor: Color = Color.White,
    backgroundColor: Color = Color.Black.copy(alpha = 0.55f),
    bottomPadding: Int = 48
) {
    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.BottomCenter
    ) {
        AnimatedVisibility(
            visible = !subtitle.isNullOrBlank(),
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.padding(
                horizontal = 24.dp,
                vertical = bottomPadding.dp
            )
        ) {
            if (!subtitle.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .background(backgroundColor, RoundedCornerShape(6.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = subtitle,
                        color = textColor,
                        fontSize = textSize.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        lineHeight = (textSize * 1.4f).sp
                    )
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// HOW TO USE IN VideoPlayerScreen.kt
// ─────────────────────────────────────────────────────────────────────────────
/*
In VideoPlayerViewModel, add:
    val subtitleManager = SubtitleManager()
    var currentSubtitle by mutableStateOf<String?>(null)
        private set

    // Call this when position updates:
    fun onPositionChanged(posMs: Long) {
        currentSubtitle = subtitleManager.getSubtitleAt(posMs)
    }

    // Load subtitle file:
    fun loadSubtitle(file: java.io.File) {
        subtitleManager.load(file)
    }

In VideoPlayerScreen.kt, add inside your main Box:
    SubtitleOverlay(
        subtitle = viewModel.currentSubtitle,
        bottomPadding = if (showControls) 80 else 48
    )

For subtitle track picker, add a button in PlayerControlsOverlay that shows
a BottomSheet with available subtitle files from the same directory as the video.
*/
