package com.darkwave.player.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val SheetBg     = Color(0xFF0E0E1E)
private val CardBg      = Color(0xFF1A1A2E)
private val AccentColor = Color(0xFF7C4DFF)
private val AccentGlow  = Color(0xFF5C35CC)
private val WarnColor   = Color(0xFFFFB300)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoColorFilterSheet(
    colorState:         VideoColorState,
    activeProfile:      SmartEnhanceProfile,
    isAnalyzing:        Boolean,
    onProfileSelected:  (SmartEnhanceProfile) -> Unit,
    onSmartEnhanceAuto: () -> Unit,
    onBrightnessChange: (Float) -> Unit,
    onContrastChange:   (Float) -> Unit,
    onSaturationChange: (Float) -> Unit,
    onHueChange:        (Float) -> Unit,
    onGammaChange:      (Float) -> Unit,
    onSharpnessChange:  (Float) -> Unit,
    onNoiseReduction:   (Boolean) -> Unit,
    onReset:            () -> Unit,
    onDismiss:          () -> Unit,
    modifier: Modifier = Modifier
) {
    var activeTab by remember { mutableIntStateOf(0) }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        color    = SheetBg
    ) {
        Column(modifier = Modifier.padding(bottom = 28.dp)) {

            // ── Drag handle ─────────────────────────────────────────────
            Box(Modifier.fillMaxWidth().padding(top = 10.dp), Alignment.Center) {
                Box(Modifier.width(36.dp).height(4.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.18f)))
            }

            // ── Header ──────────────────────────────────────────────────
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
                Arrangement.SpaceBetween, Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Animated icon: spin when analyzing
                    val spin by rememberInfiniteTransition(label = "spin").animateFloat(
                        initialValue   = 0f, targetValue = if (isAnalyzing) 360f else 0f,
                        animationSpec  = if (isAnalyzing) infiniteRepeatable(tween(900, easing = LinearEasing)) else snap(),
                        label          = "spinAngle"
                    )
                    Box(
                        Modifier.size(38.dp).clip(CircleShape)
                            .background(Brush.radialGradient(listOf(AccentColor, AccentGlow))),
                        Alignment.Center
                    ) {
                        Icon(
                            if (isAnalyzing) Icons.Default.AutoFixHigh else Icons.Default.AutoAwesome,
                            null, tint = Color.White,
                            modifier = Modifier.size(20.dp).rotate(spin)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text("Video Enhancement", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        AnimatedContent(targetState = isAnalyzing to activeProfile, label = "subtitle") { (analyzing, profile) ->
                            Text(
                                when {
                                    analyzing            -> "Analyzing video frame…"
                                    profile == SmartEnhanceProfile.OFF -> "Off — tap a profile to enhance"
                                    else                 -> "${profile.icon} ${profile.label} · ${profile.description}"
                                },
                                color = if (analyzing) WarnColor else AccentColor, fontSize = 11.sp
                            )
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (activeProfile != SmartEnhanceProfile.OFF || !colorState.isNeutral) {
                        TextButton(onClick = onReset, contentPadding = PaddingValues(horizontal = 8.dp)) {
                            Text("Reset", color = Color.White.copy(alpha = 0.45f), fontSize = 12.sp)
                        }
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Close, null, tint = Color.White.copy(alpha = 0.45f), modifier = Modifier.size(18.dp))
                    }
                }
            }

            // ── Active profile badge ─────────────────────────────────────
            if (activeProfile != SmartEnhanceProfile.OFF) {
                Row(
                    Modifier.padding(horizontal = 20.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val cs = activeProfile.toColorState()
                    listOf(
                        "☀ ${if (cs.brightness >= 0) "+" else ""}${(cs.brightness * 100).toInt()}%" to "Bright",
                        "◑ ${"%.2f".format(cs.contrast)}x" to "Contrast",
                        "⬤ ${"%.2f".format(cs.saturation)}x" to "Color",
                        "△ ${(cs.sharpness * 100).toInt()}%" to "Sharp"
                    ).forEach { (value, label) ->
                        Card(Modifier.weight(1f), RoundedCornerShape(10.dp),
                            CardDefaults.cardColors(containerColor = AccentColor.copy(alpha = 0.15f))) {
                            Column(Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(value, color = AccentColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                Text(label, color = Color.White.copy(alpha = 0.4f), fontSize = 8.sp)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
            }

            // ── Tab row ─────────────────────────────────────────────────
            TabRow(
                selectedTabIndex = activeTab,
                containerColor   = CardBg,
                contentColor     = AccentColor,
                indicator = { positions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(positions[activeTab]), color = AccentColor)
                },
                divider = {}
            ) {
                listOf("✨ Smart Enhance", "🎨 Manual").forEachIndexed { i, label ->
                    Tab(selected = activeTab == i, onClick = { activeTab = i }) {
                        Text(label, Modifier.padding(vertical = 12.dp),
                            color = if (activeTab == i) AccentColor else Color.White.copy(alpha = 0.45f),
                            fontSize = 13.sp, fontWeight = if (activeTab == i) FontWeight.SemiBold else FontWeight.Normal)
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            AnimatedContent(targetState = activeTab, transitionSpec = {
                fadeIn(tween(180)) togetherWith fadeOut(tween(180))
            }, label = "tabContent") { tab ->
                when (tab) {
                    0 -> SmartEnhanceTab(activeProfile, isAnalyzing, onProfileSelected, onSmartEnhanceAuto)
                    1 -> ManualTab(colorState, onBrightnessChange, onContrastChange, onSaturationChange, onHueChange, onGammaChange, onSharpnessChange, onNoiseReduction)
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Smart Enhance Tab
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun SmartEnhanceTab(
    activeProfile:     SmartEnhanceProfile,
    isAnalyzing:       Boolean,
    onProfileSelected: (SmartEnhanceProfile) -> Unit,
    onSmartAuto:       () -> Unit
) {
    Column(Modifier.padding(horizontal = 16.dp)) {

        // Auto Smart Enhance button
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(Brush.horizontalGradient(listOf(Color(0xFF4527A0), AccentColor, Color(0xFF0097A7))))
                .clickable(enabled = !isAnalyzing, onClick = onSmartAuto)
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.15f)),
                    Alignment.Center
                ) {
                    if (isAnalyzing) {
                        CircularProgressIndicator(
                            color = Color.White, strokeWidth = 2.dp,
                            modifier = Modifier.size(26.dp)
                        )
                    } else {
                        Icon(Icons.Default.AutoFixHigh, null, tint = Color.White, modifier = Modifier.size(26.dp))
                    }
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        if (isAnalyzing) "Analyzing frame…" else "✨ Auto Smart Enhance",
                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp
                    )
                    Text(
                        if (isAnalyzing)
                            "Reading brightness, contrast & colors"
                        else
                            "Analyzes current frame → picks best profile automatically",
                        color = Color.White.copy(alpha = 0.75f), fontSize = 11.sp
                    )
                }
                if (!isAnalyzing) {
                    Icon(Icons.Default.ChevronRight, null, tint = Color.White.copy(alpha = 0.7f))
                }
            }
        }

        Spacer(Modifier.height(18.dp))

        Text(
            "Enhancement Profiles",
            color = Color.White.copy(alpha = 0.55f), fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 4.dp, bottom = 10.dp)
        )

        // 4-column profile grid
        val profiles = SmartEnhanceProfile.entries
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement   = Arrangement.spacedBy(8.dp),
            modifier = Modifier.heightIn(max = 260.dp),
            userScrollEnabled = false
        ) {
            items(profiles.size) { i ->
                val p = profiles[i]
                ProfileCard(p, activeProfile == p) { onProfileSelected(p) }
            }
        }
    }
}

@Composable
private fun ProfileCard(profile: SmartEnhanceProfile, isActive: Boolean, onClick: () -> Unit) {
    val borderColor = if (isActive) AccentColor else Color.White.copy(alpha = 0.07f)
    Box(
        Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (isActive) Brush.linearGradient(listOf(AccentColor.copy(alpha = 0.8f), AccentGlow))
                        else Brush.linearGradient(listOf(CardBg, CardBg)))
            .border(BorderStroke(if (isActive) 1.5.dp else 1.dp, borderColor), RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 10.dp, horizontal = 6.dp),
        Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(profile.icon, fontSize = 20.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                profile.label, textAlign = TextAlign.Center,
                color = if (isActive) Color.White else Color.White.copy(alpha = 0.7f),
                fontSize = 10.sp, fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Manual Tab
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun ManualTab(
    cs: VideoColorState,
    onBrightness: (Float) -> Unit,
    onContrast:   (Float) -> Unit,
    onSaturation: (Float) -> Unit,
    onHue:        (Float) -> Unit,
    onGamma:      (Float) -> Unit,
    onSharpness:  (Float) -> Unit,
    onNR:         (Boolean) -> Unit
) {
    Column(Modifier.padding(horizontal = 20.dp)) {

        // Quick preset chips
        data class Preset(val name: String, val state: VideoColorState)
        val presets = listOf(
            Preset("Normal",  VideoColorState()),
            Preset("Vivid",   SmartEnhanceProfile.VIVID.toColorState()),
            Preset("Cinema",  SmartEnhanceProfile.CINEMA.toColorState()),
            Preset("Night",   SmartEnhanceProfile.NIGHT.toColorState()),
            Preset("HDR",     SmartEnhanceProfile.HDR_SIM.toColorState()),
            Preset("B&W",     VideoColorState(saturation = 0f)),
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            presets.forEach { p ->
                val isActive = cs == p.state
                Box(
                    Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isActive) AccentColor else CardBg)
                        .border(BorderStroke(1.dp, if (isActive) AccentColor else Color.White.copy(alpha = 0.1f)), RoundedCornerShape(20.dp))
                        .clickable {
                            onBrightness(p.state.brightness); onContrast(p.state.contrast)
                            onSaturation(p.state.saturation); onHue(p.state.hue)
                            onGamma(p.state.gamma); onSharpness(p.state.sharpness)
                            onNR(p.state.noiseReduction)
                        }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                ) {
                    Text(p.name, color = Color.White, fontSize = 12.sp,
                        fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // Sliders
        EnhanceSlider("☀  Brightness", cs.brightness, -1f,   1f,   0f, "${(cs.brightness*100).toInt()}%", onBrightness)
        EnhanceSlider("◑  Contrast",   cs.contrast,   0.5f,  2f,   1f, "${"%.2f".format(cs.contrast)}x", onContrast)
        EnhanceSlider("⬤  Saturation", cs.saturation, 0f,    2f,   1f, "${"%.2f".format(cs.saturation)}x", onSaturation)
        EnhanceSlider("△  Sharpness",  cs.sharpness,  0f,    1f,   0f, "${(cs.sharpness*100).toInt()}%", onSharpness)
        EnhanceSlider("γ  Gamma",      cs.gamma,      0.5f,  2f,   1f, "${"%.2f".format(cs.gamma)}", onGamma)
        EnhanceSlider("◷  Hue Shift",  cs.hue,       -180f, 180f,  0f, "${cs.hue.toInt()}°", onHue)

        Spacer(Modifier.height(6.dp))

        // Noise Reduction toggle
        Card(Modifier.fillMaxWidth(), RoundedCornerShape(14.dp),
            CardDefaults.cardColors(containerColor = CardBg)) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(36.dp).clip(CircleShape)
                    .background(if (cs.noiseReduction) AccentColor.copy(alpha = 0.2f) else Color.White.copy(alpha = 0.05f)),
                    Alignment.Center) {
                    Icon(Icons.Default.Flare, null,
                        tint = if (cs.noiseReduction) AccentColor else Color.White.copy(alpha = 0.3f),
                        modifier = Modifier.size(18.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Noise Reduction", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text("Smooths grain in low-light scenes", color = Color.White.copy(alpha = 0.35f), fontSize = 10.sp)
                }
                Switch(
                    checked = cs.noiseReduction, onCheckedChange = onNR,
                    colors  = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = AccentColor,
                        uncheckedThumbColor = Color.Gray, uncheckedTrackColor = Color.White.copy(alpha = 0.15f))
                )
            }
        }

        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun EnhanceSlider(
    label: String, value: Float, min: Float, max: Float, neutral: Float,
    display: String, onChange: (Float) -> Unit
) {
    val changed = value != neutral
    Column(Modifier.padding(vertical = 2.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(label, color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (changed) {
                    Box(Modifier.size(6.dp).clip(CircleShape).background(AccentColor))
                    Spacer(Modifier.width(4.dp))
                }
                Text(display,
                    color = if (changed) AccentColor else Color.White.copy(alpha = 0.28f),
                    fontSize = 12.sp, fontWeight = if (changed) FontWeight.SemiBold else FontWeight.Normal)
            }
        }
        Slider(
            value = value, onValueChange = onChange, valueRange = min..max,
            colors = SliderDefaults.colors(
                thumbColor         = if (changed) AccentColor else Color(0xFF555577),
                activeTrackColor   = AccentColor,
                inactiveTrackColor = Color.White.copy(alpha = 0.12f)
            ),
            modifier = Modifier.height(30.dp)
        )
    }
}
