package com.darkwave.player.ui

import android.graphics.ColorMatrixColorFilter
import android.view.View
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView

fun indexToResizeMode(index: Int): Int = when (index) {
    0 -> AspectRatioFrameLayout.RESIZE_MODE_FIT
    1 -> AspectRatioFrameLayout.RESIZE_MODE_FILL
    2 -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH
    3 -> AspectRatioFrameLayout.RESIZE_MODE_FIXED_HEIGHT
    4 -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
    else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
}

@Composable
fun PlayerSurface(
    player: ExoPlayer,
    aspectRatioIndex: Int = 0,
    zoomScale: Float = 1f,
    colorState: VideoColorState = VideoColorState(),
    modifier: Modifier = Modifier
) {
    AndroidView(
        factory = { context ->
            PlayerView(context).apply {
                this.player   = player
                useController = false
                setShowBuffering(PlayerView.SHOW_BUFFERING_NEVER)
                resizeMode = indexToResizeMode(aspectRatioIndex)
            }
        },
        update = { view ->
            view.player     = player
            view.resizeMode = indexToResizeMode(aspectRatioIndex)

            if (colorState.isNeutral) {
                applyColorFilterToView(view, null)
            } else {
                val cm     = buildColorMatrix(colorState)
                val filter = ColorMatrixColorFilter(cm)
                applyColorFilterToView(view, filter)
            }
        },
        modifier = modifier.graphicsLayer(
            scaleX = zoomScale.coerceIn(0.5f, 4f),
            scaleY = zoomScale.coerceIn(0.5f, 4f)
        )
    )
}

private fun applyColorFilterToView(playerView: PlayerView, filter: ColorMatrixColorFilter?) {
    try {
        playerView.videoSurfaceView?.let { surfaceView ->
            if (surfaceView is android.view.TextureView) {
                if (filter != null) {
                    surfaceView.setLayerType(View.LAYER_TYPE_HARDWARE, android.graphics.Paint().apply {
                        colorFilter = filter
                    })
                } else {
                    surfaceView.setLayerType(View.LAYER_TYPE_HARDWARE, null)
                }
            }
        }
    } catch (_: Exception) {}
}
