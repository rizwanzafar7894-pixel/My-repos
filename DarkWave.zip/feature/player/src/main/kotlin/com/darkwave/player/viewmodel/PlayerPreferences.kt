package com.darkwave.player.viewmodel

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

// Separate datastore file for player settings — does NOT conflict with app-level datastore
private val Context.playerPrefsStore by preferencesDataStore(name = "player_prefs")

@Singleton
class PlayerPreferences @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private val store get() = context.playerPrefsStore

    companion object {
        val KEY_SPEED         = floatPreferencesKey("speed")
        val KEY_ASPECT        = intPreferencesKey("aspect")
        val KEY_VOLUME        = intPreferencesKey("volume_pct")
        val KEY_BRIGHTNESS    = floatPreferencesKey("brightness")
        val KEY_HW_DECODING   = booleanPreferencesKey("hw_decode")
        val KEY_SUBTITLE_SIZE = floatPreferencesKey("sub_size")
    }

    val speed:        Flow<Float>   = pref { it[KEY_SPEED]         ?: 1f }
    val aspectIndex:  Flow<Int>     = pref { it[KEY_ASPECT]        ?: 0 }
    val volumePercent:Flow<Int>     = pref { it[KEY_VOLUME]        ?: 100 }
    val brightness:   Flow<Float>   = pref { it[KEY_BRIGHTNESS]    ?: 0.5f }
    val hwDecoding:   Flow<Boolean> = pref { it[KEY_HW_DECODING]   ?: true }
    val subtitleSize: Flow<Float>   = pref { it[KEY_SUBTITLE_SIZE] ?: 16f }

    suspend fun saveSpeed(v: Float)       { store.edit { it[KEY_SPEED]         = v } }
    suspend fun saveAspect(v: Int)        { store.edit { it[KEY_ASPECT]        = v } }
    suspend fun saveVolume(v: Int)        { store.edit { it[KEY_VOLUME]        = v } }
    suspend fun saveBrightness(v: Float)  { store.edit { it[KEY_BRIGHTNESS]    = v } }
    suspend fun saveHwDecoding(v: Boolean){ store.edit { it[KEY_HW_DECODING]   = v } }
    suspend fun saveSubtitleSize(v: Float){ store.edit { it[KEY_SUBTITLE_SIZE] = v } }

    private fun <T> pref(mapper: (androidx.datastore.preferences.core.Preferences) -> T): Flow<T> =
        store.data.catch { emit(emptyPreferences()) }.map(mapper)
}
