package com.darkwave.player.viewmodel

import android.content.Context
import android.content.ContentValues
import android.graphics.Bitmap
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.view.SurfaceView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import com.darkwave.domain.repository.MediaRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.io.File
import java.io.OutputStream
import javax.inject.Inject
import javax.inject.Named

// ── Models ────────────────────────────────────────────────────────────────
data class AudioTrackInfo(
    val index: Int,
    val label: String,
    val language: String,
    val codec: String,
    val channels: Int,
    val sampleRate: Int,
    val bitrate: Int
)

data class SubtitleTrack(val name: String, val filePath: String)

data class PlayerUiState(
    val title: String = "",
    val uri: String = "",
    val isPlaying: Boolean = false,
    val isBuffering: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val bufferedPositionMs: Long = 0L,
    val playbackSpeed: Float = 1f,
    val isMuted: Boolean = false,
    val isLocked: Boolean = false,
    val brightness: Float = 0.5f,

    // Volume
    val volume: Float = 1f,
    val volumeBoostGain: Int = 0,
    val volumePercent: Int = 100,
    val showVolumeBoostWarning: Boolean = false,

    // Controls visibility
    val showControls: Boolean = true,
    val isFullscreen: Boolean = true,
    val isPipMode: Boolean = false,

    // Aspect ratio & zoom
    val aspectRatio: Float = 16f / 9f,
    val aspectRatioIndex: Int = 0,
    val zoomScale: Float = 1f,
    val videoWidth: Int = 0,
    val videoHeight: Int = 0,

    // Long-press 2x speed
    val isTempSpeed2x: Boolean = false,
    val speedBeforeTemp: Float = 1f,

    // Menus
    val showSpeedMenu: Boolean = false,
    val showAspectMenu: Boolean = false,
    val showSubtitleMenu: Boolean = false,
    val showAudioTrackMenu: Boolean = false,
    val showVolumeBoostMenu: Boolean = false,
    val showVideoInfo: Boolean = false,
    val showSleepTimer: Boolean = false,
    val showSubtitleDelayMenu: Boolean = false,
    val showSubtitleStyleMenu: Boolean = false,
    val showNetworkUrlDialog: Boolean = false,

    // Subtitles
    val subtitleTracks: List<SubtitleTrack> = emptyList(),
    val subtitleTrackIndex: Int = -1,
    val currentSubtitle: String? = null,
    val subtitleDelayMs: Long = 0L,
    val subtitleFontSize: Float = 16f,
    val subtitleColor: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.White,
    val subtitleBgColor: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.55f),

    // Audio tracks
    val audioTracks: List<AudioTrackInfo> = emptyList(),
    val selectedAudioTrackIndex: Int = 0,
    val audioTrackIndex: Int = 0,

    // Seek flash
    val doubleTapSeekSide: SeekSide? = null,
    val repeatMode: Int = Player.REPEAT_MODE_OFF,
    val errorMessage: String? = null,

    // Sleep timer
    val sleepTimerRemainingMs: Long = 0L,

    // Screenshot flash
    val showScreenshotFlash: Boolean = false,

    // Playlist
    val playlist: List<String> = emptyList(),
    val currentPlaylistIndex: Int = 0,

    // Network URL
    val networkUrl: String = "",

    // Video Equalizer
    val showVideoEq: Boolean = false,

    // Hardware decoder
    val useHardwareDecoding: Boolean = true,

    // Audio-only mode (screen-off background play)
    val isAudioOnlyMode: Boolean = false,

    // Color filter + Smart Enhance
    val colorState: com.darkwave.player.ui.VideoColorState = com.darkwave.player.ui.VideoColorState(),
    val activeEnhanceProfile: com.darkwave.player.ui.SmartEnhanceProfile = com.darkwave.player.ui.SmartEnhanceProfile.OFF,
    val isSmartEnhancing: Boolean = false,   // true while auto-analysis is running
    val showColorFilter: Boolean = false,

    // Chapters
    val chapters: List<com.darkwave.player.ui.Chapter> = emptyList(),
    val showChapters: Boolean = false,

    // Cast
    val castDevices: List<com.darkwave.player.ui.CastDevice> = emptyList(),
    val showCastSheet: Boolean = false,
    val isCastScanning: Boolean = false,
    val activeCastDeviceId: String? = null,

    // Clock overlay
    val showClock: Boolean = false,

    // Resume position
    val resumedFromMs: Long = 0L,
    val showResumePrompt: Boolean = false,

    // Rotation mode
    val rotationMode: RotationMode = RotationMode.SENSOR_LANDSCAPE,

    // Bookmark from player
    val showBookmarkSaved: Boolean = false,

    // Frame step
    val frameStepActive: Boolean = false
)

enum class RotationMode { PORTRAIT, LANDSCAPE, SENSOR_LANDSCAPE, REVERSE_LANDSCAPE }

enum class SeekSide { LEFT, RIGHT }

val playbackSpeeds = listOf(0.25f, 0.5f, 0.75f, 1f, 1.25f, 1.5f, 1.75f, 2f, 3f)

@HiltViewModel
class VideoPlayerViewModel @Inject constructor(
    @ApplicationContext private val context: Context,
    @Named("video") val player: ExoPlayer,
    private val mediaRepository: MediaRepository,
    private val playerPrefs: PlayerPreferences
) : ViewModel() {

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    private var loudnessEnhancer: LoudnessEnhancer? = null
    private val subtitleManager = com.darkwave.player.subtitle.SubtitleManager()
    private var controlsJob: Job? = null
    private var progressJob: Job? = null
    private var sleepTimerJob: Job? = null

    init {
        loadSavedPreferences()
    }

    private fun loadSavedPreferences() {
        viewModelScope.launch {
            // Read each pref once (first value) and apply
            val speed  = playerPrefs.speed.first()
            val aspect = playerPrefs.aspectIndex.first()
            val vol    = playerPrefs.volumePercent.first()
            val bright = playerPrefs.brightness.first()

            player.setPlaybackSpeed(speed)
            _uiState.update { it.copy(
                playbackSpeed    = speed,
                aspectRatioIndex = aspect,
                volumePercent    = vol,
                brightness       = bright
            ) }

            // Apply saved volume level
            try {
                val am    = context.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
                val max   = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, (max * vol / 100).coerceIn(0, max), 0)
            } catch (_: Exception) {}
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            _uiState.update { it.copy(isPlaying = isPlaying) }
            if (isPlaying) startProgressTracking() else stopProgressTracking()
        }

        override fun onPlaybackStateChanged(state: Int) {
            _uiState.update {
                it.copy(
                    isBuffering  = state == Player.STATE_BUFFERING,
                    durationMs   = player.duration.coerceAtLeast(0L),
                    errorMessage = if (state == Player.STATE_IDLE) "Playback error" else null
                )
            }
            if (state == Player.STATE_READY && loudnessEnhancer == null) initLoudnessEnhancer()
            // Auto-play next in playlist when video ends
            if (state == Player.STATE_ENDED) {
                val s = _uiState.value
                if (s.sleepTimerRemainingMs == -1L) { player.pause(); return }
                val nextIdx = s.currentPlaylistIndex + 1
                if (nextIdx < s.playlist.size) {
                    loadMedia(s.playlist[nextIdx], "Video ${nextIdx + 1}", nextIdx)
                }
            }
        }

        override fun onTracksChanged(tracks: Tracks) {
            // ── Embedded subtitle/text tracks (MKV, MP4, etc.) ───────────
            val embeddedSubTracks = mutableListOf<SubtitleTrack>()
            for (groupIdx in 0 until tracks.groups.size) {
                val group = tracks.groups[groupIdx]
                if (group.type == C.TRACK_TYPE_TEXT) {
                    for (trackIdx in 0 until group.length) {
                        val fmt = group.getTrackFormat(trackIdx)
                        val lang = fmt.language ?: "und"
                        val label = when {
                            fmt.label != null    -> fmt.label!!
                            lang != "und"        -> java.util.Locale(lang).displayLanguage.ifEmpty { lang }
                            else                 -> "Subtitle ${embeddedSubTracks.size + 1}"
                        }
                        val isSelected = group.isTrackSelected(trackIdx)
                        embeddedSubTracks.add(SubtitleTrack(
                            name     = "[$label]" + if (isSelected) " ✓" else "",
                            filePath = "embedded:$groupIdx:$trackIdx"  // special prefix
                        ))
                    }
                }
            }
            // Merge embedded + discovered external subs
            val allSubs = embeddedSubTracks + _uiState.value.subtitleTracks
                .filter { !it.filePath.startsWith("embedded:") }
            _uiState.update { it.copy(subtitleTracks = allSubs) }

            val audioTracks = mutableListOf<AudioTrackInfo>()
            var idx = 0
            tracks.groups.forEach { group ->
                if (group.type == C.TRACK_TYPE_AUDIO) {
                    for (i in 0 until group.length) {
                        val fmt = group.getTrackFormat(i)
                        audioTracks.add(AudioTrackInfo(
                            index      = idx++,
                            label      = buildTrackLabel(fmt),
                            language   = fmt.language ?: "und",
                            codec      = simplifyCodec(fmt.sampleMimeType ?: ""),
                            channels   = fmt.channelCount,
                            sampleRate = fmt.sampleRate,
                            bitrate    = fmt.bitrate
                        ))
                    }
                }
            }
            _uiState.update { it.copy(audioTracks = audioTracks) }
        }

        override fun onVideoSizeChanged(videoSize: VideoSize) {
            if (videoSize.width > 0 && videoSize.height > 0) {
                _uiState.update { it.copy(
                    videoWidth  = videoSize.width,
                    videoHeight = videoSize.height,
                    aspectRatio = videoSize.width.toFloat() / videoSize.height.toFloat()
                )}
            }
        }
    }

    init {
        player.addListener(playerListener)
        player.prepare()
        startPositionSaving()
    }

    // ── Media loading ─────────────────────────────────────────────────────
    fun loadMedia(uri: String, title: String, playlistIndex: Int = 0) {
        _uiState.update { it.copy(uri = uri, title = title, currentPlaylistIndex = playlistIndex) }
        val mediaItem = MediaItem.fromUri(Uri.parse(uri))
        player.setMediaItem(mediaItem)
        player.prepare()
        player.playWhenReady = true

        viewModelScope.launch(Dispatchers.IO) {
            // Restore last resume position (if any)
            val videoId = uri.hashCode().toLong().let { if (it < 0) -it else it }
            val videoItem = try { mediaRepository.getVideoById(videoId) } catch (_: Exception) { null }
            val resumeMs = videoItem?.bookmarkPosition ?: 0L
            if (resumeMs > 5000L) {
                withContext(Dispatchers.Main) {
                    player.seekTo(resumeMs)
                    _uiState.update { it.copy(resumedFromMs = resumeMs, showResumePrompt = true) }
                }
                // Auto-hide the prompt after 4s
                delay(4000)
                _uiState.update { it.copy(showResumePrompt = false) }
            }
            // Subtitle discovery
            val tracks = discoverSubtitleFiles(uri)
            _uiState.update { it.copy(subtitleTracks = tracks) }
            if (tracks.isNotEmpty()) loadSubtitleFile(File(tracks[0].filePath), 0)
        }
    }

    // Save resume position periodically and on exit
    private fun startPositionSaving() {
        viewModelScope.launch {
            while (isActive) {
                delay(5000) // save every 5 seconds
                saveCurrentPosition()
            }
        }
    }

    private suspend fun saveCurrentPosition() {
        val state = _uiState.value
        val pos = player.currentPosition
        if (pos < 5000L || state.uri.isBlank()) return
        val videoId = state.uri.hashCode().toLong().let { if (it < 0) -it else it }
        try {
            mediaRepository.toggleVideoBookmark(videoId, false, pos)
        } catch (_: Exception) {}
    }

    fun dismissResumePrompt() {
        _uiState.update { it.copy(showResumePrompt = false) }
    }

    fun seekToBeginning() {
        player.seekTo(0L)
        _uiState.update { it.copy(showResumePrompt = false) }
    }

    fun loadPlaylist(uris: List<String>) {
        _uiState.update { it.copy(playlist = uris) }
        if (uris.isNotEmpty()) loadMedia(uris[0], "Video 1", 0)
    }

    // ── Playlist navigation ───────────────────────────────────────────────
    fun playNext() {
        val s = _uiState.value
        val nextIdx = s.currentPlaylistIndex + 1
        if (nextIdx < s.playlist.size) loadMedia(s.playlist[nextIdx], "Video ${nextIdx + 1}", nextIdx)
    }

    fun playPrevious() {
        val s = _uiState.value
        if (player.currentPosition > 3000L) { seekTo(0L); return }
        val prevIdx = s.currentPlaylistIndex - 1
        if (prevIdx >= 0) loadMedia(s.playlist[prevIdx], "Video ${prevIdx + 1}", prevIdx)
    }

    // ── Audio track ───────────────────────────────────────────────────────
    fun selectAudioTrack(index: Int) {
        val tracks = _uiState.value.audioTracks
        if (index !in tracks.indices) return
        val params = player.trackSelectionParameters.buildUpon()
            .setPreferredAudioLanguage(tracks[index].language)
            .build()
        player.trackSelectionParameters = params
        _uiState.update { it.copy(selectedAudioTrackIndex = index, showAudioTrackMenu = false) }
    }

    // ── Volume boost ──────────────────────────────────────────────────────
    fun setVolumePercent(percent: Int) {
        val pct = percent.coerceIn(0, 200)
        if (pct <= 100) {
            val vol = pct / 100f
            player.volume = vol
            loudnessEnhancer?.setTargetGain(0)
            loudnessEnhancer?.enabled = false
            _uiState.update { it.copy(volume = vol, volumePercent = pct, volumeBoostGain = 0, isMuted = pct == 0, showVolumeBoostWarning = false) }
            viewModelScope.launch { playerPrefs.saveVolume(pct) }
        } else {
            val gainMb = (pct - 100) * 100
            player.volume = 1f
            try {
                if (loudnessEnhancer == null) initLoudnessEnhancer()
                loudnessEnhancer?.setTargetGain(gainMb)
                loudnessEnhancer?.enabled = true
            } catch (_: Exception) {}
            _uiState.update { it.copy(volume = 1f, volumePercent = pct, volumeBoostGain = gainMb, isMuted = false, showVolumeBoostWarning = pct > 150) }
            viewModelScope.launch { playerPrefs.saveVolume(pct) }
        }
    }

    fun setVolumeFromGesture(delta: Float) {
        val newPct = (_uiState.value.volumePercent + (-delta / 8).toInt()).coerceIn(0, 200)
        setVolumePercent(newPct)
    }

    fun toggleMute() {
        if (_uiState.value.isMuted) setVolumePercent(_uiState.value.volumePercent.coerceAtLeast(10))
        else { player.volume = 0f; loudnessEnhancer?.enabled = false; _uiState.update { it.copy(isMuted = true) } }
    }

    // ── Aspect ratio & zoom ───────────────────────────────────────────────
    fun setAspectRatio(index: Int) {
        _uiState.update { it.copy(aspectRatioIndex = index, showAspectMenu = false) }
        viewModelScope.launch { playerPrefs.saveAspect(index) }
    }
    fun setZoomScale(scale: Float)  { _uiState.update { it.copy(zoomScale = scale) } }

    // ── PiP ───────────────────────────────────────────────────────────────
    fun enterPipMode() { _uiState.update { it.copy(isPipMode = true) } }
    fun exitPipMode()  { _uiState.update { it.copy(isPipMode = false) } }

    // ── Screenshot ────────────────────────────────────────────────────────
    fun takeScreenshot(activity: android.app.Activity) {
        viewModelScope.launch {
            _uiState.update { it.copy(showScreenshotFlash = true) }
            delay(150)
            _uiState.update { it.copy(showScreenshotFlash = false) }

            withContext(Dispatchers.IO) {
                try {
                    // Get frame from ExoPlayer via MediaMetadataRetriever
                    val retriever = android.media.MediaMetadataRetriever()
                    retriever.setDataSource(context, Uri.parse(_uiState.value.uri))
                    val bitmap = retriever.getFrameAtTime(
                        player.currentPosition * 1000,
                        android.media.MediaMetadataRetriever.OPTION_CLOSEST
                    )
                    retriever.release()
                    bitmap?.let { saveBitmapToGallery(it) }
                } catch (e: Exception) {
                    android.util.Log.w("DW/Player", "Screenshot failed", e)
                }
            }
        }
    }

    private suspend fun saveBitmapToGallery(bitmap: Bitmap) {
        val filename = "DarkWave_${System.currentTimeMillis()}.jpg"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DarkWave")
            }
            val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            uri?.let {
                context.contentResolver.openOutputStream(it)?.use { stream ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
                }
            }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "DarkWave")
            dir.mkdirs()
            File(dir, filename).outputStream().use { stream ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, stream)
            }
        }
    }

    // ── Video info ────────────────────────────────────────────────────────
    fun toggleVideoInfo() { _uiState.update { it.copy(showVideoInfo = !it.showVideoInfo) } }

    // ── Sleep timer ───────────────────────────────────────────────────────
    fun setSleepTimer(ms: Long) {
        sleepTimerJob?.cancel()
        if (ms == -1L) {
            // End of video mode
            _uiState.update { it.copy(sleepTimerRemainingMs = -1L, showSleepTimer = false) }
            return
        }
        _uiState.update { it.copy(sleepTimerRemainingMs = ms, showSleepTimer = false) }
        sleepTimerJob = viewModelScope.launch {
            var remaining = ms
            while (remaining > 0) {
                delay(1000L)
                remaining -= 1000L
                _uiState.update { it.copy(sleepTimerRemainingMs = remaining.coerceAtLeast(0L)) }
            }
            player.pause()
            _uiState.update { it.copy(sleepTimerRemainingMs = 0L) }
        }
    }

    fun cancelSleepTimer() {
        sleepTimerJob?.cancel()
        _uiState.update { it.copy(sleepTimerRemainingMs = 0L, showSleepTimer = false) }
    }

    // ── Subtitle delay ────────────────────────────────────────────────────
    fun setSubtitleDelay(ms: Long) {
        subtitleManager.setDelay(ms)
        _uiState.update { it.copy(subtitleDelayMs = ms) }
    }

    // ── Subtitle ──────────────────────────────────────────────────────────
    fun selectSubtitleTrack(index: Int) {
        if (index == -1) {
            subtitleManager.clear()
            _uiState.update { it.copy(subtitleTrackIndex = -1, currentSubtitle = null, showSubtitleMenu = false) }
            return
        }
        val tracks = _uiState.value.subtitleTracks
        val track  = tracks.getOrNull(index) ?: return

        // Handle MKV/MP4 embedded text tracks (detected via TRACK_TYPE_TEXT)
        if (track.filePath.startsWith("embedded:")) {
            try {
                val parts     = track.filePath.split(":")
                val groupIdx  = parts[1].toInt()
                val trackIdx  = parts[2].toInt()
                val curTracks = player.currentTracks
                if (groupIdx < curTracks.groups.size) {
                    val group    = curTracks.groups[groupIdx]
                    val override = androidx.media3.common.TrackSelectionOverride(
                        group.mediaTrackGroup, trackIdx
                    )
                    player.trackSelectionParameters = player.trackSelectionParameters
                        .buildUpon()
                        .addOverride(override)
                        .build()
                }
                _uiState.update { it.copy(subtitleTrackIndex = index, showSubtitleMenu = false) }
            } catch (e: Exception) {
                android.util.Log.w("DW/Player", "Embedded subtitle select failed", e)
            }
            return
        }

        // External .srt / .ass file
        loadSubtitleFile(File(track.filePath), index)
        _uiState.update { it.copy(showSubtitleMenu = false) }
    }

    fun loadSubtitleFile(file: File, trackIndex: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            subtitleManager.load(file)
            _uiState.update { it.copy(subtitleTrackIndex = trackIndex) }
        }
    }

    fun pickSubtitleFile() { /* Launcher in Screen */ }

    fun loadSubtitleFromUri(uriString: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val uri  = Uri.parse(uriString)
                val name = uri.lastPathSegment ?: "subtitle"
                val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.readText() ?: return@launch
                val tmp  = File(context.cacheDir, name)
                tmp.writeText(text)
                loadSubtitleFile(tmp, _uiState.value.subtitleTracks.size)
            } catch (e: Exception) { android.util.Log.w("DW/Player", "Subtitle load failed", e) }
        }
    }

    // ── Standard controls ─────────────────────────────────────────────────
    fun togglePlayPause() {
        if (player.isPlaying) player.pause() else player.play()
        showControlsTemporarily()
    }

    fun seekTo(positionMs: Long) {
        player.seekTo(positionMs)
        _uiState.update { it.copy(currentPositionMs = positionMs) }
    }

    fun seekForward(ms: Long = 10_000L) {
        player.seekTo((player.currentPosition + ms).coerceAtMost(player.duration))
        _uiState.update { it.copy(doubleTapSeekSide = SeekSide.RIGHT) }
        viewModelScope.launch { delay(600); _uiState.update { it.copy(doubleTapSeekSide = null) } }
    }

    fun seekBackward(ms: Long = 10_000L) {
        player.seekTo((player.currentPosition - ms).coerceAtLeast(0L))
        _uiState.update { it.copy(doubleTapSeekSide = SeekSide.LEFT) }
        viewModelScope.launch { delay(600); _uiState.update { it.copy(doubleTapSeekSide = null) } }
    }

    fun setPlaybackSpeed(speed: Float) {
        player.setPlaybackSpeed(speed)
        _uiState.update { it.copy(playbackSpeed = speed, showSpeedMenu = false) }
        viewModelScope.launch { playerPrefs.saveSpeed(speed) }
    }

    fun setScreenBrightness(brightness: Float) {
        val v = brightness.coerceIn(0f, 1f)
        _uiState.update { it.copy(brightness = v) }
        viewModelScope.launch { playerPrefs.saveBrightness(v) }
    }
    fun toggleLock() { _uiState.update { it.copy(isLocked = !it.isLocked, showControls = false) } }

    // ── Menu toggles ──────────────────────────────────────────────────────
    fun toggleSubtitleMenu()     { _uiState.update { it.copy(showSubtitleMenu = !it.showSubtitleMenu, showSpeedMenu = false, showAspectMenu = false, showAudioTrackMenu = false, showVolumeBoostMenu = false, showSleepTimer = false) } }
    fun toggleAudioTrackMenu()   { _uiState.update { it.copy(showAudioTrackMenu = !it.showAudioTrackMenu, showSubtitleMenu = false, showSpeedMenu = false, showAspectMenu = false, showVolumeBoostMenu = false) } }
    fun toggleVolumeBoostMenu()  { _uiState.update { it.copy(showVolumeBoostMenu = !it.showVolumeBoostMenu, showAudioTrackMenu = false, showSubtitleMenu = false, showSpeedMenu = false, showAspectMenu = false) } }
    fun toggleSpeedMenu()        { _uiState.update { it.copy(showSpeedMenu = !it.showSpeedMenu, showAspectMenu = false, showSubtitleMenu = false, showAudioTrackMenu = false, showVolumeBoostMenu = false) } }
    fun toggleAspectMenu()       { _uiState.update { it.copy(showAspectMenu = !it.showAspectMenu, showSpeedMenu = false, showSubtitleMenu = false, showAudioTrackMenu = false, showVolumeBoostMenu = false) } }
    fun toggleSleepTimer()       { _uiState.update { it.copy(showSleepTimer = !it.showSleepTimer, showSpeedMenu = false, showAspectMenu = false, showSubtitleMenu = false, showAudioTrackMenu = false) } }
    fun toggleSubtitleDelay()    { _uiState.update { it.copy(showSubtitleDelayMenu = !it.showSubtitleDelayMenu) } }
    fun dismissMenus()           { _uiState.update { it.copy(showSpeedMenu = false, showAspectMenu = false, showSubtitleMenu = false, showAudioTrackMenu = false, showVolumeBoostMenu = false, showSleepTimer = false, showSubtitleDelayMenu = false, showSubtitleStyleMenu = false, showNetworkUrlDialog = false, showVideoEq = false, showChapters = false, showCastSheet = false, showColorFilter = false) } }

    fun showControls(autoHide: Boolean = true) {
        _uiState.update { it.copy(showControls = true) }
        if (autoHide) showControlsTemporarily()
    }
    fun hideControls()   { _uiState.update { it.copy(showControls = false) } }

    fun cycleRepeatMode() {
        val next = when (player.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ONE
            Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_ALL
            else                   -> Player.REPEAT_MODE_OFF
        }
        player.repeatMode = next
        _uiState.update { it.copy(repeatMode = next) }
    }

    // ── Private helpers ───────────────────────────────────────────────────
    private fun showControlsTemporarily() {
        controlsJob?.cancel()
        _uiState.update { it.copy(showControls = true) }
        controlsJob = viewModelScope.launch {
            delay(4000)
            if (_uiState.value.isPlaying) _uiState.update { it.copy(showControls = false) }
        }
    }

    private fun startProgressTracking() {
        progressJob?.cancel()
        progressJob = viewModelScope.launch {
            while (isActive) {
                val pos = player.currentPosition.coerceAtLeast(0L)
                _uiState.update { it.copy(
                    currentPositionMs  = pos,
                    bufferedPositionMs = player.bufferedPosition.coerceAtLeast(0L),
                    durationMs         = player.duration.coerceAtLeast(0L),
                    currentSubtitle    = subtitleManager.getSubtitleAt(pos)
                )}
                delay(100)
            }
        }
    }

    private fun stopProgressTracking() { progressJob?.cancel() }

    private fun discoverSubtitleFiles(videoUri: String): List<SubtitleTrack> {
        return try {
            val path = Uri.parse(videoUri).path ?: return emptyList()
            val videoFile = File(path)
            val dir  = videoFile.parentFile ?: return emptyList()
            val base = videoFile.nameWithoutExtension
            dir.listFiles()
                ?.filter { it.nameWithoutExtension.equals(base, ignoreCase = true) && it.extension.lowercase() in listOf("srt","vtt","ass","ssa","sub") }
                ?.map { SubtitleTrack(name = it.name, filePath = it.absolutePath) }
                ?: emptyList()
        } catch (_: Exception) { emptyList() }
    }

    private fun initLoudnessEnhancer() {
        try {
            val id = player.audioSessionId
            if (id == C.AUDIO_SESSION_ID_UNSET) return
            loudnessEnhancer?.release()
            loudnessEnhancer = LoudnessEnhancer(id).also { it.enabled = false }
        } catch (_: Exception) {}
    }

    private fun buildTrackLabel(format: androidx.media3.common.Format): String {
        val lang  = format.language?.uppercase() ?: "Unknown"
        val codec = simplifyCodec(format.sampleMimeType ?: "")
        val ch    = when (format.channelCount) { 1 -> "Mono"; 2 -> "Stereo"; 6 -> "5.1"; 8 -> "7.1"; else -> "${format.channelCount}ch" }
        val kbps  = if (format.bitrate > 0) " ${format.bitrate / 1000}kbps" else ""
        return "$lang ($codec $ch$kbps)"
    }

    private fun simplifyCodec(mimeType: String): String = when {
        mimeType.contains("ac3")    -> "AC3"
        mimeType.contains("eac3")   -> "EAC3"
        mimeType.contains("dts")    -> "DTS"
        mimeType.contains("mp4a")   -> "AAC"
        mimeType.contains("mpeg")   -> "MP3"
        mimeType.contains("opus")   -> "Opus"
        mimeType.contains("vorbis") -> "Vorbis"
        mimeType.contains("flac")   -> "FLAC"
        else -> mimeType.substringAfterLast("/").uppercase().take(6)
    }

    // ── Background Audio-Only Mode ───────────────────────────────────────
    fun toggleAudioOnlyMode() {
        val newMode = !_uiState.value.isAudioOnlyMode
        _uiState.update { it.copy(isAudioOnlyMode = newMode) }
        if (newMode) {
            // Detach video surface so audio-only plays without rendering frames
            // We don't call setVideoSurface(null) here — instead we hide the
            // PlayerSurface composable via isAudioOnlyMode flag in VideoPlayerScreen.
            // ExoPlayer continues playing audio; the surface just becomes invisible.
            acquireWakeLock()
        } else {
            // Surface is automatically re-attached when PlayerSurface becomes
            // visible again (Compose recomposition triggers AndroidView update
            // which sets player = player, re-creating the video output path).
            releaseWakeLock()
        }
    }

    @Suppress("DEPRECATION")
    private var wakeLock: android.os.PowerManager.WakeLock? = null

    private fun acquireWakeLock() {
        try {
            val pm = context.getSystemService(android.content.Context.POWER_SERVICE)
                as android.os.PowerManager
            wakeLock?.release()
            wakeLock = pm.newWakeLock(
                android.os.PowerManager.PARTIAL_WAKE_LOCK,
                "DarkWave:AudioOnlyMode"
            ).also { it.acquire(4 * 60 * 60 * 1000L) }  // max 4 hours
        } catch (_: Exception) {}
    }

    private fun releaseWakeLock() {
        try { wakeLock?.release() } catch (_: Exception) {}
        wakeLock = null
    }

    // ── Video Color Filter & Smart Enhance ──────────────────────────────
    fun toggleColorFilter() { _uiState.update { it.copy(showColorFilter = !it.showColorFilter) } }

    // Manual sliders
    fun setBrightness(v: Float) { _uiState.update { it.copy(colorState = it.colorState.copy(brightness = v), activeEnhanceProfile = com.darkwave.player.ui.SmartEnhanceProfile.OFF) } }
    fun setContrast(v: Float)   { _uiState.update { it.copy(colorState = it.colorState.copy(contrast   = v), activeEnhanceProfile = com.darkwave.player.ui.SmartEnhanceProfile.OFF) } }
    fun setSaturation(v: Float) { _uiState.update { it.copy(colorState = it.colorState.copy(saturation = v), activeEnhanceProfile = com.darkwave.player.ui.SmartEnhanceProfile.OFF) } }
    fun setHueShift(v: Float)   { _uiState.update { it.copy(colorState = it.colorState.copy(hue        = v), activeEnhanceProfile = com.darkwave.player.ui.SmartEnhanceProfile.OFF) } }
    fun setGamma(v: Float)      { _uiState.update { it.copy(colorState = it.colorState.copy(gamma      = v), activeEnhanceProfile = com.darkwave.player.ui.SmartEnhanceProfile.OFF) } }
    fun setSharpness(v: Float)  { _uiState.update { it.copy(colorState = it.colorState.copy(sharpness  = v), activeEnhanceProfile = com.darkwave.player.ui.SmartEnhanceProfile.OFF) } }
    fun setNoiseReduction(on: Boolean) { _uiState.update { it.copy(colorState = it.colorState.copy(noiseReduction = on)) } }
    fun resetColorFilter()      { _uiState.update { it.copy(colorState = com.darkwave.player.ui.VideoColorState(), activeEnhanceProfile = com.darkwave.player.ui.SmartEnhanceProfile.OFF) } }

    /** Apply a named Smart Enhance profile instantly */
    fun applyEnhanceProfile(profile: com.darkwave.player.ui.SmartEnhanceProfile) {
        _uiState.update { it.copy(
            colorState           = profile.toColorState(),
            activeEnhanceProfile = profile
        ) }
    }

    /**
     * Auto Smart Enhance — grabs a thumbnail frame from the current position,
     * analyzes its average luminance + saturation, then picks the best profile
     * and fine-tunes brightness/contrast to compensate for the video's actual look.
     */
    fun applyAutoSmartEnhance() {
        viewModelScope.launch {
            _uiState.update { it.copy(isSmartEnhancing = true) }

            val analysis = analyzeCurrentFrame()
            val chosen   = pickBestProfile(analysis)
            val base     = chosen.toColorState()

            // Fine-tune based on measured luminance deviation from ideal 0.45
            val lumDelta  = 0.45f - analysis.avgLuminance        // negative = too bright
            val finalState = base.copy(
                brightness = (base.brightness + lumDelta * 0.4f).coerceIn(-0.8f, 0.8f),
                contrast   = if (analysis.contrast < 0.25f)     // low-contrast video → boost
                    (base.contrast + 0.15f).coerceIn(0.5f, 2f)
                else base.contrast,
                saturation = if (analysis.avgSaturation < 0.15f) // very desaturated → lift
                    (base.saturation + 0.2f).coerceIn(0f, 2f)
                else base.saturation
            )

            _uiState.update { it.copy(
                colorState           = finalState,
                activeEnhanceProfile = chosen,
                isSmartEnhancing     = false
            ) }
        }
    }

    /** Frame metrics extracted from a thumbnail bitmap */
    private data class FrameAnalysis(
        val avgLuminance:  Float,   // 0..1
        val avgSaturation: Float,   // 0..1
        val contrast:      Float,   // 0..1  (std-dev of luminance)
        val avgHue:        Float    // 0..360
    )

    /**
     * Decode a thumbnail from the current playback position using
     * MediaMetadataRetriever, then compute per-pixel HSL statistics.
     * Falls back to neutral analysis if retrieval fails.
     */
    private suspend fun analyzeCurrentFrame(): FrameAnalysis =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val uri      = _uiState.value.uri.ifBlank { return@withContext neutralAnalysis() }
                val posUs    = player.currentPosition * 1000L
                val retriever = android.media.MediaMetadataRetriever()
                retriever.setDataSource(context, android.net.Uri.parse(uri))
                val bmp = retriever.getFrameAtTime(posUs,
                    android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: return@withContext neutralAnalysis()
                retriever.release()

                // Sample every 8th pixel for speed
                val w = bmp.width; val h = bmp.height
                var sumL = 0f; var sumS = 0f; var sumH = 0f; var n = 0
                val pixels = IntArray(w * h)
                bmp.getPixels(pixels, 0, w, 0, 0, w, h)
                bmp.recycle()

                val hsl = FloatArray(3)
                var step = 1
                if (pixels.size > 4000) step = (pixels.size / 4000).coerceAtLeast(1)

                var i = 0
                while (i < pixels.size) {
                    val px  = pixels[i]
                    val r   = ((px shr 16) and 0xFF) / 255f
                    val g   = ((px shr 8)  and 0xFF) / 255f
                    val b   = (px          and 0xFF) / 255f
                    android.graphics.Color.RGBToHSV(
                        (r * 255).toInt(), (g * 255).toInt(), (b * 255).toInt(), hsl)
                    val lum = 0.2126f * r + 0.7152f * g + 0.0722f * b
                    sumL += lum; sumS += hsl[1]; sumH += hsl[0]; n++
                    i += step
                }

                val avgL = sumL / n
                val avgS = sumS / n
                val avgH = sumH / n

                // Compute contrast as mean absolute deviation of luminance
                var devSum = 0f
                i = 0
                while (i < pixels.size) {
                    val px = pixels[i]
                    val r  = ((px shr 16) and 0xFF) / 255f
                    val g  = ((px shr 8)  and 0xFF) / 255f
                    val bC = (px          and 0xFF) / 255f
                    val lum = 0.2126f * r + 0.7152f * g + 0.0722f * bC
                    devSum += kotlin.math.abs(lum - avgL)
                    i += step
                }
                val contrast = (devSum / n) * 3f   // scale so 0.33 ≈ normal

                FrameAnalysis(avgL, avgS, contrast.coerceIn(0f, 1f), avgH)

            } catch (_: Exception) { neutralAnalysis() }
        }

    private fun neutralAnalysis() = FrameAnalysis(0.45f, 0.4f, 0.35f, 180f)

    /**
     * Choose the best SmartEnhanceProfile based on frame statistics.
     * Logic mirrors what MX Player / PowerAMP do internally.
     */
    private fun pickBestProfile(a: FrameAnalysis): com.darkwave.player.ui.SmartEnhanceProfile {
        return when {
            a.avgLuminance < 0.18f                            -> com.darkwave.player.ui.SmartEnhanceProfile.NIGHT
            a.avgLuminance > 0.72f && a.avgSaturation < 0.2f -> com.darkwave.player.ui.SmartEnhanceProfile.DOCUMENTARY
            a.contrast < 0.20f                                -> com.darkwave.player.ui.SmartEnhanceProfile.HDR_SIM
            a.avgSaturation < 0.15f                           -> com.darkwave.player.ui.SmartEnhanceProfile.VIVID
            a.avgSaturation > 0.65f && a.avgLuminance > 0.5f -> com.darkwave.player.ui.SmartEnhanceProfile.ANIME
            a.avgHue in 20f..50f                              -> com.darkwave.player.ui.SmartEnhanceProfile.INDOOR
            a.avgHue in 180f..240f                            -> com.darkwave.player.ui.SmartEnhanceProfile.OUTDOOR
            a.contrast > 0.55f                                -> com.darkwave.player.ui.SmartEnhanceProfile.SPORTS
            else                                              -> com.darkwave.player.ui.SmartEnhanceProfile.AUTO
        }
    }

    // ── Chapters ─────────────────────────────────────────────────────────
    fun toggleChapters() { _uiState.update { it.copy(showChapters = !it.showChapters) } }

    private fun loadChapters() {
        // ExoPlayer exposes chapters via Timeline — read from current media metadata
        try {
            val metadata = player.mediaMetadata
            // chapters() is available in Media3 1.4+ via MediaMetadata.chapters
            // Fall back to empty if not available
            @Suppress("UNCHECKED_CAST")
            val rawChapters = metadata.javaClass.getMethod("chapters")
                .invoke(metadata) as? List<*>
            if (rawChapters != null && rawChapters.isNotEmpty()) {
                val parsed = rawChapters.mapIndexedNotNull { i, ch ->
                    try {
                        val title = ch!!.javaClass.getMethod("title").invoke(ch)?.toString() ?: "Chapter ${i + 1}"
                        val start = (ch.javaClass.getMethod("startTimeMs").invoke(ch) as? Long) ?: 0L
                        val end   = (ch.javaClass.getMethod("endTimeMs").invoke(ch) as? Long) ?: 0L
                        com.darkwave.player.ui.Chapter(title, start, end)
                    } catch (_: Exception) { null }
                }
                _uiState.update { it.copy(chapters = parsed) }
            }
        } catch (_: Exception) { /* chapters not available in this media */ }
    }

    // ── Cast / DLNA ───────────────────────────────────────────────────────
    fun showCastSheet() {
        _uiState.update { it.copy(showCastSheet = true) }
        scanCastDevices()
    }

    fun dismissCastSheet() { _uiState.update { it.copy(showCastSheet = false) } }

    private fun scanCastDevices() {
        viewModelScope.launch {
            _uiState.update { it.copy(isCastScanning = true) }
            // Real implementation: use NsdManager for mDNS discovery
            val nsdManager = context.getSystemService(android.content.Context.NSD_SERVICE)
                as android.net.nsd.NsdManager
            val discoveredDevices = mutableListOf<com.darkwave.player.ui.CastDevice>()
            val listener = object : android.net.nsd.NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(type: String) {}
                override fun onServiceFound(info: android.net.nsd.NsdServiceInfo) {
                    val type = when {
                        info.serviceType.contains("_googlecast") -> com.darkwave.player.ui.CastType.CHROMECAST
                        info.serviceType.contains("_http")       -> com.darkwave.player.ui.CastType.DLNA
                        info.serviceType.contains("_airplay")    -> com.darkwave.player.ui.CastType.AIRPLAY
                        else -> com.darkwave.player.ui.CastType.DLNA
                    }
                    discoveredDevices.add(com.darkwave.player.ui.CastDevice(
                        id = info.host?.hostAddress ?: info.serviceName,
                        name = info.serviceName,
                        type = type
                    ))
                    _uiState.update { it.copy(castDevices = discoveredDevices.toList()) }
                }
                override fun onServiceLost(info: android.net.nsd.NsdServiceInfo) {
                    discoveredDevices.removeAll { it.name == info.serviceName }
                    _uiState.update { it.copy(castDevices = discoveredDevices.toList()) }
                }
                override fun onDiscoveryStopped(type: String) {}
                override fun onStartDiscoveryFailed(type: String, code: Int) {
                    _uiState.update { it.copy(isCastScanning = false) }
                }
                override fun onStopDiscoveryFailed(type: String, code: Int) {}
            }
            try {
                nsdManager.discoverServices("_googlecast._tcp.", android.net.nsd.NsdManager.PROTOCOL_DNS_SD, listener)
                kotlinx.coroutines.delay(5000)
                nsdManager.stopServiceDiscovery(listener)
            } catch (_: Exception) {}
            _uiState.update { it.copy(isCastScanning = false) }
        }
    }

    fun connectCastDevice(device: com.darkwave.player.ui.CastDevice) {
        _uiState.update { state ->
            state.copy(
                activeCastDeviceId = device.id,
                castDevices = state.castDevices.map { it.copy(isConnected = it.id == device.id) }
            )
        }
        android.util.Log.d("DW/Cast", "Casting to: ${device.name} (${device.type})")
    }

    // ── Clock overlay toggle ──────────────────────────────────────────────
    fun toggleClock() { _uiState.update { it.copy(showClock = !it.showClock) } }

    // ── Floating / Popup player ───────────────────────────────────────────
    fun launchFloatingPlayer() {
        val uri   = _uiState.value.uri
        val posMs = player.currentPosition
        if (uri.isEmpty()) return
        // Pause main player before floating takes over
        player.pause()
        com.darkwave.app.service.FloatingPlayerService.startFloating(context, uri)
    }

    fun stopFloatingPlayer() {
        com.darkwave.app.service.FloatingPlayerService.stopFloating(context)
    }

    // ── Video Equalizer ──────────────────────────────────────────────────
    fun toggleVideoEq() {
        val newVal = !_uiState.value.showVideoEq
        _uiState.update { it.copy(showVideoEq = newVal) }
        if (newVal) initVideoEqualizer()
    }

    // ── Rotation control ─────────────────────────────────────────────────
    fun cycleRotation(activity: android.app.Activity) {
        val next = when (_uiState.value.rotationMode) {
            RotationMode.SENSOR_LANDSCAPE  -> RotationMode.PORTRAIT
            RotationMode.PORTRAIT          -> RotationMode.LANDSCAPE
            RotationMode.LANDSCAPE         -> RotationMode.REVERSE_LANDSCAPE
            RotationMode.REVERSE_LANDSCAPE -> RotationMode.SENSOR_LANDSCAPE
        }
        _uiState.update { it.copy(rotationMode = next) }
        activity.requestedOrientation = when (next) {
            RotationMode.PORTRAIT          -> android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            RotationMode.LANDSCAPE         -> android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
            RotationMode.REVERSE_LANDSCAPE -> android.content.pm.ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
            RotationMode.SENSOR_LANDSCAPE  -> android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    // ── Bookmark from inside player ───────────────────────────────────────
    fun addBookmarkAtCurrentPosition() {
        val uri   = _uiState.value.uri
        val title = _uiState.value.title
        val pos   = player.currentPosition
        val videoId = uri.hashCode().toLong().let { if (it < 0) -it else it }
        viewModelScope.launch {
            try {
                mediaRepository.toggleVideoBookmark(videoId, true, pos)
                _uiState.update { it.copy(showBookmarkSaved = true) }
                delay(2000)
                _uiState.update { it.copy(showBookmarkSaved = false) }
            } catch (_: Exception) {}
        }
    }

    // ── Frame-by-frame (step forward ~1 frame ≈ 40ms) ────────────────────
    fun stepFrameForward() {
        player.pause()
        val frameMs = when {
            _uiState.value.playbackSpeed >= 2f -> 100L
            else -> 40L   // ~25fps
        }
        val newPos = (player.currentPosition + frameMs).coerceAtMost(player.duration)
        player.seekTo(newPos)
        _uiState.update { it.copy(frameStepActive = true) }
    }

    fun stepFrameBackward() {
        player.pause()
        val frameMs = when {
            _uiState.value.playbackSpeed >= 2f -> 100L
            else -> 40L
        }
        val newPos = (player.currentPosition - frameMs).coerceAtLeast(0L)
        player.seekTo(newPos)
        _uiState.update { it.copy(frameStepActive = true) }
    }

    // ── Long-press 2x speed ───────────────────────────────────────────────
    fun startTempSpeed2x() {
        if (_uiState.value.isTempSpeed2x) return
        val currentSpeed = _uiState.value.playbackSpeed
        player.setPlaybackSpeed(2f)
        _uiState.update { it.copy(isTempSpeed2x = true, speedBeforeTemp = currentSpeed) }
    }

    fun stopTempSpeed2x() {
        if (!_uiState.value.isTempSpeed2x) return
        val prev = _uiState.value.speedBeforeTemp
        player.setPlaybackSpeed(prev)
        _uiState.update { it.copy(isTempSpeed2x = false) }
    }

    // ── Zoom reset ────────────────────────────────────────────────────────
    fun resetZoom() {
        _uiState.update { it.copy(zoomScale = 1f) }
    }

    // ── Subtitle style ────────────────────────────────────────────────────
    fun setSubtitleFontSize(size: Float) {
        _uiState.update { it.copy(subtitleFontSize = size) }
    }

    fun setSubtitleColor(color: androidx.compose.ui.graphics.Color) {
        _uiState.update { it.copy(subtitleColor = color) }
    }

    fun setSubtitleBgOpacity(opacity: Float) {
        _uiState.update { it.copy(
            subtitleBgColor = androidx.compose.ui.graphics.Color.Black.copy(alpha = opacity)
        )}
    }

    fun toggleSubtitleStyleMenu() {
        _uiState.update { it.copy(showSubtitleStyleMenu = !it.showSubtitleStyleMenu) }
    }

    // ── Network URL streaming ─────────────────────────────────────────────
    fun showNetworkUrlDialog() {
        _uiState.update { it.copy(showNetworkUrlDialog = true) }
    }

    fun dismissNetworkUrlDialog() {
        _uiState.update { it.copy(showNetworkUrlDialog = false) }
    }

    fun playNetworkUrl(url: String) {
        if (url.isBlank()) return
        val cleanUrl = url.trim()
        _uiState.update { it.copy(networkUrl = cleanUrl, showNetworkUrlDialog = false) }
        // ExoPlayer handles HLS (.m3u8), DASH (.mpd), RTSP, direct HTTP streams natively
        loadMedia(cleanUrl, extractTitleFromUrl(cleanUrl))
    }

    private fun extractTitleFromUrl(url: String): String {
        return try {
            val path = android.net.Uri.parse(url).lastPathSegment ?: ""
            path.substringBeforeLast(".").ifBlank { "Network Stream" }
        } catch (_: Exception) { "Network Stream" }
    }

    // ── Hardware decoder toggle ───────────────────────────────────────────
    /**
     * ExoPlayer hardware decoding is controlled at build time via DefaultRenderersFactory.
     * We store the preference and apply it on next video load by rebuilding the player.
     * For immediate effect, we toggle track selection to force re-initialization.
     */
    fun setHardwareDecoding(enabled: Boolean) {
        _uiState.update { it.copy(useHardwareDecoding = enabled) }
        // Re-apply track selection parameters to trigger decoder re-selection
        val params = player.trackSelectionParameters.buildUpon()
            .setForceLowestBitrate(!enabled)    // SW path tends to use lower bitrate
            .build()
        player.trackSelectionParameters = params
        android.util.Log.d("DW/Player", "Hardware decoding: $enabled")
        viewModelScope.launch { playerPrefs.saveHwDecoding(enabled) }
    }

    // ── Equalizer for video ───────────────────────────────────────────────
    private var videoEqualizer: android.media.audiofx.Equalizer? = null

    fun initVideoEqualizer() {
        try {
            val sessionId = player.audioSessionId
            if (sessionId == androidx.media3.common.C.AUDIO_SESSION_ID_UNSET) return
            videoEqualizer?.release()
            videoEqualizer = android.media.audiofx.Equalizer(0, sessionId).apply { enabled = true }
        } catch (_: Exception) {}
    }

    fun setVideoEqBand(band: Short, levelMillibel: Short) {
        try {
            videoEqualizer?.setBandLevel(band, levelMillibel)
        } catch (_: Exception) {}
    }

    fun getVideoEqBands(): List<Triple<Short, Int, Int>> {
        val eq = videoEqualizer ?: return emptyList()
        return try {
            val range = eq.bandLevelRange
            (0 until eq.numberOfBands).map { i ->
                Triple(i.toShort(), range[0], range[1])
            }
        } catch (_: Exception) { emptyList() }
    }

    fun resetVideoEq() {
        try {
            val eq = videoEqualizer ?: return
            for (i in 0 until eq.numberOfBands) {
                eq.setBandLevel(i.toShort(), 0)
            }
        } catch (_: Exception) {}
    }

    override fun onCleared() {
        // Save resume position before exit
        val pos = player.currentPosition
        val state = _uiState.value
        if (pos > 5000L && state.uri.isNotBlank()) {
            val videoId = state.uri.hashCode().toLong().let { if (it < 0) -it else it }
            kotlinx.coroutines.runBlocking {
                try { mediaRepository.toggleVideoBookmark(videoId, false, pos) }
                catch (_: Exception) {}
            }
        }
        player.removeListener(playerListener)
        loudnessEnhancer?.release()
        loudnessEnhancer = null
        videoEqualizer?.release()
        videoEqualizer = null
        sleepTimerJob?.cancel()
        player.release()
        super.onCleared()
    }

// ── Online subtitle search (opensubtitles.com REST API v1) ────────────────
    // No API key needed for basic search; uses public endpoint
    data class OnlineSubtitleResult(
        val id: String,
        val language: String,
        val movieName: String,
        val downloadCount: Int,
        val downloadUrl: String,
        val fileName: String
    )

    private val _onlineSubResults = MutableStateFlow<List<OnlineSubtitleResult>>(emptyList())
    val onlineSubResults: StateFlow<List<OnlineSubtitleResult>> = _onlineSubResults.asStateFlow()

    private val _isSearchingSubtitles = MutableStateFlow(false)
    val isSearchingSubtitles: StateFlow<Boolean> = _isSearchingSubtitles.asStateFlow()

    fun searchOnlineSubtitles(query: String, language: String = "en") {
        viewModelScope.launch {
            _isSearchingSubtitles.value = true
            _onlineSubResults.value = emptyList()
            try {
                val encodedQuery = java.net.URLEncoder.encode(query, "UTF-8")
                val url = "https://rest.opensubtitles.org/search/query-$encodedQuery/sublanguageid-$language"
                val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                conn.apply {
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "DarkWave Android Player v1.0")
                    connectTimeout = 10_000
                    readTimeout    = 10_000
                }
                val resp = conn.inputStream.bufferedReader().readText()
                conn.disconnect()

                // Parse JSON manually (no Gson/Moshi dependency in player module)
                val results = mutableListOf<OnlineSubtitleResult>()
                val items = resp.split("\"IDSubtitleFile\"")
                    .drop(1).take(15)
                for (item in items) {
                    try {
                        fun field(key: String): String {
                            val start = item.indexOf("\"$key\":\"") + "\"$key\":\"".length
                            val end   = item.indexOf("\"", start)
                            return if (start < "\"$key\":\"".length || end <= start) ""
                            else item.substring(start, end)
                        }
                        val dlUrl = field("SubDownloadLink").replace("\\/", "/")
                        if (dlUrl.isBlank()) continue
                        results.add(OnlineSubtitleResult(
                            id            = field("IDSubtitleFile"),
                            language      = field("SubLanguageID"),
                            movieName     = field("MovieName"),
                            downloadCount = field("SubDownloadsCnt").toIntOrNull() ?: 0,
                            downloadUrl   = dlUrl,
                            fileName      = field("SubFileName").ifBlank { "subtitle.srt" }
                        ))
                    } catch (_: Exception) {}
                }
                _onlineSubResults.value = results
            } catch (_: Exception) {
                _onlineSubResults.value = emptyList()
            } finally {
                _isSearchingSubtitles.value = false
            }
        }
    }

    fun downloadAndLoadOnlineSubtitle(result: OnlineSubtitleResult) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val outDir  = File(context.cacheDir, "subtitles").also { it.mkdirs() }
                val outFile = File(outDir, "${result.id}_${result.fileName}")
                // Download (may be gzipped)
                val conn = java.net.URL(result.downloadUrl).openConnection() as java.net.HttpURLConnection
                conn.setRequestProperty("User-Agent", "DarkWave Android Player v1.0")
                val bytes = conn.inputStream.readBytes()
                conn.disconnect()
                // Try gunzip
                val content = try {
                    java.util.zip.GZIPInputStream(bytes.inputStream()).bufferedReader().readText()
                } catch (_: Exception) {
                    bytes.toString(Charsets.UTF_8)
                }
                outFile.writeText(content)
                val trackIdx = _uiState.value.subtitleTracks.size
                loadSubtitleFile(outFile, trackIdx)
            } catch (_: Exception) {}
        }
    }
}
