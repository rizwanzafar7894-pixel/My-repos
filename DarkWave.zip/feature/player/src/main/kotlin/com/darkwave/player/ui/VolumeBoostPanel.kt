package com.darkwave.player.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val DangerRed   = Color(0xFFE53935)
private val WarnOrange  = Color(0xFFFF8F00)
private val SafeGreen   = Color(0xFF43A047)
private val BoostPurple = Color(0xFF5C6BC0)
private val PanelBg     = Color(0xF2111120)
private val TrackBg     = Color(0xFF2A2A3E)

/**
 * Volume boost bottom sheet — supports 0% to 200%.
 * 0–100%: normal ExoPlayer volume
 * 101–200%: ExoPlayer at max + LoudnessEnhancer gain
 */
@Composable
fun VolumeBoostPanel(
    volumePercent: Int,
    showWarning: Boolean,
    onVolumeChange: (Int) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val density      = LocalDensity.current
    var trackWidthPx by remember { mutableIntStateOf(1) }
    var isDragging   by remember { mutableStateOf(false) }

    val fraction  = volumePercent / 200f
    val fillColor = when {
        volumePercent > 175 -> DangerRed
        volumePercent > 150 -> WarnOrange
        volumePercent > 100 -> BoostPurple
        else                -> SafeGreen
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .background(PanelBg)
    ) {
        Column(modifier = Modifier.padding(bottom = 24.dp)) {

            // ── Handle ────────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(top = 10.dp)
                    .size(width = 40.dp, height = 4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.25f))
            )

            // ── Header ────────────────────────────────────────────────
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.VolumeUp, null, tint = fillColor, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(10.dp))
                Text(
                    "Volume Boost",
                    color = Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    modifier = Modifier.weight(1f)
                )
                if (volumePercent > 100) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(fillColor.copy(alpha = 0.2f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text("BOOST", color = fillColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Divider(color = Color.White.copy(alpha = 0.08f))
            Spacer(Modifier.height(20.dp))

            // ── Big % display ─────────────────────────────────────────
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("$volumePercent", color = fillColor, fontSize = 72.sp, fontWeight = FontWeight.ExtraBold)
                    Text("%", color = fillColor.copy(alpha = 0.7f), fontSize = 28.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 12.dp))
                }
            }
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(volumeLabel(volumePercent), color = fillColor.copy(alpha = 0.8f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }

            Spacer(Modifier.height(24.dp))

            // ── Slider ────────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .height(36.dp)
                    .onSizeChanged { trackWidthPx = it.width }
                    .pointerInput(Unit) {
                        detectTapGestures { offset ->
                            onVolumeChange(((offset.x / trackWidthPx) * 200).toInt().coerceIn(0, 200))
                        }
                    }
                    .pointerInput(Unit) {
                        detectHorizontalDragGestures(
                            onDragStart  = { isDragging = true },
                            onDragEnd    = { isDragging = false },
                            onDragCancel = { isDragging = false }
                        ) { change, _ ->
                            change.consume()
                            onVolumeChange(((change.position.x / trackWidthPx) * 200).toInt().coerceIn(0, 200))
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                // Track
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp))
                        .background(TrackBg)
                ) {
                    // Gradient fill
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(fraction)
                            .fillMaxHeight()
                            .background(
                                Brush.horizontalGradient(
                                    0f    to SafeGreen,
                                    0.5f  to BoostPurple,
                                    0.75f to WarnOrange,
                                    1f    to DangerRed
                                )
                            )
                    )
                    // 100% divider mark
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(2.dp)
                            .background(Color.White.copy(alpha = 0.5f))
                            .align(Alignment.CenterStart)
                            .offset(x = with(density) { (trackWidthPx / 2).toDp() } - 1.dp)
                    )
                }

                // Thumb
                val thumbSize     = if (isDragging) 22.dp else 18.dp
                val thumbOffsetDp = with(density) { (fraction * trackWidthPx).toDp() } - thumbSize / 2
                Box(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .offset(x = thumbOffsetDp.coerceAtLeast(0.dp))
                        .size(thumbSize)
                        .clip(CircleShape)
                        .background(Color.White)
                )
            }

            // Scale labels
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("0%",   color = Color.White.copy(alpha = 0.35f), fontSize = 10.sp)
                Text("50%",  color = Color.White.copy(alpha = 0.35f), fontSize = 10.sp)
                Text("100%", color = Color.White.copy(alpha = 0.6f),  fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                Text("150%", color = WarnOrange.copy(alpha = 0.7f),   fontSize = 10.sp)
                Text("200%", color = DangerRed,                        fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }

            Spacer(Modifier.height(16.dp))

            // ── Step buttons ──────────────────────────────────────────
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                VolumeStepBtn("-10%") { onVolumeChange((volumePercent - 10).coerceAtLeast(0)) }
                VolumeStepBtn("-1%")  { onVolumeChange((volumePercent - 1).coerceAtLeast(0)) }
                Spacer(Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White.copy(alpha = 0.09f))
                        .pointerInput(Unit) { detectTapGestures { onVolumeChange(100) } }
                        .padding(horizontal = 16.dp, vertical = 9.dp)
                ) {
                    Text("Reset 100%", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                }
                Spacer(Modifier.weight(1f))
                VolumeStepBtn("+1%")  { onVolumeChange((volumePercent + 1).coerceAtMost(200)) }
                VolumeStepBtn("+10%") { onVolumeChange((volumePercent + 10).coerceAtMost(200)) }
            }

            // ── Warning ───────────────────────────────────────────────
            AnimatedVisibility(
                visible = showWarning,
                enter   = fadeIn() + expandVertically(),
                exit    = fadeOut() + shrinkVertically()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(DangerRed.copy(alpha = 0.14f))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Warning, null, tint = DangerRed, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "High volume can damage hearing. Use carefully.",
                        color = DangerRed,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun VolumeStepBtn(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color.White.copy(alpha = 0.08f))
            .pointerInput(Unit) { detectTapGestures { onClick() } }
            .padding(horizontal = 10.dp, vertical = 9.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

private fun volumeLabel(pct: Int) = when {
    pct == 0   -> "Muted"
    pct < 30   -> "Very Quiet"
    pct < 60   -> "Quiet"
    pct < 90   -> "Normal"
    pct == 100 -> "Normal (100%)"
    pct < 130  -> "Boosted"
    pct < 160  -> "High Boost"
    pct < 185  -> "Very High — Caution"
    else       -> "Max Boost — Distortion risk"
}
