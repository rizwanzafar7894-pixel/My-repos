package com.darkwave.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val DangerRed   = Color(0xFFE53935)
private val WarnOrange  = Color(0xFFFF8F00)
private val BoostPurple = Color(0xFF5C6BC0)

/**
 * Left-side HUD showing brightness + volume.
 * Volume shows percentage (supports >100% boost).
 */
@Composable
fun VolumeAndBrightnessHud(
    brightness: Float,
    volumePercent: Int,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Brightness indicator
        HudIndicator(
            icon  = Icons.Default.Brightness6,
            value = brightness,
            tint  = Color.White,
            label = "${(brightness * 100).toInt()}%"
        )

        // Volume indicator — color changes at >100%
        val volColor = when {
            volumePercent > 150 -> DangerRed
            volumePercent > 100 -> BoostPurple
            else                -> Color.White
        }
        HudIndicator(
            icon  = if (volumePercent == 0) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
            value = (volumePercent / 200f).coerceIn(0f, 1f),
            tint  = volColor,
            label = "$volumePercent%",
            showBoostIndicator = volumePercent > 100
        )
    }
}

@Composable
private fun HudIndicator(
    icon: ImageVector,
    value: Float,
    tint: Color,
    label: String,
    showBoostIndicator: Boolean = false
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color.Black.copy(alpha = 0.55f)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(16.dp))
            Spacer(Modifier.height(4.dp))

            // Vertical bar
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(56.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.2f))
            ) {
                // Fill (capped at 1f visually — bar represents 0..200% in 0..1 space)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(value.coerceIn(0f, 1f))
                        .background(tint)
                        .align(Alignment.BottomCenter)
                )
            }

            Spacer(Modifier.height(4.dp))
            Text(label, color = tint, fontSize = 9.sp)

            // Boost "+" badge
            if (showBoostIndicator) {
                Text("⚡", fontSize = 10.sp)
            }
        }
    }
}
