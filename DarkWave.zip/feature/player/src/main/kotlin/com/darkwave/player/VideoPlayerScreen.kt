package com.darkwave.player

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.os.Build
import android.util.Rational
import android.view.WindowManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.awaitPointerEventScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darkwave.player.subtitle.SubtitleOverlay
import com.darkwave.player.ui.*
import com.darkwave.player.viewmodel.SeekSide
import com.darkwave.player.viewmodel.VideoPlayerViewModel

@Composable
fun VideoPlayerScreen(
    uri: String,
    title: String,
    onBack: () -> Unit,
    viewModel: VideoPlayerViewModel = hiltViewModel()
) {
    val state   by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current as Activity

    // ── Subtitle file picker launcher ─────────────────────────────────────
    val subtitleLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri2 ->
        uri2?.let { viewModel.loadSubtitleFromUri(it.toString()) }
    }

    // ── Landscape + immersive mode ────────────────────────────────────────
    DisposableEffect(Unit) {
        val origOrientation = context.requestedOrientation
        context.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        val wic = WindowCompat.getInsetsController(context.window, context.window.decorView)
        wic.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        wic.hide(WindowInsetsCompat.Type.systemBars())
        context.window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        onDispose {
            context.requestedOrientation = origOrientation
            wic.show(WindowInsetsCompat.Type.systemBars())
            context.window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // ── Apply brightness to window ────────────────────────────────────────
    LaunchedEffect(state.brightness) {
        val lp = context.window.attributes
        lp.screenBrightness = state.brightness.coerceIn(0.01f, 1f)
        context.window.attributes = lp
    }

    // ── PiP mode: enter when isPipMode = true ─────────────────────────────
    LaunchedEffect(state.isPipMode) {
        if (state.isPipMode && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val rational = if (state.videoWidth > 0 && state.videoHeight > 0)
                Rational(state.videoWidth, state.videoHeight)
            else Rational(16, 9)
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(rational)
                .build()
            context.enterPictureInPictureMode(params)
        }
    }

    // Start VideoPlaybackService for lock-screen + notification controls
    DisposableEffect(Unit) {
        val svcIntent = android.content.Intent()
            .setClassName(context.packageName, "${context.packageName}.service.VideoPlaybackService")
        try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
                context.startForegroundService(svcIntent)
            else
                context.startService(svcIntent)
        } catch (_: Exception) {}
        onDispose {
            try { context.stopService(svcIntent) } catch (_: Exception) {}
        }
    }

    LaunchedEffect(uri) { viewModel.loadMedia(uri, title) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // ── 1. Video surface with aspect ratio ─────────────────────────
        // Hidden in audio-only mode (surface stays attached, just not visible)
        if (!state.isAudioOnlyMode) {
            PlayerSurface(
                player           = viewModel.player,
                aspectRatioIndex = state.aspectRatioIndex,
                zoomScale        = state.zoomScale,
                colorState       = state.colorState,
                modifier         = Modifier.fillMaxSize()
            )
        }

        // ── 2. Double-tap seek flash ──────────────────────────────────────
        state.doubleTapSeekSide?.let { side ->
            SeekFlashOverlay(side = side, modifier = Modifier.fillMaxSize())
        }

        // ── 3. Pinch-to-zoom overlay ──────────────────────────────────────
        PinchZoomOverlay(
            modifier = Modifier.fillMaxSize(),
            onZoom   = { scale -> viewModel.setZoomScale(scale) }
        )

        // ── 4. Gesture zones ──────────────────────────────────────────────
        if (!state.isLocked) {
            GestureDragZone(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.4f)
                    .align(Alignment.CenterStart),
                onDrag = { delta -> viewModel.setScreenBrightness(state.brightness - delta / 1000f) }
            )
            GestureDragZone(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.4f)
                    .align(Alignment.CenterEnd),
                onDrag = { delta -> viewModel.setVolumeFromGesture(delta) }
            )
        }

        // ── Swipe-to-next/previous video (vertical swipe in playlist) ────────────
        if (!state.isLocked && state.playlist.size > 1) {
            var swipeAccum by remember { mutableStateOf(0f) }
            Box(modifier = Modifier
                .fillMaxSize()
                .pointerInput(state.playlist.size) {
                    detectVerticalDragGestures(
                        onDragStart = { swipeAccum = 0f },
                        onDragEnd   = {
                            when {
                                swipeAccum < -250f -> viewModel.playNext()
                                swipeAccum >  250f -> viewModel.playPrevious()
                            }
                            swipeAccum = 0f
                        },
                        onVerticalDrag = { _, dy -> swipeAccum += dy }
                    )
                })
        }

        // ── 5. Tap / double-tap / long-press ─────────────────────────────
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(state.isLocked) {
                    if (!state.isLocked) {
                        detectTapGestures(
                            onTap = { viewModel.showControls() },
                            onDoubleTap = { offset ->
                                when {
                                    offset.x < size.width * 0.35f -> viewModel.seekBackward()
                                    offset.x > size.width * 0.65f -> viewModel.seekForward()
                                    else -> viewModel.resetZoom()  // double-tap center = reset zoom
                                }
                            },
                            onLongPress = { viewModel.startTempSpeed2x() }
                        )
                    } else {
                        detectTapGestures(onTap = { viewModel.showControls(autoHide = true) })
                    }
                }
                .pointerInput(state.isLocked) {
                    // Release long press → restore speed
                    if (!state.isLocked) {
                        awaitPointerEventScope {
                            while (true) {
                                val event = awaitPointerEvent()
                                if (event.changes.all { !it.pressed } && state.isTempSpeed2x) {
                                    viewModel.stopTempSpeed2x()
                                }
                            }
                        }
                    }
                }
        )

        // ── 6. Player controls overlay ────────────────────────────────────
        AnimatedVisibility(
            visible  = state.showControls,
            enter    = fadeIn(tween(200)),
            exit     = fadeOut(tween(300)),
            modifier = Modifier.fillMaxSize()
        ) {
            PlayerControlsOverlay(
                state              = state,
                onBack             = onBack,
                onPlayPause        = viewModel::togglePlayPause,
                onSeekTo           = viewModel::seekTo,
                onForward          = { viewModel.seekForward() },
                onBackward         = { viewModel.seekBackward() },
                onToggleMute       = viewModel::toggleMute,
                onToggleLock       = viewModel::toggleLock,
                onCycleRepeat      = viewModel::cycleRepeatMode,
                onToggleSpeed      = viewModel::toggleSpeedMenu,
                onToggleAspect     = viewModel::toggleAspectMenu,
                onSubtitleClick    = viewModel::toggleSubtitleMenu,
                onAudioTrackClick  = viewModel::toggleAudioTrackMenu,
                onVolumeBoostClick = viewModel::toggleVolumeBoostMenu,
                onPipClick         = viewModel::enterPipMode,
                onScreenshot       = { viewModel.takeScreenshot(context) },
                onVideoInfo        = viewModel::toggleVideoInfo,
                onSleepTimer       = viewModel::toggleSleepTimer,
                onNetworkUrl       = viewModel::showNetworkUrlDialog,
                onEqualizer        = viewModel::toggleVideoEq,
                onRotation         = { viewModel.cycleRotation(context) },
                onBookmark         = viewModel::addBookmarkAtCurrentPosition,
                onStepForward      = viewModel::stepFrameForward,
                onStepBackward     = viewModel::stepFrameBackward,
                onAudioOnlyMode    = viewModel::toggleAudioOnlyMode,
                onColorFilter      = viewModel::toggleColorFilter,
                onChapters         = viewModel::toggleChapters,
                onCast             = viewModel::showCastSheet,
                onToggleClock      = viewModel::toggleClock,
                onFloatingPlayer   = {
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M &&
                        !android.provider.Settings.canDrawOverlays(activity)) {
                        val intent = android.content.Intent(
                            android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            android.net.Uri.parse("package:${activity.packageName}")
                        )
                        activity.startActivity(intent)
                    } else {
                        viewModel.launchFloatingPlayer()
                        onBack()
                    }
                },
                onDismiss          = viewModel::hideControls
            )
        }

        // ── 7. Lock overlay ───────────────────────────────────────────────
        if (state.isLocked && state.showControls) {
            LockOverlay(
                onUnlock = viewModel::toggleLock,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        // ── 8. Speed popup ────────────────────────────────────────────────
        if (state.showSpeedMenu) {
            SpeedMenu(
                currentSpeed  = state.playbackSpeed,
                onSpeedSelect = viewModel::setPlaybackSpeed,
                onDismiss     = viewModel::dismissMenus,
                modifier      = Modifier.align(Alignment.TopEnd).padding(top = 56.dp, end = 16.dp)
            )
        }

        // ── 9. Aspect ratio popup ─────────────────────────────────────────
        if (state.showAspectMenu) {
            AspectMenu(
                currentIndex   = state.aspectRatioIndex,
                onAspectSelect = viewModel::setAspectRatio,
                onDismiss      = viewModel::dismissMenus,
                modifier       = Modifier.align(Alignment.TopEnd).padding(top = 56.dp, end = 56.dp)
            )
        }

        // ── 10. Audio track picker ─────────────────────────────────────────
        AnimatedVisibility(
            visible  = state.showAudioTrackMenu,
            enter    = slideInVertically(initialOffsetY = { it }),
            exit     = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            AudioTrackPickerSheet(
                tracks          = state.audioTracks,
                selectedIndex   = state.selectedAudioTrackIndex,
                onTrackSelected = viewModel::selectAudioTrack,
                onDismiss       = viewModel::dismissMenus
            )
        }

        // ── 11. Volume boost panel ─────────────────────────────────────────
        AnimatedVisibility(
            visible  = state.showVolumeBoostMenu,
            enter    = slideInVertically(initialOffsetY = { it }),
            exit     = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            VolumeBoostPanel(
                volumePercent  = state.volumePercent,
                showWarning    = state.showVolumeBoostWarning,
                onVolumeChange = viewModel::setVolumePercent,
                onDismiss      = viewModel::dismissMenus
            )
        }

        // ── 12. Subtitle picker ────────────────────────────────────────────
        AnimatedVisibility(
            visible  = state.showSubtitleMenu,
            enter    = slideInVertically(initialOffsetY = { it }),
            exit     = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            SubtitlePickerSheet(
                tracks          = state.subtitleTracks,
                selectedIndex   = state.subtitleTrackIndex,
                videoTitle      = state.title,
                onTrackSelected = viewModel::selectSubtitleTrack,
                onPickFile      = { subtitleLauncher.launch("*/*") },
                onSubtitleDelay = viewModel::toggleSubtitleDelay,
                onSubtitleStyle = viewModel::toggleSubtitleStyleMenu,
                onSearchOnline  = viewModel::searchOnlineSubtitles,
                onDownloadOnlineSubtitle = viewModel::downloadAndLoadOnlineSubtitle,
                onlineResults   = onlineSubResults,
                isSearchingOnline = isSearchingOnline,
                onDismiss       = viewModel::dismissMenus
            )
        }

        // ── 13. Subtitle delay sheet ───────────────────────────────────────
        AnimatedVisibility(
            visible  = state.showSubtitleDelayMenu,
            enter    = slideInVertically(initialOffsetY = { it }),
            exit     = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            SubtitleDelaySheet(
                delayMs   = state.subtitleDelayMs,
                onDelayChange = viewModel::setSubtitleDelay,
                onDismiss = viewModel::dismissMenus
            )
        }

        // ── 14. Sleep timer sheet ──────────────────────────────────────────
        AnimatedVisibility(
            visible  = state.showSleepTimer,
            enter    = slideInVertically(initialOffsetY = { it }),
            exit     = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            SleepTimerSheet(
                remainingMs   = state.sleepTimerRemainingMs,
                onSetTimer    = viewModel::setSleepTimer,
                onCancelTimer = viewModel::cancelSleepTimer,
                onDismiss     = viewModel::dismissMenus
            )
        }

        // ── 15. Video info overlay ─────────────────────────────────────────
        if (state.showVideoInfo) {
            VideoInfoOverlay(
                state    = state,
                onDismiss = viewModel::toggleVideoInfo,
                modifier = Modifier.align(Alignment.TopStart).padding(16.dp)
            )
        }

        // ── Subtitle Style sheet ───────────────────────────────────────────
        AnimatedVisibility(
            visible  = state.showSubtitleStyleMenu,
            enter    = slideInVertically(initialOffsetY = { it }),
            exit     = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            SubtitleStyleSheet(
                fontSize        = state.subtitleFontSize,
                textColor       = state.subtitleColor,
                bgOpacity       = state.subtitleBgColor.alpha,
                onFontSizeChange = viewModel::setSubtitleFontSize,
                onColorChange   = viewModel::setSubtitleColor,
                onBgOpacityChange = viewModel::setSubtitleBgOpacity,
                onDismiss       = viewModel::toggleSubtitleStyleMenu
            )
        }

        // ── Network URL dialog ─────────────────────────────────────────────
        if (state.showNetworkUrlDialog) {
            NetworkUrlDialog(
                currentUrl = state.networkUrl,
                onPlay     = viewModel::playNetworkUrl,
                onDismiss  = viewModel::dismissNetworkUrlDialog
            )
        }

        // ── Audio-Only Mode Overlay ──────────────────────────────────────────
        if (state.isAudioOnlyMode) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0A0A1A)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.MusicNote,
                        null,
                        tint = Color(0xFF5C6BC0),
                        modifier = Modifier.size(80.dp)
                    )
                    Spacer(Modifier.height(16.dp))
                    Text(
                        state.title,
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 32.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Audio Only Mode — Screen may turn off",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 13.sp
                    )
                    Spacer(Modifier.height(24.dp))
                    OutlinedButton(
                        onClick = viewModel::toggleAudioOnlyMode,
                        colors  = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFF5C6BC0))
                    ) {
                        Icon(Icons.Default.Videocam, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Back to Video")
                    }
                }
            }
        }

        // ── Color Filter sheet ──────────────────────────────────────────────
        AnimatedVisibility(
            visible  = state.showColorFilter,
            enter    = slideInVertically(initialOffsetY = { it }),
            exit     = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            VideoColorFilterSheet(
                colorState         = state.colorState,
                activeProfile      = state.activeEnhanceProfile,
                isAnalyzing        = state.isSmartEnhancing,
                onProfileSelected  = viewModel::applyEnhanceProfile,
                onSmartEnhanceAuto = viewModel::applyAutoSmartEnhance,
                onBrightnessChange = viewModel::setBrightness,
                onContrastChange   = viewModel::setContrast,
                onSaturationChange = viewModel::setSaturation,
                onHueChange        = viewModel::setHueShift,
                onGammaChange      = viewModel::setGamma,
                onSharpnessChange  = viewModel::setSharpness,
                onNoiseReduction   = viewModel::setNoiseReduction,
                onReset            = viewModel::resetColorFilter,
                onDismiss          = viewModel::toggleColorFilter
            )
        }

        // ── Chapters sheet ───────────────────────────────────────────────
        AnimatedVisibility(
            visible  = state.showChapters,
            enter    = slideInVertically(initialOffsetY = { it }),
            exit     = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            ChaptersSheet(
                chapters         = state.chapters,
                currentPositionMs = state.currentPositionMs,
                onChapterClick   = viewModel::seekTo,
                onDismiss        = viewModel::toggleChapters
            )
        }

        // ── Cast sheet ────────────────────────────────────────────────────
        AnimatedVisibility(
            visible  = state.showCastSheet,
            enter    = slideInVertically(initialOffsetY = { it }),
            exit     = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            CastSheet(
                devices     = state.castDevices,
                isScanning  = state.isCastScanning,
                onDeviceClick = viewModel::connectCastDevice,
                onScan      = viewModel::showCastSheet,
                onDismiss   = viewModel::dismissCastSheet
            )
        }

        // ── Clock overlay ─────────────────────────────────────────────────
        if (state.showClock) {
            ClockOverlay(modifier = Modifier.align(Alignment.TopEnd).padding(top = 56.dp, end = 16.dp))
        }

        // ── Video Equalizer sheet ─────────────────────────────────────────────────────
        AnimatedVisibility(
            visible  = state.showVideoEq,
            enter    = slideInVertically(initialOffsetY = { it }),
            exit     = slideOutVertically(targetOffsetY = { it }),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            VideoEqualizerSheet(
                onBandChange = viewModel::setVideoEqBand,
                onReset      = viewModel::resetVideoEq,
                onDismiss    = viewModel::toggleVideoEq
            )
        }

        // ── 16. Screenshot flash ───────────────────────────────────────────
        if (state.showScreenshotFlash) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.White.copy(alpha = 0.6f))
            )
        }

        // ── 17. Brightness / Volume HUD ────────────────────────────────────
        if (state.showControls) {
            VolumeAndBrightnessHud(
                brightness    = state.brightness,
                volumePercent = state.volumePercent,
                modifier      = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 16.dp)
            )
        }

        // ── 18. Subtitle overlay with style params ────────────────────────
        SubtitleOverlay(
            subtitle         = state.currentSubtitle,
            textSize         = state.subtitleFontSize,
            textColor        = state.subtitleColor,
            backgroundColor  = state.subtitleBgColor,
            bottomPadding    = if (state.showControls) 80 else 40
        )

        // ── 19. Sleep timer badge ──────────────────────────────────────────
        if (state.sleepTimerRemainingMs > 0 && !state.showSleepTimer) {
            SleepTimerBadge(
                remainingMs = state.sleepTimerRemainingMs,
                modifier    = Modifier.align(Alignment.TopCenter).padding(top = 12.dp)
            )
        }

        // ── 20. Long-press 2x speed indicator ────────────────────────────
        if (state.isTempSpeed2x) {
            Speed2xBadge(modifier = Modifier.align(Alignment.Center))
        }

        // ── Resume from last position prompt ─────────────────────────────
        if (state.showResumePrompt && state.resumedFromMs > 0) {
            ResumePromptBadge(
                positionMs = state.resumedFromMs,
                onDismiss  = viewModel::dismissResumePrompt,
                onRestart  = viewModel::seekToBeginning,
                modifier   = Modifier.align(Alignment.BottomCenter).padding(bottom = 90.dp)
            )
        }

        // ── Bookmark saved badge ──────────────────────────────────────────
        if (state.showBookmarkSaved) {
            BookmarkSavedBadge(modifier = Modifier.align(Alignment.TopCenter).padding(top = 60.dp))
        }

        // ── 21. Zoom level badge (when zoomed) ────────────────────────────
        if (state.zoomScale != 1f && state.zoomScale != 0f) {
            ZoomBadge(
                zoomScale = state.zoomScale,
                modifier  = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = if (state.sleepTimerRemainingMs > 0) 48.dp else 12.dp)
            )
        }
    }
}
