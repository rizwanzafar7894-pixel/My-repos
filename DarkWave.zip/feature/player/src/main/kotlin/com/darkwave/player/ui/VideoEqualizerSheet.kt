package com.darkwave.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val SheetBg     = Color(0xF2111120)
private val AccentColor = Color(0xFF5C6BC0)

// Standard 5-band EQ presets (gain in millibel: 1000 = +1dB)
private val eqPresets = listOf(
    "Flat"       to listOf(0, 0, 0, 0, 0),
    "Bass Boost" to listOf(800, 400, 0, 0, 0),
    "Treble"     to listOf(0, 0, 0, 400, 800),
    "Vocal"      to listOf(-300, 200, 600, 200, -300),
    "Rock"       to listOf(400, 200, -100, 200, 400),
    "Pop"        to listOf(-100, 300, 500, 300, -100),
    "Classical"  to listOf(300, 100, -200, 100, 300),
    "Movie"      to listOf(200, -100, 300, -100, 200)
)

private val bandLabels = listOf("60Hz", "230Hz", "910Hz", "3.6kHz", "14kHz")

@Composable
fun VideoEqualizerSheet(
    onBandChange: (band: Short, levelMb: Short) -> Unit,
    onReset: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    // 5 bands, each starts at 0 (flat). Range: -1500..1500 millibel = -15dB..+15dB
    val bandLevels = remember { mutableStateListOf(0f, 0f, 0f, 0f, 0f) }
    var selectedPreset by remember { mutableStateOf("Flat") }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        color    = SheetBg
    ) {
        Column(modifier = Modifier.padding(16.dp)) {

            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.GraphicEq, null, tint = AccentColor, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Equalizer", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Row {
                    TextButton(onClick = {
                        for (i in bandLevels.indices) bandLevels[i] = 0f
                        selectedPreset = "Flat"
                        onReset()
                    }) {
                        Text("Reset", color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp)
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, null, tint = Color.White.copy(alpha = 0.6f))
                    }
                }
            }

            // Preset chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Scrollable row of presets
                eqPresets.forEach { (name, gains) ->
                    val active = selectedPreset == name
                    Surface(
                        shape  = RoundedCornerShape(20.dp),
                        color  = if (active) AccentColor else AccentColor.copy(alpha = 0.15f),
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .let { m ->
                                // Make it clickable
                                m
                            }
                    ) {
                        TextButton(
                            onClick = {
                                selectedPreset = name
                                gains.forEachIndexed { i, gain ->
                                    bandLevels[i] = gain.toFloat()
                                    onBandChange(i.toShort(), gain.toShort())
                                }
                            },
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                name,
                                color = if (active) Color.White else Color.White.copy(alpha = 0.6f),
                                fontSize = 11.sp,
                                fontWeight = if (active) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // 5-band sliders
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                bandLevels.forEachIndexed { index, level ->
                    Column(
                        modifier = Modifier.width(48.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        // dB label
                        Text(
                            "${if (level >= 0) "+" else ""}${(level / 100).toInt()}dB",
                            color = if (level > 0) AccentColor
                                    else if (level < 0) Color(0xFFEF5350)
                                    else Color.White.copy(alpha = 0.5f),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )

                        // Vertical slider (rotated)
                        Slider(
                            value = level,
                            onValueChange = { v ->
                                selectedPreset = "Custom"
                                bandLevels[index] = v
                                onBandChange(index.toShort(), v.toInt().toShort())
                            },
                            valueRange = -1500f..1500f,
                            steps = 29,
                            colors = SliderDefaults.colors(
                                thumbColor       = if (level >= 0) AccentColor else Color(0xFFEF5350),
                                activeTrackColor = if (level >= 0) AccentColor else Color(0xFFEF5350),
                                inactiveTrackColor = Color.White.copy(alpha = 0.1f)
                            ),
                            modifier = Modifier
                                .height(48.dp)
                                .width(140.dp)
                                .rotate(-90f)
                        )

                        // Frequency label
                        Text(
                            bandLabels[index],
                            color    = Color.White.copy(alpha = 0.5f),
                            fontSize = 9.sp
                        )
                    }
                }
            }

            // Visual EQ curve (simple bar chart)
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(32.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.3f)),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.Bottom
            ) {
                bandLevels.forEach { level ->
                    val fraction = ((level + 1500f) / 3000f).coerceIn(0f, 1f)
                    val barColor = when {
                        level > 500  -> AccentColor
                        level < -500 -> Color(0xFFEF5350)
                        else         -> Color.White.copy(alpha = 0.3f)
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(fraction.coerceAtLeast(0.05f))
                            .padding(horizontal = 2.dp)
                            .background(barColor, RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                    )
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}
