package com.darkwave.player.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.player.viewmodel.SubtitleTrack
import com.darkwave.player.viewmodel.VideoPlayerViewModel

@Composable
fun SubtitlePickerSheet(
    tracks: List<SubtitleTrack>,
    selectedIndex: Int,
    videoTitle: String = "",
    onTrackSelected: (Int) -> Unit,
    onPickFile: () -> Unit,
    onSubtitleDelay: (() -> Unit)? = null,
    onSubtitleStyle: (() -> Unit)? = null,
    onSearchOnline: ((query: String, lang: String) -> Unit)? = null,
    onDownloadOnlineSubtitle: ((VideoPlayerViewModel.OnlineSubtitleResult) -> Unit)? = null,
    onlineResults: List<VideoPlayerViewModel.OnlineSubtitleResult> = emptyList(),
    isSearchingOnline: Boolean = false,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showOnlineSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf(videoTitle.take(60)) }
    var langCode by remember { mutableStateOf("en") }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .background(Color(0xF0111120))
            .padding(bottom = 16.dp)
    ) {
        Column {
            // Handle
            Box(
                modifier = Modifier
                    .align(Alignment.CenterHorizontally)
                    .padding(top = 10.dp)
                    .size(width = 40.dp, height = 4.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.3f))
            )

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    if (showOnlineSearch) "Online Subtitle Search" else "Subtitles",
                    color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp
                )
                if (onSearchOnline != null) {
                    TextButton(onClick = { showOnlineSearch = !showOnlineSearch }) {
                        Text(
                            if (showOnlineSearch) "← Local" else "🌐 Online",
                            color = Color(0xFF9FA8DA), fontSize = 12.sp
                        )
                    }
                }
            }

            Divider(color = Color.White.copy(alpha = 0.1f))

            if (showOnlineSearch && onSearchOnline != null) {
                // Online search UI
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Movie / Episode name", color = Color.White.copy(alpha = 0.6f)) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = Color(0xFF9FA8DA),
                            unfocusedBorderColor = Color.White.copy(alpha = 0.3f)
                        ),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(
                            onSearch = { onSearchOnline(searchQuery, langCode) }
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Language:", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
                        Spacer(Modifier.width(8.dp))
                        listOf("en" to "English", "hi" to "Hindi", "es" to "Spanish", "fr" to "French").forEach { (code, label) ->
                            val selected = langCode == code
                            FilterChip(
                                selected = selected,
                                onClick = { langCode = code },
                                label = { Text(label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF3949AB),
                                    labelColor = Color.White,
                                    selectedLabelColor = Color.White
                                ),
                                modifier = Modifier.padding(end = 4.dp)
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { onSearchOnline(searchQuery, langCode) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3949AB)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (isSearchingOnline) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp
                            )
                            Spacer(Modifier.width(8.dp))
                        }
                        Text(if (isSearchingOnline) "Searching…" else "Search Subtitles")
                    }

                    if (onlineResults.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("${onlineResults.size} results found", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
                        Spacer(Modifier.height(4.dp))
                        LazyColumn(modifier = Modifier.heightIn(max = 280.dp)) {
                            itemsIndexed(onlineResults) { _, result ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { onDownloadOnlineSubtitle?.invoke(result); onDismiss() }
                                        .padding(vertical = 10.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Subtitles, null, tint = Color(0xFF9FA8DA), modifier = Modifier.size(18.dp))
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(result.fileName.take(50), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                                        Text(
                                            "${result.language.uppercase()} · ↓${result.downloadCount}",
                                            color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp
                                        )
                                    }
                                    Icon(Icons.Default.Download, null, tint = Color(0xFF9FA8DA), modifier = Modifier.size(18.dp))
                                }
                                Divider(color = Color.White.copy(alpha = 0.05f))
                            }
                        }
                    } else if (!isSearchingOnline) {
                        Box(Modifier.fillMaxWidth().padding(24.dp), Alignment.Center) {
                            Text(
                                "Search for subtitles using movie or episode name",
                                color = Color.White.copy(alpha = 0.4f),
                                fontSize = 13.sp,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                // Local tracks
                LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                    item {
                        SubtitleTrackRow("Off", Icons.Default.SubtitlesOff, selectedIndex == -1, { onTrackSelected(-1) })
                    }
                    itemsIndexed(tracks) { index, track ->
                        SubtitleTrackRow(track.name, Icons.Default.Subtitles, selectedIndex == index, { onTrackSelected(index) })
                    }
                    item {
                        SubtitleTrackRow("Open subtitle file…", Icons.Default.FolderOpen, false, onPickFile, tint = Color(0xFF9FA8DA))
                        if (onSubtitleDelay != null)
                            SubtitleTrackRow("Adjust subtitle delay…", Icons.Default.Tune, false, { onSubtitleDelay(); onDismiss() }, tint = Color(0xFF80CBC4))
                        if (onSubtitleStyle != null)
                            SubtitleTrackRow("Subtitle appearance…", Icons.Default.FormatSize, false, { onSubtitleStyle(); onDismiss() }, tint = Color(0xFFCE93D8))
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun SubtitleTrackRow(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    tint: Color = Color.White
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .background(if (selected) Color.White.copy(alpha = 0.08f) else Color.Transparent)
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (selected) Color(0xFF9FA8DA) else tint.copy(alpha = 0.7f), modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(14.dp))
        Text(label, color = if (selected) Color.White else tint.copy(alpha = 0.85f), fontSize = 14.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal, modifier = Modifier.weight(1f))
        if (selected) Icon(Icons.Default.Check, null, tint = Color(0xFF9FA8DA), modifier = Modifier.size(18.dp))
    }
}
