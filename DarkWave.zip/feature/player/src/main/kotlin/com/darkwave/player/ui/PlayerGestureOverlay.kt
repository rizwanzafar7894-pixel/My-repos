package com.darkwave.player.ui

import android.content.Context
import android.media.AudioManager
import android.provider.Settings
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

enum class GestureZone { LEFT, RIGHT, CENTER }

data class GestureState(
    val showVolume: Boolean = false,
    val volumeLevel: Float = 0f,       // 0..1
    val showBrightness: Boolean = false,
    val brightnessLevel: Float = 0f,   // 0..1
    val showSeek: Boolean = false,
    val seekDeltaSec: Int = 0,
    val showDoubleTapSeek: Boolean = false,
    val doubleTapSide: GestureZone = GestureZone.LEFT
)

/**
 * Drop-in overlay for gesture controls on VideoPlayerScreen.
 *
 * Usage:
 * ```
 * Box(modifier = Modifier.fillMaxSize()) {
 *     VideoSurface(...)
 *     PlayerGestureOverlay(
 *         durationMs = viewModel.duration,
 *         positionMs = viewModel.position,
 *         onSeekTo   = viewModel::seekTo,
 *         onPlayPause = viewModel::togglePlayPause,
 *         onToggleControls = { showControls = !showControls }
 *     )
 * }
 * ```
 */
@Composable
fun PlayerGestureOverlay(
    durationMs: Long,
    positionMs: Long,
    onSeekTo: (Long) -> Unit,
    onPlayPause: () -> Unit,
    onToggleControls: () -> Unit,
    onLongPressStart: () -> Unit = {},   // Long-press = 2× speed (MX Player signature)
    onLongPressEnd:   () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).toFloat() }

    var gestureState by remember { mutableStateOf(GestureState()) }
    var lastTapTime  by remember { mutableStateOf(0L) }
    var lastTapZone  by remember { mutableStateOf(GestureZone.CENTER) }
    var doubleTapCount by remember { mutableStateOf(0) }

    // Auto-hide gesture indicators
    LaunchedEffect(gestureState.showVolume, gestureState.showBrightness, gestureState.showSeek, gestureState.showDoubleTapSeek) {
        delay(1200)
        gestureState = gestureState.copy(
            showVolume = false,
            showBrightness = false,
            showSeek = false,
            showDoubleTapSeek = false
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            // ── Tap & Double-tap ──────────────────────────────────────
            .pointerInput(durationMs, positionMs) {
                detectTapGestures(
                    onLongPress = { onLongPressStart() },
                    onPress = { _ ->
                        val pressStart = System.currentTimeMillis()
                        tryAwaitRelease()
                        if (System.currentTimeMillis() - pressStart > 400L) {
                            onLongPressEnd()
                        }
                    },
                    onTap = { offset ->
                        val zone = when {
                            offset.x < size.width * 0.33f -> GestureZone.LEFT
                            offset.x > size.width * 0.66f -> GestureZone.RIGHT
                            else -> GestureZone.CENTER
                        }
                        val now = System.currentTimeMillis()
                        if (now - lastTapTime < 350 && zone == lastTapZone) {
                            // Double-tap
                            doubleTapCount++
                            val seekMs = if (zone == GestureZone.LEFT) -10_000L else 10_000L
                            val newPos = (positionMs + seekMs).coerceIn(0, durationMs)
                            onSeekTo(newPos)
                            gestureState = gestureState.copy(
                                showDoubleTapSeek = true,
                                doubleTapSide = zone
                            )
                        } else {
                            // Single tap
                            onToggleControls()
                        }
                        lastTapTime = now
                        lastTapZone = zone
                    }
                )
            }
    ) {
        // Left half: brightness control (vertical drag)
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(0.5f)
                .align(Alignment.CenterStart)
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dragAmount ->
                        val delta = -dragAmount / size.height
                        val current = try {
                            Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
                        } catch (e: Exception) { 0.5f }
                        val newBrightness = (current + delta).coerceIn(0f, 1f)
                        try {
                            Settings.System.putInt(
                                context.contentResolver,
                                Settings.System.SCREEN_BRIGHTNESS,
                                (newBrightness * 255).toInt()
                            )
                        } catch (_: Exception) {}
                        gestureState = gestureState.copy(
                            showBrightness = true,
                            brightnessLevel = newBrightness,
                            showVolume = false
                        )
                    }
                }
        )

        // Right half: volume control (vertical drag)
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(0.5f)
                .align(Alignment.CenterEnd)
                .pointerInput(Unit) {
                    detectVerticalDragGestures { _, dragAmount ->
                        val delta = -dragAmount / size.height
                        val currentVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                        val newVol = (currentVol + delta * maxVolume).coerceIn(0f, maxVolume)
                        audioManager.setStreamVolume(
                            AudioManager.STREAM_MUSIC,
                            newVol.toInt(),
                            0
                        )
                        gestureState = gestureState.copy(
                            showVolume = true,
                            volumeLevel = newVol / maxVolume,
                            showBrightness = false
                        )
                    }
                }
        )

        // Full width: horizontal drag for seek
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(durationMs, positionMs) {
                    var totalDrag = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { totalDrag = 0f },
                        onDragEnd = {
                            val seekMs = (totalDrag / size.width * durationMs * 0.2f).toLong()
                            val newPos = (positionMs + seekMs).coerceIn(0, durationMs)
                            onSeekTo(newPos)
                            gestureState = gestureState.copy(showSeek = false)
                        }
                    ) { _, dragAmount ->
                        totalDrag += dragAmount
                        val seekSec = (totalDrag / size.width * (durationMs / 1000) * 0.2f).toInt()
                        gestureState = gestureState.copy(
                            showSeek = true,
                            seekDeltaSec = seekSec
                        )
                    }
                }
        )

        // ── Gesture Indicators ────────────────────────────────────────

        // Volume indicator (right side)
        AnimatedVisibility(
            visible = gestureState.showVolume,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.CenterEnd).padding(end = 32.dp)
        ) {
            GestureIndicator(
                icon = when {
                    gestureState.volumeLevel > 0.6f -> Icons.Default.VolumeUp
                    gestureState.volumeLevel > 0f   -> Icons.Default.VolumeDown
                    else                            -> Icons.Default.VolumeOff
                },
                value = gestureState.volumeLevel,
                label = "${(gestureState.volumeLevel * 100).toInt()}%"
            )
        }

        // Brightness indicator (left side)
        AnimatedVisibility(
            visible = gestureState.showBrightness,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.CenterStart).padding(start = 32.dp)
        ) {
            GestureIndicator(
                icon = when {
                    gestureState.brightnessLevel > 0.6f -> Icons.Default.BrightnessHigh
                    gestureState.brightnessLevel > 0f   -> Icons.Default.BrightnessMedium
                    else                                -> Icons.Default.BrightnessLow
                },
                value = gestureState.brightnessLevel,
                label = "${(gestureState.brightnessLevel * 100).toInt()}%"
            )
        }

        // Seek indicator (center)
        AnimatedVisibility(
            visible = gestureState.showSeek,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.Center)
        ) {
            val delta = gestureState.seekDeltaSec
            Box(
                modifier = Modifier
                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                    .padding(horizontal = 20.dp, vertical = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (delta >= 0) Icons.Default.FastForward else Icons.Default.FastRewind,
                        null, tint = Color.White, modifier = Modifier.size(24.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = "${if (delta >= 0) "+" else ""}${delta}s",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }
        }

        // Double-tap seek ripple (left/right)
        AnimatedVisibility(
            visible = gestureState.showDoubleTapSeek,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(
                if (gestureState.doubleTapSide == GestureZone.LEFT) Alignment.CenterStart
                else Alignment.CenterEnd
            )
        ) {
            val isLeft = gestureState.doubleTapSide == GestureZone.LEFT
            Box(
                modifier = Modifier
                    .width(120.dp)
                    .fillMaxHeight()
                    .background(Color.White.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        if (isLeft) Icons.Default.FastRewind else Icons.Default.FastForward,
                        null, tint = Color.White, modifier = Modifier.size(36.dp)
                    )
                    Text("10s", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun GestureIndicator(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: Float,
    label: String
) {
    Column(
        modifier = Modifier
            .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(12.dp))
            .padding(12.dp)
            .width(56.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(24.dp))
        // Vertical progress bar
        Box(
            modifier = Modifier
                .width(4.dp)
                .height(80.dp)
                .background(Color.White.copy(alpha = 0.3f), RoundedCornerShape(2.dp))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(value)
                    .align(Alignment.BottomCenter)
                    .background(Color.White, RoundedCornerShape(2.dp))
            )
        }
        Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}
