package com.darkwave.player.ui

import android.app.Activity
import android.graphics.Bitmap
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.BorderStroke
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.player.viewmodel.PlayerUiState

private val SheetBg  = Color(0xF2111120)
private val AccentColor = Color(0xFF5C6BC0)

// ── 1. PINCH TO ZOOM ─────────────────────────────────────────────────────
@Composable
fun PinchZoomOverlay(
    modifier: Modifier = Modifier,
    onZoom: (Float) -> Unit
) {
    var scale by remember { mutableFloatStateOf(1f) }
    Box(
        modifier = modifier.pointerInput(Unit) {
            detectTransformGestures { _, _, zoom, _ ->
                scale = (scale * zoom).coerceIn(0.5f, 4f)
                onZoom(scale)
            }
        }
    )
}

// ── 2. VIDEO INFO OVERLAY ────────────────────────────────────────────────
@Composable
fun VideoInfoOverlay(
    state: PlayerUiState,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier  = modifier,
        shape     = RoundedCornerShape(12.dp),
        color     = SheetBg,
        shadowElevation = 8.dp
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Video Info", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                IconButton(onClick = onDismiss, modifier = Modifier.size(20.dp)) {
                    Icon(Icons.Default.Close, null, tint = Color.White.copy(alpha = 0.6f), modifier = Modifier.size(16.dp))
                }
            }
            Divider(color = Color.White.copy(alpha = 0.1f))
            InfoRow("Resolution", if (state.videoWidth > 0) "${state.videoWidth}×${state.videoHeight}" else "—")
            InfoRow("Aspect Ratio", if (state.videoWidth > 0) String.format("%.2f:1", state.aspectRatio) else "—")
            InfoRow("Duration", formatMs(state.durationMs))
            InfoRow("Position", formatMs(state.currentPositionMs))
            InfoRow("Speed", "${state.playbackSpeed}x")
            InfoRow("Volume", "${state.volumePercent}%")
            if (state.audioTracks.isNotEmpty()) {
                val track = state.audioTracks.getOrNull(state.selectedAudioTrackIndex)
                InfoRow("Audio", track?.label ?: "—")
                InfoRow("Codec", track?.codec ?: "—")
                InfoRow("Channels", when(track?.channels) {
                    1 -> "Mono"; 2 -> "Stereo"; 6 -> "5.1 Surround"; 8 -> "7.1 Surround"; else -> "${track?.channels}ch"
                })
                if ((track?.bitrate ?: 0) > 0)
                    InfoRow("Audio Bitrate", "${(track!!.bitrate / 1000)}kbps")
            }
            InfoRow("Subtitles", if (state.subtitleTrackIndex >= 0) "Active" else "Off")
            if (state.subtitleDelayMs != 0L)
                InfoRow("Sub Delay", "${state.subtitleDelayMs}ms")
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth()) {
        Text(label, color = Color.White.copy(alpha = 0.5f), fontSize = 12.sp, modifier = Modifier.width(110.dp))
        Text(value, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

private fun formatMs(ms: Long): String {
    val totalSec = ms / 1000
    val h = totalSec / 3600; val m = (totalSec % 3600) / 60; val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

// ── 3. SLEEP TIMER SHEET ─────────────────────────────────────────────────
private val timerOptions = listOf(
    "5 min"  to 5 * 60_000L,
    "10 min" to 10 * 60_000L,
    "15 min" to 15 * 60_000L,
    "30 min" to 30 * 60_000L,
    "45 min" to 45 * 60_000L,
    "1 hour" to 60 * 60_000L,
    "End of video" to -1L
)

@Composable
fun SleepTimerSheet(
    remainingMs: Long,
    onSetTimer: (Long) -> Unit,
    onCancelTimer: () -> Unit,
    onDismiss: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        color    = SheetBg
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Sleep Timer", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                if (remainingMs > 0) {
                    TextButton(onClick = onCancelTimer) {
                        Text("Cancel", color = Color(0xFFE53935), fontSize = 13.sp)
                    }
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, null, tint = Color.White.copy(alpha = 0.6f))
                }
            }
            if (remainingMs > 0) {
                Text(
                    "Remaining: ${formatMs(remainingMs)}",
                    color = AccentColor,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
            }
            timerOptions.forEach { (label, ms) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSetTimer(ms); onDismiss() }
                        .padding(vertical = 12.dp, horizontal = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Timer,
                        null,
                        tint  = AccentColor,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(label, color = Color.White, fontSize = 14.sp)
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ── 4. SLEEP TIMER BADGE ─────────────────────────────────────────────────
@Composable
fun SleepTimerBadge(remainingMs: Long, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape    = RoundedCornerShape(20.dp),
        color    = Color.Black.copy(alpha = 0.6f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Timer, null, tint = AccentColor, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(5.dp))
            Text(formatMs(remainingMs), color = Color.White, fontSize = 12.sp)
        }
    }
}

// ── 5. SUBTITLE DELAY SHEET ──────────────────────────────────────────────
@Composable
fun SubtitleDelaySheet(
    delayMs: Long,
    onDelayChange: (Long) -> Unit,
    onDismiss: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        color    = SheetBg
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Subtitle Delay", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, null, tint = Color.White.copy(alpha = 0.6f))
                }
            }
            Spacer(Modifier.height(12.dp))
            Text(
                "${if (delayMs >= 0) "+" else ""}${delayMs}ms",
                color      = if (delayMs == 0L) Color.White else AccentColor,
                fontSize   = 32.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf(-500L, -100L, -50L).forEach { delta ->
                    OutlinedButton(
                        onClick = { onDelayChange(delayMs + delta) },
                        colors  = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                    ) { Text("${delta}ms", fontSize = 12.sp) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf(50L, 100L, 500L).forEach { delta ->
                    OutlinedButton(
                        onClick = { onDelayChange(delayMs + delta) },
                        colors  = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                    ) { Text("+${delta}ms", fontSize = 12.sp) }
                }
            }
            Spacer(Modifier.height(8.dp))
            TextButton(onClick = { onDelayChange(0L) }) {
                Text("Reset to 0ms", color = Color(0xFFE53935))
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

// ── 6. SPEED 2X BADGE ────────────────────────────────────────────────────
@Composable
fun Speed2xBadge(modifier: Modifier = Modifier) {
    Surface(
        modifier  = modifier,
        shape     = RoundedCornerShape(12.dp),
        color     = Color.Black.copy(alpha = 0.6f)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("▶▶  2×", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
    }
}

// ── 7. ZOOM BADGE ─────────────────────────────────────────────────────────
@Composable
fun ZoomBadge(zoomScale: Float, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape    = RoundedCornerShape(20.dp),
        color    = Color.Black.copy(alpha = 0.5f)
    ) {
        Text(
            "🔍 ${"%.1f".format(zoomScale)}×",
            color    = Color.White,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
        )
    }
}

// ── 8. SUBTITLE STYLE SHEET ───────────────────────────────────────────────
@Composable
fun SubtitleStyleSheet(
    fontSize: Float,
    textColor: androidx.compose.ui.graphics.Color,
    bgOpacity: Float,
    onFontSizeChange: (Float) -> Unit,
    onColorChange: (androidx.compose.ui.graphics.Color) -> Unit,
    onBgOpacityChange: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    val subtitleColors = listOf(
        "White"  to androidx.compose.ui.graphics.Color.White,
        "Yellow" to androidx.compose.ui.graphics.Color(0xFFFFEB3B),
        "Cyan"   to androidx.compose.ui.graphics.Color(0xFF00BCD4),
        "Green"  to androidx.compose.ui.graphics.Color(0xFF4CAF50),
        "Orange" to androidx.compose.ui.graphics.Color(0xFFFF9800),
    )

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        color    = SheetBg
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Subtitle Style", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, null, tint = Color.White.copy(alpha = 0.6f))
                }
            }

            Spacer(Modifier.height(12.dp))

            // Font size
            Text("Font Size: ${fontSize.toInt()}sp", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
            Slider(
                value = fontSize,
                onValueChange = onFontSizeChange,
                valueRange = 12f..32f,
                steps = 9,
                colors = SliderDefaults.colors(thumbColor = AccentColor, activeTrackColor = AccentColor),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(8.dp))

            // BG Opacity
            Text("Background Opacity: ${(bgOpacity * 100).toInt()}%", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
            Slider(
                value = bgOpacity,
                onValueChange = onBgOpacityChange,
                valueRange = 0f..1f,
                colors = SliderDefaults.colors(thumbColor = AccentColor, activeTrackColor = AccentColor),
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(8.dp))

            // Text color chips
            Text("Text Color", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                subtitleColors.forEach { (name, color) ->
                    val selected = textColor == color
                    Surface(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .clickable { onColorChange(color) },
                        color = color,
                        border = if (selected)
                            BorderStroke(2.dp, AccentColor)
                        else null
                    ) {}
                }
            }

            // Preview
            Spacer(Modifier.height(12.dp))
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = Color.Black.copy(alpha = bgOpacity)
            ) {
                Text(
                    "Sample subtitle text",
                    color    = textColor,
                    fontSize = androidx.compose.ui.unit.TextUnit(fontSize, androidx.compose.ui.unit.TextUnitType.Sp),
                    modifier = Modifier.padding(8.dp),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}

// ── 9. NETWORK URL DIALOG ─────────────────────────────────────────────────
@Composable
fun NetworkUrlDialog(
    currentUrl: String = "",
    onPlay: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var url by remember { mutableStateOf(currentUrl) }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Open Network Stream", color = Color.White, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    "Enter URL (HTTP, HLS, DASH, RTSP)",
                    color = Color.White.copy(alpha = 0.6f),
                    fontSize = 12.sp
                )
                OutlinedTextField(
                    value = url,
                    onValueChange = { url = it },
                    placeholder = { Text("https://example.com/stream.m3u8", fontSize = 13.sp) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        cursorColor = AccentColor,
                        focusedBorderColor = AccentColor
                    )
                )
                // Quick paste examples
                Text("Common formats:", color = Color.White.copy(alpha = 0.4f), fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("HLS (.m3u8)", "DASH (.mpd)", "RTSP://", "HTTP MP4").forEach { hint ->
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = AccentColor.copy(alpha = 0.15f)
                        ) {
                            Text(hint, color = AccentColor, fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (url.isNotBlank()) onPlay(url.trim()) },
                enabled = url.isNotBlank()
            ) { Text("Play", color = AccentColor, fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Color.White.copy(alpha = 0.6f)) }
        },
        containerColor = Color(0xFF1A1A2E)
    )
}

// ── 10. RESUME PROMPT ────────────────────────────────────────────────────
@Composable
fun ResumePromptBadge(
    positionMs: Long,
    onDismiss: () -> Unit,
    onRestart: () -> Unit,
    modifier: Modifier = Modifier
) {
    val minutes = positionMs / 60000
    val seconds = (positionMs % 60000) / 1000
    val timeStr = if (minutes > 0) "${minutes}m ${seconds}s" else "${seconds}s"

    Surface(
        modifier = modifier,
        shape    = RoundedCornerShape(12.dp),
        color    = Color(0xEE1A1A2E)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(Icons.Default.History, null, tint = AccentColor, modifier = Modifier.size(18.dp))
            Text("Resumed from $timeStr", color = Color.White, fontSize = 13.sp)
            Spacer(Modifier.width(4.dp))
            TextButton(
                onClick = onRestart,
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
            ) { Text("Start over", color = AccentColor, fontSize = 12.sp) }
            IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.Close, null, tint = Color.White.copy(alpha = 0.5f), modifier = Modifier.size(14.dp))
            }
        }
    }
}

// ── 11. BOOKMARK SAVED BADGE ─────────────────────────────────────────────
@Composable
fun BookmarkSavedBadge(modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape    = RoundedCornerShape(20.dp),
        color    = Color(0xCC1B5E20)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(Icons.Default.Bookmark, null, tint = Color(0xFF81C784), modifier = Modifier.size(16.dp))
            Text("Bookmark saved", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
    }
}

// ── 12. CHAPTERS SHEET ───────────────────────────────────────────────────
data class Chapter(val titleText: String, val startMs: Long, val endMs: Long)

@Composable
fun ChaptersSheet(
    chapters: List<Chapter>,
    currentPositionMs: Long,
    onChapterClick: (Long) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        color    = SheetBg
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MenuBook, null, tint = AccentColor, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Chapters (${chapters.size})", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, null, tint = Color.White.copy(alpha = 0.6f))
                }
            }
            Spacer(Modifier.height(8.dp))
            if (chapters.isEmpty()) {
                Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("No chapters found", color = Color.White.copy(alpha = 0.4f), fontSize = 14.sp)
                }
            } else {
                chapters.forEach { chapter ->
                    val isActive = currentPositionMs >= chapter.startMs &&
                        (chapter.endMs == 0L || currentPositionMs < chapter.endMs)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isActive) AccentColor.copy(alpha = 0.15f) else Color.Transparent)
                            .clickable { onChapterClick(chapter.startMs); onDismiss() }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (isActive) {
                            Icon(Icons.Default.PlayArrow, null, tint = AccentColor, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(8.dp))
                        } else {
                            Spacer(Modifier.width(24.dp))
                        }
                        Text(
                            chapter.titleText,
                            color = if (isActive) Color.White else Color.White.copy(alpha = 0.8f),
                            fontWeight = if (isActive) FontWeight.SemiBold else FontWeight.Normal,
                            fontSize = 14.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            formatMs(chapter.startMs),
                            color = if (isActive) AccentColor else Color.White.copy(alpha = 0.4f),
                            fontSize = 12.sp
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

private fun formatMs(ms: Long): String {
    val h = ms / 3600000
    val m = (ms % 3600000) / 60000
    val s = (ms % 60000) / 1000
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

// ── 13. CAST/DLNA SHEET ──────────────────────────────────────────────────
data class CastDevice(val id: String, val name: String, val type: CastType, val isConnected: Boolean = false)
enum class CastType { CHROMECAST, DLNA, AIRPLAY, MIRACAST }

@Composable
fun CastSheet(
    devices: List<CastDevice>,
    isScanning: Boolean,
    onDeviceClick: (CastDevice) -> Unit,
    onScan: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape    = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        color    = SheetBg
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Cast, null, tint = AccentColor, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Cast to Device", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
                Row {
                    if (isScanning) {
                        CircularProgressIndicator(color = AccentColor, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    } else {
                        IconButton(onClick = onScan, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.Refresh, null, tint = AccentColor, modifier = Modifier.size(18.dp))
                        }
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, null, tint = Color.White.copy(alpha = 0.6f))
                    }
                }
            }
            Spacer(Modifier.height(8.dp))

            if (devices.isEmpty() && !isScanning) {
                Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CastConnected, null, tint = Color.White.copy(alpha = 0.3f), modifier = Modifier.size(48.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("No devices found", color = Color.White.copy(alpha = 0.4f))
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = onScan) { Text("Scan again", color = AccentColor) }
                }
            }

            devices.forEach { device ->
                val icon = when (device.type) {
                    CastType.CHROMECAST -> Icons.Default.Cast
                    CastType.DLNA       -> Icons.Default.Tv
                    CastType.AIRPLAY    -> Icons.Default.Airplay
                    CastType.MIRACAST   -> Icons.Default.ScreenShare
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (device.isConnected) AccentColor.copy(alpha = 0.15f) else Color.Transparent)
                        .clickable { onDeviceClick(device) }
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(icon, null, tint = if (device.isConnected) AccentColor else Color.White.copy(alpha = 0.6f), modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(device.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                        Text(device.type.name.lowercase().replaceFirstChar { it.uppercase() },
                            color = Color.White.copy(alpha = 0.4f), fontSize = 11.sp)
                    }
                    if (device.isConnected) {
                        Text("Connected", color = AccentColor, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

// ── 14. CLOCK OVERLAY ────────────────────────────────────────────────────
@Composable
fun ClockOverlay(modifier: Modifier = Modifier) {
    val time by produceState(initialValue = "") {
        while (true) {
            val cal = java.util.Calendar.getInstance()
            val h = cal.get(java.util.Calendar.HOUR_OF_DAY)
            val m = cal.get(java.util.Calendar.MINUTE)
            value = "%02d:%02d".format(h, m)
            kotlinx.coroutines.delay(10_000) // update every 10s
        }
    }
    Surface(
        modifier = modifier,
        shape    = RoundedCornerShape(6.dp),
        color    = Color.Black.copy(alpha = 0.5f)
    ) {
        Text(
            time,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}
