package com.darkwave.player.ui

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val TrackColor    = Color.White.copy(alpha = 0.25f)
private val BufferedColor = Color.White.copy(alpha = 0.45f)
private val ProgressColor = Color(0xFF5C6BC0)
private val ThumbColor    = Color.White

// ── Thumbnail cache to avoid repeated extraction ───────────────────────────
private val thumbnailCache = LinkedHashMap<Long, Bitmap>(16, 0.75f, true).also { map ->
    // LRU eviction at 20 entries
    object : LinkedHashMap<Long, Bitmap>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, Bitmap>?) =
            size > 20
    }
}

@Composable
fun PlayerSeekBar(
    position: Long,
    buffered: Long,
    duration: Long,
    videoUri: String = "",          // For thumbnail extraction
    onSeekTo: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isDragging   by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }
    var trackWidthPx by remember { mutableFloatStateOf(1f) }

    // Thumbnail state
    var thumbBitmap  by remember { mutableStateOf<Bitmap?>(null) }
    var thumbJob: Job? by remember { mutableStateOf(null) }
    val coroutineScope = rememberCoroutineScope()

    val fraction = if (isDragging) dragFraction
                   else if (duration > 0) position.toFloat() / duration else 0f
    val bufferedFraction = if (duration > 0) buffered.toFloat() / duration else 0f

    // Compute display position string while dragging
    val dragPositionMs = (dragFraction * duration).toLong()
    val seekTimeStr = remember(dragPositionMs) { formatMs(dragPositionMs) }

    // Thumbnail x offset on screen (clamped so it doesn't go off-edge)
    val thumbnailWidthDp = 120.dp
    val thumbOffsetX by remember(dragFraction, trackWidthPx) {
        derivedStateOf {
            val px = dragFraction * trackWidthPx
            px.dp - thumbnailWidthDp / 2
        }
    }

    Column(modifier = modifier) {

        // ── Thumbnail preview popup ───────────────────────────────────────
        AnimatedVisibility(
            visible = isDragging && videoUri.isNotEmpty(),
            enter = fadeIn(),
            exit  = fadeOut()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .padding(bottom = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .offset(x = thumbOffsetX.coerceIn(0.dp, (trackWidthPx - thumbnailWidthDp.value * 3).dp))
                        .width(thumbnailWidthDp)
                        .height(68.dp)
                        .shadow(8.dp, RoundedCornerShape(6.dp))
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF1A1A2E))
                        .align(Alignment.BottomStart)
                ) {
                    val bmp = thumbBitmap
                    if (bmp != null) {
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Box(Modifier.fillMaxSize().background(Color(0xFF1A1A2E)))
                    }
                    // Time label overlay
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.55f))
                            .padding(vertical = 2.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            seekTimeStr,
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // ── Seek bar track ────────────────────────────────────────────────
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(28.dp)
                .pointerInput(duration) {
                    detectTapGestures { offset ->
                        val frac = (offset.x / trackWidthPx).coerceIn(0f, 1f)
                        onSeekTo((frac * duration).toLong())
                    }
                }
                .pointerInput(duration, videoUri) {
                    detectHorizontalDragGestures(
                        onDragStart = { offset ->
                            isDragging = true
                            dragFraction = (offset.x / trackWidthPx).coerceIn(0f, 1f)
                        },
                        onDragEnd = {
                            isDragging = false
                            onSeekTo((dragFraction * duration).toLong())
                            thumbBitmap = null
                        },
                        onDragCancel = {
                            isDragging = false
                            thumbBitmap = null
                        },
                        onHorizontalDrag = { change, dragAmount ->
                            change.consume()
                            dragFraction = (dragFraction + dragAmount / trackWidthPx).coerceIn(0f, 1f)

                            // Throttled thumbnail extraction
                            thumbJob?.cancel()
                            thumbJob = coroutineScope.launch {
                                delay(80)  // debounce 80ms
                                val seekMs = (dragFraction * duration).toLong()
                                val snappedMs = (seekMs / 2000L) * 2000L  // snap to 2s grid for cache
                                val cached = thumbnailCache[snappedMs]
                                if (cached != null) {
                                    thumbBitmap = cached
                                } else {
                                    val bmp = withContext(Dispatchers.IO) {
                                        extractFrame(videoUri, seekMs)
                                    }
                                    if (bmp != null) {
                                        thumbnailCache[snappedMs] = bmp
                                        thumbBitmap = bmp
                                    }
                                }
                            }
                        }
                    )
                },
            contentAlignment = Alignment.CenterStart
        ) {
            // Background track
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (isDragging) 5.dp else 3.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(TrackColor)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(bufferedFraction)
                        .fillMaxHeight()
                        .background(BufferedColor)
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth(fraction)
                        .fillMaxHeight()
                        .background(ProgressColor)
                )
            }

            // Thumb knob
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .onSizeChanged { trackWidthPx = it.width.toFloat() }
            ) {
                Box(
                    modifier = Modifier
                        .offset(x = ((fraction * trackWidthPx) - 6.dp.value).dp)
                        .size(if (isDragging) 18.dp else 12.dp)
                        .clip(CircleShape)
                        .background(ThumbColor)
                        .align(Alignment.CenterStart)
                )
            }
        }
    }
}

// ── Frame extraction via MediaMetadataRetriever ────────────────────────────
private fun extractFrame(videoUri: String, positionMs: Long): Bitmap? {
    if (videoUri.isEmpty()) return null
    return try {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(videoUri)
        // OPTION_CLOSEST_SYNC = faster; OPTION_CLOSEST = more accurate but slower
        val bmp = retriever.getFrameAtTime(
            positionMs * 1000L,
            MediaMetadataRetriever.OPTION_CLOSEST_SYNC
        )
        retriever.release()
        bmp
    } catch (_: Exception) { null }
}

private fun formatMs(ms: Long): String {
    val h = ms / 3_600_000; val m = (ms % 3_600_000) / 60_000; val s = (ms % 60_000) / 1_000
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

