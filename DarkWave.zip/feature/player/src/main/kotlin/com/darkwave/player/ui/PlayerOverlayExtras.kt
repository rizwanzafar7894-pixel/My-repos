package com.darkwave.player.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.player.viewmodel.SeekSide
import com.darkwave.player.viewmodel.playbackSpeeds

// ── Double tap seek flash ────────────────────────────────────────────────
@Composable
fun SeekFlashOverlay(side: SeekSide, modifier: Modifier = Modifier) {
    Box(modifier = modifier) {
        if (side == SeekSide.LEFT) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.35f)
                    .background(Color.White.copy(alpha = 0.12f))
                    .align(Alignment.CenterStart),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Replay10, null, tint = Color.White, modifier = Modifier.size(36.dp))
                    Text("-10s", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        } else {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.35f)
                    .background(Color.White.copy(alpha = 0.12f))
                    .align(Alignment.CenterEnd),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Forward10, null, tint = Color.White, modifier = Modifier.size(36.dp))
                    Text("+10s", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

// ── Gesture drag zone for brightness/volume ──────────────────────────────
@Composable
fun GestureDragZone(
    modifier: Modifier = Modifier,
    onDrag: (Float) -> Unit
) {
    Box(
        modifier = modifier.pointerInput(Unit) {
            detectVerticalDragGestures { _, dragAmount -> onDrag(dragAmount) }
        }
    )
}

// ── Lock overlay — just shows unlock icon centered ───────────────────────
@Composable
fun LockOverlay(onUnlock: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.15f))
                .clickable(onClick = onUnlock)
                .padding(16.dp)
        ) {
            Icon(Icons.Default.Lock, "Unlock", tint = Color.White, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(6.dp))
        Text("Tap to unlock", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
    }
}

// ── Brightness / Volume HUD ───────────────────────────────────────────────
@Composable
fun SliderHud(brightness: Float, volume: Float, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Brightness
        VerticalSliderIndicator(
            icon  = Icons.Default.Brightness6,
            value = brightness
        )
        // Volume
        VerticalSliderIndicator(
            icon  = if (volume == 0f) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
            value = volume
        )
    }
}

@Composable
private fun VerticalSliderIndicator(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    value: Float
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = Color.Black.copy(alpha = 0.5f)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(16.dp))
            Spacer(Modifier.height(4.dp))
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(50.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(Color.White.copy(alpha = 0.3f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight(value)
                        .background(Color.White)
                        .align(Alignment.BottomCenter)
                )
            }
        }
    }
}

// ── Speed picker popup ────────────────────────────────────────────────────
@Composable
fun SpeedMenu(
    currentSpeed: Float,
    onSpeedSelect: (Float) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier  = modifier,
        shape     = RoundedCornerShape(12.dp),
        color     = Color(0xEE1A1A2E),
        shadowElevation = 8.dp
    ) {
        Column(modifier = Modifier.padding(vertical = 8.dp)) {
            Text(
                "Speed",
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
            playbackSpeeds.forEach { speed ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSpeedSelect(speed) }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = currentSpeed == speed,
                        onClick  = { onSpeedSelect(speed) },
                        colors   = RadioButtonDefaults.colors(
                            selectedColor   = Color(0xFF5C6BC0),
                            unselectedColor = Color.White.copy(alpha = 0.5f)
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text  = "${speed}x",
                        color = if (currentSpeed == speed) Color.White else Color.White.copy(alpha = 0.7f),
                        fontSize = 14.sp,
                        fontWeight = if (currentSpeed == speed) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }
    }
}

// ── Aspect Ratio picker popup ─────────────────────────────────────────────
private val aspectRatios = listOf("Fit" to 0, "Fill" to 1, "16:9" to 2, "4:3" to 3, "Stretch" to 4)

@Composable
fun AspectMenu(
    currentIndex: Int,
    onAspectSelect: (Int) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier  = modifier,
        shape     = RoundedCornerShape(12.dp),
        color     = Color(0xEE1A1A2E),
        shadowElevation = 8.dp
    ) {
        Column(modifier = Modifier.padding(vertical = 8.dp)) {
            Text(
                "Aspect Ratio",
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
            aspectRatios.forEachIndexed { index, (label, _) ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onAspectSelect(index); onDismiss() }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = currentIndex == index,
                        onClick  = { onAspectSelect(index); onDismiss() },
                        colors   = RadioButtonDefaults.colors(
                            selectedColor   = Color(0xFF5C6BC0),
                            unselectedColor = Color.White.copy(alpha = 0.5f)
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text  = label,
                        color = if (currentIndex == index) Color.White else Color.White.copy(alpha = 0.7f),
                        fontSize = 14.sp,
                        fontWeight = if (currentIndex == index) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }
    }
}
