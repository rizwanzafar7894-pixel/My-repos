package com.darkwave.player.ui

import android.graphics.ColorMatrix
import kotlin.math.cos
import kotlin.math.sin

// ── Video Color State ────────────────────────────────────────────────────────
data class VideoColorState(
    val brightness: Float = 0f,    // -1..+1  (0 = neutral)
    val contrast:   Float = 1f,    //  0..2   (1 = neutral)
    val saturation: Float = 1f,    //  0..2   (1 = neutral)
    val hue:        Float = 0f,    // -180..+180 degrees (0 = neutral)
    val gamma:      Float = 1f,    //  0.5..2 (1 = neutral)
    val sharpness:  Float = 0f,    //  0..1   (0 = no sharpening)
    val noiseReduction: Boolean = false
) {
    val isNeutral: Boolean get() =
        brightness == 0f && contrast == 1f && saturation == 1f &&
        hue == 0f && gamma == 1f && sharpness == 0f && !noiseReduction
}

// ── Smart Enhance Profiles ────────────────────────────────────────────────────
enum class SmartEnhanceProfile(val label: String, val icon: String, val description: String) {
    OFF         ("Off",      "✕",  "No enhancement"),
    AUTO        ("Auto",     "✨", "Balanced auto-enhance"),
    VIVID       ("Vivid",    "🎨", "Rich colors, high contrast"),
    CINEMA      ("Cinema",   "🎬", "Cinematic warm tones"),
    SPORTS      ("Sports",   "⚡", "Sharp, high motion clarity"),
    ANIME       ("Anime",    "🌸", "Bright, saturated anime style"),
    DOCUMENTARY ("Docu",     "📽", "Natural, neutral tones"),
    NIGHT       ("Night",    "🌙", "Dark ambient, soft glow"),
    INDOOR      ("Indoor",   "💡", "Warm, corrected indoors"),
    OUTDOOR     ("Outdoor",  "☀", "Cool, sharp daylight"),
    HDR_SIM     ("HDR",      "🔆", "Simulated HDR lift"),
    RETRO       ("Retro",    "📺", "Vintage film look");

    fun toColorState(): VideoColorState = when (this) {
        OFF         -> VideoColorState()
        AUTO        -> VideoColorState(brightness = 0.05f, contrast = 1.10f, saturation = 1.15f, sharpness = 0.3f, gamma = 0.95f)
        VIVID       -> VideoColorState(brightness = 0.05f, contrast = 1.25f, saturation = 1.6f,  sharpness = 0.4f, gamma = 0.9f)
        CINEMA      -> VideoColorState(brightness = -0.05f,contrast = 1.20f, saturation = 1.1f,  hue = 8f,  sharpness = 0.2f, gamma = 1.05f)
        SPORTS      -> VideoColorState(brightness = 0.08f, contrast = 1.30f, saturation = 1.2f,  sharpness = 0.6f, gamma = 0.92f)
        ANIME       -> VideoColorState(brightness = 0.10f, contrast = 1.15f, saturation = 1.5f,  sharpness = 0.35f,gamma = 0.88f)
        DOCUMENTARY -> VideoColorState(brightness = 0.02f, contrast = 1.05f, saturation = 0.95f, sharpness = 0.15f,gamma = 1.0f)
        NIGHT       -> VideoColorState(brightness = -0.15f,contrast = 0.85f, saturation = 0.75f, hue = 5f,  sharpness = 0.1f, gamma = 1.2f, noiseReduction = true)
        INDOOR      -> VideoColorState(brightness = 0.08f, contrast = 1.10f, saturation = 1.05f, hue = 12f, sharpness = 0.25f,gamma = 0.95f)
        OUTDOOR     -> VideoColorState(brightness = 0.05f, contrast = 1.20f, saturation = 1.15f, hue = -8f, sharpness = 0.45f,gamma = 0.9f)
        HDR_SIM     -> VideoColorState(brightness = 0.08f, contrast = 1.35f, saturation = 1.3f,  sharpness = 0.5f, gamma = 0.85f)
        RETRO       -> VideoColorState(brightness = -0.05f,contrast = 0.90f, saturation = 0.7f,  hue = 20f, sharpness = 0f,   gamma = 1.1f)
    }
}

// ── Color Matrix Builder ──────────────────────────────────────────────────────
fun buildColorMatrix(cs: VideoColorState): ColorMatrix {
    val cm = ColorMatrix()

    // 1. Saturation
    cm.setSaturation(cs.saturation)

    // 2. Contrast — scale around midpoint 0.5
    val c = cs.contrast
    val cm2 = ColorMatrix(floatArrayOf(
        c, 0f, 0f, 0f, (1f - c) * 127.5f,
        0f, c, 0f, 0f, (1f - c) * 127.5f,
        0f, 0f, c, 0f, (1f - c) * 127.5f,
        0f, 0f, 0f, 1f, 0f
    ))
    cm.postConcat(cm2)

    // 3. Brightness
    val b = cs.brightness * 255f
    cm.postConcat(ColorMatrix(floatArrayOf(
        1f, 0f, 0f, 0f, b,
        0f, 1f, 0f, 0f, b,
        0f, 0f, 1f, 0f, b,
        0f, 0f, 0f, 1f, 0f
    )))

    // 4. Hue rotation
    val hueRad = Math.toRadians(cs.hue.toDouble())
    val cosH = cos(hueRad).toFloat(); val sinH = sin(hueRad).toFloat()
    cm.postConcat(ColorMatrix(floatArrayOf(
        0.213f + cosH*0.787f - sinH*0.213f, 0.715f - cosH*0.715f - sinH*0.715f, 0.072f - cosH*0.072f + sinH*0.928f, 0f, 0f,
        0.213f - cosH*0.213f + sinH*0.143f, 0.715f + cosH*0.285f + sinH*0.140f, 0.072f - cosH*0.072f - sinH*0.283f, 0f, 0f,
        0.213f - cosH*0.213f - sinH*0.787f, 0.715f - cosH*0.715f + sinH*0.715f, 0.072f + cosH*0.928f + sinH*0.072f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    )))

    // 5. Gamma
    val gs = 1f / cs.gamma.coerceIn(0.1f, 4f)
    val go = (1f - gs) * 128f
    cm.postConcat(ColorMatrix(floatArrayOf(
        gs, 0f, 0f, 0f, go,
        0f, gs, 0f, 0f, go,
        0f, 0f, gs, 0f, go,
        0f, 0f, 0f, 1f, 0f
    )))

    // 6. Sharpness — simulated via unsharp mask: boost edges by enhancing contrast locally
    // In ColorMatrix: we can't do true convolution, but we boost contrast more in midtones
    if (cs.sharpness > 0f) {
        val s = 1f + cs.sharpness * 0.4f  // small boost — real sharpening needs RenderScript
        val so = (1f - s) * 128f
        cm.postConcat(ColorMatrix(floatArrayOf(
            s, 0f, 0f, 0f, so,
            0f, s, 0f, 0f, so,
            0f, 0f, s, 0f, so,
            0f, 0f, 0f, 1f, 0f
        )))
    }

    return cm
}
