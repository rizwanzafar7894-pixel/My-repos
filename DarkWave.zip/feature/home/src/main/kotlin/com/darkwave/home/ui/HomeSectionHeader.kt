package com.darkwave.home.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.theme.*

@Composable
fun HomeSectionHeader(
    title: String,
    actionLabel: String = "",
    onAction: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            modifier = Modifier.weight(1f)
        )
        if (actionLabel.isNotBlank()) {
            TextButton(onClick = onAction) {
                Text(
                    text = actionLabel,
                    fontSize = 13.sp,
                    color = Purple500,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
