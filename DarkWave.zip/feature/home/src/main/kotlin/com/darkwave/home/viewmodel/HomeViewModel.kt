package com.darkwave.home.viewmodel

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darkwave.domain.model.AudioItem
import com.darkwave.domain.model.CuratedPlaylist
import com.darkwave.domain.model.MediaFolder
import com.darkwave.domain.model.Playlist
import com.darkwave.domain.model.VideoItem
import com.darkwave.domain.repository.MediaRepository
import com.darkwave.domain.repository.PlaylistRepository
import com.darkwave.domain.usecase.recommendation.GetRecommendationsUseCase
import com.darkwave.common.util.getGreeting
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class HomeUiState(
    val greeting: String = "Good Morning",
    val userName: String = "Guest",
    val userInitials: String = "G",
    val notificationCount: Int = 3,
    val selectedFilterIndex: Int = 0,
    val discoverWeeklyPlaylist: Playlist? = null,
    val discoverWeeklySongs: List<AudioItem> = emptyList(),
    val recentFolders: List<MediaFolder> = emptyList(),
    val recommendedSongs: List<AudioItem> = emptyList(),
    val curatedPlaylists: List<CuratedPlaylist> = emptyList(),
    val recentVideos: List<VideoItem> = emptyList(),
    val isLoading: Boolean = true,
    // Search
    val searchQuery: String = "",
    val audioSearchResults: List<AudioItem> = emptyList(),
    val videoSearchResults: List<VideoItem> = emptyList(),
    val searchResults: List<Any> = emptyList()
)

val homeFilterLabels = listOf(
    "All", "Most Watched", "Trending", "Top Rated", "Recently Added", "Favorites"
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val mediaRepository: MediaRepository,
    private val playlistRepository: PlaylistRepository,
    private val recommendationsUseCase: GetRecommendationsUseCase,
    private val dataStore: DataStore<Preferences>
) : ViewModel() {

    private val _uiState = MutableStateFlow(HomeUiState())
    val uiState: StateFlow<HomeUiState> = _uiState.asStateFlow()

    private val _selectedFilter = MutableStateFlow(0)

    init {
        loadUserName()
        observeDiscoverWeekly()
        observeRecommendations()
        observeCurated()
        observeFolders()
        observeRecentVideos()
        _uiState.update { it.copy(greeting = getGreeting()) }
    }

    private fun loadUserName() {
        viewModelScope.launch {
            dataStore.data.collect { prefs ->
                val name = prefs[stringPreferencesKey("user_name")]?.takeIf { it.isNotBlank() } ?: "Guest"
                val initials = when {
                    name.contains(" ") -> "${name.first()}${name.split(" ")[1].first()}".uppercase()
                    name.isNotBlank() -> name.first().uppercase()
                    else -> "G"
                }
                _uiState.update { it.copy(userName = name, userInitials = initials) }
            }
        }
    }

    private fun observeDiscoverWeekly() {
        viewModelScope.launch {
            playlistRepository.getAllPlaylists()
                .combine(mediaRepository.getAllAudio()) { playlists, audio ->
                    val dw = playlists.firstOrNull { it.name == "Discover Weekly" }
                    val songs = audio.shuffled().take(52)
                    Pair(dw, songs)
                }
                .collect { (playlist, songs) ->
                    _uiState.update {
                        it.copy(
                            discoverWeeklyPlaylist = playlist,
                            discoverWeeklySongs = songs,
                            isLoading = false
                        )
                    }
                }
        }
    }

    private fun observeRecommendations() {
        viewModelScope.launch {
            recommendationsUseCase.getTopPlayed(20).collect { songs ->
                _uiState.update { it.copy(recommendedSongs = songs) }
            }
        }
    }

    private fun observeCurated() {
        viewModelScope.launch {
            recommendationsUseCase.getCuratedPlaylists().collect { curated ->
                _uiState.update { it.copy(curatedPlaylists = curated) }
            }
        }
    }

    private fun observeFolders() {
        viewModelScope.launch {
            mediaRepository.getVideoFolders()
                .combine(mediaRepository.getAudioFolders()) { videoFolders, audioFolders ->
                    (videoFolders + audioFolders)
                        .sortedByDescending { it.lastModified }
                        .take(6)
                }
                .collect { folders ->
                    _uiState.update { it.copy(recentFolders = folders) }
                }
        }
    }

    private fun observeRecentVideos() {
        viewModelScope.launch {
            mediaRepository.getAllVideos()
                .map { it.sortedByDescending { v -> v.dateAdded }.take(10) }
                .collect { videos ->
                    _uiState.update { it.copy(recentVideos = videos) }
                }
        }
    }

    fun onFilterSelected(index: Int) {
        _selectedFilter.value = index
        _uiState.update { it.copy(selectedFilterIndex = index) }
    }

    fun onRefresh() {
        viewModelScope.launch {
            val audio = mediaRepository.getAllAudio().first()
            if (audio.isNotEmpty()) {
                playlistRepository.refreshDiscoverWeekly(audio)
            }
        }
    }

    // ── Search ────────────────────────────────────────────────────────────
    fun onSearchQuery(query: String) {
        if (query.isBlank()) {
            _uiState.update { it.copy(searchResults = emptyList(), searchQuery = "") }
            return
        }
        _uiState.update { it.copy(searchQuery = query) }
        viewModelScope.launch {
            val allAudio = mediaRepository.getAllAudio().first()
            val allVideo = mediaRepository.getAllVideos().first()
            val q = query.lowercase()
            val audioResults = allAudio.filter {
                it.title.lowercase().contains(q) || it.artist.lowercase().contains(q)
            }.take(5)
            val videoResults = allVideo.filter {
                it.title.lowercase().contains(q)
            }.take(5)
            _uiState.update {
                it.copy(
                    audioSearchResults = audioResults,
                    videoSearchResults = videoResults
                )
            }
        }
    }

    // ── Notifications: mark all read ─────────────────────────────────────
    fun clearNotifications() {
        _uiState.update { it.copy(notificationCount = 0) }
    }
}
