package com.darkwave.home.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.darkwave.common.util.toFormattedSize
import com.darkwave.domain.model.MediaFolder
import com.darkwave.common.ui.theme.*

@Composable
fun FolderCard(
    folder: MediaFolder,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val folderColors = listOf(
        listOf(Color(0xFF5C6BC0), Color(0xFF3F51B5)),
        listOf(Color(0xFFE91E8C), Color(0xFFC2185B)),
        listOf(Color(0xFF4CAF50), Color(0xFF388E3C)),
        listOf(Color(0xFFFF5722), Color(0xFFE64A19)),
        listOf(Color(0xFF2196F3), Color(0xFF1976D2)),
        listOf(Color(0xFF9C27B0), Color(0xFF7B1FA2))
    )
    val colorPair = folderColors[folder.name.hashCode().and(0x7FFFFFFF) % folderColors.size]

    Column(
        modifier = modifier
            .width(90.dp)
            .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(colorPair)),
            contentAlignment = Alignment.Center
        ) {
            if (folder.coverArtUri.isNotBlank()) {
                AsyncImage(
                    model = folder.coverArtUri,
                    contentDescription = folder.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(
                    imageVector = Icons.Default.Folder,
                    contentDescription = null,
                    tint = White.copy(alpha = 0.9f),
                    modifier = Modifier.size(36.dp)
                )
            }
        }

        Spacer(Modifier.height(6.dp))

        Text(
            text = folder.name,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Text(
            text = buildString {
                if (folder.videoCount > 0) append("${folder.videoCount}v ")
                if (folder.audioCount > 0) append("${folder.audioCount}a")
            }.trim(),
            fontSize = 10.sp,
            color = TextSecondary
        )
    }
}
