package com.darkwave.home.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.util.toHoursMinutes
import com.darkwave.common.ui.theme.*

@Composable
fun DiscoverWeeklyCard(
    songCount: Int,
    totalDurationMs: Long,
    onPlayClick: () -> Unit,
    onLikeClick: () -> Unit,
    onShareClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var isLiked by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(DiscoverCardStart, DiscoverCardEnd)
                )
            )
            .padding(20.dp)
    ) {
        Column {
            // Top row — label + action icons
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // "FEATURED PLAYLIST" badge
                Surface(
                    shape = RoundedCornerShape(50),
                    color = White.copy(alpha = 0.7f)
                ) {
                    Text(
                        text = "FEATURED PLAYLIST",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Purple600,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                    )
                }

                Spacer(Modifier.weight(1f))

                // Like button
                IconButton(
                    onClick = {
                        isLiked = !isLiked
                        onLikeClick()
                    },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(White)
                ) {
                    Icon(
                        imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Like",
                        tint = if (isLiked) PinkAccent else TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(Modifier.width(8.dp))

                // Share button
                IconButton(
                    onClick = onShareClick,
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(White)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            // Title
            Text(
                text = "Discover Weekly",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )

            Spacer(Modifier.height(6.dp))

            Text(
                text = "Your personalized music mix updated every Monday",
                fontSize = 13.sp,
                color = TextSecondary
            )

            Spacer(Modifier.height(20.dp))

            // Song count + duration + play button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = songCount.toString(),
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Bold,
                        color = Purple500
                    )
                    Text(
                        text = if (totalDurationMs > 0)
                            "songs · ${totalDurationMs.toHoursMinutes()}"
                        else
                            "songs",
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                }

                Spacer(Modifier.weight(1f))

                // Play button — large purple circle
                IconButton(
                    onClick = onPlayClick,
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Purple500)
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Play",
                        tint = White,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
        }
    }
}
