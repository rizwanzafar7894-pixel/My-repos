package com.darkwave.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darkwave.common.ui.components.DWTopBar
import com.darkwave.common.ui.components.DWFilterChipRow
import com.darkwave.common.ui.components.LoadingIndicator
import com.darkwave.common.ui.theme.Background
import com.darkwave.common.ui.theme.White
import com.darkwave.home.ui.*
import com.darkwave.home.viewmodel.HomeViewModel
import com.darkwave.home.viewmodel.homeFilterLabels

@Composable
fun HomeScreen(
    onVideoClick: (uri: String, title: String) -> Unit,
    onAudioClick: () -> Unit,
    onOrganizerClick: () -> Unit,
    onConverterClick: () -> Unit,
    onVaultClick: () -> Unit,
    onDownloadsClick: () -> Unit,
    viewModel: HomeViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
    ) {
        // Top bar — sticky
        DWTopBar(
            userName            = state.userName,
            greeting            = state.greeting,
            userInitials        = state.userInitials,
            notificationCount   = state.notificationCount,
            onSearchClick       = { viewModel.onSearchQuery("") },
            onFavoriteClick     = {},  // navigates to favorites (handled by NavHost)
            onNotificationClick = { viewModel.clearNotifications() },
            onAvatarClick       = {},
            modifier            = Modifier.background(White)
        )

        if (state.isLoading) {
            LoadingIndicator()
        } else {
            LazyColumn(
                modifier            = Modifier.fillMaxSize(),
                contentPadding      = PaddingValues(bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                // Greeting header
                item {
                    HomeGreetingHeader(
                        greeting             = state.greeting,
                        userName             = state.userName,
                        notifCount           = state.notificationCount,
                        onFavoriteClick      = { /* navigate to liked songs — handled by tabs */ },
                        onNotificationClick  = { viewModel.clearNotifications() },
                        modifier             = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                    )
                }

                // Filter chips — All, Most Watched, Trending, Top Rated, Recently Added, Favorites
                item {
                    DWFilterChipRow(
                        items             = homeFilterLabels,
                        selectedIndex     = state.selectedFilterIndex,
                        onSelectionChanged = { viewModel.onFilterSelected(it) },
                        modifier          = Modifier.padding(bottom = 16.dp)
                    )
                }

                // Discover Weekly card
                item {
                    DiscoverWeeklyCard(
                        songCount      = state.discoverWeeklySongs.size,
                        totalDurationMs = state.discoverWeeklySongs.sumOf { it.duration },
                        onPlayClick    = onAudioClick,
                        onLikeClick    = {},
                        onShareClick   = {},
                        modifier       = Modifier.padding(horizontal = 16.dp)
                    )
                    Spacer(Modifier.height(20.dp))
                }

                // Quick Actions — Organize, Convert, Vault, Downloads
                item {
                    QuickActionsRow(
                        onOrganizerClick  = onOrganizerClick,
                        onConverterClick  = onConverterClick,
                        onVaultClick      = onVaultClick,
                        onDownloadsClick  = onDownloadsClick,
                        modifier          = Modifier.padding(horizontal = 16.dp)
                    )
                    Spacer(Modifier.height(20.dp))
                }

                // Folders section
                if (state.recentFolders.isNotEmpty()) {
                    item {
                        HomeSectionHeader(
                            title       = "Folders",
                            actionLabel = "View All",
                            onAction    = {},
                            modifier    = Modifier.padding(horizontal = 16.dp)
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                    item {
                        LazyRow(
                            contentPadding      = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(state.recentFolders) { folder ->
                                FolderCard(
                                    folder    = folder,
                                    onClick   = {}
                                )
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                    }
                }

                // Curated & Trending
                if (state.curatedPlaylists.isNotEmpty()) {
                    item {
                        HomeSectionHeader(
                            title       = "Curated & Trending",
                            actionLabel = "See All",
                            onAction    = {},
                            modifier    = Modifier.padding(horizontal = 16.dp)
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                    item {
                        LazyRow(
                            contentPadding        = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(state.curatedPlaylists.take(6)) { playlist ->
                                CuratedPlaylistCard(
                                    playlist = playlist,
                                    onClick  = onAudioClick
                                )
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                    }
                }

                // For You
                if (state.discoverWeeklySongs.isNotEmpty()) {
                    item {
                        HomeSectionHeader(
                            title       = "For You",
                            actionLabel = "See All",
                            onAction    = {},
                            modifier    = Modifier.padding(horizontal = 16.dp)
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                    item {
                        ForYouCard(
                            song    = state.discoverWeeklySongs.firstOrNull(),
                            onClick = onAudioClick,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        Spacer(Modifier.height(20.dp))
                    }
                }

                // Recommended songs
                if (state.recommendedSongs.isNotEmpty()) {
                    item {
                        HomeSectionHeader(
                            title       = "Recommended",
                            actionLabel = "Show All",
                            onAction    = {},
                            modifier    = Modifier.padding(horizontal = 16.dp)
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                    items(state.recommendedSongs.take(5)) { song ->
                        RecommendedSongRow(
                            song    = song,
                            index   = state.recommendedSongs.indexOf(song) + 1,
                            onClick = onAudioClick,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                    }
                    item { Spacer(Modifier.height(20.dp)) }
                }

                // All Songs quick grid
                if (state.discoverWeeklySongs.isNotEmpty()) {
                    item {
                        HomeSectionHeader(
                            title       = "All Songs",
                            actionLabel = "+ Playlist",
                            onAction    = {},
                            modifier    = Modifier.padding(horizontal = 16.dp)
                        )
                        Spacer(Modifier.height(10.dp))
                    }
                    item {
                        LazyRow(
                            contentPadding        = PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(state.discoverWeeklySongs.take(10)) { song ->
                                AlbumArtCard(song = song, onClick = onAudioClick)
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                    }
                }
            }
        }
    }
}
