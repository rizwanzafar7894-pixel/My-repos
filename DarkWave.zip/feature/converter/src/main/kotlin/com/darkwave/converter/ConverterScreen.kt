package com.darkwave.converter

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darkwave.common.ui.theme.*
import com.darkwave.converter.viewmodel.*

@Composable
fun ConverterScreen(
    onBack: () -> Unit,
    viewModel: ConverterViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            val name = uri.lastPathSegment ?: "file"
            viewModel.onFileSelected(uri.toString(), name)
        }
    }

    // Error / success snackbars
    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(state.errorMessage) {
        state.errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearError()
        }
    }
    LaunchedEffect(state.successMessage) {
        state.successMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearSuccess()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = Background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Background)
        ) {
            // ── Top bar ──────────────────────────────────────────────
            Row(
                modifier          = Modifier.fillMaxWidth().background(White).padding(horizontal = 4.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = TextPrimary) }
                Text("Converter", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, modifier = Modifier.weight(1f))
            }

            // ── Mode tabs ─────────────────────────────────────────────
            ScrollableTabRow(
                selectedTabIndex = state.mode.ordinal,
                edgePadding      = 12.dp,
                containerColor   = White,
                contentColor     = Purple500,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[state.mode.ordinal]),
                        color    = Purple500
                    )
                },
                divider = { Divider(color = DividerColor) }
            ) {
                val labels = mapOf(
                    ConverterMode.VIDEO         to "Video",
                    ConverterMode.AUDIO         to "Audio",
                    ConverterMode.COMPRESS      to "Compress",
                    ConverterMode.EXTRACT_AUDIO to "Extract Audio"
                )
                ConverterMode.entries.forEach { mode ->
                    Tab(
                        selected = state.mode == mode,
                        onClick  = { viewModel.setMode(mode) },
                        text = {
                            Text(
                                labels[mode] ?: mode.name,
                                color = if (state.mode == mode) Purple500 else TextSecondary,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    )
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                // ── Input file card ───────────────────────────────────
                item {
                    InputFileCard(
                        name    = state.selectedInputName,
                        onClick = {
                            val mime = when (state.mode) {
                                ConverterMode.AUDIO, ConverterMode.EXTRACT_AUDIO -> "audio/*"
                                else -> "video/*"
                            }
                            fileLauncher.launch(mime)
                        }
                    )
                }

                // ── Format card ───────────────────────────────────────
                item {
                    val formats = when (state.mode) {
                        ConverterMode.VIDEO, ConverterMode.COMPRESS   -> videoFormats
                        ConverterMode.AUDIO, ConverterMode.EXTRACT_AUDIO -> audioFormats
                    }
                    OptionCard(title = "Output Format") {
                        FormatGrid(
                            formats  = formats,
                            selected = state.outputFormat,
                            onSelect = viewModel::setFormat
                        )
                    }
                }

                // ── Quality card (video/compress) ─────────────────────
                if (state.mode == ConverterMode.VIDEO || state.mode == ConverterMode.COMPRESS) {
                    item {
                        OptionCard(title = "Quality Preset") {
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                qualityOptions.forEach { q ->
                                    FilterChip(
                                        selected = state.outputQuality == q,
                                        onClick  = { viewModel.setQuality(q) },
                                        label    = { Text(q.replaceFirstChar { it.uppercase() }) },
                                        colors   = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = Purple500,
                                            selectedLabelColor     = White
                                        )
                                    )
                                }
                            }
                        }
                    }
                    item {
                        OptionCard(title = "Resolution") {
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                resolutionOptions.forEach { r ->
                                    FilterChip(
                                        selected = state.resolution == r,
                                        onClick  = { viewModel.setResolution(r) },
                                        label    = { Text(r) },
                                        colors   = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = Purple500,
                                            selectedLabelColor     = White
                                        )
                                    )
                                }
                            }
                        }
                    }
                    item {
                        OptionCard(title = "Options") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Remove audio track", fontSize = 13.sp, color = TextPrimary, modifier = Modifier.weight(1f))
                                Switch(
                                    checked         = state.removeAudio,
                                    onCheckedChange = viewModel::setRemoveAudio,
                                    colors          = SwitchDefaults.colors(checkedTrackColor = Purple500)
                                )
                            }
                        }
                    }
                }

                // ── Audio bitrate ─────────────────────────────────────
                if (state.mode == ConverterMode.AUDIO || state.mode == ConverterMode.EXTRACT_AUDIO) {
                    item {
                        OptionCard(title = "Audio Bitrate") {
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("128k", "192k", "256k", "320k").forEach { br ->
                                    FilterChip(
                                        selected = state.audioBitrate == br,
                                        onClick  = { viewModel.setAudioBitrate(br) },
                                        label    = { Text(br) },
                                        colors   = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = Purple500,
                                            selectedLabelColor     = White
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                // ── Progress / convert button ─────────────────────────
                item {
                    ConvertButton(
                        isRunning = state.isRunning,
                        progress  = state.progress,
                        hasInput  = state.selectedInputUri.isNotBlank(),
                        onStart   = viewModel::startConversion,
                        onCancel  = viewModel::cancelConversion
                    )
                }

                // ── Job history ───────────────────────────────────────
                if (state.jobs.isNotEmpty()) {
                    item { Text("History", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary) }
                    items(state.jobs.reversed()) { job ->
                        JobRow(job = job, onClear = { viewModel.clearJob(job.id) })
                    }
                }
            }
        }
    }

    if (state.showFormatPicker) {
        val formats = if (state.mode == ConverterMode.VIDEO || state.mode == ConverterMode.COMPRESS) videoFormats else audioFormats
        FormatPickerSheet(formats = formats, selected = state.outputFormat, onSelect = viewModel::setFormat, onDismiss = viewModel::hideFormatPicker)
    }
}

// ── Composables ───────────────────────────────────────────────────────────

@Composable
private fun InputFileCard(name: String, onClick: () -> Unit) {
    Card(
        modifier  = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape     = RoundedCornerShape(16.dp),
        colors    = CardDefaults.cardColors(containerColor = White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier         = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Purple100),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.FileOpen, null, tint = Purple500, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text("Input File", fontSize = 12.sp, color = TextSecondary)
                Text(
                    name.ifBlank { "Tap to select a file" },
                    fontSize  = 14.sp,
                    fontWeight = if (name.isNotBlank()) FontWeight.Medium else FontWeight.Normal,
                    color     = if (name.isNotBlank()) TextPrimary else TextTertiary,
                    maxLines  = 1,
                    overflow  = TextOverflow.Ellipsis
                )
            }
            Icon(Icons.Default.ChevronRight, null, tint = TextTertiary, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun OptionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape     = RoundedCornerShape(16.dp),
        colors    = CardDefaults.cardColors(containerColor = White),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier  = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, fontSize = 13.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun FormatGrid(formats: List<String>, selected: String, onSelect: (String) -> Unit) {
    val rows = formats.chunked(4)
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { fmt ->
                    val isSelected = selected == fmt
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) Purple500 else SurfaceVariant)
                            .clickable { onSelect(fmt) }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Text(
                            fmt.uppercase(),
                            fontSize   = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color      = if (isSelected) White else TextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ConvertButton(
    isRunning: Boolean,
    progress: Float,
    hasInput: Boolean,
    onStart: () -> Unit,
    onCancel: () -> Unit
) {
    Card(
        shape     = RoundedCornerShape(16.dp),
        colors    = CardDefaults.cardColors(containerColor = White),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier  = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            if (isRunning) {
                Text(
                    "Converting… ${(progress * 100).toInt()}%",
                    fontSize = 13.sp, color = TextSecondary
                )
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress     = { progress },
                    modifier     = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color        = Purple500,
                    trackColor   = SurfaceVariant
                )
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick  = onCancel,
                    modifier = Modifier.fillMaxWidth(),
                    shape    = RoundedCornerShape(12.dp),
                    colors   = ButtonDefaults.outlinedButtonColors(contentColor = Error)
                ) {
                    Icon(Icons.Default.Stop, null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Cancel")
                }
            } else {
                Button(
                    onClick  = onStart,
                    enabled  = hasInput,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    shape    = RoundedCornerShape(12.dp),
                    colors   = ButtonDefaults.buttonColors(containerColor = Purple500)
                ) {
                    Icon(Icons.Default.SwapHoriz, null, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Start Conversion", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun JobRow(job: ConversionJob, onClear: () -> Unit) {
    val statusColor = when (job.status) {
        JobStatus.DONE    -> Color(0xFF4CAF50)
        JobStatus.FAILED  -> Error
        JobStatus.RUNNING -> Purple500
        JobStatus.QUEUED  -> TextSecondary
    }
    val statusIcon = when (job.status) {
        JobStatus.DONE    -> Icons.Default.CheckCircle
        JobStatus.FAILED  -> Icons.Default.Error
        JobStatus.RUNNING -> Icons.Default.HourglassBottom
        JobStatus.QUEUED  -> Icons.Default.Schedule
    }
    Row(
        modifier          = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(White)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(statusIcon, null, tint = statusColor, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                java.io.File(job.outputPath).name,
                fontSize  = 12.sp,
                fontWeight = FontWeight.Medium,
                color     = TextPrimary,
                maxLines  = 1,
                overflow  = TextOverflow.Ellipsis
            )
            Text(job.status.name, fontSize = 11.sp, color = statusColor)
        }
        IconButton(onClick = onClear, modifier = Modifier.size(30.dp)) {
            Icon(Icons.Default.Close, "Clear", tint = TextTertiary, modifier = Modifier.size(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FormatPickerSheet(
    formats: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = White) {
        Column(modifier = Modifier.padding(bottom = 32.dp)) {
            Text("Select Format", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = TextPrimary, modifier = Modifier.padding(16.dp))
            formats.forEach { fmt ->
                Row(
                    modifier = Modifier.fillMaxWidth().clickable { onSelect(fmt) }.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = selected == fmt, onClick = { onSelect(fmt) }, colors = RadioButtonDefaults.colors(selectedColor = Purple500))
                    Spacer(Modifier.width(10.dp))
                    Text(fmt.uppercase(), fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
                }
            }
        }
    }
}

@Composable
private fun rememberScrollState() = androidx.compose.foundation.rememberScrollState()

@Composable
private fun Modifier.horizontalScroll(state: androidx.compose.foundation.ScrollState) =
    this.then(androidx.compose.foundation.horizontalScroll(state))
