package com.darkwave.converter.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.ReturnCode
import com.arthenica.ffmpegkit.Statistics
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.File
import javax.inject.Inject

enum class ConverterMode { VIDEO, AUDIO, COMPRESS, EXTRACT_AUDIO }

data class ConversionJob(
    val id: Long = System.currentTimeMillis(),
    val inputPath: String,
    val outputPath: String,
    val outputFormat: String,
    val progress: Float = 0f,
    val status: JobStatus = JobStatus.QUEUED
)

enum class JobStatus { QUEUED, RUNNING, DONE, FAILED }

data class ConverterUiState(
    val mode: ConverterMode = ConverterMode.VIDEO,
    val selectedInputUri: String = "",
    val selectedInputName: String = "",
    val outputFormat: String = "mp4",
    val outputQuality: String = "medium",      // low / medium / high
    val videoBitrate: String = "2000k",
    val audioBitrate: String = "192k",
    val resolution: String = "original",       // original / 1080p / 720p / 480p
    val removeAudio: Boolean = false,
    val jobs: List<ConversionJob> = emptyList(),
    val activeJob: ConversionJob? = null,
    val showFormatPicker: Boolean = false,
    val showFilePicker: Boolean = false,
    val isRunning: Boolean = false,
    val progress: Float = 0f,
    val errorMessage: String? = null,
    val successMessage: String? = null
)

val videoFormats = listOf("mp4", "mkv", "avi", "mov", "webm", "flv", "3gp")
val audioFormats = listOf("mp3", "aac", "flac", "wav", "ogg", "m4a", "opus")
val qualityOptions = listOf("low", "medium", "high")
val resolutionOptions = listOf("original", "1080p", "720p", "480p", "360p")

@HiltViewModel
class ConverterViewModel @Inject constructor(
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _uiState = MutableStateFlow(ConverterUiState())
    val uiState: StateFlow<ConverterUiState> = _uiState.asStateFlow()

    fun setMode(mode: ConverterMode) {
        val fmt = when (mode) {
            ConverterMode.VIDEO, ConverterMode.COMPRESS -> "mp4"
            ConverterMode.AUDIO, ConverterMode.EXTRACT_AUDIO -> "mp3"
        }
        _uiState.update { it.copy(mode = mode, outputFormat = fmt) }
    }

    fun onFileSelected(uri: String, name: String) {
        _uiState.update { it.copy(selectedInputUri = uri, selectedInputName = name, showFilePicker = false) }
    }

    fun setFormat(fmt: String) { _uiState.update { it.copy(outputFormat = fmt, showFormatPicker = false) } }
    fun setQuality(q: String) { _uiState.update { it.copy(outputQuality = q) } }
    fun setResolution(r: String) { _uiState.update { it.copy(resolution = r) } }
    fun setRemoveAudio(v: Boolean) { _uiState.update { it.copy(removeAudio = v) } }
    fun setVideoBitrate(v: String) { _uiState.update { it.copy(videoBitrate = v) } }
    fun setAudioBitrate(v: String) { _uiState.update { it.copy(audioBitrate = v) } }
    fun showFormatPicker()  { _uiState.update { it.copy(showFormatPicker = true) } }
    fun hideFormatPicker()  { _uiState.update { it.copy(showFormatPicker = false) } }
    fun showFilePicker()    { _uiState.update { it.copy(showFilePicker = true) } }
    fun clearError()        { _uiState.update { it.copy(errorMessage = null) } }
    fun clearSuccess()      { _uiState.update { it.copy(successMessage = null) } }

    fun startConversion() {
        val state = _uiState.value
        if (state.selectedInputUri.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Please select an input file") }
            return
        }
        if (state.isRunning) {
            _uiState.update { it.copy(errorMessage = "A conversion is already running") }
            return
        }

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val inputFile  = resolveInputPath(state.selectedInputUri)
                val outputDir  = File(context.getExternalFilesDir(null), "Converted").also { it.mkdirs() }
                val outputName = "${File(inputFile).nameWithoutExtension}_converted.${state.outputFormat}"
                val outputFile = File(outputDir, outputName)

                val cmd = buildFfmpegCommand(inputFile, outputFile.absolutePath, state)
                Timber.d("FFmpeg command: $cmd")

                val job = ConversionJob(
                    inputPath    = inputFile,
                    outputPath   = outputFile.absolutePath,
                    outputFormat = state.outputFormat,
                    status       = JobStatus.RUNNING
                )
                _uiState.update { it.copy(isRunning = true, progress = 0f, activeJob = job, jobs = it.jobs + job) }

                // Enable statistics callback for progress
                FFmpegKitConfig.enableStatisticsCallback { stats: Statistics ->
                    val time = stats.time.toFloat()
                    // Estimate progress by bytes written / expected (simple heuristic)
                    val pct = (time / 1000f / 60f).coerceIn(0f, 0.99f)  // crude estimate
                    _uiState.update { it.copy(progress = pct) }
                }

                FFmpegKit.execute(cmd).let { session ->
                    val success = ReturnCode.isSuccess(session.returnCode)
                    val updatedJob = job.copy(
                        progress = if (success) 1f else 0f,
                        status   = if (success) JobStatus.DONE else JobStatus.FAILED
                    )
                    _uiState.update { state2 ->
                        state2.copy(
                            isRunning      = false,
                            progress       = if (success) 1f else 0f,
                            activeJob      = updatedJob,
                            jobs           = state2.jobs.map { if (it.id == job.id) updatedJob else it },
                            successMessage = if (success) "Saved to ${outputFile.absolutePath}" else null,
                            errorMessage   = if (!success) "Conversion failed. Check the file format." else null
                        )
                    }
                }
            } catch (e: Exception) {
                Timber.e(e, "Conversion error")
                _uiState.update { it.copy(isRunning = false, errorMessage = e.message) }
            }
        }
    }

    fun cancelConversion() {
        FFmpegKit.cancel()
        _uiState.update { it.copy(isRunning = false, progress = 0f) }
    }

    fun clearJob(jobId: Long) {
        _uiState.update { it.copy(jobs = it.jobs.filter { j -> j.id != jobId }) }
    }

    private fun resolveInputPath(uriString: String): String {
        // If already a file path, return directly
        if (uriString.startsWith("/")) return uriString
        val uri  = Uri.parse(uriString)
        val path = uri.path ?: throw IllegalArgumentException("Cannot resolve URI: $uriString")
        return path
    }

    private fun buildFfmpegCommand(input: String, output: String, state: ConverterUiState): String {
        val args = mutableListOf("-i", "\"$input\"", "-y")   // -y = overwrite

        when (state.mode) {
            ConverterMode.VIDEO -> {
                // Resolution scaling
                if (state.resolution != "original") {
                    val scale = when (state.resolution) {
                        "1080p" -> "1920:1080"
                        "720p"  -> "1280:720"
                        "480p"  -> "854:480"
                        "360p"  -> "640:360"
                        else    -> null
                    }
                    scale?.let { args += listOf("-vf", "scale=$it") }
                }
                // Quality preset
                val crf = when (state.outputQuality) {
                    "high"   -> "18"
                    "medium" -> "23"
                    else     -> "28"
                }
                args += listOf("-c:v", "libx264", "-crf", crf, "-preset", "fast")
                if (state.removeAudio) args += listOf("-an")
                else args += listOf("-c:a", "aac", "-b:a", state.audioBitrate)
            }
            ConverterMode.AUDIO, ConverterMode.EXTRACT_AUDIO -> {
                args += listOf("-vn")   // no video
                when (state.outputFormat) {
                    "mp3"  -> args += listOf("-c:a", "libmp3lame", "-b:a", state.audioBitrate)
                    "aac"  -> args += listOf("-c:a", "aac", "-b:a", state.audioBitrate)
                    "flac" -> args += listOf("-c:a", "flac")
                    "wav"  -> args += listOf("-c:a", "pcm_s16le")
                    "ogg"  -> args += listOf("-c:a", "libvorbis", "-b:a", state.audioBitrate)
                    "opus" -> args += listOf("-c:a", "libopus", "-b:a", state.audioBitrate)
                    else   -> args += listOf("-c:a", "copy")
                }
            }
            ConverterMode.COMPRESS -> {
                val crf = "28"   // aggressive compression
                args += listOf("-c:v", "libx264", "-crf", crf, "-preset", "medium", "-c:a", "aac", "-b:a", "128k")
            }
        }

        args += listOf("\"$output\"")
        return args.joinToString(" ")
    }
}
