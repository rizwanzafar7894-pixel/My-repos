package com.darkwave.editor

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darkwave.common.util.toFormattedDuration
import com.darkwave.editor.viewmodel.*
import com.darkwave.common.ui.theme.*

@Composable
fun EditorScreen(
    onBack: () -> Unit,
    viewModel: EditorViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHost = remember { SnackbarHostState() }

    LaunchedEffect(state.errorMessage)   { state.errorMessage?.let   { snackbarHost.showSnackbar(it); viewModel.clearError() } }
    LaunchedEffect(state.successMessage) { state.successMessage?.let { snackbarHost.showSnackbar(it); viewModel.clearSuccess() } }

    Scaffold(
        snackbarHost    = { SnackbarHost(snackbarHost) },
        containerColor  = Background
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Background)
        ) {
            // ── Top bar ──────────────────────────────────────────────
            Row(
                modifier          = Modifier.fillMaxWidth().background(White).padding(horizontal = 4.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = TextPrimary) }
                Text("Editor", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, modifier = Modifier.weight(1f))
                if (state.jobStatus == EditorJobStatus.RUNNING) {
                    IconButton(onClick = viewModel::cancelJob) {
                        Icon(Icons.Default.Stop, "Cancel", tint = Error)
                    }
                }
            }

            // ── Mode tabs ─────────────────────────────────────────────
            TabRow(
                selectedTabIndex = state.mode.ordinal,
                containerColor   = White,
                contentColor     = Purple500,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[state.mode.ordinal]),
                        color    = Purple500
                    )
                },
                divider = { Divider(color = DividerColor) }
            ) {
                val modeLabels = mapOf(EditorMode.TRIM to "Trim", EditorMode.MERGE to "Merge", EditorMode.AUDIO to "Audio")
                EditorMode.entries.forEach { mode ->
                    Tab(
                        selected = state.mode == mode,
                        onClick  = { viewModel.setMode(mode) },
                        text = {
                            Text(
                                modeLabels[mode] ?: mode.name,
                                color = if (state.mode == mode) Purple500 else TextSecondary,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    )
                }
            }

            // ── Job progress bar ──────────────────────────────────────
            if (state.jobStatus == EditorJobStatus.RUNNING) {
                LinearProgressIndicator(
                    progress   = { state.progress },
                    modifier   = Modifier.fillMaxWidth().height(3.dp),
                    color      = Purple500,
                    trackColor = Color.Transparent
                )
            }

            // ── Tab content ───────────────────────────────────────────
            AnimatedContent(
                targetState = state.mode,
                transitionSpec = { fadeIn(tween(150)) togetherWith fadeOut(tween(150)) },
                label = "editorMode",
                modifier = Modifier.weight(1f)
            ) { mode ->
                when (mode) {
                    EditorMode.TRIM  -> TrimTab(state, viewModel)
                    EditorMode.MERGE -> MergeTab(state, viewModel)
                    EditorMode.AUDIO -> AudioTab(state, viewModel)
                }
            }
        }
    }
}

// ── Trim tab ──────────────────────────────────────────────────────────────
@Composable
private fun TrimTab(state: EditorUiState, viewModel: EditorViewModel) {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { viewModel.setTrimInput(it.toString(), it.lastPathSegment ?: "video", 0L) }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            EditorInputCard(
                label   = "Video File",
                name    = state.trimInputName,
                onClick = { launcher.launch("video/*") }
            )
        }

        if (state.trimInputUri.isNotBlank()) {
            item {
                Card(
                    shape     = RoundedCornerShape(16.dp),
                    colors    = CardDefaults.cardColors(containerColor = White),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier  = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Trim Range", fontSize = 13.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(12.dp))

                        // Timeline scrubber
                        TrimTimeline(
                            durationMs = state.trimDurationMs,
                            startMs    = state.trimStartMs,
                            endMs      = state.trimEndMs,
                            onStartChange = viewModel::setTrimStart,
                            onEndChange   = viewModel::setTrimEnd
                        )

                        Spacer(Modifier.height(12.dp))
                        Row {
                            Column(Modifier.weight(1f)) {
                                Text("Start", fontSize = 11.sp, color = TextSecondary)
                                Text(state.trimStartMs.toFormattedDuration(), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("End", fontSize = 11.sp, color = TextSecondary)
                                Text(state.trimEndMs.toFormattedDuration(), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                            }
                        }
                        Text(
                            "Duration: ${(state.trimEndMs - state.trimStartMs).toFormattedDuration()}",
                            fontSize = 12.sp, color = Purple500, fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }

            item {
                EditorActionButton(
                    label     = "Trim Video",
                    icon      = Icons.Default.ContentCut,
                    isRunning = state.jobStatus == EditorJobStatus.RUNNING,
                    onClick   = viewModel::executeTrim
                )
            }
        }
    }
}

// ── Merge tab ─────────────────────────────────────────────────────────────
@Composable
private fun MergeTab(state: EditorUiState, viewModel: EditorViewModel) {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { viewModel.addMergeClip(it.toString(), it.lastPathSegment ?: "clip") }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Clips (${state.mergeClips.size})", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, modifier = Modifier.weight(1f))
                TextButton(onClick = { launcher.launch("video/*") }) {
                    Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp), tint = Purple500)
                    Spacer(Modifier.width(4.dp))
                    Text("Add Clip", color = Purple500)
                }
            }
        }

        if (state.mergeClips.isEmpty()) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(16.dp)).background(White),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.VideoFile, null, tint = TextTertiary, modifier = Modifier.size(36.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("Add at least 2 clips to merge", color = TextSecondary, fontSize = 13.sp)
                    }
                }
            }
        } else {
            items(state.mergeClips, key = { it.id }) { clip ->
                MergeClipRow(
                    clip     = clip,
                    index    = state.mergeClips.indexOf(clip) + 1,
                    onRemove = { viewModel.removeMergeClip(clip.id) }
                )
            }
        }

        if (state.mergeClips.size >= 2) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Output Format", fontSize = 12.sp, color = TextSecondary)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("mp4", "mkv", "mov").forEach { fmt ->
                                FilterChip(
                                    selected = state.mergeOutputFormat == fmt,
                                    onClick  = { viewModel.setMergeFormat(fmt) },
                                    label    = { Text(fmt.uppercase()) },
                                    colors   = FilterChipDefaults.filterChipColors(selectedContainerColor = Purple500, selectedLabelColor = White)
                                )
                            }
                        }
                    }
                }
            }
            item {
                EditorActionButton(
                    label     = "Merge ${state.mergeClips.size} Clips",
                    icon      = Icons.Default.MergeType,
                    isRunning = state.jobStatus == EditorJobStatus.RUNNING,
                    onClick   = viewModel::executeMerge
                )
            }
        }
    }
}

// ── Audio editor tab ──────────────────────────────────────────────────────
@Composable
private fun AudioTab(state: EditorUiState, viewModel: EditorViewModel) {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { viewModel.setAudioInput(it.toString(), it.lastPathSegment ?: "audio") }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            EditorInputCard(
                label   = "Audio / Video File",
                name    = state.audioInputName,
                onClick = { launcher.launch("*/*") }
            )
        }

        if (state.audioInputUri.isNotBlank()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = White),
                    elevation = CardDefaults.cardElevation(2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        // Volume
                        AudioSliderRow("Volume", state.audioVolume, 0f..2f, "%.1fx".format(state.audioVolume)) { viewModel.setVolume(it) }
                        // Speed
                        AudioSliderRow("Speed",  state.audioSpeed, 0.5f..2f, "%.2fx".format(state.audioSpeed))  { viewModel.setSpeed(it) }
                        // Fade in
                        AudioSliderRow("Fade In", state.audioFadeIn, 0f..5f, "%.1fs".format(state.audioFadeIn)) { viewModel.setFadeIn(it) }
                        // Fade out
                        AudioSliderRow("Fade Out", state.audioFadeOut, 0f..5f, "%.1fs".format(state.audioFadeOut)) { viewModel.setFadeOut(it) }
                        // Remove silence
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Remove Silence", fontSize = 13.sp, color = TextPrimary, modifier = Modifier.weight(1f))
                            Switch(
                                checked         = state.audioRemoveSilence,
                                onCheckedChange = viewModel::setRemoveSilence,
                                colors          = SwitchDefaults.colors(checkedTrackColor = Purple500)
                            )
                        }
                    }
                }
            }
            item {
                EditorActionButton(
                    label     = "Process Audio",
                    icon      = Icons.Default.GraphicEq,
                    isRunning = state.jobStatus == EditorJobStatus.RUNNING,
                    onClick   = viewModel::executeAudioProcess
                )
            }
        }
    }
}

// ── Shared composables ────────────────────────────────────────────────────

@Composable
private fun EditorInputCard(label: String, name: String, onClick: () -> Unit) {
    Card(
        modifier  = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape     = RoundedCornerShape(16.dp),
        colors    = CardDefaults.cardColors(containerColor = White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier         = Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Purple100),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.FileOpen, null, tint = Purple500, modifier = Modifier.size(24.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(label, fontSize = 12.sp, color = TextSecondary)
                Text(
                    name.ifBlank { "Tap to select file" },
                    fontSize   = 14.sp,
                    fontWeight = if (name.isNotBlank()) FontWeight.Medium else FontWeight.Normal,
                    color      = if (name.isNotBlank()) TextPrimary else TextTertiary,
                    maxLines   = 1,
                    overflow   = TextOverflow.Ellipsis
                )
            }
            Icon(Icons.Default.ChevronRight, null, tint = TextTertiary, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun EditorActionButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, isRunning: Boolean, onClick: () -> Unit) {
    Button(
        onClick  = onClick,
        enabled  = !isRunning,
        modifier = Modifier.fillMaxWidth().height(48.dp),
        shape    = RoundedCornerShape(12.dp),
        colors   = ButtonDefaults.buttonColors(containerColor = Purple500)
    ) {
        if (isRunning) {
            CircularProgressIndicator(color = White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
        } else {
            Icon(icon, null, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(8.dp))
        Text(if (isRunning) "Processing…" else label, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun MergeClipRow(clip: MergeClip, index: Int, onRemove: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(White)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier         = Modifier.size(32.dp).clip(CircleShape).background(Purple100),
            contentAlignment = Alignment.Center
        ) {
            Text("$index", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Purple500)
        }
        Spacer(Modifier.width(10.dp))
        Icon(Icons.Default.VideoFile, null, tint = Purple500, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text(clip.name, fontSize = 13.sp, color = TextPrimary, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        IconButton(onClick = onRemove, modifier = Modifier.size(32.dp)) {
            Icon(Icons.Default.Close, "Remove", tint = TextSecondary, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun AudioSliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, valueLabel: String, onChange: (Float) -> Unit) {
    Column {
        Row {
            Text(label, fontSize = 13.sp, color = TextPrimary, modifier = Modifier.weight(1f))
            Text(valueLabel, fontSize = 13.sp, color = Purple500, fontWeight = FontWeight.Medium)
        }
        Slider(
            value         = value,
            onValueChange = onChange,
            valueRange    = range,
            colors        = SliderDefaults.colors(thumbColor = Purple500, activeTrackColor = Purple500),
            modifier      = Modifier.fillMaxWidth()
        )
    }
}

// ── Trim timeline scrubber ─────────────────────────────────────────────────
@Composable
private fun TrimTimeline(
    durationMs: Long,
    startMs: Long,
    endMs: Long,
    onStartChange: (Long) -> Unit,
    onEndChange: (Long) -> Unit
) {
    if (durationMs <= 0L) {
        Box(
            modifier = Modifier.fillMaxWidth().height(48.dp).clip(RoundedCornerShape(8.dp)).background(SurfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Text("Load a video to see the timeline", color = TextTertiary, fontSize = 12.sp)
        }
        return
    }

    var widthPx by remember { mutableIntStateOf(1) }
    val density = LocalDensity.current

    val startFrac = startMs.toFloat() / durationMs
    val endFrac   = endMs.toFloat()   / durationMs

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .onSizeChanged { widthPx = it.width }
    ) {
        // Track background
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(12.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(SurfaceVariant)
                .align(Alignment.Center)
        )
        // Selected range
        Box(
            modifier = Modifier
                .fillMaxWidth(endFrac - startFrac)
                .offset(x = with(density) { (startFrac * widthPx).toDp() })
                .height(12.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(Purple500.copy(alpha = 0.4f))
                .align(Alignment.Center)
        )
        // Start handle
        TrimHandle(
            fraction = startFrac,
            widthPx  = widthPx,
            color    = Purple500,
            onDrag   = { delta ->
                val newFrac = (startFrac + delta / widthPx).coerceIn(0f, endFrac - 0.01f)
                onStartChange((newFrac * durationMs).toLong())
            }
        )
        // End handle
        TrimHandle(
            fraction = endFrac,
            widthPx  = widthPx,
            color    = Purple600,
            onDrag   = { delta ->
                val newFrac = (endFrac + delta / widthPx).coerceIn(startFrac + 0.01f, 1f)
                onEndChange((newFrac * durationMs).toLong())
            }
        )
    }
}

@Composable
private fun TrimHandle(fraction: Float, widthPx: Int, color: Color, onDrag: (Float) -> Unit) {
    val density = LocalDensity.current
    Box(
        modifier = Modifier
            .offset(x = with(density) { (fraction * widthPx - 12).toDp() })
            .size(24.dp)
            .clip(CircleShape)
            .background(color)
            .pointerInput(Unit) {
                detectHorizontalDragGestures { _, dragAmount -> onDrag(dragAmount) }
            }
    )
}
