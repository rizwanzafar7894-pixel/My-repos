package com.darkwave.editor.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import java.io.File
import javax.inject.Inject

enum class EditorMode { TRIM, MERGE, AUDIO }
enum class EditorJobStatus { IDLE, RUNNING, DONE, FAILED }

data class MergeClip(
    val id: Long = System.currentTimeMillis(),
    val uri: String,
    val name: String,
    val durationMs: Long = 0L
)

data class EditorUiState(
    val mode: EditorMode = EditorMode.TRIM,
    // Trim
    val trimInputUri: String = "",
    val trimInputName: String = "",
    val trimDurationMs: Long = 0L,
    val trimStartMs: Long = 0L,
    val trimEndMs: Long = 0L,
    val trimPreviewPositionMs: Long = 0L,
    // Merge
    val mergeClips: List<MergeClip> = emptyList(),
    val mergeOutputFormat: String = "mp4",
    // Audio
    val audioInputUri: String = "",
    val audioInputName: String = "",
    val audioVolume: Float = 1f,
    val audioSpeed: Float = 1f,
    val audioFadeIn: Float = 0f,
    val audioFadeOut: Float = 0f,
    val audioPitchShift: Int = 0,
    val audioRemoveSilence: Boolean = false,
    // Job
    val jobStatus: EditorJobStatus = EditorJobStatus.IDLE,
    val progress: Float = 0f,
    val outputPath: String = "",
    val errorMessage: String? = null,
    val successMessage: String? = null
)

@HiltViewModel
class EditorViewModel @Inject constructor(
    @ApplicationContext private val context: Context
) : ViewModel() {

    private val _uiState = MutableStateFlow(EditorUiState())
    val uiState: StateFlow<EditorUiState> = _uiState.asStateFlow()

    fun setMode(mode: EditorMode) { _uiState.update { it.copy(mode = mode) } }

    // ── Trim ──────────────────────────────────────────────────────────
    fun setTrimInput(uri: String, name: String, durationMs: Long) {
        _uiState.update {
            it.copy(
                trimInputUri   = uri,
                trimInputName  = name,
                trimDurationMs = durationMs,
                trimStartMs    = 0L,
                trimEndMs      = durationMs
            )
        }
    }
    fun setTrimStart(ms: Long) { _uiState.update { it.copy(trimStartMs = ms.coerceIn(0L, it.trimEndMs - 1000)) } }
    fun setTrimEnd(ms: Long)   { _uiState.update { it.copy(trimEndMs   = ms.coerceIn(it.trimStartMs + 1000, it.trimDurationMs)) } }

    fun executeTrim() {
        val state = _uiState.value
        if (state.trimInputUri.isBlank()) return
        runFfmpeg(state) {
            val input  = resolvePath(state.trimInputUri)
            val ext    = File(input).extension.ifBlank { "mp4" }
            val output = outputFile("trimmed", ext)
            val ss     = formatSeconds(state.trimStartMs)
            val to     = formatSeconds(state.trimEndMs)
            "-i \"$input\" -ss $ss -to $to -c copy -y \"${output.absolutePath}\""
        }
    }

    // ── Merge ─────────────────────────────────────────────────────────
    fun addMergeClip(uri: String, name: String) {
        _uiState.update { it.copy(mergeClips = it.mergeClips + MergeClip(uri = uri, name = name)) }
    }
    fun removeMergeClip(id: Long) { _uiState.update { it.copy(mergeClips = it.mergeClips.filter { c -> c.id != id }) } }
    fun reorderMergeClips(from: Int, to: Int) {
        _uiState.update { state ->
            val list = state.mergeClips.toMutableList()
            list.add(to, list.removeAt(from))
            state.copy(mergeClips = list)
        }
    }
    fun setMergeFormat(fmt: String) { _uiState.update { it.copy(mergeOutputFormat = fmt) } }

    fun executeMerge() {
        val state = _uiState.value
        if (state.mergeClips.size < 2) {
            _uiState.update { it.copy(errorMessage = "Add at least 2 clips to merge") }
            return
        }
        runFfmpeg(state) {
            val concat = state.mergeClips.joinToString(" ") { "-i \"${resolvePath(it.uri)}\"" }
            val filter = (state.mergeClips.indices).joinToString("") { "[$it:v][$it:a]" } +
                    "concat=n=${state.mergeClips.size}:v=1:a=1[v][a]"
            val output = outputFile("merged", state.mergeOutputFormat)
            "$concat -filter_complex \"$filter\" -map \"[v]\" -map \"[a]\" -y \"${output.absolutePath}\""
        }
    }

    // ── Audio editor ──────────────────────────────────────────────────
    fun setAudioInput(uri: String, name: String) { _uiState.update { it.copy(audioInputUri = uri, audioInputName = name) } }
    fun setVolume(v: Float)         { _uiState.update { it.copy(audioVolume = v) } }
    fun setSpeed(v: Float)          { _uiState.update { it.copy(audioSpeed = v) } }
    fun setFadeIn(v: Float)         { _uiState.update { it.copy(audioFadeIn = v) } }
    fun setFadeOut(v: Float)        { _uiState.update { it.copy(audioFadeOut = v) } }
    fun setPitchShift(v: Int)       { _uiState.update { it.copy(audioPitchShift = v) } }
    fun setRemoveSilence(v: Boolean){ _uiState.update { it.copy(audioRemoveSilence = v) } }

    fun executeAudioProcess() {
        val state = _uiState.value
        if (state.audioInputUri.isBlank()) return
        runFfmpeg(state) {
            val input   = resolvePath(state.audioInputUri)
            val ext     = File(input).extension.ifBlank { "mp3" }
            val output  = outputFile("processed", ext)
            val filters = mutableListOf<String>()

            if (state.audioVolume != 1f) filters.add("volume=${state.audioVolume}")
            if (state.audioSpeed  != 1f) filters.add("atempo=${state.audioSpeed.coerceIn(0.5f, 2f)}")
            if (state.audioFadeIn  > 0f) filters.add("afade=t=in:st=0:d=${state.audioFadeIn}")
            if (state.audioFadeOut > 0f) filters.add("afade=t=out:st=0:d=${state.audioFadeOut}")
            if (state.audioRemoveSilence)filters.add("silenceremove=start_periods=1:start_threshold=-50dB")

            val filterStr = if (filters.isNotEmpty()) "-af \"${filters.joinToString(",")}\"" else ""
            "-i \"$input\" $filterStr -y \"${output.absolutePath}\""
        }
    }

    fun cancelJob() {
        FFmpegKit.cancel()
        _uiState.update { it.copy(jobStatus = EditorJobStatus.IDLE, progress = 0f) }
    }

    fun clearError()   { _uiState.update { it.copy(errorMessage   = null) } }
    fun clearSuccess() { _uiState.update { it.copy(successMessage = null) } }

    // ── FFmpeg runner ─────────────────────────────────────────────────
    private fun runFfmpeg(state: EditorUiState, buildCmd: () -> String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                _uiState.update { it.copy(jobStatus = EditorJobStatus.RUNNING, progress = 0.05f) }
                val cmd = buildCmd()
                Timber.d("Editor FFmpeg: $cmd")

                FFmpegKit.execute(cmd).let { session ->
                    val success = ReturnCode.isSuccess(session.returnCode)
                    _uiState.update {
                        it.copy(
                            jobStatus      = if (success) EditorJobStatus.DONE else EditorJobStatus.FAILED,
                            progress       = if (success) 1f else 0f,
                            successMessage = if (success) "Saved to ${it.outputPath}" else null,
                            errorMessage   = if (!success) "Processing failed. Check file format." else null
                        )
                    }
                }
            } catch (e: Exception) {
                Timber.e(e)
                _uiState.update { it.copy(jobStatus = EditorJobStatus.FAILED, errorMessage = e.message) }
            }
        }
    }

    private fun resolvePath(uri: String): String {
        if (uri.startsWith("/")) return uri
        return Uri.parse(uri).path ?: uri
    }

    private fun outputFile(prefix: String, ext: String): File {
        val dir = File(context.getExternalFilesDir(null), "Edited").also { it.mkdirs() }
        val name = "${prefix}_${System.currentTimeMillis()}.$ext"
        val file = File(dir, name)
        _uiState.update { it.copy(outputPath = file.absolutePath) }
        return file
    }

    private fun formatSeconds(ms: Long): String {
        val total = ms / 1000
        val h = total / 3600; val m = (total % 3600) / 60; val s = total % 60
        return "%02d:%02d:%02d".format(h, m, s)
    }
}
