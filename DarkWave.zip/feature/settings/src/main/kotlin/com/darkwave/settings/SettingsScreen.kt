package com.darkwave.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darkwave.common.ui.components.LoadingIndicator
import com.darkwave.common.ui.theme.*
import com.darkwave.settings.ui.analytics.AnalyticsTab
import com.darkwave.settings.ui.general.*
import com.darkwave.settings.ui.storage.StorageTab
import com.darkwave.settings.ui.tools.ToolsTab
import com.darkwave.settings.viewmodel.SettingsViewModel
import com.darkwave.settings.viewmodel.settingsTabLabels

@Composable
fun SettingsScreen(
    onProfileClick: () -> Unit,
    onPlaybackClick: () -> Unit,
    onAppearanceClick: () -> Unit,
    onAccessibilityClick: () -> Unit,
    onPrivacyClick: () -> Unit,
    onAnalyticsClick: () -> Unit,
    onDownloadsClick: () -> Unit,
    onStorageClick: () -> Unit,
    onNetworkClick: () -> Unit,
    onBpmClick: () -> Unit,
    onMetronomeClick: () -> Unit,
    onTunerClick: () -> Unit,
    onRecorderClick: () -> Unit,
    onAnalyzerClick: () -> Unit,
    onEqualizerClick: () -> Unit,
    onRemoteClick: () -> Unit,
    onFocusClick: () -> Unit,
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize().background(Background)) {

        // Header
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(White)
                .padding(horizontal = 16.dp, vertical = 16.dp)
        ) {
            Text(
                "Settings",
                style = MaterialTheme.typography.headlineSmall,
                color = TextPrimary
            )
        }

        // Tab row — General / Tools / Analytics / Downloads / Storage / Network / Accessibility
        ScrollableTabRow(
            selectedTabIndex  = state.selectedTabIndex,
            edgePadding       = 16.dp,
            containerColor    = White,
            contentColor      = Purple500,
            indicator = { tabPositions ->
                if (state.selectedTabIndex < tabPositions.size) {
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[state.selectedTabIndex]),
                        color    = Purple500
                    )
                }
            },
            divider = { Divider(color = DividerColor) }
        ) {
            settingsTabLabels.forEachIndexed { index, label ->
                Tab(
                    selected = state.selectedTabIndex == index,
                    onClick  = { viewModel.onTabSelected(index) },
                    text = {
                        Text(
                            text  = label,
                            style = MaterialTheme.typography.labelLarge,
                            color = if (state.selectedTabIndex == index) Purple500 else TextSecondary
                        )
                    }
                )
            }
        }

        if (state.isLoading) {
            LoadingIndicator()
        } else {
            when (state.selectedTabIndex) {
                0 -> GeneralTab(
                    state             = state,
                    onProfileClick    = onProfileClick,
                    onPlaybackClick   = onPlaybackClick,
                    onAppearanceClick = onAppearanceClick,
                    onAccessibility   = onAccessibilityClick,
                    onPrivacy         = onPrivacyClick,
                    onAnalytics       = onAnalyticsClick,
                    onDarkModeToggle  = viewModel::setDarkMode
                )
                1 -> ToolsTab(
                    onBpmClick      = onBpmClick,
                    onMetronomeClick = onMetronomeClick,
                    onTunerClick    = onTunerClick,
                    onRecorderClick = onRecorderClick,
                    onAnalyzerClick = onAnalyzerClick,
                    onEqualizerClick = onEqualizerClick,
                    onRemoteClick   = onRemoteClick,
                    onFocusClick    = onFocusClick
                )
                2 -> AnalyticsTab(
                    stats    = state.watchStats,
                    onClear  = viewModel::clearAnalytics
                )
                3 -> DownloadsTab(
                    wifiOnly   = state.wifiOnly,
                    onWifiOnly = viewModel::setWifiOnly,
                    onDownloadsClick = onDownloadsClick
                )
                4 -> StorageTab(
                    videosSize   = state.videoSizeBytes,
                    audioSize    = state.audioSizeBytes,
                    cacheSize    = state.cacheBytes,
                    onClearCache = viewModel::clearCache
                )
                5 -> NetworkTab(onNetworkClick = onNetworkClick)
                6 -> AccessibilitySettingsTab(onAccessibilityClick = onAccessibilityClick)
            }
        }
    }
}
