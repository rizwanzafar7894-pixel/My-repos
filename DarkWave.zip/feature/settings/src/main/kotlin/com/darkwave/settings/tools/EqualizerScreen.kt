package com.darkwave.settings.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.components.TopBar
import com.darkwave.common.ui.theme.*

private val EQ_BANDS = listOf("32", "64", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")

private val EQ_PRESETS = mapOf(
    "Flat"       to listOf(0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f, 0f),
    "Bass Boost" to listOf(6f, 5f, 4f, 2f, 0f, 0f, 0f, 0f, 0f, 0f),
    "Treble"     to listOf(0f, 0f, 0f, 0f, 0f, 1f, 2f, 3f, 4f, 5f),
    "Pop"        to listOf(1f, 2f, 3f, 2f, 0f, -1f, 0f, 1f, 2f, 2f),
    "Rock"       to listOf(4f, 3f, 2f, 0f, -1f, 0f, 2f, 3f, 3f, 2f),
    "Jazz"       to listOf(3f, 2f, 0f, 1f, 2f, 2f, 1f, 0f, 1f, 2f),
    "Classical"  to listOf(4f, 3f, 2f, 1f, 0f, 0f, 0f, 1f, 2f, 3f),
    "Electronic" to listOf(4f, 3f, 1f, 0f, -1f, 0f, 1f, 2f, 3f, 4f),
    "Vocal"      to listOf(-2f, -1f, 0f, 2f, 4f, 4f, 3f, 1f, 0f, -1f),
    "Podcast"    to listOf(-3f, -2f, 0f, 3f, 4f, 3f, 2f, 0f, -1f, -2f)
)

@Composable
fun EqualizerScreen(onBack: () -> Unit) {
    var eqEnabled    by remember { mutableStateOf(true) }
    var selectedPreset by remember { mutableStateOf("Flat") }
    var bandValues   by remember { mutableStateOf(List(10) { 0f }) }
    var bassBoost    by remember { mutableStateOf(0f) }
    var virtualizer  by remember { mutableStateOf(0f) }
    var preamp       by remember { mutableStateOf(0f) }

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        TopBar(title = "Equalizer", onBack = onBack) {
            Switch(
                checked = eqEnabled,
                onCheckedChange = { eqEnabled = it },
                colors = SwitchDefaults.colors(checkedThumbColor = White, checkedTrackColor = Purple500)
            )
        }

        // Presets
        Text(
            "Presets",
            modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp),
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary,
            fontSize = 14.sp
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(EQ_PRESETS.keys.toList()) { preset ->
                val selected = selectedPreset == preset
                FilterChip(
                    selected = selected,
                    onClick = {
                        selectedPreset = preset
                        bandValues = EQ_PRESETS[preset]!!
                    },
                    label = { Text(preset, fontSize = 13.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Purple500,
                        selectedLabelColor = White,
                        containerColor = SurfaceLight,
                        labelColor = TextSecondary
                    )
                )
            }
        }

        Spacer(Modifier.height(8.dp))

        // EQ sliders
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
                .padding(horizontal = 8.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(SurfaceLight)
                .padding(8.dp)
        ) {
            // 0dB line
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .align(Alignment.Center)
                    .background(DividerColor)
            )

            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                EQ_BANDS.forEachIndexed { i, freq ->
                    EqBandSlider(
                        freq = freq,
                        value = if (eqEnabled) bandValues[i] else 0f,
                        enabled = eqEnabled,
                        onValueChange = { newVal ->
                            if (selectedPreset != "Custom") selectedPreset = "Custom"
                            bandValues = bandValues.toMutableList().also { it[i] = newVal }
                        }
                    )
                }
            }
        }

        // dB labels
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("+12 dB", fontSize = 9.sp, color = TextTertiary)
            Text("0 dB", fontSize = 9.sp, color = TextTertiary)
            Text("-12 dB", fontSize = 9.sp, color = TextTertiary)
        }

        Spacer(Modifier.height(16.dp))

        // Bass Boost & Virtualizer
        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            EffectSlider(
                label = "Bass Boost",
                value = bassBoost,
                onValueChange = { bassBoost = it },
                enabled = eqEnabled,
                color = OrangeAccent
            )
            Spacer(Modifier.height(8.dp))
            EffectSlider(
                label = "Virtualizer",
                value = virtualizer,
                onValueChange = { virtualizer = it },
                enabled = eqEnabled,
                color = BlueAccent
            )
            Spacer(Modifier.height(8.dp))
            EffectSlider(
                label = "Preamp",
                value = preamp,
                onValueChange = { preamp = it },
                enabled = eqEnabled,
                color = Purple500,
                range = -12f..12f
            )
        }

        Spacer(Modifier.height(16.dp))

        // Reset button
        OutlinedButton(
            onClick = {
                selectedPreset = "Flat"
                bandValues = List(10) { 0f }
                bassBoost = 0f
                virtualizer = 0f
                preamp = 0f
            },
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(bottom = 16.dp),
            shape = RoundedCornerShape(12.dp),
            border = ButtonDefaults.outlinedButtonBorder.copy(),
            colors = ButtonColors(
                containerColor = Color.Transparent,
                contentColor = Purple500,
                disabledContainerColor = Color.Transparent,
                disabledContentColor = TextTertiary
            )
        ) {
            Icon(Icons.Default.RestartAlt, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Reset to Flat")
        }
    }
}

@Composable
private fun RowScope.EqBandSlider(
    freq: String,
    value: Float,
    enabled: Boolean,
    onValueChange: (Float) -> Unit
) {
    Column(
        modifier = Modifier.weight(1f).fillMaxHeight(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Value label
        Text(
            text = "${if (value >= 0) "+" else ""}${"%.0f".format(value)}",
            fontSize = 8.sp,
            color = if (value != 0f) Purple500 else TextTertiary,
            fontWeight = if (value != 0f) FontWeight.Bold else FontWeight.Normal
        )

        // Vertical slider
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = -12f..12f,
            enabled = enabled,
            modifier = Modifier
                .weight(1f)
                .graphicsLayerRotation(),
            colors = SliderDefaults.colors(
                thumbColor = Purple500,
                activeTrackColor = Purple500,
                inactiveTrackColor = Purple100
            )
        )

        // Freq label
        Text(freq, fontSize = 8.sp, color = TextSecondary)
    }
}

// Extension to rotate slider vertically
private fun Modifier.graphicsLayerRotation() = this
    .height(180.dp)
    .width(24.dp)

@Composable
private fun EffectSlider(
    label: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    enabled: Boolean,
    color: Color,
    range: ClosedFloatingPointRange<Float> = 0f..1000f
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            modifier = Modifier.width(90.dp),
            fontSize = 13.sp,
            color = if (enabled) TextPrimary else TextTertiary,
            fontWeight = FontWeight.Medium
        )
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = range,
            enabled = enabled,
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(
                thumbColor = color,
                activeTrackColor = color,
                inactiveTrackColor = SurfaceVariant
            )
        )
        Text(
            text = "%.0f".format(value),
            modifier = Modifier.width(36.dp),
            fontSize = 12.sp,
            color = TextSecondary,
            textAlign = TextAlign.End
        )
    }
}
