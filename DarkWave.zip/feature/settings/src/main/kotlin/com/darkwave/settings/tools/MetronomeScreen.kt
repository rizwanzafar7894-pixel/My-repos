package com.darkwave.settings.tools

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.components.TopBar
import com.darkwave.common.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive

@Composable
fun MetronomeScreen(onBack: () -> Unit) {
    var bpm          by remember { mutableStateOf(120) }
    var isRunning    by remember { mutableStateOf(false) }
    var beat         by remember { mutableStateOf(0) }
    var timeSignature by remember { mutableStateOf(4) }
    var currentBeat  by remember { mutableStateOf(0) }

    // Pendulum animation
    val pendulumAngle by animateFloatAsState(
        targetValue = if (beat % 2 == 0) -30f else 30f,
        animationSpec = tween(
            durationMillis = (60_000 / bpm) / 2,
            easing = FastOutSlowInEasing
        ),
        label = "pendulum"
    )

    // Beat flash color
    val flashColor by animateColorAsState(
        targetValue = if (currentBeat == 0 && isRunning) Purple500 else SurfaceVariant,
        animationSpec = tween(80),
        label = "flash"
    )

    // Metronome tick loop
    LaunchedEffect(isRunning, bpm, timeSignature) {
        if (!isRunning) return@LaunchedEffect
        val toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
        while (isActive) {
            val intervalMs = 60_000L / bpm
            toneGen.startTone(
                if (currentBeat == 0) ToneGenerator.TONE_PROP_BEEP2
                else ToneGenerator.TONE_PROP_BEEP,
                50
            )
            beat++
            currentBeat = (currentBeat + 1) % timeSignature
            delay(intervalMs)
        }
        toneGen.release()
    }

    Column(
        modifier = Modifier.fillMaxSize().background(Background)
    ) {
        TopBar(title = "Metronome", onBack = onBack)

        // Beat indicators
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
        ) {
            repeat(timeSignature) { i ->
                Box(
                    modifier = Modifier
                        .size(if (i == 0) 18.dp else 14.dp)
                        .clip(CircleShape)
                        .background(
                            if (isRunning && i == currentBeat) {
                                if (i == 0) Purple500 else Purple300
                            } else DividerColor
                        )
                )
            }
        }

        // Time Signature selector
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
        ) {
            listOf(2, 3, 4, 6, 8).forEach { sig ->
                FilterChip(
                    selected = timeSignature == sig,
                    onClick = { timeSignature = sig; currentBeat = 0 },
                    label = { Text("$sig/4") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Purple500,
                        selectedLabelColor = White
                    )
                )
            }
        }

        Spacer(Modifier.weight(1f))

        // Pendulum
        Box(
            modifier = Modifier.fillMaxWidth().height(240.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            // Rod
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(180.dp)
                    .rotate(pendulumAngle)
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        Brush.verticalGradient(listOf(Purple500, Purple300))
                    )
                    .align(Alignment.BottomCenter)
            )
            // Bob
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .rotate(pendulumAngle)
                    .offset(y = (-160).dp)
                    .clip(CircleShape)
                    .background(Purple500)
                    .align(Alignment.BottomCenter)
            )
            // Pivot
            Box(
                modifier = Modifier
                    .size(14.dp)
                    .clip(CircleShape)
                    .background(TextPrimary)
                    .align(Alignment.BottomCenter)
            )
        }

        Spacer(Modifier.weight(1f))

        // BPM display & slider
        Column(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "$bpm",
                fontSize = 64.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Purple500
            )
            Text("BPM", fontSize = 16.sp, color = TextSecondary)
            Text(
                text = bpmLabel(bpm.toFloat()),
                fontSize = 13.sp,
                color = Purple400,
                modifier = Modifier.padding(top = 4.dp)
            )

            Spacer(Modifier.height(16.dp))

            Slider(
                value = bpm.toFloat(),
                onValueChange = { bpm = it.toInt() },
                valueRange = 40f..240f,
                steps = 199,
                colors = SliderDefaults.colors(
                    thumbColor = Purple500,
                    activeTrackColor = Purple500,
                    inactiveTrackColor = Purple100
                )
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("40", fontSize = 12.sp, color = TextTertiary)
                Text("240", fontSize = 12.sp, color = TextTertiary)
            }

            Spacer(Modifier.height(8.dp))

            // +/- buttons
            Row(
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { if (bpm > 40) bpm -= 5 },
                    modifier = Modifier.size(48.dp).clip(CircleShape).background(SurfaceVariant)
                ) { Icon(Icons.Default.Remove, null, tint = TextPrimary) }

                IconButton(
                    onClick = { if (bpm < 240) bpm += 5 },
                    modifier = Modifier.size(48.dp).clip(CircleShape).background(SurfaceVariant)
                ) { Icon(Icons.Default.Add, null, tint = TextPrimary) }
            }
        }

        Spacer(Modifier.height(24.dp))

        // Start/Stop button
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 48.dp, vertical = 24.dp),
            contentAlignment = Alignment.Center
        ) {
            Button(
                onClick = {
                    isRunning = !isRunning
                    if (!isRunning) currentBeat = 0
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isRunning) RedAccent else Purple500
                )
            ) {
                Icon(
                    if (isRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                    null, modifier = Modifier.size(24.dp)
                )
                Spacer(Modifier.width(8.dp))
                Text(
                    if (isRunning) "Stop" else "Start",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
