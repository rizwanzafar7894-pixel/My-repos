package com.darkwave.settings.viewmodel

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darkwave.domain.repository.AnalyticsRepository
import com.darkwave.domain.repository.MediaRepository
import com.darkwave.domain.model.WatchStats
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val selectedTabIndex: Int = 0,
    val userName: String = "DarkWave User",
    val userEmail: String = "user@darkwave.app",
    // Playback
    val autoPlay: Boolean = true,
    val rememberPosition: Boolean = true,
    val defaultSpeed: Float = 1f,
    val hardwareDecoding: Boolean = true,
    val pipEnabled: Boolean = true,
    val skipSilence: Boolean = false,
    // Appearance
    val isDarkMode: Boolean = false,
    val accentColor: String = "purple",
    val fontSize: String = "medium",
    val showThumbnails: Boolean = true,
    // Privacy
    val saveHistory: Boolean = true,
    val analyticsEnabled: Boolean = true,
    // Downloads
    val downloadPath: String = "Downloads/DarkWave",
    val wifiOnly: Boolean = true,
    val maxConcurrentDownloads: Int = 3,
    // Storage
    val videoSizeBytes: Long = 3_440_000_000L,
    val audioSizeBytes: Long = 2_200_000_000L,
    val cacheBytes: Long = 420_000_000L,
    val otherBytes: Long = 400_000_000L,
    // Network
    val streamingQuality: String = "Auto",
    val prefetchEnabled: Boolean = true,
    val proxyEnabled: Boolean = false,
    // Analytics
    val watchStats: WatchStats = WatchStats(),
    val isLoading: Boolean = true
)

val settingsTabLabels = listOf("General", "Tools", "Analytics", "Downloads", "Storage", "Network", "Accessibility")

@HiltViewModel
class SettingsViewModel @Inject constructor(
    application: android.app.Application,
    private val dataStore: DataStore<Preferences>,
    private val analyticsRepository: AnalyticsRepository,
    private val mediaRepository: MediaRepository
) : androidx.lifecycle.AndroidViewModel(application) {

    private val context: android.content.Context get() = getApplication<android.app.Application>().applicationContext

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        loadPreferences()
        loadStats()
        loadStorageInfo()
    }

    private fun loadPreferences() {
        viewModelScope.launch {
            dataStore.data.collect { prefs ->
                _uiState.update {
                    it.copy(
                        userName          = prefs[stringPreferencesKey("user_name")] ?: "DarkWave User",
                        userEmail         = prefs[stringPreferencesKey("user_email")] ?: "user@darkwave.app",
                        autoPlay          = prefs[booleanPreferencesKey("auto_play")] ?: true,
                        rememberPosition  = prefs[booleanPreferencesKey("remember_position")] ?: true,
                        hardwareDecoding  = prefs[booleanPreferencesKey("hw_decoding")] ?: true,
                        pipEnabled        = prefs[booleanPreferencesKey("pip_enabled")] ?: true,
                        skipSilence       = prefs[booleanPreferencesKey("skip_silence")] ?: false,
                        isDarkMode        = prefs[booleanPreferencesKey("dark_mode")] ?: false,
                        saveHistory       = prefs[booleanPreferencesKey("save_history")] ?: true,
                        analyticsEnabled  = prefs[booleanPreferencesKey("analytics_enabled")] ?: true,
                        wifiOnly          = prefs[booleanPreferencesKey("wifi_only")] ?: true,
                        isLoading         = false
                    )
                }
            }
        }
    }

    private fun loadStats() {
        viewModelScope.launch {
            analyticsRepository.getWatchStats().collect { stats ->
                _uiState.update { it.copy(watchStats = stats) }
            }
        }
    }

    private fun loadStorageInfo() {
        viewModelScope.launch {
            mediaRepository.getAllVideos().combine(mediaRepository.getAllAudio()) { videos, audio ->
                val videoBytes = videos.sumOf { it.size }
                val audioBytes = audio.sumOf { it.size }
                Pair(videoBytes, audioBytes)
            }.collect { (v, a) ->
                _uiState.update { it.copy(videoSizeBytes = v, audioSizeBytes = a) }
            }
        }
    }

    fun onTabSelected(index: Int) { _uiState.update { it.copy(selectedTabIndex = index) } }

    fun <T> savePref(key: Preferences.Key<T>, value: T) {
        viewModelScope.launch { dataStore.edit { it[key] = value } }
    }

    fun setAutoPlay(v: Boolean) {
        _uiState.update { it.copy(autoPlay = v) }
        savePref(booleanPreferencesKey("auto_play"), v)
    }
    fun setRememberPosition(v: Boolean) {
        _uiState.update { it.copy(rememberPosition = v) }
        savePref(booleanPreferencesKey("remember_position"), v)
    }
    fun setHardwareDecoding(v: Boolean) {
        _uiState.update { it.copy(hardwareDecoding = v) }
        savePref(booleanPreferencesKey("hw_decoding"), v)
    }
    fun setPip(v: Boolean) {
        _uiState.update { it.copy(pipEnabled = v) }
        savePref(booleanPreferencesKey("pip_enabled"), v)
    }
    fun setSkipSilence(v: Boolean) {
        _uiState.update { it.copy(skipSilence = v) }
        savePref(booleanPreferencesKey("skip_silence"), v)
    }
    fun setDarkMode(v: Boolean) {
        _uiState.update { it.copy(isDarkMode = v) }
        savePref(booleanPreferencesKey("dark_mode"), v)
    }
    fun setSaveHistory(v: Boolean) {
        _uiState.update { it.copy(saveHistory = v) }
        savePref(booleanPreferencesKey("save_history"), v)
    }
    fun setWifiOnly(v: Boolean) {
        _uiState.update { it.copy(wifiOnly = v) }
        savePref(booleanPreferencesKey("wifi_only"), v)
    }
    fun clearAnalytics() {
        viewModelScope.launch { analyticsRepository.clearAllStats() }
    }

    fun clearCache() {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                context.cacheDir.deleteRecursively()
                _uiState.update { it.copy(cacheBytes = 0L) }
            } catch (e: Exception) {
                android.util.Log.w("DW/Settings", "clearCache failed", e)
            }
        }
    }
}
