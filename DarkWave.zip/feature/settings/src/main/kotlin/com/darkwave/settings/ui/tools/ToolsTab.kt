package com.darkwave.settings.ui.tools

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.theme.*

private data class ToolItem(
    val name: String,
    val description: String,
    val icon: ImageVector,
    val color: Color,
    val bgColor: Color,
    val onClick: () -> Unit
)

@Composable
fun ToolsTab(
    onBpmClick: () -> Unit,
    onMetronomeClick: () -> Unit,
    onTunerClick: () -> Unit,
    onRecorderClick: () -> Unit,
    onAnalyzerClick: () -> Unit,
    onEqualizerClick: () -> Unit,
    onRemoteClick: () -> Unit,
    onFocusClick: () -> Unit
) {
    val tools = listOf(
        ToolItem("BPM Detector",  "Tap or mic detect",     Icons.Default.Speed,        Color(0xFF5C6BC0), Color(0xFFE8EAF6), onBpmClick),
        ToolItem("Metronome",     "Tempo & time signature", Icons.Default.Timer,         Color(0xFF43A047), Color(0xFFE8F5E9), onMetronomeClick),
        ToolItem("Tuner",         "Chromatic, guitar, bass",Icons.Default.MusicNote,     Color(0xFFE91E8C), Color(0xFFFCE4EC), onTunerClick),
        ToolItem("Recorder",      "Audio & screen record",  Icons.Default.Mic,           Color(0xFFFF5722), Color(0xFFFBE9E7), onRecorderClick),
        ToolItem("Analyzer",      "Frequency spectrum",     Icons.Default.Equalizer,     Color(0xFF8E24AA), Color(0xFFF3E5F5), onAnalyzerClick),
        ToolItem("Equalizer",     "10-band EQ & presets",   Icons.Default.Tune,          Color(0xFF0288D1), Color(0xFFE1F5FE), onEqualizerClick),
        ToolItem("Remote Control","WebSocket + QR code",    Icons.Default.SettingsRemote,Color(0xFF6D4C41), Color(0xFFEFEBE9), onRemoteClick),
        ToolItem("Focus Timer",   "Pomodoro & deep work",   Icons.Default.HourglassEmpty,Color(0xFF2E7D32), Color(0xFFE8F5E9), onFocusClick)
    )

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text(
                "Professional Tools",
                fontSize = 18.sp, fontWeight = FontWeight.Bold, color = TextPrimary,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                "Advanced audio & video tools for professionals",
                fontSize = 13.sp, color = TextSecondary
            )
            Spacer(Modifier.height(4.dp))
        }

        // 2-column grid using rows of 2
        items(tools.chunked(2).size) { rowIdx ->
            val row = tools.chunked(2)[rowIdx]
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                row.forEach { tool ->
                    ToolCard(
                        tool     = tool,
                        modifier = Modifier.weight(1f)
                    )
                }
                // Fill remaining space if odd number
                if (row.size == 1) {
                    Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun ToolCard(tool: ToolItem, modifier: Modifier = Modifier) {
    Card(
        modifier  = modifier.clickable(onClick = tool.onClick),
        shape     = RoundedCornerShape(16.dp),
        colors    = CardDefaults.cardColors(containerColor = White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(tool.bgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = tool.icon,
                    contentDescription = tool.name,
                    tint     = tool.color,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(Modifier.height(12.dp))
            Text(
                text = tool.name,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary
            )
            Spacer(Modifier.height(3.dp))
            Text(
                text = tool.description,
                fontSize = 11.sp,
                color = TextSecondary,
                lineHeight = 15.sp
            )
        }
    }
}
