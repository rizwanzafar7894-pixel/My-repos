package com.darkwave.settings.ui.analytics

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.theme.*
import com.darkwave.domain.model.DayWatchData
import com.darkwave.domain.model.WatchStats

@Composable
fun AnalyticsTab(
    stats: WatchStats,
    onClear: () -> Unit
) {
    var showClearDialog by remember { mutableStateOf(false) }

    LazyColumn(
        contentPadding      = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier            = Modifier.fillMaxSize()
    ) {
        // ── Summary chips ──────────────────────────────────────────────
        item {
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatChip("Watch Time",  formatHours(stats.totalWatchMinutes), Purple500, Modifier.weight(1f))
                StatChip("Videos",     "${stats.totalVideosWatched}",          Color(0xFF2196F3), Modifier.weight(1f))
                StatChip("Songs",      "${stats.totalSongsPlayed}",            Color(0xFF4CAF50), Modifier.weight(1f))
            }
        }

        // ── Weekly bar chart ───────────────────────────────────────────
        item {
            Card(
                shape     = RoundedCornerShape(16.dp),
                colors    = CardDefaults.cardColors(containerColor = White),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier  = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "This Week",
                        fontSize   = 15.sp,
                        fontWeight = FontWeight.SemiBold,
                        color      = TextPrimary
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Daily watch time in minutes",
                        fontSize = 12.sp,
                        color    = TextSecondary
                    )
                    Spacer(Modifier.height(16.dp))

                    // Fixed WeeklyBarChart
                    WeeklyBarChart(
                        data     = stats.weeklyData,
                        barColor = Purple500,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                    )
                }
            }
        }

        // ── Most watched ───────────────────────────────────────────────
        item {
            Card(
                shape     = RoundedCornerShape(16.dp),
                colors    = CardDefaults.cardColors(containerColor = White),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier  = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Most Watched", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Spacer(Modifier.height(12.dp))

                    if (stats.topVideos.isEmpty()) {
                        Text("No data yet", fontSize = 13.sp, color = TextSecondary)
                    } else {
                        stats.topVideos.forEachIndexed { i, video ->
                            Row(
                                modifier            = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                verticalAlignment   = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier         = Modifier
                                        .size(28.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (i == 0) Purple500 else SurfaceVariant),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "${i + 1}",
                                        fontSize   = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color      = if (i == 0) White else TextSecondary
                                    )
                                }
                                Spacer(Modifier.width(10.dp))
                                Text(video, fontSize = 13.sp, color = TextPrimary, modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }

        // ── Playback breakdown ─────────────────────────────────────────
        item {
            Card(
                shape     = RoundedCornerShape(16.dp),
                colors    = CardDefaults.cardColors(containerColor = White),
                elevation = CardDefaults.cardElevation(2.dp),
                modifier  = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Breakdown", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                    Spacer(Modifier.height(12.dp))
                    BreakdownRow("Video",      stats.videoWatchMinutes,  stats.totalWatchMinutes, Color(0xFF5C6BC0))
                    Spacer(Modifier.height(8.dp))
                    BreakdownRow("Music",      stats.musicPlayMinutes,   stats.totalWatchMinutes, Color(0xFF43A047))
                    Spacer(Modifier.height(8.dp))
                    BreakdownRow("Browser",    stats.browserMinutes,     stats.totalWatchMinutes, Color(0xFF0288D1))
                }
            }
        }

        // ── Clear button ───────────────────────────────────────────────
        item {
            OutlinedButton(
                onClick = { showClearDialog = true },
                modifier = Modifier.fillMaxWidth(),
                shape    = RoundedCornerShape(12.dp),
                colors   = ButtonDefaults.outlinedButtonColors(contentColor = Error)
            ) {
                Icon(Icons.Default.DeleteSweep, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Clear All Analytics Data")
            }
        }
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            title   = { Text("Clear Analytics?") },
            text    = { Text("This will permanently delete all watch history and statistics.") },
            confirmButton = {
                TextButton(onClick = { onClear(); showClearDialog = false }) {
                    Text("Clear", color = Error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearDialog = false }) { Text("Cancel") }
            }
        )
    }
}

// ── Fixed WeeklyBarChart ─────────────────────────────────────────────────
@Composable
fun WeeklyBarChart(
    data: List<DayWatchData>,
    barColor: Color,
    modifier: Modifier = Modifier
) {
    // Provide default 7 days if empty
    val chartData = remember(data) {
        val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
        if (data.isEmpty()) {
            days.map { DayWatchData(it, 0) }
        } else {
            // Ensure exactly 7 entries, merge or pad
            val mapped = data.associateBy { it.dayLabel }
            days.map { day -> mapped[day] ?: DayWatchData(day, 0) }
        }
    }

    val maxMinutes = remember(chartData) {
        chartData.maxOfOrNull { it.watchMinutes }?.coerceAtLeast(1) ?: 60
    }

    val density  = LocalDensity.current
    val labelPx  = with(density) { 11.sp.toPx() }
    val labelColor = TextSecondary.toArgb()
    val barColorArgb = barColor.toArgb()

    Canvas(modifier = modifier) {
        val count      = chartData.size
        val totalWidth = size.width
        val totalHeight = size.height
        val bottomPad  = labelPx * 2.5f          // space for day labels
        val chartH     = totalHeight - bottomPad
        val barW       = (totalWidth / count) * 0.5f
        val gap        = (totalWidth / count) * 0.5f
        val halfGap    = gap / 2f

        chartData.forEachIndexed { index, day ->
            val centerX  = index * (barW + gap) + halfGap + barW / 2
            val fraction = day.watchMinutes.toFloat() / maxMinutes
            val barH     = (fraction * chartH).coerceAtLeast(4f)
            val top      = chartH - barH

            // Bar
            drawRoundRect(
                color        = barColor,
                topLeft      = Offset(centerX - barW / 2, top),
                size         = Size(barW, barH),
                cornerRadius = CornerRadius(6f, 6f)
            )

            // Day label below bar
            drawContext.canvas.nativeCanvas.drawText(
                day.dayLabel,
                centerX,
                totalHeight,
                android.graphics.Paint().apply {
                    color     = labelColor
                    textSize  = labelPx
                    textAlign = android.graphics.Paint.Align.CENTER
                    isAntiAlias = true
                }
            )
        }

        // Baseline
        drawLine(
            color       = Color(0xFFE0E0E0),
            start       = Offset(0f, chartH),
            end         = Offset(totalWidth, chartH),
            strokeWidth = 1.dp.toPx()
        )
    }
}

// ── Helpers ──────────────────────────────────────────────────────────────

@Composable
private fun StatChip(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        shape     = RoundedCornerShape(12.dp),
        colors    = CardDefaults.cardColors(containerColor = White),
        elevation = CardDefaults.cardElevation(2.dp),
        modifier  = modifier
    ) {
        Column(
            modifier            = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = color)
            Spacer(Modifier.height(2.dp))
            Text(label, fontSize = 11.sp, color = TextSecondary)
        }
    }
}

@Composable
private fun BreakdownRow(label: String, minutes: Int, total: Int, color: Color) {
    val fraction = if (total > 0) minutes.toFloat() / total else 0f
    Column {
        Row {
            Text(label, fontSize = 13.sp, color = TextPrimary, modifier = Modifier.weight(1f))
            Text(formatHours(minutes), fontSize = 13.sp, color = TextSecondary)
        }
        Spacer(Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(SurfaceVariant)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(fraction)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(3.dp))
                    .background(color)
            )
        }
    }
}

private fun formatHours(minutes: Int): String {
    val h = minutes / 60
    val m = minutes % 60
    return if (h > 0) "${h}h ${m}m" else "${m}m"
}
