package com.darkwave.settings.ui.storage

import android.content.Context
import android.os.Environment
import android.os.StatFs
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.components.TopBar
import com.darkwave.common.ui.theme.*

// FIX: Use real StatFs instead of hardcoded 32GB
private fun getStorageStats(context: Context): Triple<Long, Long, Long> {
    return try {
        val stat = StatFs(Environment.getExternalStorageDirectory().path)
        val total     = stat.totalBytes
        val available = stat.availableBytes
        val used      = total - available
        Triple(total, used, available)
    } catch (e: Exception) {
        Triple(0L, 0L, 0L)
    }
}

private fun Long.toReadableSize(): String {
    val gb = this / (1024.0 * 1024.0 * 1024.0)
    val mb = this / (1024.0 * 1024.0)
    return when {
        gb >= 1.0 -> "%.1f GB".format(gb)
        mb >= 1.0 -> "%.0f MB".format(mb)
        else      -> "%.0f KB".format(this / 1024.0)
    }
}

@Composable
fun StorageTab(
    videosSize: Long = 0L,
    audioSize: Long = 0L,
    cacheSize: Long = 0L,
    onClearCache: () -> Unit = {}
) {
    val context = LocalContext.current
    val (totalBytes, usedBytes, freeBytes) = remember {
        getStorageStats(context)
    }

    val appUsedBytes = videosSize + audioSize + cacheSize
    val usedFraction = if (totalBytes > 0) usedBytes.toFloat() / totalBytes else 0f

    LazyColumn(
        modifier        = Modifier.fillMaxSize().background(Background),
        contentPadding  = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // ── Storage overview card ─────────────────────────────────
            Card(
                shape  = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        "Device Storage",
                        fontSize   = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color      = TextPrimary
                    )
                    Spacer(Modifier.height(16.dp))

                    // Segmented bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(12.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(Purple100)
                    ) {
                        // Used portion
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(usedFraction.coerceIn(0f, 1f))
                                .fillMaxHeight()
                                .background(Purple500)
                        )
                    }

                    Spacer(Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        StorageLegendItem("Used", usedBytes.toReadableSize(), Purple500)
                        StorageLegendItem("Free", freeBytes.toReadableSize(), Purple100)
                        StorageLegendItem("Total", totalBytes.toReadableSize(), TextSecondary)
                    }
                }
            }
        }

        item {
            // ── App usage breakdown ───────────────────────────────────
            Card(
                shape  = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        "DarkWave Usage",
                        fontSize   = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color      = TextPrimary
                    )
                    Spacer(Modifier.height(12.dp))

                    StorageRow(
                        icon  = Icons.Default.VideoLibrary,
                        label = "Videos",
                        size  = videosSize.toReadableSize(),
                        color = Badge4K
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    StorageRow(
                        icon  = Icons.Default.MusicNote,
                        label = "Music",
                        size  = audioSize.toReadableSize(),
                        color = PinkAccent
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    StorageRow(
                        icon  = Icons.Default.Storage,
                        label = "Cache",
                        size  = cacheSize.toReadableSize(),
                        color = GreenAccent
                    )
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
                    StorageRow(
                        icon  = Icons.Default.FolderOpen,
                        label = "Total App Usage",
                        size  = appUsedBytes.toReadableSize(),
                        color = Purple500
                    )
                }
            }
        }

        item {
            // ── Clear cache button ────────────────────────────────────
            Button(
                onClick = onClearCache,
                modifier = Modifier.fillMaxWidth(),
                colors   = ButtonDefaults.buttonColors(containerColor = Purple500),
                shape    = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Delete, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Clear Cache (${cacheSize.toReadableSize()})")
            }
        }
    }
}

@Composable
private fun StorageLegendItem(label: String, value: String, color: androidx.compose.ui.graphics.Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(color)
            )
            Spacer(Modifier.width(4.dp))
            Text(label, fontSize = 11.sp, color = TextSecondary)
        }
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
    }
}

@Composable
private fun StorageRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    size: String,
    color: androidx.compose.ui.graphics.Color
) {
    Row(
        modifier            = Modifier.fillMaxWidth(),
        verticalAlignment   = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(10.dp))
            Text(label, fontSize = 14.sp, color = TextPrimary)
        }
        Text(size, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextSecondary)
    }
}
