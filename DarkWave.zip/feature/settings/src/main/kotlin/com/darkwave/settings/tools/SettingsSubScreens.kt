package com.darkwave.settings.tools

import android.os.StatFs
import android.os.Environment
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.components.TopBar
import com.darkwave.common.ui.theme.*

// ─────────────────────────────────────────────────────────────────────────────
// DOWNLOAD SETTINGS
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun DownloadSettingsScreen(onBack: () -> Unit) {
    var wifiOnly      by remember { mutableStateOf(true) }
    var autoDownload  by remember { mutableStateOf(false) }
    var quality       by remember { mutableStateOf("720p") }
    var maxConcurrent by remember { mutableStateOf(3) }
    var downloadPath  by remember { mutableStateOf("Internal/DarkWave/Downloads") }
    var cacheCleared  by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Background),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item { TopBar(title = "Downloads", onBack = onBack) }

        item {
            SettingsSection("Connection") {
                ToggleSetting(
                    icon = Icons.Default.Wifi,
                    label = "Wi-Fi Only",
                    subtitle = "Download only when connected to Wi-Fi",
                    checked = wifiOnly,
                    onCheckedChange = { wifiOnly = it }
                )
                ToggleSetting(
                    icon = Icons.Default.DownloadForOffline,
                    label = "Auto Download",
                    subtitle = "Automatically download recommended tracks",
                    checked = autoDownload,
                    onCheckedChange = { autoDownload = it }
                )
            }
        }

        item {
            SettingsSection("Quality") {
                Text(
                    "Default Download Quality",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    fontSize = 14.sp, color = TextPrimary, fontWeight = FontWeight.Medium
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("480p", "720p", "1080p", "4K").forEach { q ->
                        FilterChip(
                            selected = quality == q,
                            onClick = { quality = q },
                            label = { Text(q, fontSize = 13.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Purple500,
                                selectedLabelColor = White
                            )
                        )
                    }
                }
            }
        }

        item {
            SettingsSection("Active Downloads") {
                val mockDownloads = remember {
                    listOf(
                        Triple("The Dark Knight (2008).mkv", 0.72f, "1.2 GB"),
                        Triple("Interstellar (2014) 4K.mp4", 0.35f, "8.4 GB"),
                        Triple("Bohemian Rhapsody.mp3", 0.91f, "8.4 MB")
                    )
                }
                if (mockDownloads.isEmpty()) {
                    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("No active downloads", color = TextTertiary, fontSize = 14.sp)
                    }
                } else {
                    mockDownloads.forEach { (name, progress, size) ->
                        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp)) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(name, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                                    modifier = Modifier.weight(1f), maxLines = 1,
                                    overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.width(8.dp))
                                Text("$size", color = TextSecondary, fontSize = 12.sp)
                            }
                            Spacer(Modifier.height(6.dp))
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                LinearProgressIndicator(
                                    progress = progress,
                                    color = Purple500,
                                    trackColor = SurfaceVariant,
                                    modifier = Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp))
                                )
                                Spacer(Modifier.width(8.dp))
                                Text("${(progress * 100).toInt()}%", color = Purple500, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                        if (mockDownloads.last() != Triple(name, progress, size)) {
                            Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                        }
                    }
                }
            }
        }

        item {
            SettingsSection("Storage") {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Concurrent Downloads", fontSize = 14.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                        Text("Max simultaneous downloads", fontSize = 12.sp, color = TextSecondary)
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        IconButton(
                            onClick = { if (maxConcurrent > 1) maxConcurrent-- },
                            modifier = Modifier.size(32.dp).clip(CircleShape).background(SurfaceVariant)
                        ) { Icon(Icons.Default.Remove, null, tint = TextPrimary, modifier = Modifier.size(16.dp)) }
                        Text("$maxConcurrent", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Purple500)
                        IconButton(
                            onClick = { if (maxConcurrent < 10) maxConcurrent++ },
                            modifier = Modifier.size(32.dp).clip(CircleShape).background(SurfaceVariant)
                        ) { Icon(Icons.Default.Add, null, tint = TextPrimary, modifier = Modifier.size(16.dp)) }
                    }
                }
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Download Location", fontSize = 14.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                        Text(downloadPath, fontSize = 12.sp, color = TextSecondary)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = TextTertiary)
                }
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                if (cacheCleared) {
                    Text(
                        "✓ Cache cleared",
                        color = androidx.compose.ui.graphics.Color(0xFF43A047),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall
                    )
                } else {
                    TextButton(
                        onClick = {
                            // Clear ExoPlayer cache dir
                            try {
                                val cacheDir = java.io.File(context.cacheDir, "exoplayer")
                                cacheDir.deleteRecursively()
                                val dwCache = java.io.File(context.cacheDir, "DarkWave")
                                dwCache.deleteRecursively()
                            } catch (_: Exception) {}
                            cacheCleared = true
                        },
                        modifier = Modifier.padding(horizontal = 8.dp)
                    ) {
                        Icon(Icons.Default.DeleteSweep, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Clear Download Cache", color = RedAccent)
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// STORAGE SCREEN  (StatFs implementation)
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun StorageScreen(onBack: () -> Unit) {
    val context = LocalContext.current

    // Real device storage using StatFs
    val (totalBytes, freeBytes) = remember {
        try {
            val stat = StatFs(Environment.getExternalStorageDirectory().absolutePath)
            val total = stat.blockCountLong * stat.blockSizeLong
            val free  = stat.availableBlocksLong * stat.blockSizeLong
            total to free
        } catch (e: Exception) {
            32_000_000_000L to 16_000_000_000L
        }
    }

    // Simulated category sizes (replace with real MediaStore queries)
    val videoBytes = 4_500_000_000L
    val audioBytes = 1_200_000_000L
    val cacheBytes = 340_000_000L
    val otherBytes = 800_000_000L
    val usedBytes  = videoBytes + audioBytes + cacheBytes + otherBytes

    val animProg by animateFloatAsState(
        targetValue = 1f,
        animationSpec = tween(800, easing = FastOutSlowInEasing),
        label = "storageAnim"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Background),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item { TopBar(title = "Storage", onBack = onBack) }

        item {
            // Storage bar
            Card(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceLight),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Device Storage", fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = TextPrimary)
                        Text(
                            "${formatSize(freeBytes)} free",
                            fontSize = 13.sp, color = GreenAccent, fontWeight = FontWeight.Medium
                        )
                    }
                    Spacer(Modifier.height(12.dp))

                    // Segmented bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(16.dp)
                            .clip(RoundedCornerShape(8.dp))
                    ) {
                        val total = totalBytes.toFloat()
                        StorageSegment(videoBytes / total * animProg, Color(0xFF5C6BC0))
                        StorageSegment(audioBytes / total * animProg, Color(0xFF43A047))
                        StorageSegment(cacheBytes / total * animProg, Color(0xFFFF9800))
                        StorageSegment(otherBytes / total * animProg, Color(0xFF90A4AE))
                        StorageSegment(((totalBytes - usedBytes).coerceAtLeast(0) / total), Color(0xFFE0E0E0))
                    }

                    Spacer(Modifier.height(12.dp))
                    Text(
                        "${formatSize(usedBytes)} of ${formatSize(totalBytes)} used",
                        fontSize = 12.sp, color = TextSecondary
                    )
                }
            }
        }

        item {
            SettingsSection("Breakdown") {
                listOf(
                    Triple("Video", videoBytes,  Color(0xFF5C6BC0)),
                    Triple("Audio", audioBytes,  Color(0xFF43A047)),
                    Triple("Cache", cacheBytes,  Color(0xFFFF9800)),
                    Triple("Other", otherBytes,  Color(0xFF90A4AE)),
                    Triple("Free",  (totalBytes - usedBytes).coerceAtLeast(0), Color(0xFFE0E0E0))
                ).forEach { (label, bytes, color) ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(12.dp).clip(CircleShape).background(color))
                        Spacer(Modifier.width(12.dp))
                        Text(label, modifier = Modifier.weight(1f), fontSize = 14.sp, color = TextPrimary)
                        Text(formatSize(bytes), fontSize = 14.sp, color = TextSecondary, fontWeight = FontWeight.Medium)
                    }
                    if (label != "Free") Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                }
            }
        }

        item {
            SettingsSection("Actions") {
                ActionItem(Icons.Default.CleaningServices, "Clear Cache", "Free up ${formatSize(cacheBytes)}", OrangeAccent) {}
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                ActionItem(Icons.Default.FolderDelete, "Clear Temp Files", "Remove temporary downloads", RedAccent) {}
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                ActionItem(Icons.Default.Analytics, "Analyze Storage", "Find large files and duplicates", BlueAccent) {}
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// NETWORK SETTINGS
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun NetworkSettingsScreen(onBack: () -> Unit) {
    var streamQuality  by remember { mutableStateOf("Auto") }
    var dataSaver      by remember { mutableStateOf(false) }
    var preloadBuffer  by remember { mutableStateOf(true) }
    var cacheSize      by remember { mutableStateOf(512f) }
    var proxyEnabled   by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Background),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item { TopBar(title = "Network", onBack = onBack) }

        item {
            SettingsSection("Streaming") {
                Text(
                    "Stream Quality",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Auto", "Low", "Medium", "High").forEach { q ->
                        FilterChip(
                            selected = streamQuality == q,
                            onClick = { streamQuality = q },
                            label = { Text(q, fontSize = 13.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Purple500,
                                selectedLabelColor = White
                            )
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                ToggleSetting(Icons.Default.DataSaverOn, "Data Saver", "Reduce data usage on mobile networks", dataSaver) { dataSaver = it }
                ToggleSetting(Icons.Default.Memory, "Preload Buffer", "Buffer next track in advance", preloadBuffer) { preloadBuffer = it }
            }
        }

        item {
            SettingsSection("Cache") {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Network Cache Size", fontSize = 14.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                        Text("%.0f MB".format(cacheSize), fontSize = 12.sp, color = TextSecondary)
                    }
                }
                Slider(
                    value = cacheSize,
                    onValueChange = { cacheSize = it },
                    valueRange = 128f..2048f,
                    modifier = Modifier.padding(horizontal = 16.dp),
                    colors = SliderDefaults.colors(thumbColor = Purple500, activeTrackColor = Purple500)
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("128 MB", fontSize = 11.sp, color = TextTertiary)
                    Text("2 GB", fontSize = 11.sp, color = TextTertiary)
                }
            }
        }

        item {
            SettingsSection("Proxy") {
                ToggleSetting(Icons.Default.VpnKey, "Use Proxy", "Route traffic through a proxy server", proxyEnabled) { proxyEnabled = it }
                if (proxyEnabled) {
                    var host by remember { mutableStateOf("") }
                    var port by remember { mutableStateOf("") }
                    OutlinedTextField(
                        value = host,
                        onValueChange = { host = it },
                        label = { Text("Proxy Host") },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = port,
                        onValueChange = { port = it },
                        label = { Text("Port") },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                        singleLine = true
                    )
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Shared Composables
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(
            title.uppercase(),
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            color = Purple500,
            modifier = Modifier.padding(bottom = 8.dp, start = 4.dp),
            letterSpacing = 0.8.sp
        )
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = SurfaceLight),
            elevation = CardDefaults.cardElevation(1.dp)
        ) {
            Column(content = content)
        }
    }
}

@Composable
fun ToggleSetting(
    icon: ImageVector,
    label: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Purple100),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = Purple500, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
            Text(subtitle, fontSize = 12.sp, color = TextSecondary)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = White, checkedTrackColor = Purple500)
        )
    }
}

@Composable
private fun ActionItem(icon: ImageVector, label: String, subtitle: String, color: Color, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(color.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = color, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = color)
            Text(subtitle, fontSize = 12.sp, color = TextSecondary)
        }
        Icon(Icons.Default.ChevronRight, null, tint = TextTertiary)
    }
}

@Composable
private fun RowScope.StorageSegment(fraction: Float, color: Color) {
    if (fraction > 0f) {
        Box(modifier = Modifier.weight(fraction.coerceAtLeast(0.001f)).fillMaxHeight().background(color))
    }
}

fun formatSize(bytes: Long): String = when {
    bytes >= 1_000_000_000L -> "%.1f GB".format(bytes / 1_000_000_000.0)
    bytes >= 1_000_000L     -> "%.0f MB".format(bytes / 1_000_000.0)
    bytes >= 1_000L         -> "%.0f KB".format(bytes / 1_000.0)
    else                    -> "$bytes B"
}
