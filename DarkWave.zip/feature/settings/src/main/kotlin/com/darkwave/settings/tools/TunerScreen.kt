package com.darkwave.settings.tools

import android.Manifest
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.components.TopBar
import com.darkwave.common.ui.theme.*
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState

private val NOTES = listOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")

private fun frequencyToNote(freq: Float): Pair<String, Float> {
    if (freq <= 0) return ("A" to 0f)
    val a4 = 440.0
    val semitones = 12 * Math.log(freq / a4.toDouble()) / Math.log(2.0)
    val rounded = Math.round(semitones).toInt()
    val noteIndex = ((rounded % 12) + 12) % 12
    val cents = ((semitones - rounded) * 100).toFloat()
    val octave = 4 + (rounded + 9) / 12
    return ("${NOTES[noteIndex]}$octave" to cents)
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun TunerScreen(onBack: () -> Unit) {
    val micPermission = rememberPermissionState(Manifest.permission.RECORD_AUDIO)

    var isListening  by remember { mutableStateOf(false) }
    var detectedFreq by remember { mutableStateOf(0f) }
    var tunerMode    by remember { mutableStateOf(TunerMode.CHROMATIC) }

    // Real pitch detection via AudioRecord + YIN algorithm
    LaunchedEffect(isListening) {
        if (!isListening) {
            detectedFreq = 0f
            return@LaunchedEffect
        }
        audioRecordFlow { buffer, _ ->
            val pitch = AudioEngine.detectPitch(buffer)
            if (pitch > 20f) {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    detectedFreq = pitch
                }
            }
        }
    }

    val (noteName, cents) = remember(detectedFreq) { frequencyToNote(detectedFreq) }

    // Needle angle: -45° (flat) to +45° (sharp), 0° = in tune
    val needleAngle by animateFloatAsState(
        targetValue = (cents / 50f * 45f).coerceIn(-45f, 45f),
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "needle"
    )

    val tuneColor = when {
        detectedFreq == 0f    -> TextTertiary
        kotlin.math.abs(cents) < 5  -> GreenAccent
        kotlin.math.abs(cents) < 15 -> AmberAccent
        else                  -> RedAccent
    }

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        TopBar(title = "Tuner", onBack = onBack)

        // Mode tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(SurfaceVariant),
        ) {
            TunerMode.entries.forEach { mode ->
                val selected = tunerMode == mode
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(4.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) Purple500 else Color.Transparent)
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = mode.label,
                        color = if (selected) White else TextSecondary,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                        fontSize = 13.sp
                    )
                }
            }
        }

        if (!micPermission.status.isGranted) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.MicOff, null, tint = TextTertiary, modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(16.dp))
                    Text("Microphone permission required", color = TextSecondary)
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = { micPermission.launchPermissionRequest() },
                        colors = ButtonDefaults.buttonColors(containerColor = Purple500)
                    ) { Text("Grant Permission") }
                }
            }
            return@Column
        }

        Spacer(Modifier.weight(1f))

        // Note display
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = if (detectedFreq > 0) noteName else "---",
                fontSize = 88.sp,
                fontWeight = FontWeight.ExtraBold,
                color = tuneColor
            )
            Text(
                text = if (detectedFreq > 0) "%.1f Hz".format(detectedFreq) else "Not detected",
                fontSize = 16.sp,
                color = TextSecondary
            )
        }

        Spacer(Modifier.height(32.dp))

        // Tuner meter / needle
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 32.dp)
                .height(160.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(SurfaceLight),
            contentAlignment = Alignment.Center
        ) {
            // Scale markings
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 16.dp)
                    .align(Alignment.TopCenter),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                listOf("♭♭", "♭", "♩", "♯", "♯♯").forEach { mark ->
                    Text(mark, fontSize = 11.sp, color = TextTertiary)
                }
            }

            // Cent value
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                // Needle
                Box(
                    modifier = Modifier
                        .width(3.dp)
                        .height(80.dp)
                        .rotate(needleAngle)
                        .clip(RoundedCornerShape(2.dp))
                        .background(
                            Brush.verticalGradient(listOf(tuneColor, tuneColor.copy(alpha = 0.3f)))
                        )
                )
                Spacer(Modifier.height(4.dp))
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(tuneColor)
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    text = if (detectedFreq > 0) {
                        when {
                            kotlin.math.abs(cents) < 3 -> "In Tune ✓"
                            cents < 0 -> "%.0f¢ flat".format(-cents)
                            else      -> "+%.0f¢ sharp".format(cents)
                        }
                    } else "",
                    fontSize = 13.sp,
                    color = tuneColor,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Spacer(Modifier.weight(1f))

        // Reference pitch for guitar/bass modes
        if (tunerMode != TunerMode.CHROMATIC) {
            val strings = when (tunerMode) {
                TunerMode.GUITAR -> listOf("E2" to 82.4f, "A2" to 110f, "D3" to 146.8f, "G3" to 196f, "B3" to 246.9f, "E4" to 329.6f)
                TunerMode.BASS   -> listOf("E1" to 41.2f, "A1" to 55f, "D2" to 73.4f, "G2" to 98f)
                TunerMode.UKULELE -> listOf("G4" to 392f, "C4" to 261.6f, "E4" to 329.6f, "A4" to 440f)
                else -> emptyList()
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
            ) {
                strings.forEach { (name, _) ->
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(SurfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(name, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary, textAlign = TextAlign.Center)
                    }
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        // Start/Stop
        Button(
            onClick = { isListening = !isListening },
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .fillMaxWidth()
                .padding(horizontal = 48.dp)
                .height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isListening) RedAccent else Purple500
            )
        ) {
            Icon(if (isListening) Icons.Default.MicOff else Icons.Default.Mic, null)
            Spacer(Modifier.width(8.dp))
            Text(
                if (isListening) "Stop Listening" else "Start Tuning",
                fontSize = 17.sp, fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(Modifier.height(32.dp))
    }
}

private enum class TunerMode(val label: String) {
    CHROMATIC("Chromatic"),
    GUITAR("Guitar"),
    BASS("Bass"),
    UKULELE("Ukulele")
}
