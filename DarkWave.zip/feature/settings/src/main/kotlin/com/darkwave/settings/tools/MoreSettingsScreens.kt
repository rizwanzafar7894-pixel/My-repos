package com.darkwave.settings.tools

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.components.TopBar
import com.darkwave.common.ui.theme.*

// ─────────────────────────────────────────────────────────────────────────────
// PROFILE EDIT SCREEN
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun ProfileEditScreen(onBack: () -> Unit) {
    var displayName by remember { mutableStateOf("") }
    var email       by remember { mutableStateOf("") }
    var bio         by remember { mutableStateOf("") }
    var photoUri    by remember { mutableStateOf<android.net.Uri?>(null) }

    val photoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri -> uri?.let { photoUri = it } }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Background),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item { TopBar(title = "Edit Profile", onBack = onBack) }

        item {
            // Avatar section
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Box {
                        Box(
                            modifier = Modifier
                                .size(96.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.radialGradient(listOf(Purple400, Purple600))
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Person, null, tint = White, modifier = Modifier.size(48.dp))
                        }
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Purple500)
                                .align(Alignment.BottomEnd),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.CameraAlt, null, tint = White, modifier = Modifier.size(16.dp))
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { photoLauncher.launch("image/*") }) {
                        Text("Change Photo", color = Purple500, fontSize = 14.sp)
                    }
                }
            }
        }

        item {
            SettingsSection("Personal Info") {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = displayName,
                        onValueChange = { displayName = it },
                        label = { Text("Display Name") },
                        leadingIcon = { Icon(Icons.Default.Person, null, tint = TextTertiary) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email") },
                        leadingIcon = { Icon(Icons.Default.Email, null, tint = TextTertiary) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                    OutlinedTextField(
                        value = bio,
                        onValueChange = { bio = it },
                        label = { Text("Bio") },
                        leadingIcon = { Icon(Icons.Default.Edit, null, tint = TextTertiary) },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        maxLines = 4,
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }

        item {
            SettingsSection("Account") {
                ActionItem(Icons.Default.Lock,       "Change Password",    "Update your password",     Purple500) {}
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                ActionItem(Icons.Default.DeleteForever, "Delete Account", "Permanently delete account", RedAccent) {}
            }
        }

        item {
            Button(
                onClick = { onBack() },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .height(52.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Purple500)
            ) {
                Text("Save Changes", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// PLAYBACK SETTINGS SCREEN
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun PlaybackSettingsScreen(onBack: () -> Unit) {
    var autoplay         by remember { mutableStateOf(true) }
    var crossfade        by remember { mutableStateOf(true) }
    var crossfadeDuration by remember { mutableStateOf(3f) }
    var gaplessPlayback  by remember { mutableStateOf(true) }
    var replayGain       by remember { mutableStateOf(false) }
    var normalizeVolume  by remember { mutableStateOf(true) }
    var defaultSpeed     by remember { mutableStateOf(1f) }
    var resumeOnHeadset  by remember { mutableStateOf(true) }
    var pauseOnCall      by remember { mutableStateOf(true) }
    var seekOnHeadset    by remember { mutableStateOf(false) }
    var doubleTapSeekSec by remember { mutableStateOf(10f) }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Background),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item { TopBar(title = "Playback", onBack = onBack) }

        item {
            SettingsSection("General") {
                ToggleSetting(Icons.Default.PlayCircle,   "Autoplay",          "Auto-play next track",         autoplay)        { autoplay = it }
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                ToggleSetting(Icons.Default.BlurOn,       "Crossfade",         "Smooth transition between tracks", crossfade)   { crossfade = it }
                if (crossfade) {
                    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                        Text("Crossfade duration: ${crossfadeDuration.toInt()}s", fontSize = 13.sp, color = TextSecondary)
                        Slider(
                            value = crossfadeDuration, onValueChange = { crossfadeDuration = it },
                            valueRange = 1f..12f, steps = 10,
                            colors = SliderDefaults.colors(thumbColor = Purple500, activeTrackColor = Purple500)
                        )
                    }
                }
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                ToggleSetting(Icons.Default.MusicNote,    "Gapless Playback",  "No silence between tracks",    gaplessPlayback)  { gaplessPlayback = it }
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                ToggleSetting(Icons.Default.VolumeUp,     "Normalize Volume",  "Auto level-match tracks",      normalizeVolume)  { normalizeVolume = it }
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                ToggleSetting(Icons.Default.Equalizer,    "ReplayGain",        "Use embedded ReplayGain data", replayGain)       { replayGain = it }
            }
        }

        item {
            SettingsSection("Speed & Seek") {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Default Playback Speed: ${defaultSpeed}x", fontSize = 14.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f).forEach { speed ->
                            FilterChip(
                                selected = defaultSpeed == speed,
                                onClick  = { defaultSpeed = speed },
                                label    = { Text("${speed}x", fontSize = 12.sp) },
                                colors   = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Purple500,
                                    selectedLabelColor = White
                                )
                            )
                        }
                    }
                }
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Double-tap seek: ${doubleTapSeekSec.toInt()}s", fontSize = 14.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                    Slider(
                        value = doubleTapSeekSec, onValueChange = { doubleTapSeekSec = it },
                        valueRange = 5f..30f, steps = 4,
                        colors = SliderDefaults.colors(thumbColor = Purple500, activeTrackColor = Purple500)
                    )
                }
            }
        }

        item {
            SettingsSection("Hardware") {
                ToggleSetting(Icons.Default.Headset,      "Resume on Headset Connect", "Auto-play when headset plugged in", resumeOnHeadset)  { resumeOnHeadset = it }
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                ToggleSetting(Icons.Default.Phone,        "Pause on Call",             "Pause music during calls",          pauseOnCall)       { pauseOnCall = it }
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                ToggleSetting(Icons.Default.SkipNext,     "Seek with Headset Buttons", "Long press skip = 30s seek",       seekOnHeadset)    { seekOnHeadset = it }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// APPEARANCE SETTINGS SCREEN
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun AppearanceSettingsScreen(onBack: () -> Unit) {
    var darkMode        by remember { mutableStateOf(0) }  // 0=system, 1=light, 2=dark
    var amoledBlack     by remember { mutableStateOf(false) }  // true = pure black background
    var accentColor     by remember { mutableStateOf(0) }  // index into palette
    var albumArtBlur    by remember { mutableStateOf(true) }
    var showLyricsBg    by remember { mutableStateOf(true) }
    var tabletLayout    by remember { mutableStateOf(false) }
    var cardStyle       by remember { mutableStateOf(0) }  // 0=rounded, 1=square
    var fontScale       by remember { mutableStateOf(1f) }

    val accentColors = listOf(
        Color(0xFF5C6BC0) to "Indigo",
        Color(0xFFE91E8C) to "Pink",
        Color(0xFF009688) to "Teal",
        Color(0xFF8E24AA) to "Purple",
        Color(0xFF0288D1) to "Blue",
        Color(0xFF2E7D32) to "Green"
    )

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Background),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item { TopBar(title = "Appearance", onBack = onBack) }

        item {
            SettingsSection("Theme") {
                Text(
                    "Dark Mode",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    fontWeight = FontWeight.Medium, color = TextPrimary, fontSize = 14.sp
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceVariant),
                ) {
                    listOf("System", "Light", "Dark").forEachIndexed { i, label ->
                        val selected = darkMode == i
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(4.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (selected) Purple500 else Color.Transparent)
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(label, color = if (selected) White else TextSecondary, fontSize = 13.sp,
                                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
                        }
                    }
                }
                // AMOLED black toggle (only meaningful in dark mode)
                if (darkMode == 2) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("AMOLED Black", color = TextPrimary, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                            Text("True black background saves battery on OLED screens", color = TextSecondary, fontSize = 12.sp)
                        }
                        Switch(
                            checked = amoledBlack,
                            onCheckedChange = { amoledBlack = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = White, checkedTrackColor = Purple500)
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))

                // Accent color picker
                Text(
                    "Accent Color",
                    modifier = Modifier.padding(horizontal = 16.dp),
                    fontWeight = FontWeight.Medium, color = TextPrimary, fontSize = 14.sp
                )
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    accentColors.forEachIndexed { i, (color, _) ->
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(color),
                            contentAlignment = Alignment.Center
                        ) {
                            if (accentColor == i) {
                                Icon(Icons.Default.Check, null, tint = White, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
            }
        }

        item {
            SettingsSection("Player") {
                ToggleSetting(Icons.Default.BlurOn, "Album Art Blur Background", "Blur album art in player", albumArtBlur) { albumArtBlur = it }
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                ToggleSetting(Icons.Default.TextFields, "Lyrics Background", "Show translucent lyrics background", showLyricsBg) { showLyricsBg = it }
            }
        }

        item {
            SettingsSection("Layout") {
                ToggleSetting(Icons.Default.TableChart, "Tablet Layout", "Two-column layout on large screens", tabletLayout) { tabletLayout = it }
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                Text(
                    "Card Style",
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    fontWeight = FontWeight.Medium, color = TextPrimary, fontSize = 14.sp
                )
                Row(modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Rounded", "Square").forEachIndexed { i, label ->
                        FilterChip(
                            selected = cardStyle == i,
                            onClick  = { cardStyle = i },
                            label    = { Text(label, fontSize = 13.sp) },
                            colors   = FilterChipDefaults.filterChipColors(selectedContainerColor = Purple500, selectedLabelColor = White)
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Font Size: ${(fontScale * 100).toInt()}%", fontSize = 14.sp, color = TextPrimary, fontWeight = FontWeight.Medium)
                    Slider(
                        value = fontScale, onValueChange = { fontScale = it },
                        valueRange = 0.8f..1.4f, steps = 5,
                        colors = SliderDefaults.colors(thumbColor = Purple500, activeTrackColor = Purple500)
                    )
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// PRIVACY SETTINGS SCREEN
// ─────────────────────────────────────────────────────────────────────────────
@Composable
fun PrivacySettingsScreen(onBack: () -> Unit) {
    var appLockEnabled   by remember { mutableStateOf(false) }
    var lockOnBackground by remember { mutableStateOf(false) }
    var lockDelayIndex   by remember { mutableStateOf(1) }  // 0=Immediately, 1=30s, 2=1min, 3=5min
    val lockDelayLabels  = listOf("Now", "30s", "1m", "5m")
    var analytics        by remember { mutableStateOf(true) }
    var crashReports     by remember { mutableStateOf(true) }
    var listenHistory    by remember { mutableStateOf(true) }
    var searchHistory    by remember { mutableStateOf(true) }
    var personalizeRec   by remember { mutableStateOf(true) }
    var shareWithFriends by remember { mutableStateOf(false) }
    var showClearConfirm by remember { mutableStateOf(false) }
    var historyCleared   by remember { mutableStateOf(false) }

    if (showClearConfirm) {
        AlertDialog(
            onDismissRequest = { showClearConfirm = false },
            title = { Text("Clear All History?") },
            text  = { Text("This will permanently delete your listening and search history. This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    historyCleared = true
                    showClearConfirm = false
                }) { Text("Clear", color = RedAccent) }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirm = false }) { Text("Cancel") }
            }
        )
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Background),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item { TopBar(title = "Privacy", onBack = onBack) }

        item {
            SettingsSection("Data Collection") {
                ToggleSetting(Icons.Default.Analytics,    "Usage Analytics",    "Help improve DarkWave with anonymous data", analytics)     { analytics = it }
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                ToggleSetting(Icons.Default.BugReport,    "Crash Reports",      "Automatically send crash reports",           crashReports)  { crashReports = it }
            }
        }

        item {
            SettingsSection("History") {
                ToggleSetting(Icons.Default.History,      "Listening History",  "Track what you listen to",      listenHistory)  { listenHistory = it }
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                ToggleSetting(Icons.Default.Search,       "Search History",     "Save your recent searches",     searchHistory)  { searchHistory = it }
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                ToggleSetting(Icons.Default.Recommend,    "Personalized Recs",  "Use history for recommendations", personalizeRec) { personalizeRec = it }
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                if (historyCleared) {
                    Text(
                        "✓ History cleared",
                        color = androidx.compose.ui.graphics.Color(0xFF43A047),
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        style = androidx.compose.material3.MaterialTheme.typography.bodySmall
                    )
                } else {
                    TextButton(
                        onClick = { showClearConfirm = true },
                        modifier = Modifier.padding(horizontal = 8.dp)
                    ) {
                        Icon(Icons.Default.DeleteSweep, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Clear All History", color = RedAccent)
                    }
                }
            }
        }

        item {
            SettingsSection("Social") {
                ToggleSetting(Icons.Default.People, "Share Activity", "Share what you're listening to", shareWithFriends) { shareWithFriends = it }
            }
        }

        item {
            SettingsSection("App Lock") {
                ToggleSetting(
                    Icons.Default.Fingerprint,
                    "Require Biometric on Launch",
                    "Lock DarkWave — authenticate to open",
                    appLockEnabled
                ) { appLockEnabled = it }
                if (appLockEnabled) {
                    Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                    ToggleSetting(
                        Icons.Default.LockClock,
                        "Lock after background",
                        "Re-authenticate when returning from background",
                        lockOnBackground
                    ) { lockOnBackground = it }
                    Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                    // Lock delay selector
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(Purple500.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Default.Timer, null, tint = Purple500, modifier = Modifier.size(20.dp)) }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Lock delay", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
                            Text(lockDelayLabels[lockDelayIndex], fontSize = 12.sp, color = TextSecondary)
                        }
                        Row {
                            lockDelayLabels.forEachIndexed { i, label ->
                                Surface(
                                    modifier = Modifier.padding(horizontal = 2.dp).clip(RoundedCornerShape(6.dp)),
                                    color = if (lockDelayIndex == i) Purple500 else SurfaceVariant
                                ) {
                                    TextButton(
                                        onClick = { lockDelayIndex = i },
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(label, color = if (lockDelayIndex == i) White else TextSecondary, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            SettingsSection("Data & Account") {
                ActionItem(Icons.Default.Download, "Export My Data",  "Download all your DarkWave data", BlueAccent) {}
                Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
                ActionItem(Icons.Default.PrivacyTip, "Privacy Policy", "Read our full privacy policy",   Purple500) {}
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Shared helper (already in SettingsSubScreens.kt — copied here for standalone)
// ─────────────────────────────────────────────────────────────────────────────
@Composable
private fun ActionItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    subtitle: String,
    color: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(color.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) { Icon(icon, null, tint = color, modifier = Modifier.size(20.dp)) }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = color)
            Text(subtitle, fontSize = 12.sp, color = TextSecondary)
        }
        Icon(Icons.Default.ChevronRight, null, tint = TextTertiary)
    }
}
