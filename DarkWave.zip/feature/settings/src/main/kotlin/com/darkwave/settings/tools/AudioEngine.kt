package com.darkwave.settings.tools

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import kotlin.math.*

// ─── AudioEngine: real AudioRecord-based pitch + FFT + BPM detection ─────────

object AudioEngine {

    private const val SAMPLE_RATE = 44100
    private const val BUFFER_SIZE_FACTOR = 4
    val bufferSize: Int = AudioRecord.getMinBufferSize(
        SAMPLE_RATE,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT
    ).let { if (it <= 0) 4096 else it * BUFFER_SIZE_FACTOR }

    // ── YIN pitch detection ───────────────────────────────────────────────
    // Reference: de Cheveigné & Kawahara (2002) "YIN, a fundamental frequency estimator"
    fun detectPitch(buffer: ShortArray, sampleRate: Int = SAMPLE_RATE): Float {
        val n = buffer.size
        val halfN = n / 2
        val threshold = 0.10f  // YIN threshold (lower = more sensitive)

        val d = FloatArray(halfN)

        // Step 1: Difference function
        for (tau in 1 until halfN) {
            for (j in 0 until halfN) {
                val delta = buffer[j].toFloat() - buffer[j + tau].toFloat()
                d[tau] += delta * delta
            }
        }

        // Step 2: Cumulative mean normalized difference
        val cmndf = FloatArray(halfN)
        cmndf[0] = 1f
        var runningSum = 0f
        for (tau in 1 until halfN) {
            runningSum += d[tau]
            cmndf[tau] = if (runningSum == 0f) 1f else d[tau] * tau / runningSum
        }

        // Step 3: Absolute threshold — find first dip below threshold
        var tau = 2
        while (tau < halfN - 1) {
            if (cmndf[tau] < threshold) {
                while (tau + 1 < halfN && cmndf[tau + 1] < cmndf[tau]) tau++
                break
            }
            tau++
        }

        if (tau == halfN - 1 || cmndf[tau] >= 0.5f) return 0f  // unvoiced / noise

        // Step 4: Parabolic interpolation for sub-sample accuracy
        val betterTau = if (tau in 1 until halfN - 1) {
            val s0 = cmndf[tau - 1]
            val s1 = cmndf[tau]
            val s2 = cmndf[tau + 1]
            tau + (s2 - s0) / (2f * (2f * s1 - s2 - s0))
        } else tau.toFloat()

        return sampleRate / betterTau
    }

    // ── FFT (Cooley-Tukey, radix-2, iterative) ───────────────────────────
    // Returns magnitudes for each frequency bin (length = n/2)
    fun fft(input: ShortArray): FloatArray {
        val n = nextPowerOf2(input.size)
        val re = FloatArray(n) { if (it < input.size) input[it].toFloat() else 0f }
        val im = FloatArray(n)

        // Apply Hanning window to reduce spectral leakage
        for (i in re.indices) {
            val w = 0.5f * (1f - cos(2 * PI.toFloat() * i / (n - 1)))
            re[i] *= w
        }

        // Bit-reversal permutation
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                var t = re[i]; re[i] = re[j]; re[j] = t
                t = im[i]; im[i] = im[j]; im[j] = t
            }
        }

        // FFT butterfly
        var len = 2
        while (len <= n) {
            val ang = -2.0 * PI / len
            val wRe = cos(ang).toFloat()
            val wIm = sin(ang).toFloat()
            var k = 0
            while (k < n) {
                var uRe = 1f; var uIm = 0f
                for (m in 0 until len / 2) {
                    val tRe = uRe * re[k + m + len/2] - uIm * im[k + m + len/2]
                    val tIm = uRe * im[k + m + len/2] + uIm * re[k + m + len/2]
                    re[k + m + len/2] = re[k + m] - tRe
                    im[k + m + len/2] = im[k + m] - tIm
                    re[k + m] += tRe
                    im[k + m] += tIm
                    val newRe = uRe * wRe - uIm * wIm
                    uIm = uRe * wIm + uIm * wRe
                    uRe = newRe
                }
                k += len
            }
            len = len shl 1
        }

        // Return magnitudes for positive frequencies only
        return FloatArray(n / 2) { i ->
            sqrt(re[i] * re[i] + im[i] * im[i]) / n
        }
    }

    // ── 10-band spectrum from FFT output ─────────────────────────────────
    // Returns normalized 0..1 values for 10 octave bands
    fun spectrumBands(magnitudes: FloatArray, sampleRate: Int = SAMPLE_RATE): FloatArray {
        val freqResolution = sampleRate.toFloat() / (magnitudes.size * 2)
        val bandEdges = floatArrayOf(20f, 60f, 120f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f, 22050f)
        val bands = FloatArray(10)
        var maxVal = 0f

        for (b in 0 until 10) {
            val startBin = (bandEdges[b] / freqResolution).toInt().coerceIn(0, magnitudes.size - 1)
            val endBin   = (bandEdges[b + 1] / freqResolution).toInt().coerceIn(0, magnitudes.size - 1)
            if (endBin > startBin) {
                bands[b] = magnitudes.slice(startBin..endBin).average().toFloat()
                if (bands[b] > maxVal) maxVal = bands[b]
            }
        }

        // Normalize
        if (maxVal > 0f) {
            for (i in bands.indices) bands[i] = (bands[i] / maxVal).coerceIn(0f, 1f)
        }
        return bands
    }

    // ── 32-band high-resolution spectrum ─────────────────────────────────
    fun spectrumBands32(magnitudes: FloatArray, sampleRate: Int = SAMPLE_RATE): FloatArray {
        val freqResolution = sampleRate.toFloat() / (magnitudes.size * 2)
        val bands = FloatArray(32)
        val nBins = magnitudes.size
        var maxVal = 0f

        for (b in 0 until 32) {
            // Logarithmic spacing: 20Hz to 22050Hz
            val fLow  = 20f * (22050f / 20f).pow(b.toFloat() / 32f)
            val fHigh = 20f * (22050f / 20f).pow((b + 1).toFloat() / 32f)
            val startBin = (fLow / freqResolution).toInt().coerceIn(0, nBins - 1)
            val endBin   = (fHigh / freqResolution).toInt().coerceIn(0, nBins - 1)
            bands[b] = if (endBin > startBin)
                magnitudes.slice(startBin..endBin).average().toFloat()
            else magnitudes.getOrElse(startBin) { 0f }
            if (bands[b] > maxVal) maxVal = bands[b]
        }

        if (maxVal > 0f) for (i in bands.indices) bands[i] = (bands[i] / maxVal).coerceIn(0f, 1f)
        return bands
    }

    // ── RMS level ─────────────────────────────────────────────────────────
    fun rms(buffer: ShortArray): Float {
        if (buffer.isEmpty()) return 0f
        val sum = buffer.sumOf { (it.toDouble() * it.toDouble()) }
        return sqrt(sum / buffer.size).toFloat() / Short.MAX_VALUE
    }

    // ── BPM onset detection (energy-based) ───────────────────────────────
    // Returns detected BPM or 0 if insufficient data
    class BpmDetector {
        private val energyHistory = ArrayDeque<Float>(43)  // ~1s at 22ms frames
        private val onsetTimes = ArrayDeque<Long>()
        private var lastOnsetEnergy = 0f

        fun feed(buffer: ShortArray, timestampMs: Long): Float {
            val energy = buffer.map { it.toFloat() * it }.average().toFloat()
            energyHistory.addLast(energy)
            if (energyHistory.size > 43) energyHistory.removeFirst()

            val avg = energyHistory.average().toFloat()
            val threshold = avg * 1.5f  // energy must be 50% above local average

            if (energy > threshold && energy > lastOnsetEnergy * 0.8f) {
                onsetTimes.addLast(timestampMs)
                lastOnsetEnergy = energy
                if (onsetTimes.size > 20) onsetTimes.removeFirst()
            }

            if (onsetTimes.size >= 4) {
                val intervals = onsetTimes.zipWithNext { a, b -> b - a }
                val filtered = intervals.filter { it in 300L..2000L }  // 30-200 BPM range
                if (filtered.size >= 3) {
                    val avgInterval = filtered.average()
                    return (60_000.0 / avgInterval).toFloat().coerceIn(40f, 220f)
                }
            }
            return 0f
        }

        fun reset() { energyHistory.clear(); onsetTimes.clear(); lastOnsetEnergy = 0f }
    }

    private fun nextPowerOf2(n: Int): Int {
        var p = 1
        while (p < n) p = p shl 1
        return p
    }
}

// ── Coroutine AudioRecord helper ─────────────────────────────────────────────
// Usage: collect { buffer -> process(buffer) }
suspend fun audioRecordFlow(
    sampleRate: Int = 44100,
    onBuffer: suspend (ShortArray, Long) -> Unit
) = withContext(Dispatchers.IO) {
    val minBuf = AudioRecord.getMinBufferSize(
        sampleRate,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT
    )
    val bufSize = maxOf(minBuf * 4, 4096)
    val recorder = AudioRecord(
        MediaRecorder.AudioSource.MIC,
        sampleRate,
        AudioFormat.CHANNEL_IN_MONO,
        AudioFormat.ENCODING_PCM_16BIT,
        bufSize
    )
    try {
        recorder.startRecording()
        val buffer = ShortArray(bufSize / 2)
        while (isActive) {
            val read = recorder.read(buffer, 0, buffer.size)
            if (read > 0) {
                onBuffer(buffer.copyOf(read), System.currentTimeMillis())
            }
        }
    } finally {
        recorder.stop()
        recorder.release()
    }
}
