package com.darkwave.settings.tools

import android.Manifest
import android.media.MediaRecorder
import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.components.TopBar
import com.darkwave.common.ui.theme.*
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberMultiplePermissionsState
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class Recording(
    val name: String,
    val path: String,
    val durationSec: Int,
    val fileSizeKb: Long,
    val date: String
)

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun RecorderScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val permissions = rememberMultiplePermissionsState(
        listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.WRITE_EXTERNAL_STORAGE)
    )

    var mediaRecorder: MediaRecorder? by remember { mutableStateOf(null) }
    var currentFilePath: String?       by remember { mutableStateOf(null) }
    var isRecording    by remember { mutableStateOf(false) }
    var isPaused       by remember { mutableStateOf(false) }
    var elapsedSeconds by remember { mutableStateOf(0) }
    var recorderMode   by remember { mutableStateOf(RecorderMode.AUDIO) }

    DisposableEffect(Unit) {
        onDispose {
            try { mediaRecorder?.apply { stop(); release() } } catch (_: Exception) {}
            mediaRecorder = null
        }
    }
    var recordings     by remember { mutableStateOf(listOf<Recording>()) }
    var amplitudes     by remember { mutableStateOf(List(40) { 0.1f }) }

    // Timer
    LaunchedEffect(isRecording, isPaused) {
        if (!isRecording || isPaused) return@LaunchedEffect
        while (isRecording && !isPaused) {
            delay(1000)
            elapsedSeconds++
        }
    }

    // Simulated amplitude for waveform
    LaunchedEffect(isRecording, isPaused) {
        if (!isRecording || isPaused) return@LaunchedEffect
        while (isRecording && !isPaused) {
            amplitudes = amplitudes.drop(1) + listOf((0.2f + Math.random().toFloat() * 0.8f))
            delay(80)
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        TopBar(title = "Recorder", onBack = onBack)

        // Mode toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(SurfaceVariant),
        ) {
            RecorderMode.entries.forEach { mode ->
                val selected = recorderMode == mode
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(4.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) Purple500 else Color.Transparent)
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (mode == RecorderMode.AUDIO) Icons.Default.Mic else Icons.Default.Videocam,
                            null,
                            tint = if (selected) White else TextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = mode.label,
                            color = if (selected) White else TextSecondary,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                            fontSize = 14.sp
                        )
                    }
                }
            }
        }

        if (!permissions.allPermissionsGranted) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                    Icon(Icons.Default.MicOff, null, tint = TextTertiary, modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(16.dp))
                    Text("Microphone permission required to record", color = TextSecondary, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = { permissions.launchMultiplePermissionRequest() },
                        colors = ButtonDefaults.buttonColors(containerColor = Purple500)
                    ) { Text("Grant Permissions") }
                }
            }
            return@Column
        }

        // Waveform display
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(120.dp)
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(SurfaceLight),
            contentAlignment = Alignment.Center
        ) {
            if (isRecording && !isPaused) {
                Row(
                    modifier = Modifier.fillMaxSize().padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    amplitudes.forEach { amp ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(amp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(
                                    if (amp > 0.7f) RedAccent
                                    else if (amp > 0.4f) OrangeAccent
                                    else Purple400
                                )
                        )
                    }
                }
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.Mic, null, tint = TextTertiary, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.height(8.dp))
                    Text(
                        if (isPaused) "Paused" else "Press record to start",
                        color = TextTertiary, fontSize = 14.sp
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))

        // Timer
        Text(
            text = formatTime(elapsedSeconds),
            modifier = Modifier.fillMaxWidth(),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            fontSize = 48.sp,
            fontWeight = FontWeight.Thin,
            color = if (isRecording && !isPaused) RedAccent else TextPrimary,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
        )

        Spacer(Modifier.height(32.dp))

        // Controls
        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 48.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Pause/Resume
            AnimatedVisibility(visible = isRecording) {
                IconButton(
                    onClick = {
                        if (isPaused) {
                            try { mediaRecorder?.resume() } catch (_: Exception) {}
                            isPaused = false
                        } else {
                            try { mediaRecorder?.pause() } catch (_: Exception) {}
                            isPaused = true
                        }
                    },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(SurfaceVariant)
                ) {
                    Icon(
                        if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                        null, tint = TextPrimary, modifier = Modifier.size(28.dp)
                    )
                }
            }

            // Record button
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(if (isRecording) RedAccent else Purple500),
                contentAlignment = Alignment.Center
            ) {
                IconButton(onClick = {
                    if (isRecording) {
                        // ── Stop real recording ──────────────────────────
                        try {
                            mediaRecorder?.apply { stop(); release() }
                        } catch (_: Exception) {}
                        mediaRecorder = null
                        isRecording = false
                        isPaused = false
                        val finalPath = currentFilePath
                        if (finalPath != null) {
                            val file = java.io.File(finalPath)
                            if (file.exists()) {
                                val rec = Recording(
                                    name = file.nameWithoutExtension,
                                    path = finalPath,
                                    durationSec = elapsedSeconds,
                                    fileSizeKb = file.length() / 1024,
                                    date = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date())
                                )
                                recordings = listOf(rec) + recordings
                            }
                        }
                        elapsedSeconds = 0
                        amplitudes = List(40) { 0.1f }
                        currentFilePath = null
                    } else {
                        // ── Start real recording ─────────────────────────
                        val dir = context.getExternalFilesDir(android.os.Environment.DIRECTORY_MUSIC)
                            ?: context.filesDir
                        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
                        val outFile = java.io.File(dir, "Recording_${ts}.m4a")
                        currentFilePath = outFile.absolutePath
                        mediaRecorder = (if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S)
                            MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder()).apply {
                            setAudioSource(MediaRecorder.AudioSource.MIC)
                            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                            setAudioEncodingBitRate(128_000)
                            setAudioSamplingRate(44_100)
                            setOutputFile(outFile.absolutePath)
                            prepare()
                            start()
                        }
                        isRecording = true
                        isPaused = false
                    }
                }) {
                    Icon(
                        if (isRecording) Icons.Default.Stop else Icons.Default.FiberManualRecord,
                        null, tint = White, modifier = Modifier.size(32.dp)
                    )
                }
            }

            // Delete/Clear (only when recording)
            AnimatedVisibility(visible = isRecording) {
                IconButton(
                    onClick = {
                        isRecording = false
                        isPaused = false
                        elapsedSeconds = 0
                        amplitudes = List(40) { 0.1f }
                    },
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(SurfaceVariant)
                ) {
                    Icon(Icons.Default.Delete, null, tint = RedAccent, modifier = Modifier.size(24.dp))
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        Divider(color = DividerColor, modifier = Modifier.padding(horizontal = 16.dp))
        Spacer(Modifier.height(8.dp))

        // Recordings list
        if (recordings.isEmpty()) {
            Box(
                Modifier.fillMaxWidth().padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("No recordings yet", color = TextTertiary, fontSize = 14.sp)
            }
        } else {
            Text(
                "Recordings",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                fontWeight = FontWeight.SemiBold,
                color = TextPrimary,
                fontSize = 15.sp
            )
            LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp)) {
                items(recordings) { rec ->
                    RecordingItem(rec)
                }
            }
        }
    }
}

@Composable
private fun RecordingItem(rec: Recording) {
    val context = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceLight),
        elevation = CardDefaults.cardElevation(1.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Purple100),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.AudioFile, null, tint = Purple500)
            }
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(rec.name, fontWeight = FontWeight.Medium, fontSize = 14.sp, color = TextPrimary)
                Text(
                    "${formatTime(rec.durationSec)} • ${rec.fileSizeKb}KB • ${rec.date}",
                    fontSize = 12.sp, color = TextSecondary
                )
            }
            // Play button — opens with system audio player
            IconButton(onClick = {
                try {
                    val file = File(rec.path)
                    val uri = androidx.core.content.FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        file
                    )
                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, "audio/*")
                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(intent)
                } catch (e: Exception) {
                    android.widget.Toast.makeText(context, "Cannot play file", android.widget.Toast.LENGTH_SHORT).show()
                }
            }) {
                Icon(Icons.Default.PlayCircleOutline, null, tint = Purple500)
            }
            // Share button
            IconButton(onClick = {
                try {
                    val file = File(rec.path)
                    val uri = androidx.core.content.FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        file
                    )
                    val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                        type = "audio/*"
                        putExtra(android.content.Intent.EXTRA_STREAM, uri)
                        addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(android.content.Intent.createChooser(intent, "Share Recording"))
                } catch (e: Exception) {
                    android.widget.Toast.makeText(context, "Cannot share file", android.widget.Toast.LENGTH_SHORT).show()
                }
            }) {
                Icon(Icons.Default.Share, null, tint = TextTertiary)
            }
        }
    }
}

private fun formatTime(seconds: Int): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s)
    else "%02d:%02d".format(m, s)
}

private enum class RecorderMode(val label: String) {
    AUDIO("Audio"),
    SCREEN("Screen")
}
