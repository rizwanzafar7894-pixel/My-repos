package com.darkwave.settings.tools

import android.Manifest
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.components.TopBar
import com.darkwave.common.ui.theme.*
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.*

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun BpmDetectorScreen(onBack: () -> Unit) {
    val micPermission = rememberPermissionState(Manifest.permission.RECORD_AUDIO)

    var tapTimes       by remember { mutableStateOf(listOf<Long>()) }
    var bpm            by remember { mutableStateOf(0f) }
    var isListening    by remember { mutableStateOf(false) }
    var pulseAnim      by remember { mutableStateOf(false) }
    var mode           by remember { mutableStateOf(BpmMode.TAP) }

    // Real mic BPM detection via AudioRecord + onset detection
    val bpmDetector = remember { AudioEngine.BpmDetector() }
    LaunchedEffect(isListening, mode) {
        if (!isListening || mode != BpmMode.MIC) {
            bpmDetector.reset()
            return@LaunchedEffect
        }
        audioRecordFlow { buffer, timestamp ->
            val detected = bpmDetector.feed(buffer, timestamp)
            if (detected > 0f) {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    bpm = detected
                }
            }
        }
    }

    // Pulse animation on tap
    val scale by animateFloatAsState(
        targetValue   = if (pulseAnim) 0.92f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label         = "pulse"
    )

    // Reset if idle >3s
    LaunchedEffect(tapTimes) {
        if (tapTimes.isNotEmpty()) {
            delay(3000)
            tapTimes = listOf()
            bpm = 0f
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
    ) {
        TopBar(title = "BPM Detector", onBack = onBack)

        // Mode toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(SurfaceVariant),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            BpmMode.entries.forEach { m ->
                val selected = mode == m
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(4.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) Purple500 else Color.Transparent)
                        .pointerInput(m) { detectTapGestures { mode = m } }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = m.label,
                        color = if (selected) White else TextSecondary,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                        fontSize = 14.sp
                    )
                }
            }
        }

        Spacer(Modifier.weight(1f))

        // BPM Display
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = if (bpm > 0) "%.0f".format(bpm) else "---",
                fontSize = 96.sp,
                fontWeight = FontWeight.ExtraBold,
                color = if (bpm > 0) Purple500 else TextTertiary
            )
            Text("BPM", fontSize = 20.sp, color = TextSecondary, fontWeight = FontWeight.Medium)

            if (bpm > 0) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = bpmLabel(bpm),
                    fontSize = 14.sp,
                    color = Purple400,
                    fontWeight = FontWeight.Medium
                )
            }
        }

        Spacer(Modifier.weight(1f))

        // TAP button
        if (mode == BpmMode.TAP) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 48.dp, vertical = 32.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(200.dp)
                        .scale(scale)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(listOf(Purple400, Purple600))
                        )
                        .pointerInput(Unit) {
                            detectTapGestures {
                                pulseAnim = !pulseAnim
                                val now = System.currentTimeMillis()
                                val newTimes = (tapTimes + now).takeLast(8)
                                tapTimes = newTimes
                                if (newTimes.size >= 2) {
                                    val intervals = newTimes.zipWithNext { a, b -> b - a }
                                    val avg = intervals.average()
                                    bpm = (60_000.0 / avg).toFloat()
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.TouchApp, null, tint = White, modifier = Modifier.size(40.dp))
                        Spacer(Modifier.height(8.dp))
                        Text("TAP", color = White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                }
            }

            Text(
                text = if (tapTimes.size < 2) "Tap to the beat" else "${tapTimes.size} taps",
                modifier = Modifier.fillMaxWidth().padding(bottom = 16.dp),
                color = TextTertiary,
                fontSize = 14.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }

        // MIC mode
        if (mode == BpmMode.MIC) {
            Box(
                modifier = Modifier.fillMaxWidth().padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                if (!micPermission.status.isGranted) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.MicOff, null, tint = TextTertiary, modifier = Modifier.size(48.dp))
                        Spacer(Modifier.height(12.dp))
                        Text("Microphone permission needed", color = TextSecondary, fontSize = 14.sp)
                        Spacer(Modifier.height(12.dp))
                        Button(
                            onClick = { micPermission.launchPermissionRequest() },
                            colors = ButtonDefaults.buttonColors(containerColor = Purple500)
                        ) { Text("Grant Permission") }
                    }
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(120.dp)
                                .clip(CircleShape)
                                .background(if (isListening) RedAccent else Purple500)
                                .pointerInput(Unit) {
                                    detectTapGestures { isListening = !isListening }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                                null, tint = White, modifier = Modifier.size(40.dp)
                            )
                        }
                        Spacer(Modifier.height(16.dp))
                        Text(
                            if (isListening) "Listening… tap to stop" else "Tap mic to start",
                            color = TextSecondary, fontSize = 14.sp
                        )
                        if (isListening) {
                            Spacer(Modifier.height(16.dp))
                            Text(
                                if (bpm > 0) "%.0f BPM detected".format(bpm) else "Listening for beat…",
                                color = if (bpm > 0) Purple500 else TextTertiary,
                                fontSize = if (bpm > 0) 22.sp else 14.sp,
                                fontWeight = if (bpm > 0) FontWeight.Bold else FontWeight.Normal
                            )
                            if (bpm > 0) {
                                Spacer(Modifier.height(4.dp))
                                Text(bpmLabel(bpm), color = TextSecondary, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }

        // Reset button
        if (bpm > 0) {
            TextButton(
                onClick = { tapTimes = listOf(); bpm = 0f },
                modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 24.dp)
            ) {
                Text("Reset", color = TextTertiary)
            }
        } else {
            Spacer(Modifier.height(56.dp))
        }
    }
}

private enum class BpmMode(val label: String) { TAP("Tap"), MIC("Microphone") }

private fun bpmLabel(bpm: Float) = when {
    bpm < 60  -> "Larghissimo"
    bpm < 66  -> "Grave"
    bpm < 76  -> "Largo"
    bpm < 108 -> "Andante"
    bpm < 120 -> "Moderato"
    bpm < 156 -> "Allegro"
    bpm < 176 -> "Vivace"
    bpm < 200 -> "Presto"
    else      -> "Prestissimo"
}
