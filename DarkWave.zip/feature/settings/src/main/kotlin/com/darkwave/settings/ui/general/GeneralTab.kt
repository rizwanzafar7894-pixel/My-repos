package com.darkwave.settings.ui.general

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.theme.*
import com.darkwave.settings.viewmodel.SettingsUiState

@Composable
fun GeneralTab(
    state: SettingsUiState,
    onProfileClick: () -> Unit,
    onPlaybackClick: () -> Unit,
    onAppearanceClick: () -> Unit,
    onAccessibility: () -> Unit,
    onPrivacy: () -> Unit,
    onAnalytics: () -> Unit,
    onDarkModeToggle: (Boolean) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Profile card
        item {
            Card(
                modifier  = Modifier.fillMaxWidth().clickable(onClick = onProfileClick),
                shape     = RoundedCornerShape(16.dp),
                colors    = CardDefaults.cardColors(containerColor = White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier.size(52.dp).clip(CircleShape).background(Purple500),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            state.userName.firstOrNull()?.uppercase() ?: "D",
                            fontSize = 22.sp, fontWeight = FontWeight.Bold, color = White
                        )
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(state.userName, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text(state.userEmail, fontSize = 13.sp, color = TextSecondary)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = TextSecondary, modifier = Modifier.size(20.dp))
                }
            }
        }

        // Settings cards
        item {
            SettingsCard(
                title    = "Playback",
                subtitle = "Speed, quality, auto-play, PiP",
                icon     = Icons.Default.PlayCircle,
                iconBg   = Color(0xFFE8F5E9),
                iconTint = Color(0xFF4CAF50),
                onClick  = onPlaybackClick
            )
        }
        item {
            SettingsCard(
                title    = "Appearance",
                subtitle = "Theme, font size, thumbnails",
                icon     = Icons.Default.Palette,
                iconBg   = Purple100,
                iconTint = Purple500,
                trailing = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Night Mode", fontSize = 12.sp, color = TextSecondary)
                        Spacer(Modifier.width(8.dp))
                        Switch(
                            checked         = state.isDarkMode,
                            onCheckedChange = onDarkModeToggle,
                            colors          = SwitchDefaults.colors(checkedThumbColor = White, checkedTrackColor = Purple500)
                        )
                    }
                },
                onClick  = onAppearanceClick
            )
        }
        item {
            SettingsCard(
                title    = "Accessibility",
                subtitle = "Gestures, captions, font scale",
                icon     = Icons.Default.Accessibility,
                iconBg   = Color(0xFFFFF3E0),
                iconTint = Color(0xFFFF9800),
                onClick  = onAccessibility
            )
        }
        item {
            SettingsCard(
                title    = "Privacy & Security",
                subtitle = "History, permissions, biometric",
                icon     = Icons.Default.Security,
                iconBg   = Color(0xFFFCE4EC),
                iconTint = Color(0xFFE91E63),
                onClick  = onPrivacy
            )
        }
        item {
            SettingsCard(
                title    = "Analytics",
                subtitle = "Watch time, play stats, reports",
                icon     = Icons.Default.BarChart,
                iconBg   = Color(0xFFE3F2FD),
                iconTint = Color(0xFF2196F3),
                onClick  = onAnalytics
            )
        }
        item {
            Spacer(Modifier.height(4.dp))
            Text(
                "DarkWave Complete Edition v1.0.0",
                fontSize = 12.sp, color = TextTertiary,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp)
            )
        }
    }
}

@Composable
fun SettingsCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconBg: Color,
    iconTint: Color,
    onClick: () -> Unit,
    trailing: @Composable (() -> Unit)? = null
) {
    Card(
        modifier  = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape     = RoundedCornerShape(16.dp),
        colors    = CardDefaults.cardColors(containerColor = White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(iconBg),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = iconTint, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                Text(subtitle, fontSize = 12.sp, color = TextSecondary)
            }
            trailing?.invoke() ?: Icon(Icons.Default.ChevronRight, null, tint = TextSecondary, modifier = Modifier.size(20.dp))
        }
    }
}

// Additional simple tab composables for non-main tabs

@Composable
fun DownloadsTab(
    wifiOnly: Boolean,
    onWifiOnly: (Boolean) -> Unit,
    onDownloadsClick: () -> Unit
) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            SettingsCard("Download Settings", "Path, limits, quality", Icons.Default.FileDownload, Color(0xFFE3F2FD), Color(0xFF2196F3), onDownloadsClick)
        }
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFFE8F5E9)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Wifi, null, tint = Color(0xFF4CAF50), modifier = Modifier.size(22.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Wi-Fi Only", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                        Text("Download only on Wi-Fi", fontSize = 12.sp, color = TextSecondary)
                    }
                    Switch(checked = wifiOnly, onCheckedChange = onWifiOnly, colors = SwitchDefaults.colors(checkedTrackColor = Purple500))
                }
            }
        }
    }
}

@Composable
fun NetworkTab(onNetworkClick: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SettingsCard("Network Settings", "Proxy, streaming quality, DNS", Icons.Default.NetworkWifi, Color(0xFFE3F2FD), Color(0xFF2196F3), onNetworkClick) }
        item { SettingsCard("Streaming Quality", "Auto · 1080p · 720p · 480p", Icons.Default.HighQuality, Color(0xFFE8EAF6), Purple500, {}) }
        item { SettingsCard("Proxy Settings", "Disabled", Icons.Default.VpnKey, Color(0xFFFCE4EC), Color(0xFFE91E63), {}) }
    }
}

@Composable
fun AccessibilitySettingsTab(onAccessibilityClick: () -> Unit) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { SettingsCard("Accessibility", "Gestures, font size, captions", Icons.Default.Accessibility, Color(0xFFFFF3E0), Color(0xFFFF9800), onAccessibilityClick) }
        item { SettingsCard("Gesture Controls", "Swipe brightness, volume", Icons.Default.TouchApp, Color(0xFFE8EAF6), Purple500, {}) }
        item { SettingsCard("Captions & Subtitles", "Font, size, background", Icons.Default.Subtitles, Color(0xFFE8F5E9), Color(0xFF4CAF50), {}) }
    }
}
