package com.darkwave.settings.tools

import android.Manifest
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.components.TopBar
import com.darkwave.common.ui.theme.*
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.delay
import kotlin.math.*

private val FREQ_BANDS = listOf(
    "31", "63", "125", "250", "500",
    "1K", "2K", "4K", "8K", "16K"
)

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun AnalyzerScreen(onBack: () -> Unit) {
    val micPermission = rememberPermissionState(Manifest.permission.RECORD_AUDIO)

    var isAnalyzing by remember { mutableStateOf(false) }
    var bands       by remember { mutableStateOf(List(32) { 0f }) }
    var peak        by remember { mutableStateOf(0f) }
    var rms         by remember { mutableStateOf(0f) }
    var displayMode by remember { mutableStateOf(AnalyzerMode.BARS) }

    // Real FFT spectrum analysis via AudioRecord
    LaunchedEffect(isAnalyzing) {
        if (!isAnalyzing) {
            bands = List(32) { 0f }
            peak = 0f
            rms = 0f
            return@LaunchedEffect
        }
        audioRecordFlow { buffer, _ ->
            val magnitudes = AudioEngine.fft(buffer)
            val newBands = AudioEngine.spectrumBands32(magnitudes).toList()
            val newRms = AudioEngine.rms(buffer)
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                bands = newBands
                peak = newBands.maxOrNull() ?: 0f
                rms = newRms
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        TopBar(title = "Spectrum Analyzer", onBack = onBack)

        // Mode tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(SurfaceVariant),
        ) {
            AnalyzerMode.entries.forEach { mode ->
                val selected = displayMode == mode
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(4.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (selected) Purple500 else Color.Transparent)
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        mode.label,
                        color = if (selected) White else TextSecondary,
                        fontSize = 13.sp,
                        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }

        if (!micPermission.status.isGranted) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                    Icon(Icons.Default.GraphicEq, null, tint = TextTertiary, modifier = Modifier.size(64.dp))
                    Spacer(Modifier.height(16.dp))
                    Text("Microphone permission needed", color = TextSecondary, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(16.dp))
                    Button(
                        onClick = { micPermission.launchPermissionRequest() },
                        colors = ButtonDefaults.buttonColors(containerColor = Purple500)
                    ) { Text("Grant Permission") }
                }
            }
            return@Column
        }

        // Stats row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(SurfaceLight)
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            StatItem("Peak", "%.1f dB".format(-20 * log10(if (peak > 0) peak else 0.001f)), Purple500)
            StatItem("RMS",  "%.1f dB".format(-20 * log10(if (rms > 0) rms else 0.001f)),   BlueAccent)
            StatItem("Status", if (isAnalyzing) "Live" else "Stopped", if (isAnalyzing) GreenAccent else TextTertiary)
        }

        Spacer(Modifier.height(16.dp))

        // Spectrum display
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(horizontal = 16.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFF0D0D1A)),
            contentAlignment = Alignment.BottomCenter
        ) {
            // Grid lines
            Column(modifier = Modifier.fillMaxSize()) {
                repeat(4) {
                    Spacer(Modifier.weight(1f))
                    Divider(color = Color(0x22FFFFFF))
                }
            }

            // Bars
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.Bottom
            ) {
                val animatedBands = bands.map { band ->
                    val anim = animateFloatAsState(
                        targetValue = band,
                        animationSpec = tween(55),
                        label = "band"
                    )
                    anim.value
                }

                animatedBands.forEachIndexed { i, level ->
                    val barColor = when {
                        level > 0.85f -> RedAccent
                        level > 0.6f  -> OrangeAccent
                        level > 0.35f -> GreenAccent
                        else          -> BlueAccent
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight(level.coerceAtLeast(0.01f))
                            .clip(RoundedCornerShape(topStart = 3.dp, topEnd = 3.dp))
                            .background(
                                Brush.verticalGradient(
                                    listOf(barColor, barColor.copy(alpha = 0.4f))
                                )
                            )
                    )
                }
            }
        }

        // Frequency labels
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            FREQ_BANDS.forEach { freq ->
                Text(freq, fontSize = 9.sp, color = TextTertiary, textAlign = TextAlign.Center)
            }
        }

        Spacer(Modifier.height(16.dp))

        // Start/Stop
        Button(
            onClick = {
                if (micPermission.status.isGranted) {
                    isAnalyzing = !isAnalyzing
                } else {
                    micPermission.launchPermissionRequest()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 48.dp)
                .height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isAnalyzing) RedAccent else Purple500
            )
        ) {
            Icon(
                if (isAnalyzing) Icons.Default.Stop else Icons.Default.GraphicEq,
                null
            )
            Spacer(Modifier.width(8.dp))
            Text(
                if (isAnalyzing) "Stop Analysis" else "Start Analysis",
                fontWeight = FontWeight.SemiBold, fontSize = 16.sp
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun StatItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, fontSize = 11.sp, color = TextTertiary)
        Text(value, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

private enum class AnalyzerMode(val label: String) {
    BARS("Bars"), LINE("Line"), WATERFALL("Waterfall")
}
