package com.darkwave.accessibility.viewmodel

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AccessibilityUiState(
    val swipeBrightness: Boolean = true,
    val swipeVolume: Boolean = true,
    val doubleTapSeek: Boolean = true,
    val pinchZoom: Boolean = true,
    val showSubtitles: Boolean = false,
    val subtitleFontScale: Float = 1f,
    val subtitleBackground: String = "Semi-transparent",
    val appFontScale: Float = 1f,
    val highContrast: Boolean = false,
    val reduceMotion: Boolean = false,
    val monoAudio: Boolean = false,
    val audioBoost: Float = 1f
)

@HiltViewModel
class AccessibilityViewModel @Inject constructor(
    private val dataStore: DataStore<androidx.datastore.preferences.core.Preferences>
) : ViewModel() {

    private val _uiState = MutableStateFlow(AccessibilityUiState())
    val uiState: StateFlow<AccessibilityUiState> = _uiState.asStateFlow()

    private val keys = object {
        val swipeBrightness     = booleanPreferencesKey("a11y_swipe_brightness")
        val swipeVolume         = booleanPreferencesKey("a11y_swipe_volume")
        val doubleTapSeek       = booleanPreferencesKey("a11y_double_tap_seek")
        val pinchZoom           = booleanPreferencesKey("a11y_pinch_zoom")
        val showSubtitles       = booleanPreferencesKey("a11y_show_subtitles")
        val subtitleFontScale   = floatPreferencesKey("a11y_subtitle_font_scale")
        val subtitleBackground  = stringPreferencesKey("a11y_subtitle_bg")
        val appFontScale        = floatPreferencesKey("a11y_app_font_scale")
        val highContrast        = booleanPreferencesKey("a11y_high_contrast")
        val reduceMotion        = booleanPreferencesKey("a11y_reduce_motion")
        val monoAudio           = booleanPreferencesKey("a11y_mono_audio")
        val audioBoost          = floatPreferencesKey("a11y_audio_boost")
    }

    init {
        viewModelScope.launch {
            dataStore.data.collect { p ->
                _uiState.update {
                    it.copy(
                        swipeBrightness    = p[keys.swipeBrightness]    ?: true,
                        swipeVolume        = p[keys.swipeVolume]        ?: true,
                        doubleTapSeek      = p[keys.doubleTapSeek]      ?: true,
                        pinchZoom          = p[keys.pinchZoom]          ?: true,
                        showSubtitles      = p[keys.showSubtitles]      ?: false,
                        subtitleFontScale  = p[keys.subtitleFontScale]  ?: 1f,
                        subtitleBackground = p[keys.subtitleBackground] ?: "Semi-transparent",
                        appFontScale       = p[keys.appFontScale]       ?: 1f,
                        highContrast       = p[keys.highContrast]       ?: false,
                        reduceMotion       = p[keys.reduceMotion]       ?: false,
                        monoAudio          = p[keys.monoAudio]          ?: false,
                        audioBoost         = p[keys.audioBoost]         ?: 1f
                    )
                }
            }
        }
    }

    fun setSwipeBrightness(v: Boolean)    { update(v); viewModelScope.launch { dataStore.edit { it[keys.swipeBrightness] = v } } }
    fun setSwipeVolume(v: Boolean)        { update(v); viewModelScope.launch { dataStore.edit { it[keys.swipeVolume] = v } } }
    fun setDoubleTapSeek(v: Boolean)      { update(v); viewModelScope.launch { dataStore.edit { it[keys.doubleTapSeek] = v } } }
    fun setPinchZoom(v: Boolean)          { update(v); viewModelScope.launch { dataStore.edit { it[keys.pinchZoom] = v } } }
    fun setShowSubtitles(v: Boolean)      { _uiState.update { it.copy(showSubtitles = v) }; viewModelScope.launch { dataStore.edit { it[keys.showSubtitles] = v } } }
    fun setSubtitleFontScale(v: Float)    { _uiState.update { it.copy(subtitleFontScale = v) }; viewModelScope.launch { dataStore.edit { it[keys.subtitleFontScale] = v } } }
    fun setSubtitleBackground(v: String)  { _uiState.update { it.copy(subtitleBackground = v) }; viewModelScope.launch { dataStore.edit { it[keys.subtitleBackground] = v } } }
    fun setAppFontScale(v: Float)         { _uiState.update { it.copy(appFontScale = v) }; viewModelScope.launch { dataStore.edit { it[keys.appFontScale] = v } } }
    fun setHighContrast(v: Boolean)       { _uiState.update { it.copy(highContrast = v) }; viewModelScope.launch { dataStore.edit { it[keys.highContrast] = v } } }
    fun setReduceMotion(v: Boolean)       { _uiState.update { it.copy(reduceMotion = v) }; viewModelScope.launch { dataStore.edit { it[keys.reduceMotion] = v } } }
    fun setMonoAudio(v: Boolean)          { _uiState.update { it.copy(monoAudio = v) }; viewModelScope.launch { dataStore.edit { it[keys.monoAudio] = v } } }
    fun setAudioBoost(v: Float)           { _uiState.update { it.copy(audioBoost = v) }; viewModelScope.launch { dataStore.edit { it[keys.audioBoost] = v } } }

    private fun update(v: Boolean) {} // no-op placeholder; each setter handles its own update
}
