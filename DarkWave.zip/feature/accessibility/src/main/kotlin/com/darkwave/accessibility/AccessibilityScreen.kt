package com.darkwave.accessibility

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darkwave.accessibility.viewmodel.AccessibilityViewModel
import com.darkwave.common.ui.theme.*

@Composable
fun AccessibilityScreen(
    onBack: () -> Unit,
    viewModel: AccessibilityViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        Row(
            modifier          = Modifier.fillMaxWidth().background(White).padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = TextPrimary) }
            Text("Accessibility", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
        }

        LazyColumn(
            contentPadding      = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier            = Modifier.fillMaxSize()
        ) {
            // ── Gestures ──────────────────────────────────────────────
            item {
                SectionHeader("Gesture Controls")
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = White), elevation = CardDefaults.cardElevation(2.dp)) {
                    Column {
                        ToggleRow(Icons.Default.SwipeVertical, Color(0xFF5C6BC0), "Swipe Brightness",   "Swipe left side to control brightness", state.swipeBrightness, viewModel::setSwipeBrightness)
                        Divider(color = DividerColor)
                        ToggleRow(Icons.Default.SwipeRight,    Color(0xFF43A047), "Swipe Volume",        "Swipe right side to control volume",    state.swipeVolume,     viewModel::setSwipeVolume)
                        Divider(color = DividerColor)
                        ToggleRow(Icons.Default.DoubleTap,     Color(0xFF0288D1), "Double Tap Seek",     "Double tap to seek 10 seconds",          state.doubleTapSeek,   viewModel::setDoubleTapSeek)
                        Divider(color = DividerColor)
                        ToggleRow(Icons.Default.PinchZoom,     Color(0xFFFF9800), "Pinch to Zoom",       "Pinch to zoom video",                   state.pinchZoom,       viewModel::setPinchZoom)
                    }
                }
            }

            // ── Subtitles ─────────────────────────────────────────────
            item {
                SectionHeader("Subtitles & Captions")
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = White), elevation = CardDefaults.cardElevation(2.dp)) {
                    Column {
                        ToggleRow(Icons.Default.Subtitles, Color(0xFF8E24AA), "Show Subtitles",    "Display subtitle track when available", state.showSubtitles,   viewModel::setShowSubtitles)
                        Divider(color = DividerColor)
                        SliderRow("Font Size",  state.subtitleFontScale, 0.5f, 2f, "%.1fx".format(state.subtitleFontScale), viewModel::setSubtitleFontScale)
                        Divider(color = DividerColor)
                        DropdownRow("Background", state.subtitleBackground, listOf("None", "Semi-transparent", "Solid"), viewModel::setSubtitleBackground)
                    }
                }
            }

            // ── Display ───────────────────────────────────────────────
            item {
                SectionHeader("Display")
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = White), elevation = CardDefaults.cardElevation(2.dp)) {
                    Column {
                        SliderRow("App Font Scale", state.appFontScale, 0.8f, 1.4f, "%.1fx".format(state.appFontScale), viewModel::setAppFontScale)
                        Divider(color = DividerColor)
                        ToggleRow(Icons.Default.HighContrast,    Color(0xFF212121), "High Contrast",      "Increase UI contrast",     state.highContrast,    viewModel::setHighContrast)
                        Divider(color = DividerColor)
                        ToggleRow(Icons.Default.Animation,       Color(0xFF2196F3), "Reduce Motion",      "Disable animations",       state.reduceMotion,    viewModel::setReduceMotion)
                    }
                }
            }

            // ── Audio ─────────────────────────────────────────────────
            item {
                SectionHeader("Audio")
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = White), elevation = CardDefaults.cardElevation(2.dp)) {
                    Column {
                        ToggleRow(Icons.Default.HearingDisabled, Color(0xFFE91E63), "Mono Audio",         "Merge channels to mono",   state.monoAudio,       viewModel::setMonoAudio)
                        Divider(color = DividerColor)
                        SliderRow("Audio Boost",  state.audioBoost, 0f, 3f, "%.1fx".format(state.audioBoost), viewModel::setAudioBoost)
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary, modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))
}

@Composable
private fun ToggleRow(icon: ImageVector, iconColor: Color, title: String, subtitle: String, checked: Boolean, onToggle: (Boolean) -> Unit) {
    Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(iconColor.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = iconColor, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
            Text(subtitle, fontSize = 11.sp, color = TextSecondary)
        }
        Switch(checked = checked, onCheckedChange = onToggle, colors = SwitchDefaults.colors(checkedTrackColor = Purple500))
    }
}

@Composable
private fun SliderRow(label: String, value: Float, min: Float, max: Float, valueLabel: String, onChange: (Float) -> Unit) {
    Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
        Row { Text(label, fontSize = 13.sp, color = TextPrimary, modifier = Modifier.weight(1f)); Text(valueLabel, fontSize = 13.sp, color = Purple500, fontWeight = FontWeight.Medium) }
        Slider(value = value, onValueChange = onChange, valueRange = min..max, colors = SliderDefaults.colors(thumbColor = Purple500, activeTrackColor = Purple500), modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun DropdownRow(label: String, current: String, options: List<String>, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Row(modifier = Modifier.fillMaxWidth().clickable { expanded = true }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 13.sp, color = TextPrimary, modifier = Modifier.weight(1f))
        Text(current, fontSize = 13.sp, color = Purple500, fontWeight = FontWeight.Medium)
        Icon(Icons.Default.ArrowDropDown, null, tint = TextSecondary, modifier = Modifier.size(20.dp))
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { opt ->
                DropdownMenuItem(text = { Text(opt) }, onClick = { onSelect(opt); expanded = false },
                    trailingIcon = { if (opt == current) Icon(Icons.Default.Check, null, tint = Purple500, modifier = Modifier.size(16.dp)) })
            }
        }
    }
}
