package com.darkwave.analytics.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darkwave.domain.model.WatchStats
import com.darkwave.domain.repository.AnalyticsRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

data class AnalyticsUiState(val stats: WatchStats = WatchStats(), val isLoading: Boolean = true)

@HiltViewModel
class AnalyticsViewModel @Inject constructor(
    private val repo: AnalyticsRepository
) : ViewModel() {
    private val _uiState = MutableStateFlow(AnalyticsUiState())
    val uiState: StateFlow<AnalyticsUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            repo.getWatchStats().collect { stats ->
                _uiState.update { it.copy(stats = stats, isLoading = false) }
            }
        }
    }

    fun clearStats() { viewModelScope.launch { repo.clearAllStats() } }
}
