package com.darkwave.analytics

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darkwave.analytics.viewmodel.AnalyticsViewModel
import com.darkwave.common.ui.theme.*
import com.darkwave.domain.model.DayWatchData
import com.darkwave.domain.model.WatchStats

@Composable
fun AnalyticsScreen(
    onBack: () -> Unit,
    viewModel: AnalyticsViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Column(modifier = Modifier.fillMaxSize().background(Background)) {
        Row(
            modifier          = Modifier.fillMaxWidth().background(White).padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = TextPrimary) }
            Text("Analytics", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, modifier = Modifier.weight(1f))
            IconButton(onClick = viewModel::clearStats) { Icon(Icons.Default.DeleteSweep, "Clear", tint = TextSecondary) }
        }

        LazyColumn(
            contentPadding      = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier            = Modifier.fillMaxSize()
        ) {
            item { StatSummaryRow(state.stats) }
            item { WeeklyChartCard(state.stats.weeklyData) }
            item { BreakdownCard(state.stats) }
            item { TopContentCard(state.stats) }
            item { GenreCard(state.stats) }
            item { ArtistCard(state.stats) }
        }
    }
}

@Composable
private fun StatSummaryRow(stats: WatchStats) {
    Row(
        modifier              = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StatTile("Watch Time",  formatMins(stats.totalWatchMinutes), Purple500,          Modifier.weight(1f))
        StatTile("Videos",     "${stats.totalVideosWatched}",        Color(0xFF2196F3),  Modifier.weight(1f))
        StatTile("Songs",      "${stats.totalSongsPlayed}",          Color(0xFF4CAF50),  Modifier.weight(1f))
    }
}

@Composable
private fun StatTile(label: String, value: String, color: Color, modifier: Modifier) {
    Card(shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = White), elevation = CardDefaults.cardElevation(2.dp), modifier = modifier) {
        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = color)
            Spacer(Modifier.height(2.dp))
            Text(label, fontSize = 11.sp, color = TextSecondary)
        }
    }
}

@Composable
private fun WeeklyChartCard(weeklyData: List<DayWatchData>) {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = White), elevation = CardDefaults.cardElevation(2.dp), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("This Week", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Text("Minutes watched per day", fontSize = 12.sp, color = TextSecondary)
            Spacer(Modifier.height(16.dp))
            StandaloneWeeklyBarChart(data = weeklyData, modifier = Modifier.fillMaxWidth().height(130.dp))
        }
    }
}

@Composable
fun StandaloneWeeklyBarChart(data: List<DayWatchData>, modifier: Modifier = Modifier) {
    val days = listOf("Mon","Tue","Wed","Thu","Fri","Sat","Sun")
    val chartData = remember(data) {
        if (data.isEmpty()) days.map { DayWatchData(it, 0) }
        else { val m = data.associateBy { it.dayLabel }; days.map { m[it] ?: DayWatchData(it, 0) } }
    }
    val maxVal = chartData.maxOfOrNull { it.watchMinutes }?.coerceAtLeast(1) ?: 60
    val density = LocalDensity.current
    val labelPx = with(density) { 11.sp.toPx() }
    val labelColor = TextSecondary.toArgb()

    Canvas(modifier = modifier) {
        val count = chartData.size
        val botPad = labelPx * 2.5f
        val chartH = size.height - botPad
        val bW = (size.width / count) * 0.5f
        val gap = (size.width / count) * 0.5f
        val halfGap = gap / 2f

        chartData.forEachIndexed { i, day ->
            val cx = i * (bW + gap) + halfGap + bW / 2
            val frac = day.watchMinutes.toFloat() / maxVal
            val bH = (frac * chartH).coerceAtLeast(4f)
            val top = chartH - bH

            drawRoundRect(color = Purple500, topLeft = Offset(cx - bW/2, top), size = Size(bW, bH), cornerRadius = CornerRadius(6f))

            if (day.watchMinutes > 0) {
                drawContext.canvas.nativeCanvas.drawText(
                    "${day.watchMinutes}",
                    cx, top - 4f,
                    android.graphics.Paint().apply { color = Purple500.toArgb(); textSize = labelPx * 0.85f; textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true }
                )
            }
            drawContext.canvas.nativeCanvas.drawText(
                day.dayLabel, cx, size.height,
                android.graphics.Paint().apply { color = labelColor; textSize = labelPx; textAlign = android.graphics.Paint.Align.CENTER; isAntiAlias = true }
            )
        }
        drawLine(color = Color(0xFFE0E0E0), start = Offset(0f, chartH), end = Offset(size.width, chartH), strokeWidth = 1.dp.toPx())
    }
}

@Composable
private fun BreakdownCard(stats: WatchStats) {
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = White), elevation = CardDefaults.cardElevation(2.dp), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Breakdown", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            val total = stats.totalWatchMinutes.coerceAtLeast(1)
            BreakdownBar("Video",   stats.videoWatchMinutes, total, Purple500)
            BreakdownBar("Music",   stats.musicPlayMinutes,  total, Color(0xFF43A047))
            BreakdownBar("Browser", stats.browserMinutes,    total, Color(0xFF0288D1))
        }
    }
}

@Composable
private fun BreakdownBar(label: String, value: Int, total: Int, color: Color) {
    val frac = (value.toFloat() / total).coerceIn(0f, 1f)
    Column {
        Row { Text(label, fontSize = 13.sp, color = TextPrimary, modifier = Modifier.weight(1f)); Text(formatMins(value), fontSize = 13.sp, color = TextSecondary) }
        Spacer(Modifier.height(4.dp))
        Box(Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(SurfaceVariant)) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().clip(RoundedCornerShape(3.dp)).background(color))
        }
    }
}

@Composable
private fun TopContentCard(stats: WatchStats) {
    if (stats.topVideos.isEmpty()) return
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = White), elevation = CardDefaults.cardElevation(2.dp), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Most Watched", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Spacer(Modifier.height(10.dp))
            stats.topVideos.take(5).forEachIndexed { i, title ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(26.dp).clip(RoundedCornerShape(6.dp)).background(if (i == 0) Purple500 else SurfaceVariant), contentAlignment = Alignment.Center) {
                        Text("${i+1}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (i == 0) White else TextSecondary)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(title, fontSize = 13.sp, color = TextPrimary, modifier = Modifier.weight(1f), maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun GenreCard(stats: WatchStats) {
    if (stats.topGenres.isEmpty()) return
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = White), elevation = CardDefaults.cardElevation(2.dp), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Top Genres", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Spacer(Modifier.height(10.dp))
            val sorted = stats.topGenres.entries.sortedByDescending { it.value }.take(5)
            val maxCount = sorted.firstOrNull()?.value?.coerceAtLeast(1) ?: 1
            val colors = listOf(Purple500, Color(0xFF43A047), Color(0xFF0288D1), Color(0xFFFF9800), Color(0xFFE91E63))
            sorted.forEachIndexed { i, (genre, count) ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(8.dp).clip(CircleShape).background(colors.getOrElse(i) { Purple500 }))
                    Spacer(Modifier.width(8.dp))
                    Text(genre, fontSize = 13.sp, color = TextPrimary, modifier = Modifier.weight(1f))
                    Text("$count plays", fontSize = 12.sp, color = TextSecondary)
                }
            }
        }
    }
}

@Composable
private fun ArtistCard(stats: WatchStats) {
    if (stats.topArtists.isEmpty()) return
    Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = White), elevation = CardDefaults.cardElevation(2.dp), modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Top Artists", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            Spacer(Modifier.height(10.dp))
            stats.topArtists.entries.sortedByDescending { it.value }.take(5).forEach { (artist, count) ->
                Row(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(34.dp).clip(CircleShape).background(Purple100), contentAlignment = Alignment.Center) {
                        Text(artist.firstOrNull()?.uppercase() ?: "?", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Purple500)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(artist, fontSize = 13.sp, color = TextPrimary, modifier = Modifier.weight(1f))
                    Text("$count plays", fontSize = 12.sp, color = TextSecondary)
                }
            }
        }
    }
}

private fun formatMins(m: Int) = if (m >= 60) "${m/60}h ${m%60}m" else "${m}m"
