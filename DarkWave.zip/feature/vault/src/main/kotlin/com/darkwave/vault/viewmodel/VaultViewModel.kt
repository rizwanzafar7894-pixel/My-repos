package com.darkwave.vault.viewmodel

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darkwave.domain.model.VaultItem
import com.darkwave.domain.model.VaultMediaType
import com.darkwave.domain.repository.MediaRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.security.MessageDigest
import javax.inject.Inject

enum class VaultScreen { LOCK, SETUP_PIN, CONFIRM_PIN, VAULT }
enum class VaultFilter { ALL, VIDEO, AUDIO, IMAGE }

data class VaultUiState(
    val screen: VaultScreen = VaultScreen.LOCK,
    val pinInput: String = "",
    val confirmPinInput: String = "",
    val pinError: String? = null,
    val hasPinSetup: Boolean = false,
    val biometricAvailable: Boolean = false,
    val biometricEnabled: Boolean = false,
    val isUnlocked: Boolean = false,
    val items: List<VaultItem> = emptyList(),
    val filter: VaultFilter = VaultFilter.ALL,
    val isLoading: Boolean = true,
    val showAddSheet: Boolean = false,
    val showItemMenu: String? = null,   // uri of item with open menu
    val errorMessage: String? = null
) {
    val filteredItems: List<VaultItem> get() = when (filter) {
        VaultFilter.ALL   -> items
        VaultFilter.VIDEO -> items.filter { it.mediaType == VaultMediaType.VIDEO }
        VaultFilter.AUDIO -> items.filter { it.mediaType == VaultMediaType.AUDIO }
        VaultFilter.IMAGE -> items.filter { it.mediaType == VaultMediaType.IMAGE }
    }
}

@HiltViewModel
class VaultViewModel @Inject constructor(
    private val dataStore: DataStore<Preferences>,
    private val mediaRepository: MediaRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(VaultUiState())
    val uiState: StateFlow<VaultUiState> = _uiState.asStateFlow()

    private val PIN_HASH_KEY   = stringPreferencesKey("vault_pin_hash")
    private val BIOMETRIC_KEY  = booleanPreferencesKey("vault_biometric")

    init {
        viewModelScope.launch {
            dataStore.data.first().let { prefs ->
                val hasPin   = prefs[PIN_HASH_KEY] != null
                val biometric = prefs[BIOMETRIC_KEY] ?: false
                _uiState.update {
                    it.copy(
                        hasPinSetup        = hasPin,
                        biometricEnabled   = biometric,
                        screen             = if (hasPin) VaultScreen.LOCK else VaultScreen.SETUP_PIN,
                        isLoading          = false
                    )
                }
            }
        }
    }

    // ── PIN input ──────────────────────────────────────────────────────
    fun onPinDigit(digit: Int) {
        val current = _uiState.value.pinInput
        if (current.length >= 6) return
        _uiState.update { it.copy(pinInput = current + digit, pinError = null) }
        if (current.length + 1 == 6) {
            when (_uiState.value.screen) {
                VaultScreen.LOCK        -> verifyPin(current + digit)
                VaultScreen.SETUP_PIN   -> {
                    _uiState.update { it.copy(screen = VaultScreen.CONFIRM_PIN, confirmPinInput = "", pinInput = "") }
                }
                VaultScreen.CONFIRM_PIN -> confirmNewPin(current + digit)
                else -> {}
            }
        }
    }

    fun onPinDelete() {
        val current = _uiState.value.pinInput
        if (current.isNotEmpty()) {
            _uiState.update { it.copy(pinInput = current.dropLast(1), pinError = null) }
        }
    }

    private fun verifyPin(pin: String) {
        viewModelScope.launch {
            val storedHash = dataStore.data.first()[PIN_HASH_KEY] ?: ""
            if (hashPin(pin) == storedHash) {
                unlockVault()
            } else {
                _uiState.update { it.copy(pinInput = "", pinError = "Incorrect PIN. Try again.") }
            }
        }
    }

    private fun confirmNewPin(confirmPin: String) {
        val setupPin = _uiState.value.confirmPinInput
        // We stored the first entered pin in confirmPinInput temporarily
        // Actually let's keep it simple: we stored setupPin in a temp field
        viewModelScope.launch {
            dataStore.edit { prefs -> prefs[PIN_HASH_KEY] = hashPin(confirmPin) }
            _uiState.update {
                it.copy(
                    hasPinSetup = true,
                    screen      = VaultScreen.LOCK,
                    pinInput    = "",
                    pinError    = null
                )
            }
        }
    }

    fun onFirstPinEntered(pin: String) {
        // called when setup step 1 is done — store temporarily
        _uiState.update { it.copy(confirmPinInput = pin, pinInput = "", screen = VaultScreen.CONFIRM_PIN) }
    }

    fun onConfirmPinEntered(confirmPin: String) {
        val firstPin = _uiState.value.confirmPinInput
        if (firstPin == confirmPin) {
            viewModelScope.launch {
                dataStore.edit { prefs -> prefs[PIN_HASH_KEY] = hashPin(confirmPin) }
                _uiState.update {
                    it.copy(
                        hasPinSetup = true,
                        pinInput    = "",
                        confirmPinInput = "",
                        screen      = VaultScreen.VAULT
                    )
                }
                unlockVault()
            }
        } else {
            _uiState.update {
                it.copy(
                    pinInput    = "",
                    pinError    = "PINs don't match. Start over.",
                    screen      = VaultScreen.SETUP_PIN,
                    confirmPinInput = ""
                )
            }
        }
    }

    // ── Biometric ─────────────────────────────────────────────────────
    fun onBiometricSuccess() { unlockVault() }
    fun onBiometricFail()    { _uiState.update { it.copy(pinError = "Biometric failed. Use PIN.") } }

    fun setBiometricEnabled(enabled: Boolean) {
        _uiState.update { it.copy(biometricEnabled = enabled) }
        viewModelScope.launch { dataStore.edit { it[BIOMETRIC_KEY] = enabled } }
    }

    fun setBiometricAvailable(available: Boolean) {
        _uiState.update { it.copy(biometricAvailable = available) }
    }

    // ── Vault content ─────────────────────────────────────────────────
    private fun unlockVault() {
        _uiState.update { it.copy(isUnlocked = true, screen = VaultScreen.VAULT, pinInput = "") }
        loadVaultItems()
    }

    fun lock() {
        _uiState.update {
            VaultUiState(
                hasPinSetup      = it.hasPinSetup,
                biometricEnabled = it.biometricEnabled,
                biometricAvailable = it.biometricAvailable,
                screen           = VaultScreen.LOCK,
                isLoading        = false
            )
        }
    }

    private fun loadVaultItems() {
        viewModelScope.launch {
            mediaRepository.getVaultItems().collect { items ->
                _uiState.update { it.copy(items = items) }
            }
        }
    }

    fun setFilter(filter: VaultFilter) { _uiState.update { it.copy(filter = filter) } }

    fun addToVault(uri: String, name: String, mediaType: VaultMediaType) {
        viewModelScope.launch {
            mediaRepository.addToVault(uri, name, mediaType)
            _uiState.update { it.copy(showAddSheet = false) }
        }
    }

    fun removeFromVault(item: VaultItem) {
        viewModelScope.launch {
            mediaRepository.removeFromVault(item.id)
            _uiState.update { it.copy(showItemMenu = null) }
        }
    }

    fun showAddSheet()       { _uiState.update { it.copy(showAddSheet = true) } }
    fun hideAddSheet()       { _uiState.update { it.copy(showAddSheet = false) } }
    fun showItemMenu(uri: String) { _uiState.update { it.copy(showItemMenu = uri) } }
    fun hideItemMenu()       { _uiState.update { it.copy(showItemMenu = null) } }
    fun clearError()         { _uiState.update { it.copy(errorMessage = null) } }

    // ── PIN hashing ───────────────────────────────────────────────────
    private fun hashPin(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
