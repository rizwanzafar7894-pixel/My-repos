package com.darkwave.vault.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.theme.*
import com.darkwave.vault.viewmodel.VaultUiState

@Composable
fun VaultLockScreen(
    state: VaultUiState,
    onDigit: (Int) -> Unit,
    onDelete: () -> Unit,
    onBiometricClick: () -> Unit,
    onBack: () -> Unit
) {
    // Shake animation on error
    val shakeOffset = remember { Animatable(0f) }
    LaunchedEffect(state.pinError) {
        if (state.pinError != null) {
            repeat(4) {
                shakeOffset.animateTo(12f, tween(60))
                shakeOffset.animateTo(-12f, tween(60))
            }
            shakeOffset.animateTo(0f, tween(60))
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
            .padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(56.dp))

        // Lock icon
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(Purple100),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.Lock, "Vault",
                tint     = Purple500,
                modifier = Modifier.size(40.dp)
            )
        }

        Spacer(Modifier.height(16.dp))
        Text("Vault", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
        Text("Enter your PIN to unlock", fontSize = 14.sp, color = TextSecondary)
        Spacer(Modifier.height(40.dp))

        // PIN dots with shake
        PinDots(
            pinLength  = state.pinInput.length,
            hasError   = state.pinError != null,
            shakeOffset = shakeOffset.value
        )

        Spacer(Modifier.height(8.dp))

        // Error message
        AnimatedVisibility(visible = state.pinError != null) {
            Text(
                state.pinError ?: "",
                fontSize = 13.sp,
                color    = Error,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        Spacer(Modifier.height(32.dp))

        // Numpad
        PinNumpad(
            onDigit          = onDigit,
            onDelete         = onDelete,
            onBiometric      = onBiometricClick,
            showBiometric    = state.biometricEnabled && state.biometricAvailable
        )

        Spacer(Modifier.weight(1f))
        TextButton(onClick = onBack, modifier = Modifier.padding(bottom = 24.dp)) {
            Text("Cancel", color = TextSecondary)
        }
    }
}

@Composable
fun VaultPinSetupScreen(
    state: VaultUiState,
    onDigit: (Int) -> Unit,
    onDelete: () -> Unit,
    onBack: () -> Unit
) {
    val isConfirmStep = state.screen == com.darkwave.vault.viewmodel.VaultScreen.CONFIRM_PIN

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
            .padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(56.dp))

        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(Purple100),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                Icons.Default.LockOpen, "Setup",
                tint     = Purple500,
                modifier = Modifier.size(40.dp)
            )
        }

        Spacer(Modifier.height(16.dp))
        Text(
            if (isConfirmStep) "Confirm PIN" else "Set Vault PIN",
            fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextPrimary
        )
        Text(
            if (isConfirmStep) "Enter your PIN again to confirm" else "Choose a 6-digit PIN for your vault",
            fontSize = 14.sp, color = TextSecondary
        )
        Spacer(Modifier.height(40.dp))

        PinDots(
            pinLength   = state.pinInput.length,
            hasError    = state.pinError != null,
            shakeOffset = 0f
        )

        Spacer(Modifier.height(8.dp))
        AnimatedVisibility(visible = state.pinError != null) {
            Text(state.pinError ?: "", fontSize = 13.sp, color = Error, modifier = Modifier.padding(top = 4.dp))
        }
        Spacer(Modifier.height(32.dp))

        PinNumpad(
            onDigit       = onDigit,
            onDelete      = onDelete,
            onBiometric   = {},
            showBiometric = false
        )

        Spacer(Modifier.weight(1f))
        TextButton(onClick = onBack, modifier = Modifier.padding(bottom = 24.dp)) {
            Text("Cancel", color = TextSecondary)
        }
    }
}

// ── PIN dots ─────────────────────────────────────────────────────────────
@Composable
fun PinDots(pinLength: Int, hasError: Boolean, shakeOffset: Float) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.offset(x = shakeOffset.dp)
    ) {
        repeat(6) { index ->
            val filled = index < pinLength
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(CircleShape)
                    .background(
                        when {
                            hasError -> Error
                            filled   -> Purple500
                            else     -> Color(0xFFE0E0E0)
                        }
                    )
                    .then(
                        if (!filled) Modifier.border(1.5.dp, Color(0xFFBDBDBD), CircleShape)
                        else Modifier
                    )
            )
        }
    }
}

// ── Numpad ────────────────────────────────────────────────────────────────
@Composable
fun PinNumpad(
    onDigit: (Int) -> Unit,
    onDelete: () -> Unit,
    onBiometric: () -> Unit,
    showBiometric: Boolean
) {
    val haptic = LocalHapticFeedback.current
    val rows = listOf(
        listOf(1, 2, 3),
        listOf(4, 5, 6),
        listOf(7, 8, 9)
    )
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        rows.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                row.forEach { digit ->
                    NumKey(digit.toString()) {
                        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                        onDigit(digit)
                    }
                }
            }
        }
        // Bottom row: biometric / 0 / delete
        Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
            if (showBiometric) {
                NumKeyIcon(Icons.Default.Fingerprint, "Biometric") {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    onBiometric()
                }
            } else {
                Box(Modifier.size(72.dp))
            }
            NumKey("0") {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onDigit(0)
            }
            NumKeyIcon(Icons.Default.Backspace, "Delete") {
                haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onDelete()
            }
        }
    }
}

@Composable
private fun NumKey(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(White)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 24.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
    }
}

@Composable
private fun NumKeyIcon(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    desc: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, desc, tint = TextSecondary, modifier = Modifier.size(28.dp))
    }
}
