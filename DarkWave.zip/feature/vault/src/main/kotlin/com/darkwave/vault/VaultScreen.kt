package com.darkwave.vault

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darkwave.vault.ui.*
import com.darkwave.vault.viewmodel.VaultScreen
import com.darkwave.vault.viewmodel.VaultViewModel

@Composable
fun VaultScreen(
    onBack: () -> Unit,
    viewModel: VaultViewModel = hiltViewModel()
) {
    val state   by viewModel.uiState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    // Check biometric availability once
    LaunchedEffect(Unit) {
        val bm = BiometricManager.from(context)
        val available = bm.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG
        ) == BiometricManager.BIOMETRIC_SUCCESS
        viewModel.setBiometricAvailable(available)
    }

    when (state.screen) {
        VaultScreen.SETUP_PIN, VaultScreen.CONFIRM_PIN -> VaultPinSetupScreen(
            state        = state,
            onDigit      = viewModel::onPinDigit,
            onDelete     = viewModel::onPinDelete,
            onBack       = onBack
        )
        VaultScreen.LOCK -> VaultLockScreen(
            state            = state,
            onDigit          = viewModel::onPinDigit,
            onDelete         = viewModel::onPinDelete,
            onBiometricClick = { launchBiometric(context, viewModel) },
            onBack           = onBack
        )
        VaultScreen.VAULT -> VaultContentScreen(
            state         = state,
            onFilter      = viewModel::setFilter,
            onAddClick    = viewModel::showAddSheet,
            onHideAdd     = viewModel::hideAddSheet,
            onItemMenu    = viewModel::showItemMenu,
            onHideMenu    = viewModel::hideItemMenu,
            onRemoveItem  = viewModel::removeFromVault,
            onAddToVault  = viewModel::addToVault,
            onLock        = viewModel::lock,
            onBack        = onBack
        )
    }
}

private fun launchBiometric(context: Context, viewModel: VaultViewModel) {
    val activity   = context as? FragmentActivity ?: return
    val executor   = ContextCompat.getMainExecutor(context)
    val callback   = object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            viewModel.onBiometricSuccess()
        }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
            viewModel.onBiometricFail()
        }
        override fun onAuthenticationFailed() {
            viewModel.onBiometricFail()
        }
    }
    val promptInfo = BiometricPrompt.PromptInfo.Builder()
        .setTitle("Unlock Vault")
        .setSubtitle("Use your fingerprint to access the vault")
        .setNegativeButtonText("Use PIN")
        .build()
    BiometricPrompt(activity, executor, callback).authenticate(promptInfo)
}
