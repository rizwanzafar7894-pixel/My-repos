package com.darkwave.vault.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.darkwave.common.ui.theme.*
import com.darkwave.domain.model.VaultItem
import com.darkwave.domain.model.VaultMediaType
import com.darkwave.vault.viewmodel.VaultFilter
import com.darkwave.vault.viewmodel.VaultUiState

@Composable
fun VaultContentScreen(
    state: VaultUiState,
    onFilter: (VaultFilter) -> Unit,
    onAddClick: () -> Unit,
    onHideAdd: () -> Unit,
    onItemMenu: (String) -> Unit,
    onHideMenu: () -> Unit,
    onRemoveItem: (VaultItem) -> Unit,
    onAddToVault: (String, String, VaultMediaType) -> Unit,
    onLock: () -> Unit,
    onBack: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize().background(Background)) {
        Column(modifier = Modifier.fillMaxSize()) {

            // Top bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(White)
                    .padding(horizontal = 4.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = TextPrimary)
                }
                Text(
                    "Vault",
                    fontSize   = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    color      = TextPrimary,
                    modifier   = Modifier.weight(1f)
                )
                IconButton(onClick = onLock) {
                    Icon(Icons.Default.Lock, "Lock", tint = TextSecondary)
                }
            }

            // Filter chips
            val filters = VaultFilter.entries
            ScrollableRow(
                modifier = Modifier
                    .background(White)
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                filters.forEach { f ->
                    val selected = state.filter == f
                    FilterChip(
                        selected = selected,
                        onClick  = { onFilter(f) },
                        label    = { Text(f.name.lowercase().replaceFirstChar { it.uppercase() }) },
                        modifier = Modifier.padding(end = 8.dp),
                        colors   = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Purple500,
                            selectedLabelColor     = White
                        )
                    )
                }
            }

            // Grid content
            if (state.filteredItems.isEmpty()) {
                VaultEmptyState(onAdd = onAddClick, modifier = Modifier.weight(1f))
            } else {
                LazyVerticalGrid(
                    columns            = GridCells.Fixed(2),
                    contentPadding     = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement   = Arrangement.spacedBy(12.dp),
                    modifier           = Modifier.weight(1f)
                ) {
                    items(state.filteredItems, key = { it.uri }) { item ->
                        VaultGridItem(
                            item        = item,
                            onLongPress = { onItemMenu(item.uri) },
                            onClick     = {}
                        )
                    }
                }
            }
        }

        // FAB
        FloatingActionButton(
            onClick           = onAddClick,
            containerColor    = Purple500,
            contentColor      = White,
            modifier          = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
        ) {
            Icon(Icons.Default.Add, "Add to Vault")
        }

        // Item context menu
        val activeItem = state.showItemMenu?.let { uri ->
            state.items.find { it.uri == uri }
        }
        if (activeItem != null) {
            VaultItemMenu(
                item     = activeItem,
                onRemove = { onRemoveItem(activeItem) },
                onDismiss = onHideMenu
            )
        }
    }

    // Add to vault bottom sheet
    if (state.showAddSheet) {
        AddToVaultSheet(
            onAdd    = onAddToVault,
            onDismiss = onHideAdd
        )
    }
}

@Composable
private fun ScrollableRow(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    Row(modifier = modifier.horizontalScroll(rememberScrollState()), content = content)
}

// ── Vault grid item ───────────────────────────────────────────────────────
@Composable
private fun VaultGridItem(
    item: VaultItem,
    onClick: () -> Unit,
    onLongPress: () -> Unit
) {
    Card(
        modifier  = Modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .clickable(onClick = onClick),
        shape     = RoundedCornerShape(14.dp),
        colors    = CardDefaults.cardColors(containerColor = White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Thumbnail or icon
            if (item.thumbnailUri.isNotBlank()) {
                AsyncImage(
                    model        = item.thumbnailUri,
                    contentDescription = item.name,
                    contentScale = ContentScale.Crop,
                    modifier     = Modifier.fillMaxSize()
                )
            } else {
                Box(
                    modifier         = Modifier.fillMaxSize().background(SurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (item.mediaType) {
                            VaultMediaType.VIDEO -> Icons.Default.VideoFile
                            VaultMediaType.AUDIO -> Icons.Default.AudioFile
                            VaultMediaType.IMAGE -> Icons.Default.Image
                        },
                        contentDescription = null,
                        tint     = Purple500,
                        modifier = Modifier.size(40.dp)
                    )
                }
            }

            // Type badge
            Box(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        when (item.mediaType) {
                            VaultMediaType.VIDEO -> Color(0xFF5C6BC0)
                            VaultMediaType.AUDIO -> Color(0xFF43A047)
                            VaultMediaType.IMAGE -> Color(0xFFE91E63)
                        }.copy(alpha = 0.9f)
                    )
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    item.mediaType.name.first().toString(),
                    fontSize = 10.sp, fontWeight = FontWeight.Bold, color = White
                )
            }

            // More button
            IconButton(
                onClick  = onLongPress,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(32.dp)
            ) {
                Icon(Icons.Default.MoreVert, "Menu", tint = White, modifier = Modifier.size(18.dp))
            }

            // Name overlay at bottom
            Box(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.45f))
                    .padding(8.dp)
            ) {
                Text(
                    item.name,
                    fontSize  = 12.sp,
                    color     = White,
                    maxLines  = 1,
                    overflow  = TextOverflow.Ellipsis
                )
            }
        }
    }
}

// ── Empty state ───────────────────────────────────────────────────────────
@Composable
private fun VaultEmptyState(onAdd: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier            = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.LockOpen, null,
            tint     = TextTertiary,
            modifier = Modifier.size(64.dp)
        )
        Spacer(Modifier.height(16.dp))
        Text("Your vault is empty", fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = TextSecondary)
        Spacer(Modifier.height(8.dp))
        Text("Add private media to keep it hidden", fontSize = 13.sp, color = TextTertiary)
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = onAdd,
            colors  = ButtonDefaults.buttonColors(containerColor = Purple500)
        ) {
            Icon(Icons.Default.Add, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("Add Media")
        }
    }
}

// ── Item context menu ─────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VaultItemMenu(
    item: VaultItem,
    onRemove: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = White) {
        Column(modifier = Modifier.padding(bottom = 32.dp)) {
            Text(
                item.name,
                fontSize   = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color      = TextPrimary,
                modifier   = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                maxLines   = 1,
                overflow   = TextOverflow.Ellipsis
            )
            Divider(color = DividerColor)
            MenuSheetRow(Icons.Default.PlayArrow,   "Open",           TextPrimary) {}
            MenuSheetRow(Icons.Default.DriveFileMove,"Move Out of Vault", TextPrimary) {}
            MenuSheetRow(Icons.Default.Share,       "Share",          TextPrimary) {}
            MenuSheetRow(Icons.Default.Delete,      "Delete",         Error, onRemove)
        }
    }
}

@Composable
private fun MenuSheetRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    color: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Text(label, fontSize = 14.sp, color = color)
    }
}

// ── Add to vault sheet ────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddToVaultSheet(
    onAdd: (String, String, VaultMediaType) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            val name = uri.lastPathSegment ?: "media_${System.currentTimeMillis()}"
            val type = when {
                uri.toString().contains("video") -> VaultMediaType.VIDEO
                uri.toString().contains("audio") -> VaultMediaType.AUDIO
                else                              -> VaultMediaType.IMAGE
            }
            onAdd(uri.toString(), name, type)
        }
    }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = White) {
        Column(modifier = Modifier.padding(bottom = 40.dp)) {
            Text(
                "Add to Vault",
                fontSize   = 18.sp,
                fontWeight = FontWeight.Bold,
                color      = TextPrimary,
                modifier   = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
            )
            Divider(color = DividerColor)
            MenuSheetRow(Icons.Default.VideoFile, "Add Video",  TextPrimary) { launcher.launch("video/*") }
            MenuSheetRow(Icons.Default.AudioFile, "Add Audio",  TextPrimary) { launcher.launch("audio/*") }
            MenuSheetRow(Icons.Default.Image,     "Add Image",  TextPrimary) { launcher.launch("image/*") }
        }
    }
}
