package com.darkwave.bookmark

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darkwave.common.ui.components.EmptyState
import com.darkwave.common.ui.components.LoadingIndicator
import com.darkwave.common.util.toFormattedDuration
import com.darkwave.domain.model.Bookmark
import com.darkwave.domain.model.BookmarkMediaType
import com.darkwave.bookmark.viewmodel.*
import com.darkwave.common.ui.theme.*

@Composable
fun BookmarkScreen(
    onBack: () -> Unit,
    onBookmarkClick: (Bookmark) -> Unit,
    viewModel: BookmarkViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val focus = LocalFocusManager.current

    Column(modifier = Modifier.fillMaxSize().background(Background)) {

        // ── Top bar ──────────────────────────────────────────────────
        Row(
            modifier          = Modifier.fillMaxWidth().background(White).padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, "Back", tint = TextPrimary)
            }
            Text(
                "Bookmarks",
                fontSize   = 18.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary,
                modifier   = Modifier.weight(1f)
            )
            Text(
                "${state.filtered.size}",
                fontSize = 13.sp, color = TextSecondary,
                modifier = Modifier.padding(end = 4.dp)
            )
            IconButton(onClick = viewModel::showSortDialog) {
                Icon(Icons.Default.Sort, "Sort", tint = TextSecondary)
            }
        }

        // ── Search ───────────────────────────────────────────────────
        TextField(
            value         = state.searchQuery,
            onValueChange = viewModel::onSearch,
            placeholder   = { Text("Search bookmarks…", color = TextTertiary) },
            leadingIcon   = { Icon(Icons.Default.Search, null, tint = TextSecondary, modifier = Modifier.size(20.dp)) },
            trailingIcon  = {
                if (state.searchQuery.isNotBlank()) {
                    IconButton(onClick = viewModel::clearSearch) {
                        Icon(Icons.Default.Close, null, tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                }
            },
            singleLine    = true,
            modifier      = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            shape         = RoundedCornerShape(12.dp),
            colors        = TextFieldDefaults.colors(
                focusedContainerColor   = White,
                unfocusedContainerColor = White,
                focusedIndicatorColor   = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent
            ),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() })
        )

        // ── Filter chips ─────────────────────────────────────────────
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            BookmarkFilter.entries.forEach { f ->
                FilterChip(
                    selected = state.filter == f,
                    onClick  = { viewModel.setFilter(f) },
                    label    = { Text(f.name.lowercase().replaceFirstChar { it.uppercase() }) },
                    colors   = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = Purple500,
                        selectedLabelColor     = White
                    )
                )
            }
        }

        Divider(color = DividerColor, modifier = Modifier.padding(top = 8.dp))

        // ── List ─────────────────────────────────────────────────────
        when {
            state.isLoading  -> LoadingIndicator()
            state.filtered.isEmpty() -> EmptyState(
                icon    = Icons.Default.BookmarkBorder,
                title   = if (state.searchQuery.isNotBlank()) "No results" else "No bookmarks yet",
                message = if (state.searchQuery.isNotBlank()) "Try a different search" else "Bookmark moments while watching"
            )
            else -> LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(state.filtered, key = { it.id }) { bookmark ->
                    BookmarkCard(
                        bookmark    = bookmark,
                        onClick     = { onBookmarkClick(bookmark) },
                        onNote      = { viewModel.startEditNote(bookmark) },
                        onDelete    = { viewModel.requestDelete(bookmark) }
                    )
                }
            }
        }
    }

    // ── Sort dialog ───────────────────────────────────────────────────
    if (state.showSortDialog) {
        AlertDialog(
            onDismissRequest = viewModel::hideSortDialog,
            title = { Text("Sort By") },
            text = {
                Column {
                    BookmarkSort.entries.forEach { s ->
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable { viewModel.setSort(s) }.padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = state.sort == s,
                                onClick  = { viewModel.setSort(s) },
                                colors   = RadioButtonDefaults.colors(selectedColor = Purple500)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                when (s) {
                                    BookmarkSort.RECENT     -> "Most Recent"
                                    BookmarkSort.NAME       -> "Title A–Z"
                                    BookmarkSort.MEDIA_TYPE -> "Media Type"
                                },
                                color = TextPrimary
                            )
                        }
                    }
                }
            },
            confirmButton = {}
        )
    }

    // ── Delete confirmation ───────────────────────────────────────────
    if (state.showDeleteDialog && state.deleteTarget != null) {
        AlertDialog(
            onDismissRequest = viewModel::cancelDelete,
            title = { Text("Delete Bookmark?") },
            text  = { Text("\"${state.deleteTarget?.title}\" will be removed.") },
            confirmButton = {
                TextButton(onClick = viewModel::confirmDelete) { Text("Delete", color = Error) }
            },
            dismissButton = {
                TextButton(onClick = viewModel::cancelDelete) { Text("Cancel") }
            }
        )
    }

    // ── Note editor ───────────────────────────────────────────────────
    if (state.editingNote != null) {
        AlertDialog(
            onDismissRequest = viewModel::cancelNote,
            title = { Text("Edit Note") },
            text = {
                OutlinedTextField(
                    value         = state.noteText,
                    onValueChange = viewModel::onNoteChange,
                    placeholder   = { Text("Add a note…", color = TextTertiary) },
                    minLines      = 3,
                    maxLines      = 6,
                    modifier      = Modifier.fillMaxWidth(),
                    colors        = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple500,
                        focusedLabelColor  = Purple500
                    )
                )
            },
            confirmButton = {
                TextButton(onClick = viewModel::saveNote) { Text("Save", color = Purple500) }
            },
            dismissButton = {
                TextButton(onClick = viewModel::cancelNote) { Text("Cancel") }
            }
        )
    }
}

// ── Bookmark card ─────────────────────────────────────────────────────────
@Composable
private fun BookmarkCard(
    bookmark: Bookmark,
    onClick: () -> Unit,
    onNote: () -> Unit,
    onDelete: () -> Unit
) {
    val isVideo = bookmark.mediaType == BookmarkMediaType.VIDEO
    val accentColor = if (isVideo) Purple500 else Color(0xFF43A047)

    Card(
        modifier  = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape     = RoundedCornerShape(14.dp),
        colors    = CardDefaults.cardColors(containerColor = White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.Top
        ) {
            // Type + timestamp badge
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.width(52.dp)
            ) {
                Box(
                    modifier         = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accentColor.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        if (isVideo) Icons.Default.VideoFile else Icons.Default.AudioFile,
                        null, tint = accentColor, modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(Modifier.height(5.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(5.dp))
                        .background(accentColor)
                        .padding(horizontal = 5.dp, vertical = 2.dp)
                ) {
                    Text(
                        bookmark.positionMs.toFormattedDuration(),
                        fontSize   = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color      = White
                    )
                }
            }

            Spacer(Modifier.width(12.dp))

            // Content
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    bookmark.title,
                    fontSize   = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary,
                    maxLines   = 1, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    bookmark.mediaTitle,
                    fontSize = 12.sp, color = TextSecondary,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (bookmark.note.isNotBlank()) {
                    Spacer(Modifier.height(6.dp))
                    Text(
                        bookmark.note,
                        fontSize = 12.sp, color = TextSecondary,
                        maxLines = 2, overflow = TextOverflow.Ellipsis,
                        lineHeight = 17.sp
                    )
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    formatRelativeTime(bookmark.createdAt),
                    fontSize = 11.sp, color = TextTertiary
                )
            }

            // Actions
            Column {
                IconButton(onClick = onNote, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.EditNote, "Note", tint = TextSecondary, modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, "Delete", tint = Error.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

private fun formatRelativeTime(millis: Long): String {
    val diff = System.currentTimeMillis() - millis
    return when {
        diff < 60_000         -> "Just now"
        diff < 3_600_000      -> "${diff / 60_000}m ago"
        diff < 86_400_000     -> "${diff / 3_600_000}h ago"
        diff < 604_800_000    -> "${diff / 86_400_000}d ago"
        else                  -> "${diff / 604_800_000}w ago"
    }
}
