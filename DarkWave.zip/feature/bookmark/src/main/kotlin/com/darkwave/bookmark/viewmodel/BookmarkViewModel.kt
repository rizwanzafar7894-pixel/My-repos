package com.darkwave.bookmark.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darkwave.domain.model.Bookmark
import com.darkwave.domain.model.BookmarkMediaType
import com.darkwave.domain.repository.BookmarkRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class BookmarkFilter { ALL, VIDEO, AUDIO }
enum class BookmarkSort { RECENT, NAME, MEDIA_TYPE }

data class BookmarkUiState(
    val bookmarks: List<Bookmark> = emptyList(),
    val filter: BookmarkFilter = BookmarkFilter.ALL,
    val sort: BookmarkSort = BookmarkSort.RECENT,
    val searchQuery: String = "",
    val isLoading: Boolean = true,
    val showSortDialog: Boolean = false,
    val showDeleteDialog: Boolean = false,
    val deleteTarget: Bookmark? = null,
    val editingNote: Bookmark? = null,
    val noteText: String = "",
    val errorMessage: String? = null
) {
    val filtered: List<Bookmark>
        get() {
            var list = bookmarks
            if (searchQuery.isNotBlank()) {
                list = list.filter {
                    it.title.contains(searchQuery, ignoreCase = true) ||
                    it.note.contains(searchQuery, ignoreCase = true)
                }
            }
            list = when (filter) {
                BookmarkFilter.ALL   -> list
                BookmarkFilter.VIDEO -> list.filter { it.mediaType == BookmarkMediaType.VIDEO }
                BookmarkFilter.AUDIO -> list.filter { it.mediaType == BookmarkMediaType.AUDIO }
            }
            return when (sort) {
                BookmarkSort.RECENT     -> list.sortedByDescending { it.createdAt }
                BookmarkSort.NAME       -> list.sortedBy { it.title }
                BookmarkSort.MEDIA_TYPE -> list.sortedBy { it.mediaType.name }
            }
        }
}

@HiltViewModel
class BookmarkViewModel @Inject constructor(
    private val bookmarkRepository: BookmarkRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(BookmarkUiState())
    val uiState: StateFlow<BookmarkUiState> = _uiState.asStateFlow()

    init {
        viewModelScope.launch {
            bookmarkRepository.getAllBookmarks().collect { bookmarks ->
                _uiState.update { it.copy(bookmarks = bookmarks, isLoading = false) }
            }
        }
    }

    fun onSearch(query: String) { _uiState.update { it.copy(searchQuery = query) } }
    fun clearSearch() { _uiState.update { it.copy(searchQuery = "") } }
    fun setFilter(f: BookmarkFilter) { _uiState.update { it.copy(filter = f) } }
    fun setSort(s: BookmarkSort) { _uiState.update { it.copy(sort = s, showSortDialog = false) } }
    fun showSortDialog() { _uiState.update { it.copy(showSortDialog = true) } }
    fun hideSortDialog() { _uiState.update { it.copy(showSortDialog = false) } }

    // ── Delete ────────────────────────────────────────────────────────
    fun requestDelete(bookmark: Bookmark) { _uiState.update { it.copy(showDeleteDialog = true, deleteTarget = bookmark) } }
    fun cancelDelete() { _uiState.update { it.copy(showDeleteDialog = false, deleteTarget = null) } }
    fun confirmDelete() {
        val target = _uiState.value.deleteTarget ?: return
        viewModelScope.launch {
            bookmarkRepository.deleteBookmark(target.id)
            _uiState.update { it.copy(showDeleteDialog = false, deleteTarget = null) }
        }
    }

    // ── Notes ─────────────────────────────────────────────────────────
    fun startEditNote(bookmark: Bookmark) {
        _uiState.update { it.copy(editingNote = bookmark, noteText = bookmark.note) }
    }
    fun onNoteChange(text: String) { _uiState.update { it.copy(noteText = text) } }
    fun saveNote() {
        val bm   = _uiState.value.editingNote ?: return
        val note = _uiState.value.noteText
        viewModelScope.launch {
            bookmarkRepository.updateBookmarkNote(bm.id, note)
            _uiState.update { it.copy(editingNote = null, noteText = "") }
        }
    }
    fun cancelNote() { _uiState.update { it.copy(editingNote = null, noteText = "") } }

    // ── Navigate to timestamp ─────────────────────────────────────────
    fun clearError() { _uiState.update { it.copy(errorMessage = null) } }
}
