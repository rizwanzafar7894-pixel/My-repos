package com.darkwave.organizer

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darkwave.common.ui.theme.*
import com.darkwave.domain.model.MediaFolder
import com.darkwave.domain.model.VideoItem
import com.darkwave.domain.model.AudioItem
import com.darkwave.organizer.viewmodel.*

@Composable
fun OrganizerScreen(
    onBack: () -> Unit,
    viewModel: OrganizerViewModel = hiltViewModel()
) {
    val state  by viewModel.uiState.collectAsStateWithLifecycle()
    val focus  = LocalFocusManager.current

    Column(modifier = Modifier.fillMaxSize().background(Background)) {

        // ── Top bar ──────────────────────────────────────────────────
        AnimatedContent(
            targetState = state.selectedFolder,
            label       = "orgTopBar",
            transitionSpec = { fadeIn(tween(150)) togetherWith fadeOut(tween(150)) }
        ) { folder ->
            if (folder == null) {
                OrganizerTopBar(
                    isSelectMode   = state.isSelectMode,
                    selectedCount  = state.selectedCount,
                    onBack         = onBack,
                    onSort         = viewModel::showSortDialog,
                    onSelectAll    = viewModel::selectAll,
                    onClearSelect  = viewModel::clearSelection,
                    onDeleteSelect = viewModel::showDeleteDialog
                )
            } else {
                FolderTopBar(
                    folderName     = folder.name,
                    isSelectMode   = state.isSelectMode,
                    selectedCount  = state.selectedCount,
                    onBack         = viewModel::onBackFromFolder,
                    onSelectAll    = viewModel::selectAll,
                    onClearSelect  = viewModel::clearSelection,
                    onDeleteSelect = viewModel::showDeleteDialog
                )
            }
        }

        // ── Tab row (only on root) ───────────────────────────────────
        if (state.selectedFolder == null) {
            TabRow(
                selectedTabIndex = state.tab.ordinal,
                containerColor   = White,
                contentColor     = Purple500,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[state.tab.ordinal]),
                        color    = Purple500
                    )
                },
                divider = {}
            ) {
                OrganizerTab.entries.forEach { tab ->
                    Tab(
                        selected = state.tab == tab,
                        onClick  = { viewModel.onTabSelected(tab) },
                        text = {
                            Text(
                                tab.name.lowercase().replaceFirstChar { it.uppercase() },
                                color = if (state.tab == tab) Purple500 else TextSecondary,
                                style = MaterialTheme.typography.labelLarge
                            )
                        }
                    )
                }
            }
        }

        // ── Search bar ───────────────────────────────────────────────
        if (state.selectedFolder == null) {
            TextField(
                value         = state.searchQuery,
                onValueChange = viewModel::onSearch,
                placeholder   = { Text("Search folders…", color = TextTertiary) },
                leadingIcon   = { Icon(Icons.Default.Search, null, tint = TextSecondary, modifier = Modifier.size(20.dp)) },
                trailingIcon  = {
                    if (state.searchQuery.isNotEmpty()) {
                        IconButton(onClick = viewModel::clearSearch) {
                            Icon(Icons.Default.Close, "Clear", tint = TextSecondary, modifier = Modifier.size(18.dp))
                        }
                    }
                },
                singleLine    = true,
                modifier      = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                shape         = RoundedCornerShape(12.dp),
                colors        = TextFieldDefaults.colors(
                    focusedContainerColor   = White,
                    unfocusedContainerColor = White,
                    focusedIndicatorColor   = Color.Transparent,
                    unfocusedIndicatorColor = Color.Transparent
                ),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() })
            )
        }

        // ── Content ──────────────────────────────────────────────────
        if (state.isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Purple500)
            }
        } else if (state.selectedFolder == null) {
            // Folder list
            val folders = if (state.tab == OrganizerTab.VIDEO)
                state.filteredVideoFolders else state.filteredAudioFolders

            if (folders.isEmpty()) {
                OrganizerEmptyState(isVideo = state.tab == OrganizerTab.VIDEO)
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier       = Modifier.fillMaxSize()
                ) {
                    items(folders, key = { it.path }) { folder ->
                        FolderRow(
                            folder  = folder,
                            onClick = { viewModel.onFolderClick(folder) }
                        )
                    }
                }
            }
        } else {
            // Folder content
            if (state.tab == OrganizerTab.VIDEO) {
                VideoFolderContent(
                    videos        = state.folderVideos,
                    selected      = state.selectedItems,
                    isSelectMode  = state.isSelectMode,
                    onLongPress   = viewModel::enterSelectMode,
                    onToggle      = viewModel::toggleItem,
                    onRename      = { v -> viewModel.startRename(v.title, v.id.toString()) },
                    onClick       = { v ->
                        if (state.isSelectMode) viewModel.toggleItem(v.id)
                    }
                )
            } else {
                AudioFolderContent(
                    audios        = state.folderAudios,
                    selected      = state.selectedItems,
                    isSelectMode  = state.isSelectMode,
                    onLongPress   = viewModel::enterSelectMode,
                    onToggle      = viewModel::toggleItem,
                    onRename      = { a -> viewModel.startRename(a.title, a.id.toString()) },
                    onClick       = { a ->
                        if (state.isSelectMode) viewModel.toggleItem(a.id)
                    }
                )
            }
        }
    }

    // ── Dialogs ──────────────────────────────────────────────────────
    if (state.showSortDialog) {
        OrganizerSortDialog(
            current  = state.sortBy,
            onSelect = viewModel::setSortBy,
            onDismiss = viewModel::hideSortDialog
        )
    }

    if (state.showRenameDialog) {
        RenameDialog(
            value     = state.renameValue,
            onChange  = viewModel::onRenameValueChange,
            onConfirm = viewModel::confirmRename,
            onDismiss = viewModel::cancelRename
        )
    }

    if (state.showDeleteDialog) {
        DeleteDialog(
            count     = state.selectedCount,
            onConfirm = viewModel::confirmDeleteSelected,
            onDismiss = viewModel::hideDeleteDialog
        )
    }
}

// ── Top bars ──────────────────────────────────────────────────────────────

@Composable
private fun OrganizerTopBar(
    isSelectMode: Boolean,
    selectedCount: Int,
    onBack: () -> Unit,
    onSort: () -> Unit,
    onSelectAll: () -> Unit,
    onClearSelect: () -> Unit,
    onDeleteSelect: () -> Unit
) {
    Row(
        modifier          = Modifier.fillMaxWidth().background(White).padding(horizontal = 4.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = if (isSelectMode) onClearSelect else onBack) {
            Icon(
                if (isSelectMode) Icons.Default.Close else Icons.Default.ArrowBack,
                null, tint = TextPrimary
            )
        }
        Text(
            if (isSelectMode) "$selectedCount selected" else "Organizer",
            fontSize   = 18.sp, fontWeight = FontWeight.SemiBold,
            color      = TextPrimary, modifier = Modifier.weight(1f)
        )
        if (isSelectMode) {
            IconButton(onClick = onSelectAll) { Icon(Icons.Default.DoneAll, "Select All", tint = Purple500) }
            IconButton(onClick = onDeleteSelect) { Icon(Icons.Default.Delete, "Delete", tint = Error) }
        } else {
            IconButton(onClick = onSort) { Icon(Icons.Default.Sort, "Sort", tint = TextSecondary) }
        }
    }
}

@Composable
private fun FolderTopBar(
    folderName: String, isSelectMode: Boolean, selectedCount: Int,
    onBack: () -> Unit, onSelectAll: () -> Unit, onClearSelect: () -> Unit, onDeleteSelect: () -> Unit
) {
    Row(
        modifier          = Modifier.fillMaxWidth().background(White).padding(horizontal = 4.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = if (isSelectMode) onClearSelect else onBack) {
            Icon(if (isSelectMode) Icons.Default.Close else Icons.Default.ArrowBack, null, tint = TextPrimary)
        }
        Text(
            if (isSelectMode) "$selectedCount selected" else folderName,
            fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, modifier = Modifier.weight(1f),
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        if (isSelectMode) {
            IconButton(onClick = onSelectAll) { Icon(Icons.Default.DoneAll, "Select All", tint = Purple500) }
            IconButton(onClick = onDeleteSelect) { Icon(Icons.Default.Delete, "Delete", tint = Error) }
        }
    }
}

// ── Folder list row ───────────────────────────────────────────────────────

@Composable
private fun FolderRow(folder: MediaFolder, onClick: () -> Unit) {
    Row(
        modifier          = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier         = Modifier.size(52.dp).clip(RoundedCornerShape(12.dp)).background(Purple100),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Folder, null, tint = Purple500, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(folder.name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                "${folder.itemCount} items · ${formatBytes(folder.totalSize)}",
                fontSize = 12.sp, color = TextSecondary
            )
            Text(folder.path, fontSize = 10.sp, color = TextTertiary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Icon(Icons.Default.ChevronRight, null, tint = TextTertiary, modifier = Modifier.size(20.dp))
    }
    Divider(modifier = Modifier.padding(start = 68.dp), color = DividerColor)
}

// ── Folder content lists ──────────────────────────────────────────────────

@Composable
private fun VideoFolderContent(
    videos: List<VideoItem>,
    selected: Set<Long>,
    isSelectMode: Boolean,
    onLongPress: (Long) -> Unit,
    onToggle: (Long) -> Unit,
    onRename: (VideoItem) -> Unit,
    onClick: (VideoItem) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        modifier       = Modifier.fillMaxSize()
    ) {
        items(videos, key = { it.id }) { video ->
            val isSelected = video.id in selected
            MediaItemRow(
                title        = video.title,
                subtitle     = "${video.resolution} · ${formatBytes(video.size)}",
                isSelected   = isSelected,
                isSelectMode = isSelectMode,
                onLongPress  = { onLongPress(video.id) },
                onToggle     = { onToggle(video.id) },
                onRename     = { onRename(video) },
                onClick      = { onClick(video) },
                icon         = Icons.Default.VideoFile,
                iconColor    = Purple500
            )
        }
    }
}

@Composable
private fun AudioFolderContent(
    audios: List<AudioItem>,
    selected: Set<Long>,
    isSelectMode: Boolean,
    onLongPress: (Long) -> Unit,
    onToggle: (Long) -> Unit,
    onRename: (AudioItem) -> Unit,
    onClick: (AudioItem) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        modifier       = Modifier.fillMaxSize()
    ) {
        items(audios, key = { it.id }) { audio ->
            val isSelected = audio.id in selected
            MediaItemRow(
                title        = audio.title,
                subtitle     = "${audio.artist} · ${formatBytes(audio.size)}",
                isSelected   = isSelected,
                isSelectMode = isSelectMode,
                onLongPress  = { onLongPress(audio.id) },
                onToggle     = { onToggle(audio.id) },
                onRename     = { onRename(audio) },
                onClick      = { onClick(audio) },
                icon         = Icons.Default.AudioFile,
                iconColor    = Color(0xFF43A047)
            )
        }
    }
}

@Composable
private fun MediaItemRow(
    title: String, subtitle: String,
    isSelected: Boolean, isSelectMode: Boolean,
    onLongPress: () -> Unit, onToggle: () -> Unit, onRename: () -> Unit, onClick: () -> Unit,
    icon: androidx.compose.ui.graphics.vector.ImageVector, iconColor: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isSelected) Purple100 else Color.Transparent)
            .combinedClickable(
                onClick      = onClick,
                onLongClick  = onLongPress
            )
            .padding(horizontal = 4.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (isSelectMode) {
            Checkbox(
                checked         = isSelected,
                onCheckedChange = { onToggle() },
                colors          = CheckboxDefaults.colors(checkedColor = Purple500)
            )
            Spacer(Modifier.width(4.dp))
        } else {
            Box(
                modifier         = Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(iconColor.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = iconColor, modifier = Modifier.size(22.dp))
            }
            Spacer(Modifier.width(12.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(title, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = TextPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, fontSize = 11.sp, color = TextSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (!isSelectMode) {
            IconButton(onClick = onRename, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.Edit, "Rename", tint = TextTertiary, modifier = Modifier.size(18.dp))
            }
        }
    }
    Divider(modifier = Modifier.padding(start = if (isSelectMode) 56.dp else 60.dp), color = DividerColor)
}

// ── Dialogs ───────────────────────────────────────────────────────────────

@Composable
private fun OrganizerSortDialog(
    current: OrganizerSortBy,
    onSelect: (OrganizerSortBy) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Sort By") },
        text = {
            Column {
                OrganizerSortBy.entries.forEach { sort ->
                    Row(
                        modifier          = Modifier.fillMaxWidth().clickable { onSelect(sort) }.padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = current == sort, onClick = { onSelect(sort) }, colors = RadioButtonDefaults.colors(selectedColor = Purple500))
                        Spacer(Modifier.width(8.dp))
                        Text(sort.name.lowercase().replaceFirstChar { it.uppercase() }, color = TextPrimary)
                    }
                }
            }
        },
        confirmButton = {}
    )
}

@Composable
private fun RenameDialog(value: String, onChange: (String) -> Unit, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rename") },
        text = {
            OutlinedTextField(
                value         = value,
                onValueChange = onChange,
                label         = { Text("New name") },
                singleLine    = true,
                colors        = OutlinedTextFieldDefaults.colors(focusedBorderColor = Purple500, focusedLabelColor = Purple500)
            )
        },
        confirmButton = {
            TextButton(onClick = onConfirm) { Text("Rename", color = Purple500) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun DeleteDialog(count: Int, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Delete $count item${if (count > 1) "s" else ""}?") },
        text  = { Text("This will permanently delete the selected files from your device.") },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Delete", color = Error) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// ── Empty state ───────────────────────────────────────────────────────────

@Composable
private fun OrganizerEmptyState(isVideo: Boolean) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                if (isVideo) Icons.Default.VideoFile else Icons.Default.AudioFile,
                null, tint = TextTertiary, modifier = Modifier.size(64.dp)
            )
            Spacer(Modifier.height(16.dp))
            Text("No ${if (isVideo) "video" else "audio"} folders found", color = TextSecondary, fontSize = 16.sp)
        }
    }
}

private fun formatBytes(bytes: Long): String = when {
    bytes >= 1_000_000_000L -> "%.1f GB".format(bytes / 1_000_000_000f)
    bytes >= 1_000_000L     -> "%.0f MB".format(bytes / 1_000_000f)
    bytes >= 1_000L         -> "%.0f KB".format(bytes / 1_000f)
    else                    -> "$bytes B"
}
