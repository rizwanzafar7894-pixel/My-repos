package com.darkwave.organizer.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.darkwave.domain.model.MediaFolder
import com.darkwave.domain.model.VideoItem
import com.darkwave.domain.model.AudioItem
import com.darkwave.domain.repository.MediaRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

enum class OrganizerTab { VIDEO, AUDIO }
enum class OrganizerSortBy { NAME, SIZE, DATE, COUNT }

data class OrganizerUiState(
    val tab: OrganizerTab = OrganizerTab.VIDEO,
    val sortBy: OrganizerSortBy = OrganizerSortBy.DATE,
    val videoFolders: List<MediaFolder> = emptyList(),
    val audioFolders: List<MediaFolder> = emptyList(),
    val selectedFolder: MediaFolder? = null,
    val folderVideos: List<VideoItem> = emptyList(),
    val folderAudios: List<AudioItem> = emptyList(),
    val selectedItems: Set<Long> = emptySet(),
    val isSelectMode: Boolean = false,
    val searchQuery: String = "",
    val showRenameDialog: Boolean = false,
    val renameTarget: String = "",    // uri or id
    val renameValue: String = "",
    val showDeleteDialog: Boolean = false,
    val showSortDialog: Boolean = false,
    val isLoading: Boolean = true,
    val errorMessage: String? = null
) {
    val filteredVideoFolders: List<MediaFolder> get() = videoFolders
        .filter { it.name.contains(searchQuery, ignoreCase = true) }
        .let { list ->
            when (sortBy) {
                OrganizerSortBy.NAME  -> list.sortedBy { it.name }
                OrganizerSortBy.SIZE  -> list.sortedByDescending { it.totalSize }
                OrganizerSortBy.DATE  -> list.sortedByDescending { it.lastModified }
                OrganizerSortBy.COUNT -> list.sortedByDescending { it.itemCount }
            }
        }

    val filteredAudioFolders: List<MediaFolder> get() = audioFolders
        .filter { it.name.contains(searchQuery, ignoreCase = true) }
        .let { list ->
            when (sortBy) {
                OrganizerSortBy.NAME  -> list.sortedBy { it.name }
                OrganizerSortBy.SIZE  -> list.sortedByDescending { it.totalSize }
                OrganizerSortBy.DATE  -> list.sortedByDescending { it.lastModified }
                OrganizerSortBy.COUNT -> list.sortedByDescending { it.itemCount }
            }
        }

    val selectedCount: Int get() = selectedItems.size
    val allSelected: Boolean get() = when (tab) {
        OrganizerTab.VIDEO -> folderVideos.isNotEmpty() && selectedItems.size == folderVideos.size
        OrganizerTab.AUDIO -> folderAudios.isNotEmpty() && selectedItems.size == folderAudios.size
    }
}

@HiltViewModel
class OrganizerViewModel @Inject constructor(
    private val mediaRepository: MediaRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(OrganizerUiState())
    val uiState: StateFlow<OrganizerUiState> = _uiState.asStateFlow()

    init {
        loadFolders()
    }

    private fun loadFolders() {
        viewModelScope.launch {
            mediaRepository.getVideoFolders()
                .combine(mediaRepository.getAudioFolders()) { vf, af -> Pair(vf, af) }
                .collect { (vf, af) ->
                    _uiState.update { it.copy(videoFolders = vf, audioFolders = af, isLoading = false) }
                }
        }
    }

    fun onTabSelected(tab: OrganizerTab) {
        _uiState.update { it.copy(tab = tab, selectedFolder = null, selectedItems = emptySet(), isSelectMode = false) }
    }

    fun onFolderClick(folder: MediaFolder) {
        _uiState.update { it.copy(selectedFolder = folder) }
        viewModelScope.launch {
            if (_uiState.value.tab == OrganizerTab.VIDEO) {
                mediaRepository.getVideosByFolder(folder.path).collect { videos ->
                    _uiState.update { it.copy(folderVideos = videos) }
                }
            } else {
                mediaRepository.getAudioByFolder(folder.path).collect { audios ->
                    _uiState.update { it.copy(folderAudios = audios) }
                }
            }
        }
    }

    fun onBackFromFolder() {
        _uiState.update {
            it.copy(
                selectedFolder = null,
                folderVideos   = emptyList(),
                folderAudios   = emptyList(),
                selectedItems  = emptySet(),
                isSelectMode   = false
            )
        }
    }

    // ── Search ────────────────────────────────────────────────────────
    fun onSearch(query: String) { _uiState.update { it.copy(searchQuery = query) } }
    fun clearSearch() { _uiState.update { it.copy(searchQuery = "") } }

    // ── Sort ──────────────────────────────────────────────────────────
    fun setSortBy(sort: OrganizerSortBy) { _uiState.update { it.copy(sortBy = sort, showSortDialog = false) } }
    fun showSortDialog() { _uiState.update { it.copy(showSortDialog = true) } }
    fun hideSortDialog() { _uiState.update { it.copy(showSortDialog = false) } }

    // ── Selection ─────────────────────────────────────────────────────
    fun enterSelectMode(id: Long) {
        _uiState.update { it.copy(isSelectMode = true, selectedItems = setOf(id)) }
    }

    fun toggleItem(id: Long) {
        _uiState.update { state ->
            val updated = state.selectedItems.toMutableSet()
            if (id in updated) updated.remove(id) else updated.add(id)
            state.copy(selectedItems = updated, isSelectMode = updated.isNotEmpty())
        }
    }

    fun selectAll() {
        val ids = when (_uiState.value.tab) {
            OrganizerTab.VIDEO -> _uiState.value.folderVideos.map { it.id }.toSet()
            OrganizerTab.AUDIO -> _uiState.value.folderAudios.map { it.id }.toSet()
        }
        _uiState.update { it.copy(selectedItems = ids) }
    }

    fun clearSelection() {
        _uiState.update { it.copy(selectedItems = emptySet(), isSelectMode = false) }
    }

    // ── Rename ────────────────────────────────────────────────────────
    fun startRename(currentName: String, id: String) {
        _uiState.update { it.copy(showRenameDialog = true, renameTarget = id, renameValue = currentName) }
    }

    fun onRenameValueChange(v: String) { _uiState.update { it.copy(renameValue = v) } }

    fun confirmRename() {
        val state = _uiState.value
        val newName = state.renameValue.trim()
        if (newName.isBlank()) return
        viewModelScope.launch {
            try {
                val id = state.renameTarget.toLongOrNull()
                if (id != null) {
                    if (state.tab == OrganizerTab.VIDEO) mediaRepository.renameVideo(id, newName)
                    else mediaRepository.renameAudio(id, newName)
                }
                _uiState.update { it.copy(showRenameDialog = false, renameTarget = "", renameValue = "") }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = "Rename failed: ${e.message}") }
            }
        }
    }

    fun cancelRename() { _uiState.update { it.copy(showRenameDialog = false, renameTarget = "", renameValue = "") } }

    // ── Delete ────────────────────────────────────────────────────────
    fun showDeleteDialog() { _uiState.update { it.copy(showDeleteDialog = true) } }
    fun hideDeleteDialog() { _uiState.update { it.copy(showDeleteDialog = false) } }

    fun confirmDeleteSelected() {
        val state = _uiState.value
        viewModelScope.launch {
            try {
                state.selectedItems.forEach { id ->
                    if (state.tab == OrganizerTab.VIDEO) mediaRepository.deleteVideo(id)
                    else mediaRepository.deleteAudio(id)
                }
                _uiState.update { it.copy(selectedItems = emptySet(), isSelectMode = false, showDeleteDialog = false) }
            } catch (e: Exception) {
                _uiState.update { it.copy(errorMessage = "Delete failed: ${e.message}", showDeleteDialog = false) }
            }
        }
    }

    fun clearError() { _uiState.update { it.copy(errorMessage = null) } }
}
