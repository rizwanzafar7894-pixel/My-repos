package com.darkwave.focus

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.darkwave.focus.viewmodel.*
import com.darkwave.common.ui.theme.*

@Composable
fun FocusScreen(
    onBack: () -> Unit,
    viewModel: FocusViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val scrollState = rememberScrollState()

    Column(
        modifier            = Modifier.fillMaxSize().background(Background).verticalScroll(scrollState),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top bar
        Row(
            modifier          = Modifier.fillMaxWidth().background(White).padding(horizontal = 4.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = TextPrimary) }
            Text("Focus Timer", fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary, modifier = Modifier.weight(1f))
            Text("${state.completedSessions} 🍅", fontSize = 14.sp, color = TextSecondary)
            Spacer(Modifier.width(8.dp))
        }

        Spacer(Modifier.height(20.dp))

        // Phase selector chips
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FocusPhase.entries.forEach { phase ->
                FilterChip(
                    selected = state.phase == phase,
                    onClick  = { viewModel.setPhase(phase) },
                    enabled  = state.timerState == TimerState.IDLE,
                    label    = {
                        Text(when (phase) {
                            FocusPhase.FOCUS       -> "Focus"
                            FocusPhase.SHORT_BREAK -> "Short Break"
                            FocusPhase.LONG_BREAK  -> "Long Break"
                        })
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = state.phaseColor,
                        selectedLabelColor     = White
                    )
                )
            }
        }

        Spacer(Modifier.height(32.dp))

        // Animated ring timer
        AnimatedTimerRing(
            progress    = state.progress,
            timeLabel   = state.timeLabel,
            phaseLabel  = when (state.phase) {
                FocusPhase.FOCUS       -> "Focus"
                FocusPhase.SHORT_BREAK -> "Short Break"
                FocusPhase.LONG_BREAK  -> "Long Break"
            },
            color       = state.phaseColor,
            isRunning   = state.timerState == TimerState.RUNNING,
            modifier    = Modifier.size(240.dp)
        )

        Spacer(Modifier.height(36.dp))

        // Controls
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment     = Alignment.CenterVertically
        ) {
            // Reset
            IconButton(
                onClick  = viewModel::resetTimer,
                modifier = Modifier.size(52.dp).clip(CircleShape).background(SurfaceVariant)
            ) {
                Icon(Icons.Default.Refresh, "Reset", tint = TextSecondary, modifier = Modifier.size(24.dp))
            }

            // Play / Pause — large
            Box(
                modifier         = Modifier.size(68.dp).clip(CircleShape).background(state.phaseColor),
                contentAlignment = Alignment.Center
            ) {
                IconButton(
                    onClick  = { if (state.timerState == TimerState.RUNNING) viewModel.pauseTimer() else viewModel.startTimer() },
                    modifier = Modifier.fillMaxSize()
                ) {
                    Icon(
                        if (state.timerState == TimerState.RUNNING) Icons.Default.Pause else Icons.Default.PlayArrow,
                        null, tint = White, modifier = Modifier.size(34.dp)
                    )
                }
            }

            // Skip
            IconButton(
                onClick  = viewModel::skipPhase,
                modifier = Modifier.size(52.dp).clip(CircleShape).background(SurfaceVariant)
            ) {
                Icon(Icons.Default.SkipNext, "Skip", tint = TextSecondary, modifier = Modifier.size(24.dp))
            }
        }

        Spacer(Modifier.height(32.dp))

        // Session progress dots
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            repeat(state.sessionsBeforeLong) { i ->
                Box(
                    modifier = Modifier.size(12.dp).clip(CircleShape)
                        .background(if (i < (state.completedSessions % state.sessionsBeforeLong)) state.phaseColor else Color(0xFFE0E0E0))
                )
            }
        }

        Spacer(Modifier.height(28.dp))

        // Settings card
        Card(
            shape     = RoundedCornerShape(16.dp),
            colors    = CardDefaults.cardColors(containerColor = White),
            elevation = CardDefaults.cardElevation(2.dp),
            modifier  = Modifier.fillMaxWidth().padding(horizontal = 16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text("Settings", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
                TimerSliderRow("Focus",       state.focusMinutes,      5, 60, viewModel::setFocusMinutes)
                TimerSliderRow("Short Break", state.shortBreakMinutes, 1, 15, viewModel::setShortBreak)
                TimerSliderRow("Long Break",  state.longBreakMinutes,  5, 30, viewModel::setLongBreak)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Auto-start Breaks", fontSize = 13.sp, color = TextPrimary, modifier = Modifier.weight(1f))
                    Switch(
                        checked         = state.autoStartBreaks,
                        onCheckedChange = viewModel::setAutoStartBreaks,
                        colors          = SwitchDefaults.colors(checkedTrackColor = state.phaseColor)
                    )
                }
            }
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun AnimatedTimerRing(
    progress: Float,
    timeLabel: String,
    phaseLabel: String,
    color: Color,
    isRunning: Boolean,
    modifier: Modifier = Modifier
) {
    val animatedProgress by animateFloatAsState(
        targetValue   = progress,
        animationSpec = tween(500, easing = LinearEasing),
        label         = "timerProgress"
    )

    // Pulse animation when running
    val pulseScale by rememberInfiniteTransition(label = "pulse").animateFloat(
        initialValue   = 1f,
        targetValue    = 1.04f,
        animationSpec  = infiniteRepeatable(tween(1000, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label          = "pulseScale"
    )

    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 16.dp.toPx()
            val inset  = stroke / 2
            val arcRect = Size(size.width - stroke, size.height - stroke)

            // Background track
            drawArc(
                color      = Color(0xFFE8EAF6),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter  = false,
                topLeft    = Offset(inset, inset),
                size       = arcRect,
                style      = Stroke(stroke, cap = StrokeCap.Round)
            )
            // Progress arc
            if (animatedProgress > 0f) {
                drawArc(
                    color      = color,
                    startAngle = -90f,
                    sweepAngle = 360f * animatedProgress,
                    useCenter  = false,
                    topLeft    = Offset(inset, inset),
                    size       = arcRect,
                    style      = Stroke(stroke, cap = StrokeCap.Round)
                )
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text       = timeLabel,
                fontSize   = 48.sp,
                fontWeight = FontWeight.Bold,
                color      = TextPrimary,
                letterSpacing = 2.sp
            )
            Text(
                text     = phaseLabel,
                fontSize = 14.sp,
                color    = color,
                fontWeight = FontWeight.Medium
            )
            if (isRunning) {
                Spacer(Modifier.height(4.dp))
                Box(Modifier.size(8.dp).clip(CircleShape).background(color))
            }
        }
    }
}

@Composable
private fun TimerSliderRow(label: String, value: Int, min: Int, max: Int, onChange: (Int) -> Unit) {
    Column {
        Row {
            Text(label, fontSize = 13.sp, color = TextPrimary, modifier = Modifier.weight(1f))
            Text("$value min", fontSize = 13.sp, color = Purple500, fontWeight = FontWeight.Medium)
        }
        Slider(
            value         = value.toFloat(),
            onValueChange = { onChange(it.toInt()) },
            valueRange    = min.toFloat()..max.toFloat(),
            steps         = max - min - 1,
            colors        = SliderDefaults.colors(thumbColor = Purple500, activeTrackColor = Purple500),
            modifier      = Modifier.fillMaxWidth()
        )
    }
}
