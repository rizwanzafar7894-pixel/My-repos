package com.darkwave.focus.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject

enum class FocusPhase { FOCUS, SHORT_BREAK, LONG_BREAK }
enum class TimerState  { IDLE, RUNNING, PAUSED }

data class FocusUiState(
    val phase: FocusPhase = FocusPhase.FOCUS,
    val timerState: TimerState = TimerState.IDLE,
    val focusMinutes: Int = 25,
    val shortBreakMinutes: Int = 5,
    val longBreakMinutes: Int = 15,
    val sessionsBeforeLong: Int = 4,
    val completedSessions: Int = 0,
    val remainingSeconds: Int = 25 * 60,
    val totalSeconds: Int = 25 * 60,
    val autoStartBreaks: Boolean = true
) {
    val progress: Float get() = if (totalSeconds == 0) 0f else 1f - (remainingSeconds.toFloat() / totalSeconds)
    val minutes: Int get() = remainingSeconds / 60
    val seconds: Int get() = remainingSeconds % 60
    val timeLabel: String get() = "%02d:%02d".format(minutes, seconds)

    val phaseColor: androidx.compose.ui.graphics.Color get() = when (phase) {
        FocusPhase.FOCUS       -> androidx.compose.ui.graphics.Color(0xFF5C6BC0)
        FocusPhase.SHORT_BREAK -> androidx.compose.ui.graphics.Color(0xFF43A047)
        FocusPhase.LONG_BREAK  -> androidx.compose.ui.graphics.Color(0xFF0288D1)
    }
}

@HiltViewModel
class FocusViewModel @Inject constructor() : ViewModel() {

    private val _uiState = MutableStateFlow(FocusUiState())
    val uiState: StateFlow<FocusUiState> = _uiState.asStateFlow()

    private var timerJob: Job? = null

    fun startTimer() {
        if (_uiState.value.timerState == TimerState.IDLE) {
            val state = _uiState.value
            _uiState.update { it.copy(totalSeconds = it.remainingSeconds) }
        }
        _uiState.update { it.copy(timerState = TimerState.RUNNING) }
        timerJob = viewModelScope.launch {
            while (isActive) {
                delay(1000L)
                val current = _uiState.value
                if (current.timerState != TimerState.RUNNING) break

                val newRemaining = current.remainingSeconds - 1
                if (newRemaining <= 0) {
                    onPhaseComplete()
                    break
                }
                _uiState.update { it.copy(remainingSeconds = newRemaining) }
            }
        }
    }

    fun pauseTimer() {
        timerJob?.cancel()
        _uiState.update { it.copy(timerState = TimerState.PAUSED) }
    }

    fun resetTimer() {
        timerJob?.cancel()
        _uiState.update { state ->
            val secs = phaseSeconds(state.phase, state)
            state.copy(timerState = TimerState.IDLE, remainingSeconds = secs, totalSeconds = secs)
        }
    }

    fun skipPhase() {
        timerJob?.cancel()
        onPhaseComplete()
    }

    fun setPhase(phase: FocusPhase) {
        timerJob?.cancel()
        val secs = phaseSeconds(phase, _uiState.value)
        _uiState.update { it.copy(phase = phase, timerState = TimerState.IDLE, remainingSeconds = secs, totalSeconds = secs) }
    }

    fun setFocusMinutes(m: Int)      { _uiState.update { it.copy(focusMinutes = m) }; if (_uiState.value.phase == FocusPhase.FOCUS) resetTimer() }
    fun setShortBreak(m: Int)        { _uiState.update { it.copy(shortBreakMinutes = m) } }
    fun setLongBreak(m: Int)         { _uiState.update { it.copy(longBreakMinutes = m) } }
    fun setAutoStartBreaks(v: Boolean){ _uiState.update { it.copy(autoStartBreaks = v) } }

    private fun onPhaseComplete() {
        val state = _uiState.value
        val completed = state.completedSessions + (if (state.phase == FocusPhase.FOCUS) 1 else 0)
        val nextPhase = when (state.phase) {
            FocusPhase.FOCUS       -> if (completed % state.sessionsBeforeLong == 0) FocusPhase.LONG_BREAK else FocusPhase.SHORT_BREAK
            FocusPhase.SHORT_BREAK,
            FocusPhase.LONG_BREAK  -> FocusPhase.FOCUS
        }
        val secs = phaseSeconds(nextPhase, state)
        _uiState.update {
            it.copy(
                phase              = nextPhase,
                completedSessions  = completed,
                remainingSeconds   = secs,
                totalSeconds       = secs,
                timerState         = TimerState.IDLE
            )
        }
        if (state.autoStartBreaks) startTimer()
    }

    private fun phaseSeconds(phase: FocusPhase, state: FocusUiState) = when (phase) {
        FocusPhase.FOCUS       -> state.focusMinutes * 60
        FocusPhase.SHORT_BREAK -> state.shortBreakMinutes * 60
        FocusPhase.LONG_BREAK  -> state.longBreakMinutes * 60
    }

    override fun onCleared() { timerJob?.cancel(); super.onCleared() }
}
