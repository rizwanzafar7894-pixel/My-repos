# DarkWave — Integration Guide
## Sabhi naye files kahan copy karni hain

---

## 📁 Folder Structure

```
dw_output/
├── patch/          ← B5 App module mein jaane wali files
├── tools/          ← Settings tools screens
├── subtitles/      ← Subtitle system
└── gestures/       ← Video player gesture overlay
```

---

## ✅ STEP 1 — Patch Files (sabse pehle karo)

| File | Kahan copy karein |
|------|------------------|
| `patch/AndroidManifest.xml` | `app/src/main/AndroidManifest.xml` **REPLACE** |
| `patch/strings.xml` | `app/src/main/res/values/strings.xml` **REPLACE** |
| `patch/MainActivity.kt` | `app/src/main/kotlin/com/darkwave/app/MainActivity.kt` **REPLACE** |
| `patch/PlaybackService.kt` | `app/src/main/kotlin/com/darkwave/app/service/PlaybackService.kt` **REPLACE** |
| `patch/DWMediaButtonReceiver.kt` | `app/src/main/kotlin/com/darkwave/app/service/DWMediaButtonReceiver.kt` **NEW** |
| `patch/DarkWaveMiniWidget.kt` | `app/src/main/kotlin/com/darkwave/app/widget/DarkWaveMiniWidget.kt` **NEW** |
| `patch/DarkWaveLargeWidget.kt` | `app/src/main/kotlin/com/darkwave/app/widget/DarkWaveLargeWidget.kt` **NEW** |
| `patch/WidgetControlReceiver.kt` | `app/src/main/kotlin/com/darkwave/app/widget/WidgetControlReceiver.kt` **NEW** |

Widget XML files B17 bundle mein already hain:
- Copy `widget_mini.xml`, `widget_large.xml`, `widget_background.xml` → `app/src/main/res/layout/`
- Copy `widget_mini_info.xml`, `widget_large_info.xml` → `app/src/main/res/xml/`
- Add `ic_music_note_placeholder` drawable (any placeholder music icon)

---

## ✅ STEP 2 — Tools Screens

Create folder: `feature/settings/src/main/kotlin/com/darkwave/settings/tools/`

| File | Description |
|------|-------------|
| `tools/BpmDetectorScreen.kt` | Tap + Mic BPM detection |
| `tools/MetronomeScreen.kt` | Visual pendulum metronome |
| `tools/TunerScreen.kt` | Chromatic/Guitar/Bass/Ukulele tuner |
| `tools/RecorderScreen.kt` | Audio recorder with waveform |
| `tools/AnalyzerScreen.kt` | Frequency spectrum visualizer |
| `tools/EqualizerScreen.kt` | 10-band EQ with presets |
| `tools/SettingsSubScreens.kt` | Download, Storage, Network settings |

Sab files copy karein: `feature/settings/src/main/kotlin/com/darkwave/settings/tools/`

---

## ✅ STEP 3 — Gesture Controls

| File | Kahan copy karein |
|------|------------------|
| `gestures/PlayerGestureOverlay.kt` | `feature/player/src/main/kotlin/com/darkwave/player/ui/` |

**VideoPlayerScreen.kt mein integrate karo:**
```kotlin
// Apne main Box ke andar, VideoSurface ke baad add karo:
PlayerGestureOverlay(
    durationMs = viewModel.duration,
    positionMs = viewModel.position,
    onSeekTo   = viewModel::seekTo,
    onPlayPause = viewModel::togglePlayPause,
    onToggleControls = { showControls = !showControls }
)
```

---

## ✅ STEP 4 — Subtitle System

| File | Kahan copy karein |
|------|------------------|
| `subtitles/SubtitleSystem.kt` | `feature/player/src/main/kotlin/com/darkwave/player/subtitle/` |

**VideoPlayerViewModel.kt mein add karo:**
```kotlin
val subtitleManager = SubtitleManager()
var currentSubtitle by mutableStateOf<String?>(null)
    private set

fun onPositionChanged(posMs: Long) {
    currentSubtitle = subtitleManager.getSubtitleAt(posMs)
}

fun loadSubtitle(file: java.io.File) {
    subtitleManager.load(file)
}
```

**VideoPlayerScreen.kt mein add karo:**
```kotlin
// SubtitleOverlay apne main Box mein
SubtitleOverlay(
    subtitle = viewModel.currentSubtitle,
    bottomPadding = if (showControls) 80 else 48
)
```

---

## ✅ STEP 5 — Widget Push in MusicPlayerViewModel

**MusicPlayerViewModel.kt ke andar jab bhi playback state change ho:**
```kotlin
// Application context inject karo
@HiltViewModel
class MusicPlayerViewModel @Inject constructor(
    application: Application,  // add this
    ...
) : AndroidViewModel(application) {  // change ViewModel to AndroidViewModel

    private fun pushWidgets() {
        val ctx = getApplication<Application>()
        val bmp: Bitmap? = null // load from currentSong.albumArtUri using Coil/Glide

        DarkWaveMiniWidget.push(
            context   = ctx,
            title     = currentSong?.title  ?: "",
            artist    = currentSong?.artist ?: "",
            isPlaying = isPlaying,
            albumArt  = bmp
        )
        DarkWaveLargeWidget.push(
            context   = ctx,
            title     = currentSong?.title  ?: "",
            artist    = currentSong?.artist ?: "",
            album     = currentSong?.album  ?: "",
            isPlaying = isPlaying,
            albumArt  = bmp,
            progress  = ((positionMs.toFloat() / durationMs) * 100).toInt(),
            position  = positionMs.toFormattedDuration(),
            duration  = durationMs.toFormattedDuration()
        )
    }
}
// pushWidgets() ko call karo: togglePlayPause(), skipNext(), skipPrev() ke andar
```

---

## ✅ STEP 6 — Build.gradle update (feature:settings)

`feature/settings/build.gradle.kts` mein yeh dependencies verify karo:
```kotlin
dependencies {
    implementation(libs.accompanist.permissions)  // for mic permission in tools
    implementation(libs.androidx.compose.material.icons)
}
```

---

## 🐛 Known Issues Fixed

| Issue | Fix |
|-------|-----|
| `BIND_INPUT_METHOD` wrong permission on PlaybackService | Removed in new AndroidManifest |
| `darkTheme = false` hardcoded | Fixed to use `isSystemInDarkTheme()` |
| Widget strings missing | Added to strings.xml |
| StorageTab hardcoded 32GB | Fixed with real `StatFs` in StorageScreen |
| All tool screens missing | Created all 6 screens + 3 settings sub-screens |
| No subtitle support | Full SRT/VTT/ASS parser + overlay added |
| No gesture controls | Volume/Brightness/Seek gestures added |

---

## 📊 After Integration — Feature Comparison

| Feature | Before | After |
|---------|--------|-------|
| Build success | ❌ Missing screens | ✅ |
| PlaybackService | ⚠️ Wrong permission | ✅ Fixed |
| Widgets | ❌ Not wired | ✅ Mini + Large |
| Tool screens | ❌ All missing | ✅ 6 screens done |
| Subtitles | ❌ None | ✅ SRT/VTT/ASS |
| Gestures | ❌ None | ✅ Vol/Bright/Seek |
| Dark mode | ❌ Locked light | ✅ System follows |
| Storage screen | ❌ Fake 32GB | ✅ Real StatFs |
