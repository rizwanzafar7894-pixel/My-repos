package com.darkwave.data.db.dao

import androidx.room.*
import com.darkwave.domain.model.VideoItem
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoDao {
    @Query("SELECT * FROM videos ORDER BY dateAdded DESC")
    fun getAllVideos(): Flow<List<VideoItem>>

    @Query("SELECT * FROM videos WHERE folderPath = :folderPath ORDER BY dateAdded DESC")
    fun getVideosByFolder(folderPath: String): Flow<List<VideoItem>>

    @Query("SELECT * FROM videos WHERE id = :id LIMIT 1")
    suspend fun getVideoById(id: Long): VideoItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(videos: List<VideoItem>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(video: VideoItem)

    @Query("UPDATE videos SET playCount = :playCount, lastPlayedAt = :lastPlayedAt WHERE id = :id")
    suspend fun updatePlayCount(id: Long, playCount: Int, lastPlayedAt: Long)

    @Query("UPDATE videos SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavorite(id: Long, isFavorite: Boolean)

    @Query("UPDATE videos SET isBookmarked = :isBookmarked, bookmarkPosition = :position WHERE id = :id")
    suspend fun updateBookmark(id: Long, isBookmarked: Boolean, position: Long)

    @Query("UPDATE videos SET isInVault = :inVault WHERE id = :id")
    suspend fun updateVault(id: Long, inVault: Boolean)

    @Query("UPDATE videos SET title = :title WHERE id = :id")
    suspend fun updateTitle(id: Long, title: String)

    @Query("DELETE FROM videos WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM videos")
    suspend fun deleteAll()

    @Query("SELECT DISTINCT folderPath, folderName FROM videos")
    suspend fun getDistinctFolders(): List<FolderInfo>

    @Query("SELECT COUNT(*) FROM videos WHERE folderPath = :path")
    suspend fun countInFolder(path: String): Int

    @Query("SELECT SUM(size) FROM videos WHERE folderPath = :path")
    suspend fun totalSizeInFolder(path: String): Long

    @Query("SELECT MAX(dateModified) FROM videos WHERE folderPath = :path")
    suspend fun lastModifiedInFolder(path: String): Long
}

data class FolderInfo(val folderPath: String, val folderName: String)
