package com.darkwave.data.worker

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.darkwave.domain.repository.MediaRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import timber.log.Timber

@HiltWorker
class MediaScanWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted workerParams: WorkerParameters,
    private val mediaRepository: MediaRepository
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            mediaRepository.scanMedia()
            Timber.d("Media scan complete")
            Result.success()
        } catch (e: Exception) {
            Timber.e(e, "Media scan failed")
            Result.retry()
        }
    }

    companion object {
        const val WORK_NAME = "media_scan"

        fun runNow(context: Context) {
            val request = OneTimeWorkRequestBuilder<MediaScanWorker>()
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                        .build()
                )
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                WORK_NAME,
                ExistingWorkPolicy.REPLACE,
                request
            )
        }
    }
}
