package com.darkwave.data.repository

import com.darkwave.data.db.dao.WatchEventDao
import com.darkwave.domain.model.WatchEvent
import com.darkwave.domain.model.WatchStats
import com.darkwave.domain.repository.AnalyticsRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AnalyticsRepositoryImpl @Inject constructor(
    private val dao: WatchEventDao
) : AnalyticsRepository {

    override suspend fun recordWatchEvent(event: WatchEvent) = dao.insert(event)

    override fun getWatchStats(): Flow<WatchStats> {
        return dao.getTotalWatchTimeMs().map { totalMs ->
            val since = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(30)
            val daily       = getDailyWatchMs(7)
            val genres      = getTopGenres(5)
            val artists     = getTopArtists(5)
            val topVideos   = getTopVideos(5)
            val videosCount = getTotalVideosWatched()
            val songsCount  = getTotalSongsPlayed()

            WatchStats(
                totalWatchTimeMs  = totalMs ?: 0L,
                totalVideosWatched = videosCount,
                totalSongsPlayed  = songsCount,
                dailyWatchMs      = daily,
                topGenres         = genres,
                topArtists        = artists,
                topVideos         = topVideos
            )
        }
    }

    override suspend fun getTotalWatchTimeMs(): Long =
        dao.getTotalWatchTimeMs() as? Long ?: 0L

    override suspend fun getTotalVideosWatched(): Int = dao.getTotalVideosWatched()

    override suspend fun getTotalSongsPlayed(): Int = dao.getTotalSongsPlayed()

    override suspend fun getDailyWatchMs(days: Int): List<Long> {
        val since = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(days.toLong())
        val breakdown = dao.getDailyBreakdown(since)
        val result = MutableList(7) { 0L }
        breakdown.forEach { day ->
            if (day.dayOfWeek in 0..6) result[day.dayOfWeek] = day.totalMs
        }
        return result
    }

    override suspend fun getTopGenres(limit: Int): Map<String, Int> {
        val since = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(30)
        return dao.getTopGenres(since, limit).associate { it.genre to it.count }
    }

    override suspend fun getTopArtists(limit: Int): Map<String, Int> {
        val since = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(30)
        return dao.getTopArtists(since, limit).associate { it.artist to it.count }
    }

    override suspend fun getTopVideos(limit: Int): List<Pair<String, Int>> {
        val since = System.currentTimeMillis() - TimeUnit.DAYS.toMillis(30)
        return dao.getTopVideos(since, limit).map { Pair(it.title, it.count) }
    }

    override suspend fun clearAllStats() = dao.deleteAll()
}
