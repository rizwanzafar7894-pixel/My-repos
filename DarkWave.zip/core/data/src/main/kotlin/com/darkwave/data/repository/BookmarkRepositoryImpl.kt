package com.darkwave.data.repository

import com.darkwave.data.db.dao.BookmarkDao
import com.darkwave.domain.model.Bookmark
import com.darkwave.domain.model.BookmarkMediaType
import com.darkwave.domain.repository.BookmarkRepository
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BookmarkRepositoryImpl @Inject constructor(
    private val dao: BookmarkDao
) : BookmarkRepository {
    override fun getAllBookmarks(): Flow<List<Bookmark>> = dao.getAllBookmarks()
    override fun getBookmarksByType(type: BookmarkMediaType): Flow<List<Bookmark>> =
        dao.getBookmarksByType(type)
    override suspend fun addBookmark(bookmark: Bookmark): Long = dao.insert(bookmark)
    override suspend fun deleteBookmark(id: Long) = dao.deleteById(id)
    override suspend fun updateBookmarkNote(id: Long, note: String) = dao.updateNote(id, note)
    override suspend fun getBookmarkForMedia(mediaId: Long): Bookmark? =
        dao.getBookmarkForMedia(mediaId)
}
