package com.darkwave.data.repository

import android.content.Context
import android.net.Uri
import com.darkwave.data.db.dao.AudioDao
import com.darkwave.data.db.dao.VaultItemDao
import com.darkwave.data.db.dao.VideoDao
import com.darkwave.data.scanner.MediaScanner
import com.darkwave.domain.model.AudioItem
import com.darkwave.domain.model.MediaFolder
import com.darkwave.domain.model.VaultItem
import com.darkwave.domain.model.VaultMediaType
import com.darkwave.domain.model.VideoItem
import com.darkwave.domain.repository.MediaRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import timber.log.Timber
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MediaRepositoryImpl @Inject constructor(
    @ApplicationContext private val context: Context,
    private val videoDao: VideoDao,
    private val audioDao: AudioDao,
    private val vaultItemDao: VaultItemDao,
    private val scanner: MediaScanner
) : MediaRepository {

    // ── Videos ───────────────────────────────────────────────────────────────
    override fun getAllVideos(): Flow<List<VideoItem>> = videoDao.getAllVideos()

    override fun getVideosByFolder(folderPath: String): Flow<List<VideoItem>> =
        videoDao.getVideosByFolder(folderPath)

    override suspend fun getVideoById(id: Long): VideoItem? = videoDao.getVideoById(id)

    override suspend fun updateVideoPlayCount(id: Long, playCount: Int, lastPlayedAt: Long) =
        videoDao.updatePlayCount(id, playCount, lastPlayedAt)

    override suspend fun toggleVideoFavorite(id: Long, isFavorite: Boolean) =
        videoDao.updateFavorite(id, isFavorite)

    override suspend fun toggleVideoBookmark(id: Long, isBookmarked: Boolean, position: Long) =
        videoDao.updateBookmark(id, isBookmarked, position)

    override suspend fun setVideoVault(id: Long, inVault: Boolean) =
        videoDao.updateVault(id, inVault)

    override suspend fun renameVideo(id: Long, newTitle: String) =
        videoDao.updateTitle(id, newTitle)

    override suspend fun deleteVideo(id: Long) = videoDao.deleteById(id)

    // ── Audio ─────────────────────────────────────────────────────────────────
    override fun getAllAudio(): Flow<List<AudioItem>> = audioDao.getAllAudio()

    override fun getAudioByFolder(folderPath: String): Flow<List<AudioItem>> =
        audioDao.getAudioByFolder(folderPath)

    override suspend fun getAudioById(id: Long): AudioItem? = audioDao.getAudioById(id)

    override suspend fun updateAudioPlayCount(id: Long, playCount: Int, lastPlayedAt: Long) =
        audioDao.updatePlayCount(id, playCount, lastPlayedAt)

    override suspend fun toggleAudioFavorite(id: Long, isFavorite: Boolean) =
        audioDao.updateFavorite(id, isFavorite)

    override suspend fun toggleAudioLiked(id: Long, isLiked: Boolean) =
        audioDao.updateLiked(id, isLiked)

    override suspend fun setAudioVault(id: Long, inVault: Boolean) =
        audioDao.updateVault(id, inVault)

    override suspend fun renameAudio(id: Long, newTitle: String) =
        audioDao.updateTitle(id, newTitle)

    override suspend fun deleteAudio(id: Long) = audioDao.deleteById(id)

    // ── Folders ───────────────────────────────────────────────────────────────
    override fun getVideoFolders(): Flow<List<MediaFolder>> =
        videoDao.getAllVideos().map { videos ->
            videos.groupBy { it.folderPath }.map { (path, items) ->
                MediaFolder(
                    name         = items.first().folderName,
                    path         = path,
                    videoCount   = items.size,
                    totalSize    = items.sumOf { it.size },
                    coverArtUri  = items.first().uri,
                    lastModified = items.maxOf { it.dateModified }
                )
            }.sortedByDescending { it.lastModified }
        }

    override fun getAudioFolders(): Flow<List<MediaFolder>> =
        audioDao.getAllAudio().map { audio ->
            audio.groupBy { it.folderPath }.map { (path, items) ->
                MediaFolder(
                    name         = items.first().folderName,
                    path         = path,
                    audioCount   = items.size,
                    totalSize    = items.sumOf { it.size },
                    coverArtUri  = items.firstOrNull { it.albumArtUri.isNotBlank() }?.albumArtUri ?: "",
                    lastModified = items.maxOf { it.dateModified }
                )
            }.sortedByDescending { it.lastModified }
        }

    // ── Vault  (FIX: Implemented missing vault methods) ──────────────────────
    override fun getVaultItems(): Flow<List<VaultItem>> = vaultItemDao.getAllItems()

    override suspend fun addToVault(uri: String, name: String, mediaType: VaultMediaType) {
        try {
            // Copy file to private vault directory
            val vaultDir = File(context.filesDir, "vault").apply { mkdirs() }
            val ext = when (mediaType) {
                VaultMediaType.VIDEO -> ".mp4"
                VaultMediaType.AUDIO -> ".mp3"
                VaultMediaType.IMAGE -> ".jpg"
                VaultMediaType.OTHER -> ""
            }
            val destFile = File(vaultDir, "${System.currentTimeMillis()}$ext")

            context.contentResolver.openInputStream(Uri.parse(uri))?.use { input ->
                destFile.outputStream().use { output -> input.copyTo(output) }
            }

            val originalSize = context.contentResolver
                .openFileDescriptor(Uri.parse(uri), "r")?.use { it.statSize } ?: 0L

            vaultItemDao.insert(
                VaultItem(
                    originalPath = uri,
                    vaultPath    = destFile.absolutePath,
                    title        = name,
                    mimeType     = when (mediaType) {
                        VaultMediaType.VIDEO -> "video/*"
                        VaultMediaType.AUDIO -> "audio/*"
                        VaultMediaType.IMAGE -> "image/*"
                        VaultMediaType.OTHER -> "*/*"
                    },
                    size      = originalSize,
                    mediaType = mediaType
                )
            )
        } catch (e: Exception) {
            Timber.e(e, "Failed to add to vault")
        }
    }

    override suspend fun removeFromVault(id: Long) {
        val item = vaultItemDao.getById(id)
        item?.let {
            File(it.vaultPath).delete()
            vaultItemDao.deleteById(id)
        }
    }

    // ── Scan ──────────────────────────────────────────────────────────────────
    override suspend fun scanMedia() {
        val videos = scanner.scanVideos()
        val audio  = scanner.scanAudio()
        if (videos.isNotEmpty()) videoDao.insertAll(videos)
        if (audio.isNotEmpty())  audioDao.insertAll(audio)
    }
}
