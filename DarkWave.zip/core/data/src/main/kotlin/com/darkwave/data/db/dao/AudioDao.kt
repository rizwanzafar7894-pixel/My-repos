package com.darkwave.data.db.dao

import androidx.room.*
import com.darkwave.domain.model.AudioItem
import kotlinx.coroutines.flow.Flow

@Dao
interface AudioDao {
    @Query("SELECT * FROM audio ORDER BY dateAdded DESC")
    fun getAllAudio(): Flow<List<AudioItem>>

    @Query("SELECT * FROM audio WHERE folderPath = :folderPath ORDER BY dateAdded DESC")
    fun getAudioByFolder(folderPath: String): Flow<List<AudioItem>>

    @Query("SELECT * FROM audio WHERE id = :id LIMIT 1")
    suspend fun getAudioById(id: Long): AudioItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(audio: List<AudioItem>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(audio: AudioItem)

    @Query("UPDATE audio SET playCount = :playCount, lastPlayedAt = :lastPlayedAt WHERE id = :id")
    suspend fun updatePlayCount(id: Long, playCount: Int, lastPlayedAt: Long)

    @Query("UPDATE audio SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavorite(id: Long, isFavorite: Boolean)

    @Query("UPDATE audio SET isLiked = :isLiked WHERE id = :id")
    suspend fun updateLiked(id: Long, isLiked: Boolean)

    @Query("UPDATE audio SET isInVault = :inVault WHERE id = :id")
    suspend fun updateVault(id: Long, inVault: Boolean)

    @Query("UPDATE audio SET title = :title WHERE id = :id")
    suspend fun updateTitle(id: Long, title: String)

    @Query("DELETE FROM audio WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM audio")
    suspend fun deleteAll()

    @Query("SELECT DISTINCT folderPath, folderName FROM audio")
    suspend fun getDistinctFolders(): List<FolderInfo>

    @Query("SELECT DISTINCT artist FROM audio WHERE artist != '' ORDER BY artist ASC")
    fun getAllArtists(): Flow<List<String>>

    @Query("SELECT DISTINCT album FROM audio WHERE album != '' ORDER BY album ASC")
    fun getAllAlbums(): Flow<List<String>>

    @Query("SELECT DISTINCT genre FROM audio WHERE genre != '' ORDER BY genre ASC")
    fun getAllGenres(): Flow<List<String>>

    @Query("SELECT * FROM audio WHERE artist = :artist ORDER BY dateAdded DESC")
    fun getAudioByArtist(artist: String): Flow<List<AudioItem>>

    @Query("SELECT * FROM audio WHERE album = :album ORDER BY trackNumber ASC")
    fun getAudioByAlbum(album: String): Flow<List<AudioItem>>

    @Query("SELECT * FROM audio WHERE genre = :genre ORDER BY dateAdded DESC")
    fun getAudioByGenre(genre: String): Flow<List<AudioItem>>

    @Query("SELECT * FROM audio WHERE isLiked = 1 ORDER BY dateAdded DESC")
    fun getLikedAudio(): Flow<List<AudioItem>>

    @Query("SELECT * FROM audio WHERE isDownloaded = 1 ORDER BY dateAdded DESC")
    fun getDownloadedAudio(): Flow<List<AudioItem>>

    @Query("SELECT * FROM audio ORDER BY playCount DESC LIMIT :limit")
    suspend fun getTopPlayed(limit: Int): List<AudioItem>

    @Query("SELECT * FROM audio ORDER BY lastPlayedAt DESC LIMIT :limit")
    suspend fun getRecentlyPlayed(limit: Int): List<AudioItem>
}
