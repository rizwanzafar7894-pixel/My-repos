package com.darkwave.data.db.dao

import androidx.room.*
import com.darkwave.domain.model.AudioItem
import com.darkwave.domain.model.Playlist
import com.darkwave.domain.model.PlaylistSong
import com.darkwave.domain.model.PlaylistType
import kotlinx.coroutines.flow.Flow

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY createdAt DESC")
    fun getAllPlaylists(): Flow<List<Playlist>>

    @Query("SELECT * FROM playlists WHERE id = :id LIMIT 1")
    suspend fun getPlaylistById(id: Long): Playlist?

    @Query("SELECT * FROM playlists WHERE playlistType = :type LIMIT 1")
    suspend fun getPlaylistByType(type: PlaylistType): Playlist?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: Playlist): Long

    @Update
    suspend fun updatePlaylist(playlist: Playlist)

    @Query("DELETE FROM playlists WHERE id = :id")
    suspend fun deletePlaylist(id: Long)

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPlaylistSong(song: PlaylistSong)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId AND audioId = :audioId")
    suspend fun removePlaylistSong(playlistId: Long, audioId: Long)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId")
    suspend fun clearPlaylistSongs(playlistId: Long)

    @Query("""
        SELECT a.* FROM audio a
        INNER JOIN playlist_songs ps ON a.id = ps.audioId
        WHERE ps.playlistId = :playlistId
        ORDER BY ps.position ASC
    """)
    fun getPlaylistSongs(playlistId: Long): Flow<List<AudioItem>>

    @Query("SELECT COUNT(*) FROM playlist_songs WHERE playlistId = :playlistId")
    suspend fun getSongCount(playlistId: Long): Int

    @Query("""
        SELECT SUM(a.duration) FROM audio a
        INNER JOIN playlist_songs ps ON a.id = ps.audioId
        WHERE ps.playlistId = :playlistId
    """)
    suspend fun getTotalDuration(playlistId: Long): Long

    @Query("UPDATE playlists SET songCount = :count, totalDuration = :duration, updatedAt = :updatedAt WHERE id = :id")
    suspend fun updatePlaylistStats(id: Long, count: Int, duration: Long, updatedAt: Long)
}
