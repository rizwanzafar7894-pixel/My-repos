package com.darkwave.data.db.dao

import androidx.room.*
import com.darkwave.domain.model.WatchEvent
import kotlinx.coroutines.flow.Flow

@Dao
interface WatchEventDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(event: WatchEvent)

    @Query("SELECT SUM(durationWatched) FROM watch_stats")
    fun getTotalWatchTimeMs(): Flow<Long?>

    @Query("SELECT COUNT(DISTINCT mediaId) FROM watch_stats WHERE mediaType = 'video'")
    suspend fun getTotalVideosWatched(): Int

    @Query("SELECT COUNT(*) FROM watch_stats WHERE mediaType = 'audio'")
    suspend fun getTotalSongsPlayed(): Int

    @Query("""
        SELECT dayOfWeek, SUM(durationWatched) as totalMs
        FROM watch_stats
        WHERE timestamp >= :since
        GROUP BY dayOfWeek
        ORDER BY dayOfWeek ASC
    """)
    suspend fun getDailyBreakdown(since: Long): List<DayBreakdown>

    @Query("""
        SELECT genre, COUNT(*) as count
        FROM watch_stats
        WHERE genre != '' AND timestamp >= :since
        GROUP BY genre
        ORDER BY count DESC
        LIMIT :limit
    """)
    suspend fun getTopGenres(since: Long, limit: Int): List<GenreCount>

    @Query("""
        SELECT artist, COUNT(*) as count
        FROM watch_stats
        WHERE artist != '' AND timestamp >= :since
        GROUP BY artist
        ORDER BY count DESC
        LIMIT :limit
    """)
    suspend fun getTopArtists(since: Long, limit: Int): List<ArtistCount>

    @Query("""
        SELECT title, COUNT(*) as count
        FROM watch_stats
        WHERE mediaType = 'video' AND timestamp >= :since
        GROUP BY title
        ORDER BY count DESC
        LIMIT :limit
    """)
    suspend fun getTopVideos(since: Long, limit: Int): List<VideoCount>

    @Query("DELETE FROM watch_stats")
    suspend fun deleteAll()

    @Query("DELETE FROM watch_stats WHERE timestamp < :before")
    suspend fun deleteOlderThan(before: Long)
}

data class DayBreakdown(val dayOfWeek: Int, val totalMs: Long)
data class GenreCount(val genre: String, val count: Int)
data class ArtistCount(val artist: String, val count: Int)
data class VideoCount(val title: String, val count: Int)
