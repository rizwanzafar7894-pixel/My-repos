package com.darkwave.data.di

import android.content.Context
import androidx.room.Room
import com.darkwave.data.db.MediaDatabase
import com.darkwave.data.db.dao.*
import com.darkwave.data.repository.*
import com.darkwave.data.scanner.MediaScanner
import com.darkwave.domain.repository.*
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): MediaDatabase {
        return Room.databaseBuilder(
            context,
            MediaDatabase::class.java,
            "darkwave_db"
        )
            .fallbackToDestructiveMigration()
            .build()
    }

    @Provides fun provideVideoDao(db: MediaDatabase): VideoDao               = db.videoDao()
    @Provides fun provideAudioDao(db: MediaDatabase): AudioDao               = db.audioDao()
    @Provides fun providePlaylistDao(db: MediaDatabase): PlaylistDao         = db.playlistDao()
    @Provides fun provideBookmarkDao(db: MediaDatabase): BookmarkDao         = db.bookmarkDao()
    @Provides fun provideWatchEventDao(db: MediaDatabase): WatchEventDao     = db.watchEventDao()
    // FIX: VaultItemDao was provided but old impl didn't use it properly
    @Provides fun provideVaultItemDao(db: MediaDatabase): VaultItemDao       = db.vaultItemDao()
    @Provides fun provideFocusSessionDao(db: MediaDatabase): FocusSessionDao = db.focusSessionDao()
}

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds @Singleton
    abstract fun bindMediaRepository(impl: MediaRepositoryImpl): MediaRepository

    @Binds @Singleton
    abstract fun bindPlaylistRepository(impl: PlaylistRepositoryImpl): PlaylistRepository

    @Binds @Singleton
    abstract fun bindAnalyticsRepository(impl: AnalyticsRepositoryImpl): AnalyticsRepository

    @Binds @Singleton
    abstract fun bindBookmarkRepository(impl: BookmarkRepositoryImpl): BookmarkRepository
}
