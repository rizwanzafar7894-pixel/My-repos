package com.darkwave.data.scanner

import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.provider.MediaStore
import com.darkwave.domain.model.AudioItem
import com.darkwave.domain.model.VideoItem
import dagger.hilt.android.qualifiers.ApplicationContext
import timber.log.Timber
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MediaScanner @Inject constructor(
    @ApplicationContext private val context: Context
) {
    fun scanVideos(): List<VideoItem> {
        val videos = mutableListOf<VideoItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DATA,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Video.Media.BUCKET_ID,
            MediaStore.Video.Media.MIME_TYPE
        )

        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        try {
            context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection, null, null, sortOrder
            )?.use { cursor ->
                val idCol          = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val dataCol        = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA)
                val displayNameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val titleCol       = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val durationCol    = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol        = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val widthCol       = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH)
                val heightCol      = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT)
                val dateAddedCol   = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val dateModCol     = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                val bucketCol      = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)
                val mimeCol        = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)

                while (cursor.moveToNext()) {
                    val id       = cursor.getLong(idCol)
                    val data     = cursor.getString(dataCol) ?: continue
                    val width    = cursor.getInt(widthCol)
                    val height   = cursor.getInt(heightCol)
                    val duration = cursor.getLong(durationCol)
                    if (duration <= 0) continue

                    val qualityLabel = when {
                        height >= 2160 -> "4K"
                        height >= 1080 -> "1080p"
                        height >= 720  -> "HD"
                        else           -> "SD"
                    }

                    val contentUri = Uri.withAppendedPath(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id.toString()
                    )

                    val folderPath = data.substringBeforeLast("/")
                    val folderName = cursor.getString(bucketCol) ?: folderPath.substringAfterLast("/")

                    videos.add(
                        VideoItem(
                            id            = id,
                            uri           = contentUri.toString(),
                            title         = cursor.getString(titleCol)?.takeIf { it.isNotBlank() }
                                            ?: cursor.getString(displayNameCol)?.substringBeforeLast(".")
                                            ?: "Unknown",
                            displayName   = cursor.getString(displayNameCol) ?: "",
                            duration      = duration,
                            size          = cursor.getLong(sizeCol),
                            width         = width,
                            height        = height,
                            dateAdded     = cursor.getLong(dateAddedCol) * 1000L,
                            dateModified  = cursor.getLong(dateModCol) * 1000L,
                            folderName    = folderName,
                            folderPath    = folderPath,
                            mimeType      = cursor.getString(mimeCol) ?: "video/*",
                            resolution    = "${width}x${height}",
                            qualityLabel  = qualityLabel
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Error scanning videos")
        }

        Timber.d("Scanned ${videos.size} videos")
        return videos
    }

    fun scanAudio(): List<AudioItem> {
        val audioList = mutableListOf<AudioItem>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATE_MODIFIED,
            MediaStore.Audio.Media.BUCKET_DISPLAY_NAME,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.BITRATE,
            MediaStore.Audio.Media.YEAR,
            MediaStore.Audio.Media.TRACK,
            MediaStore.Audio.Media.GENRE
        )

        val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

        try {
            context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection, null, null, sortOrder
            )?.use { cursor ->
                val idCol          = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val dataCol        = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val displayNameCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val titleCol       = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol      = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumCol       = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val albumIdCol     = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
                val durationCol    = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeCol        = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dateAddedCol   = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val dateModCol     = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
                val bucketCol      = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.BUCKET_DISPLAY_NAME)
                val mimeCol        = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)
                val bitrateCol     = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.BITRATE)
                val yearCol        = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.YEAR)
                val trackCol       = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
                val genreCol       = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.GENRE)

                while (cursor.moveToNext()) {
                    val id       = cursor.getLong(idCol)
                    val data     = cursor.getString(dataCol) ?: continue
                    val duration = cursor.getLong(durationCol)
                    if (duration <= 0) continue

                    val albumId = cursor.getLong(albumIdCol)
                    val albumArtUri = "content://media/external/audio/albumart/$albumId"

                    val contentUri = Uri.withAppendedPath(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id.toString()
                    )

                    val folderPath = data.substringBeforeLast("/")
                    val folderName = cursor.getString(bucketCol) ?: folderPath.substringAfterLast("/")
                    val artist     = cursor.getString(artistCol)?.takeIf { it != "<unknown>" } ?: "Unknown Artist"
                    val genre      = cursor.getString(genreCol) ?: ""

                    audioList.add(
                        AudioItem(
                            id           = id,
                            uri          = contentUri.toString(),
                            title        = cursor.getString(titleCol)?.takeIf { it.isNotBlank() }
                                           ?: cursor.getString(displayNameCol)?.substringBeforeLast(".")
                                           ?: "Unknown",
                            artist       = artist,
                            album        = cursor.getString(albumCol) ?: "",
                            albumId      = albumId,
                            albumArtUri  = albumArtUri,
                            duration     = duration,
                            size         = cursor.getLong(sizeCol),
                            dateAdded    = cursor.getLong(dateAddedCol) * 1000L,
                            dateModified = cursor.getLong(dateModCol) * 1000L,
                            folderName   = folderName,
                            folderPath   = folderPath,
                            mimeType     = cursor.getString(mimeCol) ?: "audio/*",
                            bitrate      = cursor.getInt(bitrateCol),
                            year         = cursor.getInt(yearCol),
                            trackNumber  = cursor.getInt(trackCol),
                            genre        = genre
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Timber.e(e, "Error scanning audio")
        }

        Timber.d("Scanned ${audioList.size} audio files")
        return audioList
    }
}
