package com.darkwave.data.db.dao

import androidx.room.*
import com.darkwave.domain.model.Bookmark
import com.darkwave.domain.model.BookmarkMediaType
import kotlinx.coroutines.flow.Flow

@Dao
interface BookmarkDao {
    @Query("SELECT * FROM bookmarks ORDER BY createdAt DESC")
    fun getAllBookmarks(): Flow<List<Bookmark>>

    @Query("SELECT * FROM bookmarks WHERE mediaType = :type ORDER BY createdAt DESC")
    fun getBookmarksByType(type: BookmarkMediaType): Flow<List<Bookmark>>

    @Query("SELECT * FROM bookmarks WHERE mediaId = :mediaId LIMIT 1")
    suspend fun getBookmarkForMedia(mediaId: Long): Bookmark?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(bookmark: Bookmark): Long

    @Query("DELETE FROM bookmarks WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE bookmarks SET note = :note WHERE id = :id")
    suspend fun updateNote(id: Long, note: String)
}
