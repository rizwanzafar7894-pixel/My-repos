package com.darkwave.data.worker

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.darkwave.domain.repository.MediaRepository
import com.darkwave.domain.repository.PlaylistRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.flow.first
import timber.log.Timber
import java.util.concurrent.TimeUnit

@HiltWorker
class DiscoverWeeklyWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted workerParams: WorkerParameters,
    private val mediaRepository: MediaRepository,
    private val playlistRepository: PlaylistRepository
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            val allAudio = mediaRepository.getAllAudio().first()
            if (allAudio.isEmpty()) return Result.success()
            playlistRepository.refreshDiscoverWeekly(allAudio)
            Timber.d("DiscoverWeekly refreshed with ${allAudio.size.coerceAtMost(52)} songs")
            Result.success()
        } catch (e: Exception) {
            Timber.e(e, "DiscoverWeeklyWorker failed")
            Result.retry()
        }
    }

    companion object {
        const val WORK_NAME = "discover_weekly"

        fun schedule(context: Context) {
            val request = PeriodicWorkRequestBuilder<DiscoverWeeklyWorker>(7, TimeUnit.DAYS)
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.NOT_REQUIRED)
                        .build()
                )
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.UPDATE,
                request
            )
        }

        fun runNow(context: Context) {
            val request = OneTimeWorkRequestBuilder<DiscoverWeeklyWorker>().build()
            WorkManager.getInstance(context).enqueue(request)
        }
    }
}
