package com.darkwave.data.db

import androidx.room.Database
import androidx.room.RoomDatabase
import com.darkwave.data.db.dao.*
import com.darkwave.domain.model.*

@Database(
    entities = [
        VideoItem::class,
        AudioItem::class,
        Playlist::class,
        PlaylistSong::class,
        Bookmark::class,
        WatchEvent::class,
        VaultItem::class,
        FocusSession::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MediaDatabase : RoomDatabase() {
    abstract fun videoDao(): VideoDao
    abstract fun audioDao(): AudioDao
    abstract fun playlistDao(): PlaylistDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun watchEventDao(): WatchEventDao
    abstract fun vaultItemDao(): VaultItemDao
    abstract fun focusSessionDao(): FocusSessionDao
}
