package com.darkwave.data.db.dao

import androidx.room.*
import com.darkwave.domain.model.VaultItem
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultItemDao {

    @Query("SELECT * FROM vault_items ORDER BY addedAt DESC")
    fun getAllItems(): Flow<List<VaultItem>>

    // FIX: getById was missing - needed by removeFromVault
    @Query("SELECT * FROM vault_items WHERE id = :id LIMIT 1")
    suspend fun getById(id: Long): VaultItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: VaultItem)

    @Delete
    suspend fun delete(item: VaultItem)

    // FIX: deleteById was missing - needed by removeFromVault
    @Query("DELETE FROM vault_items WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM vault_items")
    suspend fun deleteAll()

    @Query("SELECT COUNT(*) FROM vault_items")
    suspend fun count(): Int

    @Query("SELECT SUM(size) FROM vault_items")
    suspend fun totalSize(): Long?
}
