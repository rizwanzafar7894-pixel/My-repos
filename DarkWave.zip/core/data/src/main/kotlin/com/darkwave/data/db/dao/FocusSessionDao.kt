package com.darkwave.data.db.dao

import androidx.room.*
import com.darkwave.domain.model.FocusSession
import kotlinx.coroutines.flow.Flow

@Dao
interface FocusSessionDao {
    @Query("SELECT * FROM focus_sessions ORDER BY startedAt DESC")
    fun getAllSessions(): Flow<List<FocusSession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: FocusSession): Long

    @Update
    suspend fun update(session: FocusSession)

    @Query("DELETE FROM focus_sessions WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("SELECT SUM(completedPomodoros) FROM focus_sessions WHERE isCompleted = 1")
    suspend fun getTotalCompletedPomodoros(): Int?

    @Query("SELECT * FROM focus_sessions ORDER BY startedAt DESC LIMIT 1")
    suspend fun getLastSession(): FocusSession?
}
