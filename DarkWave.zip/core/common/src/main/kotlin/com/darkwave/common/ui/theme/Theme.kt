package com.darkwave.common.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary            = Purple500,
    onPrimary          = White,
    primaryContainer   = Purple100,
    onPrimaryContainer = Purple600,
    secondary          = Purple400,
    onSecondary        = White,
    secondaryContainer = Purple50,
    onSecondaryContainer = Purple600,
    tertiary           = PinkAccent,
    onTertiary         = White,
    background         = Background,
    onBackground       = TextPrimary,
    surface            = SurfaceLight,
    onSurface          = TextPrimary,
    surfaceVariant     = SurfaceVariant,
    onSurfaceVariant   = TextSecondary,
    outline            = BorderColor,
    outlineVariant     = DividerColor,
    error              = Error,
    onError            = White,
    inverseSurface     = TextPrimary,
    inverseOnSurface   = White,
    inversePrimary     = Purple300,
    scrim              = Color(0x52000000)
)

private val DarkColorScheme = darkColorScheme(
    primary            = Purple400,
    onPrimary          = White,
    primaryContainer   = Purple600,
    onPrimaryContainer = Purple100,
    secondary          = Purple300,
    onSecondary        = TextPrimary,
    secondaryContainer = Color(0xFF1E1E2E),
    onSecondaryContainer = Purple300,
    tertiary           = PinkAccent,
    onTertiary         = White,
    background         = Color(0xFF0F0F1A),
    onBackground       = Color(0xFFE8E8F0),
    surface            = Color(0xFF1A1A2E),
    onSurface          = Color(0xFFE8E8F0),
    surfaceVariant     = Color(0xFF252535),
    onSurfaceVariant   = Color(0xFFB0B0C8),
    outline            = Color(0xFF383858),
    outlineVariant     = Color(0xFF2A2A40),
    error              = Error,
    onError            = White
)

@Composable
fun DarkWaveTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = Color.Transparent.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography  = DarkWaveTypography,
        shapes      = DarkWaveShapes,
        content     = content
    )
}
