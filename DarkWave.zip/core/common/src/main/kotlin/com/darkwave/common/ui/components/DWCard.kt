package com.darkwave.common.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.darkwave.common.ui.theme.CardBackground
import com.darkwave.common.ui.theme.DividerColor
import com.darkwave.common.ui.theme.ShapeCard

@Composable
fun DWCard(
    modifier: Modifier = Modifier,
    elevation: Dp = 2.dp,
    border: Boolean = false,
    containerColor: Color = CardBackground,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier,
        shape = ShapeCard,
        elevation = CardDefaults.cardElevation(defaultElevation = elevation),
        border = if (border) BorderStroke(1.dp, DividerColor) else null,
        colors = CardDefaults.cardColors(containerColor = containerColor)
    ) {
        Column(content = content)
    }
}

@Composable
fun DWElevatedCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    containerColor: Color = CardBackground,
    elevation: Dp = 4.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    if (onClick != null) {
        Card(
            onClick = onClick,
            modifier = modifier,
            shape = ShapeCard,
            elevation = CardDefaults.cardElevation(
                defaultElevation = elevation,
                pressedElevation = 8.dp,
                hoveredElevation = 6.dp
            ),
            colors = CardDefaults.cardColors(containerColor = containerColor)
        ) {
            Column(content = content)
        }
    } else {
        Card(
            modifier = modifier,
            shape = ShapeCard,
            elevation = CardDefaults.cardElevation(defaultElevation = elevation),
            colors = CardDefaults.cardColors(containerColor = containerColor)
        ) {
            Column(content = content)
        }
    }
}
