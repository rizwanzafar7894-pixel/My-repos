package com.darkwave.common.util

object Constants {
    // App
    const val APP_NAME            = "DarkWave"
    const val APP_VERSION         = "1.0.0"
    const val DB_NAME             = "darkwave_db"
    const val DB_VERSION          = 1

    // DataStore
    const val PREFS_NAME          = "darkwave_prefs"
    const val KEY_ONBOARDING_DONE = "onboarding_complete"
    const val KEY_USER_NAME       = "user_name"
    const val KEY_USER_INITIALS   = "user_initials"
    const val KEY_THEME_DARK      = "theme_dark"
    const val KEY_LAST_PLAYED_URI = "last_played_uri"
    const val KEY_PLAYBACK_SPEED  = "playback_speed"
    const val KEY_REPEAT_MODE     = "repeat_mode"
    const val KEY_SHUFFLE_ON      = "shuffle_on"
    const val KEY_VAULT_PIN       = "vault_pin"
    const val KEY_VAULT_BIOMETRIC = "vault_biometric"
    const val KEY_FONT_SIZE       = "font_size_scale"

    // Notifications
    const val CHANNEL_PLAYBACK    = "channel_playback"
    const val CHANNEL_DOWNLOAD    = "channel_download"
    const val CHANNEL_REMINDER    = "channel_reminder"

    // WorkManager tags
    const val WORK_DISCOVER_WEEKLY = "discover_weekly_work"
    const val WORK_MEDIA_SCAN      = "media_scan_work"

    // Player defaults
    const val DEFAULT_SPEED       = 1.0f
    const val MIN_SPEED           = 0.25f
    const val MAX_SPEED           = 4.0f
    const val SEEK_INCREMENT_MS   = 10_000L
    const val SKIP_SILENCE_MIN_MS = 2_000L

    // Discover Weekly
    const val DISCOVER_WEEKLY_COUNT = 52
    const val DISCOVER_PLAYLIST_NAME = "Discover Weekly"

    // Recommendation
    const val MIN_PLAY_COUNT_FOR_RECOMMEND = 2
    const val RECENT_DAYS_WINDOW          = 30
    const val FOR_YOU_PLAYLIST_SIZE       = 25
    const val CURATED_MIN_SONGS           = 5

    // Remote control
    const val REMOTE_SERVER_PORT  = 8765
    const val REMOTE_QR_SIZE_PX   = 512

    // Focus / Pomodoro
    const val POMODORO_WORK_MIN   = 25
    const val POMODORO_SHORT_MIN  = 5
    const val POMODORO_LONG_MIN   = 15

    // Tools
    const val AUDIO_SAMPLE_RATE   = 44100
    const val AUDIO_BUFFER_SIZE   = 4096
    const val BPM_MIN             = 40
    const val BPM_MAX             = 240
    const val TUNER_SAMPLE_RATE   = 44100

    // Vault
    const val VAULT_DIR_NAME      = ".darkwave_vault"
    const val VAULT_PIN_LENGTH    = 4

    // Analytics
    const val ANALYTICS_HISTORY_DAYS = 30
}
