package com.darkwave.common.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.darkwave.common.ui.theme.Background
import com.darkwave.common.ui.theme.NotifBadge
import com.darkwave.common.ui.theme.Purple500
import com.darkwave.common.ui.theme.TextPrimary
import com.darkwave.common.ui.theme.TextSecondary
import com.darkwave.common.ui.theme.White

@Composable
fun DWTopBar(
    userName: String,
    greeting: String,
    userInitials: String,
    notificationCount: Int = 0,
    onSearchClick: () -> Unit,
    onFavoriteClick: () -> Unit,
    onNotificationClick: () -> Unit,
    onAvatarClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(White)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Avatar
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(CircleShape)
                .background(Purple500)
                .padding(0.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = userInitials.take(1).uppercase(),
                color = White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Greeting + Name
        androidx.compose.foundation.layout.Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = greeting,
                fontSize = 12.sp,
                color = TextSecondary,
                fontWeight = FontWeight.Normal
            )
            Text(
                text = userName,
                fontSize = 15.sp,
                color = TextPrimary,
                fontWeight = FontWeight.SemiBold
            )
        }

        // Search
        IconButton(onClick = onSearchClick) {
            Icon(
                imageVector = Icons.Default.Search,
                contentDescription = "Search",
                tint = TextSecondary,
                modifier = Modifier.size(22.dp)
            )
        }

        // Favorite
        IconButton(onClick = onFavoriteClick) {
            Icon(
                imageVector = Icons.Default.Favorite,
                contentDescription = "Favorites",
                tint = TextSecondary,
                modifier = Modifier.size(22.dp)
            )
        }

        // Notifications with badge
        BadgedBox(
            badge = {
                if (notificationCount > 0) {
                    Badge(
                        containerColor = NotifBadge,
                        contentColor = White
                    ) {
                        Text(
                            text = notificationCount.toString(),
                            fontSize = 10.sp
                        )
                    }
                }
            }
        ) {
            IconButton(onClick = onNotificationClick) {
                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = "Notifications",
                    tint = TextSecondary,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}
