package com.darkwave.common.util

import android.content.Context
import android.widget.Toast
import java.util.concurrent.TimeUnit

fun Long.toFormattedDuration(): String {
    val hours   = TimeUnit.MILLISECONDS.toHours(this)
    val minutes = TimeUnit.MILLISECONDS.toMinutes(this) % 60
    val seconds = TimeUnit.MILLISECONDS.toSeconds(this) % 60
    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%d:%02d", minutes, seconds)
    }
}

fun Long.toFormattedSize(): String {
    val kb = this / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1.0 -> String.format("%.1f GB", gb)
        mb >= 1.0 -> String.format("%.1f MB", mb)
        else      -> String.format("%.0f KB", kb)
    }
}

fun Long.toHoursMinutes(): String {
    val hours   = TimeUnit.MILLISECONDS.toHours(this)
    val minutes = TimeUnit.MILLISECONDS.toMinutes(this) % 60
    return when {
        hours > 0 && minutes > 0 -> "${hours}h ${minutes}m"
        hours > 0                -> "${hours}h"
        else                     -> "${minutes}m"
    }
}

fun Int.toFormattedHoursMinutes(): String {
    val hours   = this / 3600
    val minutes = (this % 3600) / 60
    return when {
        hours > 0 && minutes > 0 -> "${hours}h ${minutes}m"
        hours > 0                -> "${hours}h"
        else                     -> "${minutes}m"
    }
}

fun Context.showToast(message: String, duration: Int = Toast.LENGTH_SHORT) {
    Toast.makeText(this, message, duration).show()
}

fun String.capitalizeWords(): String =
    split(" ").joinToString(" ") { word ->
        word.replaceFirstChar { it.uppercase() }
    }

fun String.getInitials(): String {
    val parts = trim().split(" ")
    return when {
        parts.size >= 2 -> "${parts[0].first()}${parts[1].first()}".uppercase()
        parts.size == 1 && parts[0].isNotEmpty() -> parts[0].first().uppercase()
        else -> "?"
    }
}

fun String.isVideoFile(): Boolean {
    val ext = substringAfterLast('.', "").lowercase()
    return ext in listOf("mp4", "mkv", "avi", "mov", "wmv", "flv", "webm", "m4v", "3gp", "ts", "m2ts")
}

fun String.isAudioFile(): Boolean {
    val ext = substringAfterLast('.', "").lowercase()
    return ext in listOf("mp3", "aac", "ogg", "flac", "wav", "m4a", "wma", "opus", "ape", "dsd")
}

fun Long.secondsToMs(): Long = this * 1000L
fun Long.msToSeconds(): Long = this / 1000L

fun getGreeting(): String {
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return when (hour) {
        in 5..11  -> "Good Morning"
        in 12..17 -> "Good Afternoon"
        in 18..21 -> "Good Evening"
        else      -> "Good Night"
    }
}

fun getDayOfWeekName(dayIndex: Int): String {
    return when (dayIndex) {
        0 -> "Mon"; 1 -> "Tue"; 2 -> "Wed"; 3 -> "Thu"
        4 -> "Fri"; 5 -> "Sat"; 6 -> "Sun"
        else -> ""
    }
}
