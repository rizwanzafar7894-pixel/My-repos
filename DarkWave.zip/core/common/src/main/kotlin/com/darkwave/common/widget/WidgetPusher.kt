package com.darkwave.common.widget

/**
 * Abstraction so feature:musicplayer doesn't depend on :app module.
 * The :app module provides the real implementation via Hilt.
 */
interface WidgetPusher {
    fun push(
        title: String,
        artist: String,
        album: String,
        isPlaying: Boolean,
        progress: Int,
        position: String,
        duration: String,
        albumArtUri: String?
    )
}

/** No-op implementation used when no real pusher is bound (e.g. tests) */
object NoOpWidgetPusher : WidgetPusher {
    override fun push(
        title: String, artist: String, album: String,
        isPlaying: Boolean, progress: Int,
        position: String, duration: String, albumArtUri: String?
    ) = Unit
}
