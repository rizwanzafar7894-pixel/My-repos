package com.darkwave.common.ui.theme

import androidx.compose.ui.graphics.Color

// ── Primary Purple (from screenshots) ─────────────────────────────────────
val Purple500      = Color(0xFF5C6BC0)
val Purple600      = Color(0xFF3F51B5)
val Purple400      = Color(0xFF7986CB)
val Purple300      = Color(0xFF9FA8DA)
val Purple100      = Color(0xFFE8EAF6)
val Purple50       = Color(0xFFF3F4FC)

// ── Accent colors (from screenshots - tool icons) ──────────────────────────
val PinkAccent     = Color(0xFFE91E8C)
val GreenAccent    = Color(0xFF4CAF50)
val OrangeAccent   = Color(0xFFFF5722)
val BlueAccent     = Color(0xFF2196F3)
val TealAccent     = Color(0xFF009688)
val RedAccent      = Color(0xFFF44336)
val AmberAccent    = Color(0xFFFFC107)

// ── Light Theme Surfaces ──────────────────────────────────────────────────
val White          = Color(0xFFFFFFFF)
val Background     = Color(0xFFF5F5F7)
val SurfaceLight   = Color(0xFFFFFFFF)
val SurfaceVariant = Color(0xFFF0F0F5)
val CardBackground = Color(0xFFFFFFFF)

// ── Discover Weekly Card gradient (light purple tint from screenshots) ────
val DiscoverCardStart = Color(0xFFEEEEFD)
val DiscoverCardEnd   = Color(0xFFDDDDFA)

// ── Text Colors ───────────────────────────────────────────────────────────
val TextPrimary    = Color(0xFF1A1A2E)
val TextSecondary  = Color(0xFF6B7280)
val TextTertiary   = Color(0xFF9CA3AF)
val TextOnPurple   = Color(0xFFFFFFFF)

// ── Divider / Border ──────────────────────────────────────────────────────
val DividerColor   = Color(0xFFE5E7EB)
val BorderColor    = Color(0xFFE0E0E0)

// ── Filter Chip ──────────────────────────────────────────────────────────
val ChipSelected   = Purple500
val ChipUnselected = Color(0xFFFFFFFF)
val ChipBorder     = Color(0xFFE0E0E0)

// ── Bottom Nav ────────────────────────────────────────────────────────────
val NavBackground  = Color(0xFFFFFFFF)
val NavSelected    = Purple500
val NavUnselected  = Color(0xFF9E9E9E)

// ── Quality Badges ────────────────────────────────────────────────────────
val Badge1080p     = Color(0xFF4CAF50)
val Badge720p      = Color(0xFF2196F3)
val Badge4K        = Color(0xFF9C27B0)
val BadgeHD        = Color(0xFF607D8B)

// ── Player ───────────────────────────────────────────────────────────────
val PlayerBackground  = Color(0xFF000000)
val PlayerSurface     = Color(0xFF1A1A1A)
val PlayerControl     = Color(0xFFFFFFFF)
val PlayerProgress    = Purple500
val PlayerProgressBg  = Color(0x33FFFFFF)

// ── Notification dot ─────────────────────────────────────────────────────
val NotifBadge     = Purple500

// ── Waveform / Visualizer ────────────────────────────────────────────────
val WaveformColor  = Purple400
val SpectrumColor  = Purple500

// ── Status colors ────────────────────────────────────────────────────────
val Success        = Color(0xFF4CAF50)
val Error          = Color(0xFFF44336)
val Warning        = Color(0xFFFFC107)
val Info           = Color(0xFF2196F3)
