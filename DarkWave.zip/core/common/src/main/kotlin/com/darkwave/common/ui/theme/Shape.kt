package com.darkwave.common.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

val DarkWaveShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small      = RoundedCornerShape(8.dp),
    medium     = RoundedCornerShape(12.dp),
    large      = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(24.dp)
)

val ShapeCard        = RoundedCornerShape(16.dp)
val ShapeChip        = RoundedCornerShape(50.dp)
val ShapeButton      = RoundedCornerShape(12.dp)
val ShapeBottomSheet = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
val ShapeDialog      = RoundedCornerShape(20.dp)
val ShapeSmall       = RoundedCornerShape(8.dp)
val ShapeCircle      = RoundedCornerShape(50)
val ShapeVideoThumb  = RoundedCornerShape(12.dp)
val ShapeListItem    = RoundedCornerShape(12.dp)
val ShapeQualityBadge = RoundedCornerShape(4.dp)
