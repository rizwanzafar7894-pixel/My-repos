package com.darkwave.common.animation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.EaseInOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically

private const val ANIM_DURATION = 300

val slideInFromRight: EnterTransition =
    slideInHorizontally(
        initialOffsetX = { it },
        animationSpec = tween(ANIM_DURATION, easing = EaseInOut)
    ) + fadeIn(tween(ANIM_DURATION))

val slideOutToRight: ExitTransition =
    slideOutHorizontally(
        targetOffsetX = { it },
        animationSpec = tween(ANIM_DURATION, easing = EaseInOut)
    ) + fadeOut(tween(ANIM_DURATION))

val slideInFromBottom: EnterTransition =
    slideInVertically(
        initialOffsetY = { it },
        animationSpec = tween(ANIM_DURATION, easing = EaseInOut)
    ) + fadeIn(tween(ANIM_DURATION))

val slideOutToBottom: ExitTransition =
    slideOutVertically(
        targetOffsetY = { it },
        animationSpec = tween(ANIM_DURATION, easing = EaseInOut)
    ) + fadeOut(tween(ANIM_DURATION))

val fadeInAnim: EnterTransition = fadeIn(tween(ANIM_DURATION))
val fadeOutAnim: ExitTransition = fadeOut(tween(ANIM_DURATION))

val scaleInAnim: EnterTransition =
    scaleIn(initialScale = 0.92f, animationSpec = tween(ANIM_DURATION)) +
    fadeIn(tween(ANIM_DURATION))

val scaleOutAnim: ExitTransition =
    scaleOut(targetScale = 0.92f, animationSpec = tween(ANIM_DURATION)) +
    fadeOut(tween(ANIM_DURATION))
