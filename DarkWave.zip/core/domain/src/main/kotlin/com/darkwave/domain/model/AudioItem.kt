package com.darkwave.domain.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "audio")
data class AudioItem(
    @PrimaryKey val id: Long,
    val uri: String,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val albumArtUri: String,
    val duration: Long,          // ms
    val size: Long,
    val dateAdded: Long,
    val dateModified: Long,
    val folderName: String,
    val folderPath: String,
    val mimeType: String,
    val bitrate: Int = 0,
    val year: Int = 0,
    val trackNumber: Int = 0,
    val genre: String = "",
    val playCount: Int = 0,
    val lastPlayedAt: Long = 0L,
    val isFavorite: Boolean = false,
    val isLiked: Boolean = false,
    val isDownloaded: Boolean = false,
    val isInVault: Boolean = false,
    val rating: Float = 0f
) {
    val artistAndAlbum: String get() = if (album.isNotBlank()) "$artist · $album" else artist
}
