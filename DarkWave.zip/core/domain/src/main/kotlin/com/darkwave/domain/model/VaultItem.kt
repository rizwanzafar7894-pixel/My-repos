package com.darkwave.domain.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vault_items")
data class VaultItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val originalPath: String,
    val vaultPath: String,
    val title: String,
    val mimeType: String,
    val size: Long,
    val addedAt: Long = System.currentTimeMillis(),
    val mediaType: VaultMediaType = VaultMediaType.VIDEO
)

enum class VaultMediaType { VIDEO, AUDIO, IMAGE, OTHER }
