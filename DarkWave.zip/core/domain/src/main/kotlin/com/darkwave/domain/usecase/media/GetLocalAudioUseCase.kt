package com.darkwave.domain.usecase.media

import com.darkwave.domain.model.AudioFilter
import com.darkwave.domain.model.AudioItem
import com.darkwave.domain.model.SortBy
import com.darkwave.domain.model.SortOptions
import com.darkwave.domain.model.SortOrder
import com.darkwave.domain.repository.MediaRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class GetLocalAudioUseCase @Inject constructor(
    private val repository: MediaRepository
) {
    operator fun invoke(
        sortOptions: SortOptions = SortOptions(),
        filter: AudioFilter = AudioFilter.ALL,
        query: String = ""
    ): Flow<List<AudioItem>> {
        return repository.getAllAudio().map { audio ->
            var result = audio

            result = when (filter) {
                AudioFilter.ALL        -> result
                AudioFilter.MY_LIBRARY -> result
                AudioFilter.LIKED      -> result.filter { it.isLiked }
                AudioFilter.PLAYLISTS  -> result
                AudioFilter.DOWNLOADS  -> result.filter { it.isDownloaded }
                AudioFilter.ARTISTS    -> result.sortedBy { it.artist }
                AudioFilter.ALBUMS     -> result.sortedBy { it.album }
                AudioFilter.GENRES     -> result.sortedBy { it.genre }
            }

            if (query.isNotBlank()) {
                result = result.filter {
                    it.title.contains(query, ignoreCase = true) ||
                    it.artist.contains(query, ignoreCase = true) ||
                    it.album.contains(query, ignoreCase = true)
                }
            }

            result = when (sortOptions.sortBy) {
                SortBy.NAME          -> result.sortedBy { it.title.lowercase() }
                SortBy.DATE_ADDED    -> result.sortedBy { it.dateAdded }
                SortBy.DATE_MODIFIED -> result.sortedBy { it.dateModified }
                SortBy.SIZE          -> result.sortedBy { it.size }
                SortBy.DURATION      -> result.sortedBy { it.duration }
                SortBy.PLAY_COUNT    -> result.sortedBy { it.playCount }
                SortBy.LAST_PLAYED   -> result.sortedBy { it.lastPlayedAt }
                SortBy.RATING        -> result.sortedBy { it.rating }
                SortBy.ARTIST        -> result.sortedBy { it.artist.lowercase() }
                SortBy.ALBUM         -> result.sortedBy { it.album.lowercase() }
                else                 -> result.sortedBy { it.dateAdded }
            }

            if (sortOptions.order == SortOrder.DESC) result.reversed() else result
        }
    }
}
