package com.darkwave.domain.repository

import com.darkwave.domain.model.AudioItem
import com.darkwave.domain.model.MediaFolder
import com.darkwave.domain.model.VideoItem
import com.darkwave.domain.model.VaultItem
import com.darkwave.domain.model.VaultMediaType
import kotlinx.coroutines.flow.Flow

interface MediaRepository {
    // Videos
    fun getAllVideos(): Flow<List<VideoItem>>
    fun getVideosByFolder(folderPath: String): Flow<List<VideoItem>>
    suspend fun getVideoById(id: Long): VideoItem?
    suspend fun updateVideoPlayCount(id: Long, playCount: Int, lastPlayedAt: Long)
    suspend fun toggleVideoFavorite(id: Long, isFavorite: Boolean)
    suspend fun toggleVideoBookmark(id: Long, isBookmarked: Boolean, position: Long)
    suspend fun setVideoVault(id: Long, inVault: Boolean)
    suspend fun renameVideo(id: Long, newTitle: String)
    suspend fun deleteVideo(id: Long)

    // Audio
    fun getAllAudio(): Flow<List<AudioItem>>
    fun getAudioByFolder(folderPath: String): Flow<List<AudioItem>>
    suspend fun getAudioById(id: Long): AudioItem?
    suspend fun updateAudioPlayCount(id: Long, playCount: Int, lastPlayedAt: Long)
    // FIX: Removed duplicate toggleAudioFavorite & toggleAudioLiked — single signature each
    suspend fun toggleAudioFavorite(id: Long, isFavorite: Boolean)
    suspend fun toggleAudioLiked(id: Long, isLiked: Boolean)
    suspend fun setAudioVault(id: Long, inVault: Boolean)
    suspend fun renameAudio(id: Long, newTitle: String)
    suspend fun deleteAudio(id: Long)

    // Folders
    fun getVideoFolders(): Flow<List<MediaFolder>>
    fun getAudioFolders(): Flow<List<MediaFolder>>

    // Vault
    fun getVaultItems(): Flow<List<VaultItem>>
    suspend fun addToVault(uri: String, name: String, mediaType: VaultMediaType)
    suspend fun removeFromVault(id: Long)

    // Scan
    suspend fun scanMedia()
}
