package com.darkwave.domain.model

enum class SortBy {
    NAME, DATE_ADDED, DATE_MODIFIED, SIZE, DURATION,
    PLAY_COUNT, LAST_PLAYED, RATING, ARTIST, ALBUM, RESOLUTION
}

enum class SortOrder { ASC, DESC }

enum class VideoFilter { ALL, MOVIES, CLIPS, DOWNLOADS, FOUR_K }

enum class AudioFilter {
    ALL, MY_LIBRARY, LIKED, PLAYLISTS, DOWNLOADS, ARTISTS, ALBUMS, GENRES
}

data class SortOptions(
    val sortBy: SortBy = SortBy.DATE_ADDED,
    val order: SortOrder = SortOrder.DESC,
    val showSize: Boolean = true,
    val showDuration: Boolean = true,
    val showResolution: Boolean = true,
    val showDateAdded: Boolean = false,
    val showPlayCount: Boolean = false
)
