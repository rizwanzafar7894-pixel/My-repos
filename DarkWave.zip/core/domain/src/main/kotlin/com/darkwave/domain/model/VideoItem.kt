package com.darkwave.domain.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "videos")
data class VideoItem(
    @PrimaryKey val id: Long,
    val uri: String,
    val title: String,
    val displayName: String,
    val duration: Long,          // ms
    val size: Long,              // bytes
    val width: Int,
    val height: Int,
    val dateAdded: Long,
    val dateModified: Long,
    val folderName: String,
    val folderPath: String,
    val mimeType: String,
    val resolution: String,      // "1920x1080"
    val qualityLabel: String,    // "1080p", "4K", "HD", "720p"
    val playCount: Int = 0,
    val lastPlayedAt: Long = 0L,
    val isFavorite: Boolean = false,
    val isBookmarked: Boolean = false,
    val bookmarkPosition: Long = 0L,
    val rating: Float = 0f,
    val isInVault: Boolean = false
) {
    val isHD: Boolean get() = height >= 720
    val is4K: Boolean get() = height >= 2160
    val is1080p: Boolean get() = height >= 1080
    val is720p: Boolean get() = height >= 720
}
