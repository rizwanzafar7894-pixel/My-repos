package com.darkwave.domain.usecase.recommendation

import com.darkwave.domain.model.AudioItem
import com.darkwave.domain.model.CuratedPlaylist
import com.darkwave.domain.model.CuratedType
import com.darkwave.domain.repository.MediaRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class GetRecommendationsUseCase @Inject constructor(
    private val repository: MediaRepository
) {
    // "For You" — based on most played artists + genres
    fun getForYou(limit: Int = 25): Flow<List<AudioItem>> {
        return repository.getAllAudio().map { all ->
            if (all.isEmpty()) return@map emptyList()

            val playedSongs = all.filter { it.playCount > 0 }

            if (playedSongs.isEmpty()) {
                // No play history — return recently added
                return@map all.sortedByDescending { it.dateAdded }.take(limit)
            }

            // Find top artists by play count
            val topArtists = playedSongs
                .groupBy { it.artist }
                .mapValues { (_, songs) -> songs.sumOf { it.playCount } }
                .entries.sortedByDescending { it.value }
                .take(5)
                .map { it.key }
                .toSet()

            // Find top genres
            val topGenres = playedSongs
                .filter { it.genre.isNotBlank() }
                .groupBy { it.genre }
                .mapValues { (_, songs) -> songs.sumOf { it.playCount } }
                .entries.sortedByDescending { it.value }
                .take(3)
                .map { it.key }
                .toSet()

            // Score each song
            val scored = all.map { song ->
                var score = 0
                if (song.artist in topArtists) score += 30
                if (song.genre.isNotBlank() && song.genre in topGenres) score += 20
                score += (song.playCount * 5).coerceAtMost(25)
                if (song.isLiked) score += 15
                Pair(song, score)
            }

            scored
                .sortedByDescending { it.second }
                .take(limit)
                .map { it.first }
        }
    }

    // "Recommended" — top played songs
    fun getTopPlayed(limit: Int = 20): Flow<List<AudioItem>> {
        return repository.getAllAudio().map { all ->
            all.filter { it.playCount > 0 }
                .sortedByDescending { it.playCount }
                .take(limit)
                .ifEmpty {
                    // No plays yet — recently added as fallback
                    all.sortedByDescending { it.dateAdded }.take(limit)
                }
        }
    }

    // "Curated & Trending" — group by genre from local library
    fun getCuratedPlaylists(): Flow<List<CuratedPlaylist>> {
        return repository.getAllAudio().map { all ->
            if (all.isEmpty()) return@map emptyList()

            val playlists = mutableListOf<CuratedPlaylist>()

            // Group by genre
            val byGenre = all
                .filter { it.genre.isNotBlank() }
                .groupBy { it.genre.capitalizeFirst() }
                .filter { it.value.size >= 3 }
                .entries.sortedByDescending { it.value.size }
                .take(6)

            byGenre.forEach { (genre, songs) ->
                val sorted = songs.sortedByDescending { it.playCount }
                playlists.add(
                    CuratedPlaylist(
                        id = "genre_$genre",
                        name = genre,
                        description = "${sorted.size} songs",
                        coverArtUri = sorted.firstOrNull { it.albumArtUri.isNotBlank() }?.albumArtUri ?: "",
                        songs = sorted.take(50),
                        genre = genre,
                        type = CuratedType.GENRE
                    )
                )
            }

            // Most played playlist
            val mostPlayed = all.filter { it.playCount > 0 }.sortedByDescending { it.playCount }.take(25)
            if (mostPlayed.size >= 5) {
                playlists.add(0,
                    CuratedPlaylist(
                        id = "most_played",
                        name = "Most Played",
                        description = "${mostPlayed.size} songs",
                        coverArtUri = mostPlayed.firstOrNull { it.albumArtUri.isNotBlank() }?.albumArtUri ?: "",
                        songs = mostPlayed,
                        type = CuratedType.MOST_PLAYED
                    )
                )
            }

            // Top artist playlist
            val topArtist = all
                .filter { it.playCount > 0 }
                .groupBy { it.artist }
                .maxByOrNull { it.value.sumOf { s -> s.playCount } }
            if (topArtist != null && topArtist.value.size >= 3) {
                playlists.add(
                    CuratedPlaylist(
                        id = "artist_${topArtist.key}",
                        name = "Best of ${topArtist.key}",
                        description = "${topArtist.value.size} songs",
                        coverArtUri = topArtist.value.firstOrNull { it.albumArtUri.isNotBlank() }?.albumArtUri ?: "",
                        songs = topArtist.value.sortedByDescending { it.playCount },
                        type = CuratedType.ARTIST
                    )
                )
            }

            playlists
        }
    }

    private fun String.capitalizeFirst(): String =
        if (isNotEmpty()) this[0].uppercaseChar() + substring(1) else this
}
