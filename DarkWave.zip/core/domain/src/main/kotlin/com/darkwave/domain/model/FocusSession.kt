package com.darkwave.domain.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "focus_sessions")
data class FocusSession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val workMinutes: Int,
    val shortBreakMinutes: Int,
    val longBreakMinutes: Int,
    val completedPomodoros: Int = 0,
    val startedAt: Long = System.currentTimeMillis(),
    val endedAt: Long = 0L,
    val isCompleted: Boolean = false
)

enum class FocusPhase { WORK, SHORT_BREAK, LONG_BREAK }
