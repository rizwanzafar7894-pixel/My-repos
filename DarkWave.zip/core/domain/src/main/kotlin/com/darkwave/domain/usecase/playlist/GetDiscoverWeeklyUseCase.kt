package com.darkwave.domain.usecase.playlist

import com.darkwave.domain.model.AudioItem
import com.darkwave.domain.model.Playlist
import com.darkwave.domain.repository.MediaRepository
import com.darkwave.domain.repository.PlaylistRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import javax.inject.Inject

class GetDiscoverWeeklyUseCase @Inject constructor(
    private val playlistRepository: PlaylistRepository,
    private val mediaRepository: MediaRepository
) {
    // FIX: Prioritizes unplayed + low-play-count songs instead of random shuffle of all audio
    operator fun invoke(): Flow<Pair<Playlist?, List<AudioItem>>> {
        return combine(
            mediaRepository.getAllAudio(),
            playlistRepository.getAllPlaylists()
        ) { allAudio, playlists ->
            val discoverPlaylist = playlists.firstOrNull { it.name == "Discover Weekly" }
            if (discoverPlaylist == null || allAudio.isEmpty()) {
                return@combine Pair(discoverPlaylist, emptyList())
            }
            val unplayed = allAudio.filter { it.playCount == 0 }.shuffled()
            val lowPlayed = allAudio.filter { it.playCount in 1..3 }.shuffled()
            val recentlyAdded = allAudio.sortedByDescending { it.dateAdded }
            val candidates = (unplayed + lowPlayed + recentlyAdded).distinctBy { it.id }.take(52)
            Pair(discoverPlaylist, candidates)
        }
    }

    suspend fun refresh(allAudio: List<AudioItem>) {
        playlistRepository.refreshDiscoverWeekly(allAudio)
    }
}
