package com.darkwave.domain.usecase.media

import com.darkwave.domain.model.AudioItem
import com.darkwave.domain.model.VideoItem
import com.darkwave.domain.repository.MediaRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import javax.inject.Inject

data class SearchResult(
    val videos: List<VideoItem>,
    val audio: List<AudioItem>
)

class SearchMediaUseCase @Inject constructor(
    private val repository: MediaRepository
) {
    // FIX: Blank query now returns ALL items instead of empty lists
    operator fun invoke(query: String): Flow<SearchResult> {
        if (query.isBlank()) {
            return combine(
                repository.getAllVideos(),
                repository.getAllAudio()
            ) { videos, audio -> SearchResult(videos, audio) }
        }
        return combine(
            repository.getAllVideos().map { videos ->
                videos.filter {
                    it.title.contains(query, ignoreCase = true) ||
                    it.folderName.contains(query, ignoreCase = true)
                }
            },
            repository.getAllAudio().map { audio ->
                audio.filter {
                    it.title.contains(query, ignoreCase = true) ||
                    it.artist.contains(query, ignoreCase = true) ||
                    it.album.contains(query, ignoreCase = true)
                }
            }
        ) { videos, audio -> SearchResult(videos, audio) }
    }
}
