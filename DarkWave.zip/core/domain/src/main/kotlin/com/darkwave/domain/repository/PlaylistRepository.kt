package com.darkwave.domain.repository

import com.darkwave.domain.model.AudioItem
import com.darkwave.domain.model.Playlist
import com.darkwave.domain.model.PlaylistSong
import com.darkwave.domain.model.PlaylistType
import kotlinx.coroutines.flow.Flow

interface PlaylistRepository {
    fun getAllPlaylists(): Flow<List<Playlist>>
    fun getPlaylistWithSongs(playlistId: Long): Flow<Pair<Playlist, List<AudioItem>>>
    suspend fun getPlaylistById(id: Long): Playlist?
    suspend fun createPlaylist(name: String, description: String = ""): Long
    suspend fun updatePlaylist(playlist: Playlist)
    suspend fun deletePlaylist(id: Long)
    suspend fun addSongToPlaylist(playlistId: Long, audioId: Long)
    suspend fun removeSongFromPlaylist(playlistId: Long, audioId: Long)
    suspend fun reorderPlaylist(playlistId: Long, songs: List<Long>)
    suspend fun getOrCreateDiscoverWeekly(): Playlist
    suspend fun refreshDiscoverWeekly(allAudio: List<AudioItem>)
    suspend fun getPlaylistByType(type: PlaylistType): Playlist?
}
