package com.darkwave.domain.repository

import com.darkwave.domain.model.WatchEvent
import com.darkwave.domain.model.WatchStats
import kotlinx.coroutines.flow.Flow

interface AnalyticsRepository {
    suspend fun recordWatchEvent(event: WatchEvent)
    fun getWatchStats(): Flow<WatchStats>
    suspend fun getTotalWatchTimeMs(): Long
    suspend fun getTotalVideosWatched(): Int
    suspend fun getTotalSongsPlayed(): Int
    suspend fun getDailyWatchMs(days: Int = 7): List<Long>
    suspend fun getTopGenres(limit: Int = 5): Map<String, Int>
    suspend fun getTopArtists(limit: Int = 5): Map<String, Int>
    suspend fun getTopVideos(limit: Int = 5): List<Pair<String, Int>>
    suspend fun clearAllStats()
}
