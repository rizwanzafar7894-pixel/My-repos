package com.darkwave.domain.model

data class MediaFolder(
    val name: String,
    val path: String,
    val videoCount: Int = 0,
    val audioCount: Int = 0,
    val totalSize: Long = 0L,
    val coverArtUri: String = "",
    val lastModified: Long = 0L
) {
    val totalCount: Int get() = videoCount + audioCount
}
