package com.darkwave.domain.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "watch_stats")
data class WatchEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mediaId: Long,
    val mediaType: String,          // "video" | "audio"
    val title: String,
    val artist: String = "",
    val genre: String = "",
    val durationWatched: Long,      // ms
    val totalDuration: Long,        // ms
    val timestamp: Long = System.currentTimeMillis(),
    val dayOfWeek: Int = 0          // 0=Mon … 6=Sun
)

data class WatchStats(
    val totalWatchTimeMs: Long = 0L,
    val totalWatchMinutes: Int = 0,
    val totalVideosWatched: Int = 0,
    val totalSongsPlayed: Int = 0,
    val videoWatchMinutes: Int = 0,
    val musicPlayMinutes: Int = 0,
    val browserMinutes: Int = 0,
    val dailyWatchMs: List<Long> = List(7) { 0L },
    val weeklyData: List<DayWatchData> = emptyList(),
    val topGenres: Map<String, Int> = emptyMap(),
    val topArtists: Map<String, Int> = emptyMap(),
    val topVideos: List<String> = emptyList()
)

data class DayWatchData(val dayLabel: String, val watchMinutes: Int, val watchMs: Long = 0L)
