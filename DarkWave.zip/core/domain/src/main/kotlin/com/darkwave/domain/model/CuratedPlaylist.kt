package com.darkwave.domain.model

data class CuratedPlaylist(
    val id: String,
    val name: String,
    val description: String,
    val coverArtUri: String,
    val songs: List<AudioItem>,
    val genre: String = "",
    val type: CuratedType = CuratedType.GENRE
)

enum class CuratedType {
    GENRE,          // e.g. Bollywood, Punjabi, Romance
    ARTIST,         // top artist playlist
    FOR_YOU,        // based on play history
    MOST_PLAYED,    // top played songs
    RECENTLY_PLAYED
}
