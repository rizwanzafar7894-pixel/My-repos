package com.darkwave.domain.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookmarks")
data class Bookmark(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val mediaId: Long,
    val mediaUri: String,
    val title: String,
    val thumbnailUri: String = "",
    val positionMs: Long = 0L,
    // FIX: Removed redundant `position` alias — was creating duplicate Room column
    val note: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val mediaType: BookmarkMediaType = BookmarkMediaType.VIDEO,
    val mediaTitle: String = ""
)

enum class BookmarkMediaType { VIDEO, AUDIO }
