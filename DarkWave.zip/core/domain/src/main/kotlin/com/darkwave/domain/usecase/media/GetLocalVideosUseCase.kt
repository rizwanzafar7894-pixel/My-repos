package com.darkwave.domain.usecase.media

import com.darkwave.domain.model.SortBy
import com.darkwave.domain.model.SortOptions
import com.darkwave.domain.model.SortOrder
import com.darkwave.domain.model.VideoFilter
import com.darkwave.domain.model.VideoItem
import com.darkwave.domain.repository.MediaRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject

class GetLocalVideosUseCase @Inject constructor(
    private val repository: MediaRepository
) {
    operator fun invoke(
        sortOptions: SortOptions = SortOptions(),
        filter: VideoFilter = VideoFilter.ALL,
        query: String = ""
    ): Flow<List<VideoItem>> {
        return repository.getAllVideos().map { videos ->
            var result = videos

            // Filter by category
            result = when (filter) {
                VideoFilter.ALL       -> result
                VideoFilter.MOVIES    -> result.filter { it.duration > 40 * 60 * 1000L }
                VideoFilter.CLIPS     -> result.filter { it.duration <= 40 * 60 * 1000L }
                VideoFilter.DOWNLOADS -> result.filter {
                    it.folderPath.contains("download", ignoreCase = true)
                }
                VideoFilter.FOUR_K    -> result.filter { it.is4K }
            }

            // Search filter
            if (query.isNotBlank()) {
                result = result.filter {
                    it.title.contains(query, ignoreCase = true) ||
                    it.folderName.contains(query, ignoreCase = true)
                }
            }

            // Sort
            result = when (sortOptions.sortBy) {
                SortBy.NAME          -> result.sortedBy { it.title.lowercase() }
                SortBy.DATE_ADDED    -> result.sortedBy { it.dateAdded }
                SortBy.DATE_MODIFIED -> result.sortedBy { it.dateModified }
                SortBy.SIZE          -> result.sortedBy { it.size }
                SortBy.DURATION      -> result.sortedBy { it.duration }
                SortBy.PLAY_COUNT    -> result.sortedBy { it.playCount }
                SortBy.LAST_PLAYED   -> result.sortedBy { it.lastPlayedAt }
                SortBy.RATING        -> result.sortedBy { it.rating }
                SortBy.RESOLUTION    -> result.sortedBy { it.width * it.height }
                else                 -> result.sortedBy { it.dateAdded }
            }

            if (sortOptions.order == SortOrder.DESC) result.reversed() else result
        }
    }
}
