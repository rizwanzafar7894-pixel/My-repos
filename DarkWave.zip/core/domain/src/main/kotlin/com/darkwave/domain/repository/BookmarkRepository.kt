package com.darkwave.domain.repository

import com.darkwave.domain.model.Bookmark
import com.darkwave.domain.model.BookmarkMediaType
import kotlinx.coroutines.flow.Flow

interface BookmarkRepository {
    fun getAllBookmarks(): Flow<List<Bookmark>>
    fun getBookmarksByType(type: BookmarkMediaType): Flow<List<Bookmark>>
    suspend fun addBookmark(bookmark: Bookmark): Long
    suspend fun deleteBookmark(id: Long)
    suspend fun updateBookmarkNote(id: Long, note: String)
    suspend fun getBookmarkForMedia(mediaId: Long): Bookmark?
}
