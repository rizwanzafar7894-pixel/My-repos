# 🐺 WolfGPT — Enterprise AI Platform

> Production-ready AI SaaS platform. Self-hosted. 100% open-source models. No per-token costs.

[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Docker](https://img.shields.io/badge/docker-ready-blue.svg)](docker-compose.yml)

---

## What It Does

WolfGPT is a complete AI platform you can host yourself:

| Feature | Models |
|---|---|
| 💬 Chat | Qwen 2.5 (7B / 32B / 72B) via Ollama |
| 🖼️ Image Generation | FLUX.1 schnell/dev/pro, SDXL |
| 🖼️ Image-to-Image | Reference image transformation |
| 🎵 Music Generation | Meta MusicGen (small/medium/large) |
| 🎤 Speech-to-Text | OpenAI Whisper |
| 🔊 Text-to-Speech | Coqui TTS |
| 💻 Code Execution | Python, JS, TS, Go, Rust, Bash |
| 📄 Document Q&A | PDF, DOCX, TXT parsing |
| 🌍 Translation | Any language via Qwen |
| 📝 Summarization | Paragraph, bullets, TL;DR |

---

## Quick Start (5 minutes)

### 1. Clone & configure

```bash
git clone https://github.com/yourname/wolfgpt.git
cd wolfgpt

# Copy env templates
cp backend/.env.example      backend/.env
cp frontend/.env.example     frontend/.env.local
cp ai-services/.env.example  ai-services/.env
```

### 2. Fill in API keys

Edit each `.env` file. The minimum required keys are:

**`backend/.env`**
```env
FIREBASE_SERVICE_ACCOUNT=./firebase-admin-key.json
FIREBASE_STORAGE_BUCKET=your-project.appspot.com
```

**`frontend/.env.local`**
```env
NEXT_PUBLIC_FIREBASE_API_KEY=AIza...
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your-project
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
NEXT_PUBLIC_FIREBASE_APP_ID=1:123:web:abc
```

> See `SETUP.md` for where to get each key.

### 3. Start

```bash
# Docker (recommended)
make docker-up

# OR manually
make install
# Then run 3 terminals: ai-service, backend, frontend
```

Visit **http://localhost:3000** 🎉

---

## Architecture

```
Nginx (80/443)
├── Frontend     Next.js 14       :3000
└── Backend      Express/TS       :4000
         └── AI Service  FastAPI/Python  :8000
                  ├── Ollama          :11434  (chat)
                  ├── Diffusers               (images)
                  ├── Whisper                 (STT)
                  ├── Coqui TTS               (TTS)
                  └── MusicGen                (music)

Firebase (Auth + Firestore + Storage)
Redis    (rate limiting + auth cache)
```

---

## Tier Pricing

| Tier | Price | Chat | Images/day | Music/day | API |
|---|---|---|---|---|---|
| Free    | $0       | Qwen 7B       | 5  | 5  | ❌ |
| Basic   | $99/yr   | Qwen 7B/32B   | 25 | 20 | ✅ 1K/mo |
| Premium | $199/yr  | Qwen up to 72B| 100| 60 | ✅ 50K/mo|
| Pro     | $399/yr  | All models    | ∞  | ∞  | ✅ Unlimited |

---

## Production Deployment

```bash
# On your VPS (Ubuntu 22.04):

# 1. Install Docker
curl -fsSL https://get.docker.com | sh

# 2. Copy files to server
scp -r . user@your-server:/app/wolfgpt

# 3. Deploy
cd /app/wolfgpt
make deploy-prod

# 4. SSL certificate (free)
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d yourdomain.com
```

---

## API Usage

```bash
# Chat completion
curl -X POST https://yourdomain.com/api/v1/chat/completions \
  -H "X-API-Key: wgpt_your_key" \
  -H "Content-Type: application/json" \
  -d '{"messages": [{"role": "user", "content": "Hello!"}]}'

# Generate image
curl -X POST https://yourdomain.com/api/v1/images/generate \
  -H "X-API-Key: wgpt_your_key" \
  -d '{"prompt": "A beautiful wolf in snow"}'

# Generate music
curl -X POST https://yourdomain.com/api/v1/music/generate \
  -H "X-API-Key: wgpt_your_key" \
  -d '{"prompt": "Lo-fi hip hop, chill beats", "duration": 10}'
```

---

## Environment Variables

See `SETUP.md` for a complete table of all variables and where to get them.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | Next.js 14, TypeScript, Tailwind CSS, shadcn/ui |
| Backend | Express.js, TypeScript, Firebase Admin |
| AI Service | FastAPI, Python 3.11, PyTorch |
| Database | Firebase Firestore |
| Storage | Firebase Storage |
| Auth | Firebase Authentication |
| Cache | Redis 7 |
| Chat Models | Ollama + Qwen 2.5 |
| Image Models | HuggingFace Diffusers (FLUX, SDXL) |
| Music Models | Meta MusicGen via HuggingFace |
| Voice STT | OpenAI Whisper |
| Voice TTS | Coqui TTS |
| Payments | Stripe + JazzCash + EasyPaisa |
| Reverse Proxy | Nginx |
| Container | Docker + Docker Compose |

---

## License

MIT — see [LICENSE](LICENSE)
