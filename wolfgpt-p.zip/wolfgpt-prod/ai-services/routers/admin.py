"""
Admin endpoints — model management, system health, GPU stats.
These should be protected by the backend (not exposed publicly).
"""

import logging
import platform
import sys
import time

import torch
from fastapi import APIRouter, HTTPException

from core.config import settings, OLLAMA_MODEL_MAP, IMAGE_MODEL_MAP, WHISPER_MODEL_MAP
from services.model_manager  import model_manager
from services.ollama_service import ollama_service

logger = logging.getLogger(__name__)
router = APIRouter()

_start_time = time.time()


@router.get("/health/detailed")
async def detailed_health():
    ollama_up = await ollama_service.is_running()
    gpu_info  = {}

    if torch.cuda.is_available():
        gpu_info = {
            "name":          torch.cuda.get_device_name(0),
            "total_gb":      round(torch.cuda.get_device_properties(0).total_memory / 1e9, 2),
            "allocated_gb":  round(torch.cuda.memory_allocated() / 1e9, 2),
            "reserved_gb":   round(torch.cuda.memory_reserved()  / 1e9, 2),
        }

    return {
        "status":       "healthy",
        "uptime_s":     round(time.time() - _start_time),
        "python":       sys.version,
        "platform":     platform.platform(),
        "torch_version": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "gpu":          gpu_info,
        "ollama":       {"running": ollama_up},
        "loaded_models": model_manager.status(),
        "config": {
            "ollama_model":  settings.OLLAMA_MODEL,
            "image_model":   settings.IMAGE_MODEL,
            "whisper_model": settings.WHISPER_MODEL,
        },
    }


@router.get("/models")
async def list_all_models():
    ollama_models = await ollama_service.list_models()
    return {
        "ollama": {
            "running": bool(ollama_models),
            "available": ollama_models,
            "aliases": OLLAMA_MODEL_MAP,
        },
        "images": list(IMAGE_MODEL_MAP.keys()),
        "whisper": list(WHISPER_MODEL_MAP.keys()),
        "loaded": model_manager.status()["loaded_models"],
    }


@router.post("/models/pull/{model_alias}")
async def pull_ollama_model(model_alias: str):
    """Pull an Ollama model by WolfGPT alias (e.g. qwen-2.5-7b)."""
    if model_alias not in OLLAMA_MODEL_MAP:
        raise HTTPException(status_code=400, detail=f"Unknown alias: {model_alias}. Known: {list(OLLAMA_MODEL_MAP)}")
    success = await ollama_service.ensure_model(model_alias)
    if not success:
        raise HTTPException(status_code=503, detail="Model pull failed")
    return {"success": True, "model": model_alias}


@router.delete("/models/{model_key}")
async def unload_model(model_key: str):
    """Unload a cached model from memory."""
    unloaded = model_manager.unload(model_key)
    if not unloaded:
        raise HTTPException(status_code=404, detail=f"Model '{model_key}' not loaded")
    return {"success": True, "unloaded": model_key}


@router.delete("/models")
async def unload_all_models():
    """Unload all cached models (frees GPU/RAM)."""
    model_manager.unload_all()
    return {"success": True, "message": "All models unloaded"}
