"""
Document parsing — extracts clean text from PDF, DOCX, CSV, TXT, MD, JSON.
"""

import csv
import io
import json
import logging
import os
import tempfile
from typing import Optional

from fastapi import APIRouter, File, HTTPException, UploadFile
from pydantic import BaseModel

logger = logging.getLogger(__name__)
router = APIRouter()

MAX_SIZE = 50 * 1024 * 1024  # 50 MB


# ── Schemas ───────────────────────────────────────────────────────────────────
class ParseResponse(BaseModel):
    text:       str
    pageCount:  int   = 1
    wordCount:  int   = 0
    charCount:  int   = 0
    fileType:   str   = ""
    truncated:  bool  = False


# ── Parsers ───────────────────────────────────────────────────────────────────
def parse_pdf(data: bytes) -> tuple[str, int]:
    """Return (text, page_count)."""
    try:
        import pypdf
        reader = pypdf.PdfReader(io.BytesIO(data))
        pages  = []
        for page in reader.pages:
            txt = page.extract_text()
            if txt:
                pages.append(txt.strip())
        return "\n\n".join(pages), len(reader.pages)
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"PDF parse error: {e}")


def parse_docx(data: bytes) -> tuple[str, int]:
    try:
        import docx
        doc   = docx.Document(io.BytesIO(data))
        paras = [p.text for p in doc.paragraphs if p.text.strip()]
        # Include table text
        for table in doc.tables:
            for row in table.rows:
                row_text = " | ".join(cell.text.strip() for cell in row.cells if cell.text.strip())
                if row_text:
                    paras.append(row_text)
        return "\n\n".join(paras), max(1, len(paras) // 40)
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"DOCX parse error: {e}")


def parse_csv(data: bytes) -> tuple[str, int]:
    try:
        text   = data.decode("utf-8", errors="replace")
        reader = csv.DictReader(io.StringIO(text))
        rows   = list(reader)
        if not rows:
            return text, 1
        headers = list(rows[0].keys())
        lines   = ["  |  ".join(headers)]
        lines.append("-" * 60)
        for row in rows[:500]:  # cap at 500 rows
            lines.append("  |  ".join(str(v) for v in row.values()))
        return "\n".join(lines), 1
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"CSV parse error: {e}")


def parse_json(data: bytes) -> tuple[str, int]:
    try:
        obj  = json.loads(data.decode("utf-8", errors="replace"))
        text = json.dumps(obj, indent=2, ensure_ascii=False)
        return text, 1
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"JSON parse error: {e}")


def parse_text(data: bytes) -> tuple[str, int]:
    text = data.decode("utf-8", errors="replace")
    return text, max(1, len(text) // 3000)


PARSERS = {
    ".pdf":  parse_pdf,
    ".docx": parse_docx,
    ".csv":  parse_csv,
    ".json": parse_json,
    ".txt":  parse_text,
    ".md":   parse_text,
}


# ── Route ─────────────────────────────────────────────────────────────────────
@router.post("/parse", response_model=ParseResponse)
async def parse_document(file: UploadFile = File(...)):
    data = await file.read()

    if len(data) > MAX_SIZE:
        raise HTTPException(status_code=413, detail="File too large (max 50 MB)")

    ext = os.path.splitext(file.filename or "")[1].lower()
    parser = PARSERS.get(ext)

    if not parser:
        # Try plain-text fallback for unknown extensions
        try:
            text, pages = parse_text(data)
        except Exception:
            raise HTTPException(
                status_code=415,
                detail=f"Unsupported file type: {ext}. Supported: {', '.join(PARSERS)}"
            )
    else:
        text, pages = parser(data)

    # Truncate to ~100 K chars to keep Firestore docs manageable
    MAX_CHARS = 100_000
    truncated = len(text) > MAX_CHARS
    if truncated:
        text = text[:MAX_CHARS]

    word_count = len(text.split())

    return ParseResponse(
        text=text,
        pageCount=pages,
        wordCount=word_count,
        charCount=len(text),
        fileType=ext.lstrip("."),
        truncated=truncated,
    )
