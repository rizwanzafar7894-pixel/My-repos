"""
WolfGPT Image Generation Service — Legendary Edition
=====================================================
Supports:
  • Text-to-Image  (FLUX.1 schnell / dev / pro, SDXL base + refiner)
  • Image-to-Image (img2img with strength control)
  • Inpainting     (mask-based regeneration)
  • Upscaling      (Stable Diffusion x4 upscaler)
  • Image Variations
  • Multipart file upload support for all image-in endpoints

Models are lazy-loaded and cached in-process after first use.
GPU OOM is handled gracefully — pipelines evicted and retried.
"""

from __future__ import annotations

import base64
import io
import logging
import time
import gc
from typing import Optional, Literal

import torch
from fastapi import APIRouter, HTTPException, UploadFile, File, Form
from PIL import Image
from pydantic import BaseModel, Field, model_validator

from core.config import settings, IMAGE_MODEL_MAP

logger = logging.getLogger(__name__)
router = APIRouter()

# ── Pipeline Registry ─────────────────────────────────────────────────────────
_pipelines: dict[str, object] = {}


def get_device() -> str:
    if settings.USE_GPU and torch.cuda.is_available():
        return "cuda"
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def _apply_memory_opts(pipe, device: str):
    if device == "cuda":
        try:
            pipe.enable_model_cpu_offload()
        except Exception:
            pass
        try:
            pipe.enable_xformers_memory_efficient_attention()
        except Exception:
            pass
    return pipe


def evict_pipelines():
    global _pipelines
    _pipelines.clear()
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    logger.warning("All pipelines evicted.")


def load_txt2img(hf_model: str, device: str):
    key = f"txt2img:{hf_model}"
    if key in _pipelines:
        return _pipelines[key]
    logger.info("Loading txt2img: %s on %s", hf_model, device)
    try:
        if "FLUX" in hf_model or "flux" in hf_model.lower():
            from diffusers import FluxPipeline
            pipe = FluxPipeline.from_pretrained(
                hf_model,
                torch_dtype=torch.bfloat16 if device in ("cuda", "mps") else torch.float32,
                cache_dir=settings.IMAGE_CACHE_DIR,
            ).to(device)
        else:
            from diffusers import StableDiffusionXLPipeline
            pipe = StableDiffusionXLPipeline.from_pretrained(
                hf_model,
                torch_dtype=torch.float16 if device == "cuda" else torch.float32,
                use_safetensors=True,
                cache_dir=settings.IMAGE_CACHE_DIR,
            ).to(device)
        _apply_memory_opts(pipe, device)
        _pipelines[key] = pipe
        logger.info("txt2img loaded: %s", hf_model)
        return pipe
    except Exception as e:
        logger.error("Failed to load txt2img %s: %s", hf_model, e)
        raise HTTPException(status_code=503, detail=f"Model load failed: {e}")


def load_img2img(hf_model: str, device: str):
    key = f"img2img:{hf_model}"
    if key in _pipelines:
        return _pipelines[key]
    logger.info("Loading img2img: %s on %s", hf_model, device)
    try:
        if "FLUX" in hf_model or "flux" in hf_model.lower():
            from diffusers import FluxImg2ImgPipeline
            pipe = FluxImg2ImgPipeline.from_pretrained(
                hf_model,
                torch_dtype=torch.bfloat16 if device in ("cuda", "mps") else torch.float32,
                cache_dir=settings.IMAGE_CACHE_DIR,
            ).to(device)
        else:
            from diffusers import StableDiffusionXLImg2ImgPipeline
            pipe = StableDiffusionXLImg2ImgPipeline.from_pretrained(
                hf_model,
                torch_dtype=torch.float16 if device == "cuda" else torch.float32,
                use_safetensors=True,
                cache_dir=settings.IMAGE_CACHE_DIR,
            ).to(device)
        _apply_memory_opts(pipe, device)
        _pipelines[key] = pipe
        logger.info("img2img loaded: %s", hf_model)
        return pipe
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"img2img model load failed: {e}")


def load_inpaint(hf_model: str, device: str):
    key = f"inpaint:{hf_model}"
    if key in _pipelines:
        return _pipelines[key]
    logger.info("Loading inpaint: %s on %s", hf_model, device)
    try:
        from diffusers import StableDiffusionXLInpaintPipeline
        pipe = StableDiffusionXLInpaintPipeline.from_pretrained(
            hf_model,
            torch_dtype=torch.float16 if device == "cuda" else torch.float32,
            use_safetensors=True,
            cache_dir=settings.IMAGE_CACHE_DIR,
        ).to(device)
        _apply_memory_opts(pipe, device)
        _pipelines[key] = pipe
        return pipe
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Inpaint model load failed: {e}")


def load_upscaler(device: str):
    key = "upscale:sd-x4"
    if key in _pipelines:
        return _pipelines[key]
    logger.info("Loading SD x4 upscaler on %s", device)
    try:
        from diffusers import StableDiffusionUpscalePipeline
        pipe = StableDiffusionUpscalePipeline.from_pretrained(
            "stabilityai/stable-diffusion-x4-upscaler",
            torch_dtype=torch.float16 if device == "cuda" else torch.float32,
            cache_dir=settings.IMAGE_CACHE_DIR,
        ).to(device)
        _apply_memory_opts(pipe, device)
        _pipelines[key] = pipe
        return pipe
    except Exception as e:
        raise HTTPException(status_code=503, detail=f"Upscaler load failed: {e}")


# ── Image Utilities ───────────────────────────────────────────────────────────

def base64_to_pil(b64: str) -> Image.Image:
    """Accept raw base64 or data-URL prefix."""
    if "," in b64:
        b64 = b64.split(",", 1)[1]
    data = base64.b64decode(b64 + "==")   # pad is harmless
    return Image.open(io.BytesIO(data)).convert("RGB")


def pil_to_base64(img: Image.Image, fmt: str = "PNG") -> str:
    buf = io.BytesIO()
    img.save(buf, format=fmt, optimize=True)
    return base64.b64encode(buf.getvalue()).decode()


def prepare_image(img: Image.Image, width: int, height: int) -> Image.Image:
    """Resize + centre-crop to target dimensions."""
    ratio = max(width / img.width, height / img.height)
    new_w = max(int(img.width  * ratio), width)
    new_h = max(int(img.height * ratio), height)
    img   = img.resize((new_w, new_h), Image.LANCZOS)
    left  = (new_w - width)  // 2
    top   = (new_h - height) // 2
    return img.crop((left, top, left + width, top + height))


def make_generator(seed: Optional[int], device: str) -> Optional[torch.Generator]:
    if seed is None:
        return None
    g = torch.Generator(device="cpu" if device == "mps" else device)
    g.manual_seed(seed)
    return g


# ── Schemas ───────────────────────────────────────────────────────────────────

class Txt2ImgRequest(BaseModel):
    prompt:          str
    negative_prompt: Optional[str] = None
    model:           str           = "flux-schnell"
    width:           int           = Field(1024, ge=256, le=2048)
    height:          int           = Field(1024, ge=256, le=2048)
    steps:           int           = Field(4,    ge=1,   le=150)
    num_images:      int           = Field(1,    ge=1,   le=4)
    guidance_scale:  float         = Field(0.0,  ge=0.0, le=20.0)
    seed:            Optional[int] = None


class Img2ImgRequest(BaseModel):
    """
    Image-to-Image generation.
    reference_image: base64-encoded input image (PNG / JPG / WEBP).
    strength: 0.0 keeps original; 1.0 = completely new image guided by prompt.
    """
    prompt:          str
    reference_image: str                   # base64
    negative_prompt: Optional[str] = None
    model:           str           = "sdxl-base"
    width:           int           = Field(1024, ge=256, le=2048)
    height:          int           = Field(1024, ge=256, le=2048)
    steps:           int           = Field(30,   ge=1,   le=150)
    strength:        float         = Field(0.75, ge=0.01, le=1.0)
    guidance_scale:  float         = Field(7.5,  ge=0.0,  le=20.0)
    num_images:      int           = Field(1,    ge=1,   le=4)
    seed:            Optional[int] = None

    @model_validator(mode="after")
    def check_b64(self):
        if not self.reference_image or len(self.reference_image) < 20:
            raise ValueError("reference_image must be a valid base64 string")
        return self


class InpaintRequest(BaseModel):
    prompt:          str
    image:           str                   # base64 source image
    mask:            str                   # base64 mask (white = repaint)
    negative_prompt: Optional[str] = None
    model:           str           = "sdxl-base"
    width:           int           = Field(1024, ge=256, le=2048)
    height:          int           = Field(1024, ge=256, le=2048)
    steps:           int           = Field(30,   ge=1,   le=150)
    strength:        float         = Field(0.99, ge=0.01, le=1.0)
    guidance_scale:  float         = Field(7.5,  ge=0.0,  le=20.0)
    seed:            Optional[int] = None


class UpscaleRequest(BaseModel):
    image:       str             # base64
    prompt:      str     = ""
    noise_level: int     = Field(20, ge=0, le=350)


class GeneratedImage(BaseModel):
    base64:  str
    width:   int
    height:  int
    seed:    Optional[int] = None
    mode:    str           = "txt2img"


class ImageResponse(BaseModel):
    images:          list[GeneratedImage]
    model:           str
    generation_time: float
    mode:            str


# ── Routes ────────────────────────────────────────────────────────────────────

@router.post("/generate", response_model=ImageResponse, summary="Text-to-Image")
async def generate_image(req: Txt2ImgRequest):
    """Generate image(s) from a text prompt using FLUX or SDXL."""
    hf_model = IMAGE_MODEL_MAP.get(req.model)
    if not hf_model:
        raise HTTPException(400, f"Unknown model {req.model!r}. Valid: {list(IMAGE_MODEL_MAP)}")

    device    = get_device()
    start     = time.time()
    generator = make_generator(req.seed, device)

    try:
        pipe = load_txt2img(hf_model, device)
        kwargs: dict = dict(
            prompt                = req.prompt,
            width                 = req.width,
            height                = req.height,
            num_inference_steps   = req.steps,
            num_images_per_prompt = req.num_images,
            generator             = generator,
        )
        if req.negative_prompt:
            kwargs["negative_prompt"] = req.negative_prompt
        if req.guidance_scale > 0:
            kwargs["guidance_scale"] = req.guidance_scale

        result = pipe(**kwargs)
    except RuntimeError as e:
        if "out of memory" in str(e).lower():
            evict_pipelines()
            raise HTTPException(503, "GPU OOM — pipelines evicted. Retry with smaller dimensions.")
        raise HTTPException(500, str(e))

    return ImageResponse(
        model=req.model, mode="txt2img",
        generation_time=round(time.time() - start, 2),
        images=[
            GeneratedImage(base64=pil_to_base64(img), width=req.width,
                           height=req.height, seed=req.seed, mode="txt2img")
            for img in result.images
        ],
    )


@router.post("/img2img", response_model=ImageResponse, summary="Image-to-Image (Reference Image)")
async def image_to_image(req: Img2ImgRequest):
    """
    Transform a reference image guided by a prompt.

    - **reference_image**: base64-encoded image (PNG/JPG/WEBP)
    - **strength**: how much to deviate from original (0 = keep, 1 = ignore)
    - **guidance_scale**: how closely to follow the prompt (7-12 recommended)
    """
    hf_model = IMAGE_MODEL_MAP.get(req.model)
    if not hf_model:
        raise HTTPException(400, f"Unknown model {req.model!r}")

    device    = get_device()
    start     = time.time()
    generator = make_generator(req.seed, device)

    try:
        ref_pil = base64_to_pil(req.reference_image)
        ref_pil = prepare_image(ref_pil, req.width, req.height)
    except Exception as e:
        raise HTTPException(400, f"Invalid reference_image: {e}")

    try:
        pipe = load_img2img(hf_model, device)
        kwargs: dict = dict(
            prompt                = req.prompt,
            image                 = ref_pil,
            strength              = req.strength,
            num_inference_steps   = req.steps,
            guidance_scale        = req.guidance_scale,
            num_images_per_prompt = req.num_images,
            generator             = generator,
        )
        if req.negative_prompt:
            kwargs["negative_prompt"] = req.negative_prompt

        result = pipe(**kwargs)
    except RuntimeError as e:
        if "out of memory" in str(e).lower():
            evict_pipelines()
            raise HTTPException(503, "GPU OOM — retry with smaller image or step count.")
        raise HTTPException(500, str(e))

    return ImageResponse(
        model=req.model, mode="img2img",
        generation_time=round(time.time() - start, 2),
        images=[
            GeneratedImage(base64=pil_to_base64(img), width=img.width,
                           height=img.height, seed=req.seed, mode="img2img")
            for img in result.images
        ],
    )


@router.post("/img2img/upload", response_model=ImageResponse,
             summary="Image-to-Image via multipart file upload")
async def image_to_image_upload(
    prompt:          str         = Form(...),
    reference_image: UploadFile  = File(..., description="Reference image (PNG/JPG/WEBP)"),
    negative_prompt: str         = Form(""),
    model:           str         = Form("sdxl-base"),
    width:           int         = Form(1024),
    height:          int         = Form(1024),
    steps:           int         = Form(30),
    strength:        float       = Form(0.75),
    guidance_scale:  float       = Form(7.5),
    num_images:      int         = Form(1),
    seed:            Optional[int] = Form(None),
):
    """
    Multipart upload variant — accepts a real image file instead of base64.
    Ideal for browser/mobile form submissions.
    """
    raw  = await reference_image.read()
    b64  = base64.b64encode(raw).decode()
    req  = Img2ImgRequest(
        prompt          = prompt,
        reference_image = b64,
        negative_prompt = negative_prompt or None,
        model           = model,
        width           = width,
        height          = height,
        steps           = steps,
        strength        = strength,
        guidance_scale  = guidance_scale,
        num_images      = num_images,
        seed            = seed,
    )
    return await image_to_image(req)


@router.post("/inpaint", response_model=ImageResponse, summary="Inpainting")
async def inpaint_image(req: InpaintRequest):
    """
    Replace a masked region with AI-generated content.
    Mask: **white** = repaint, **black** = keep.
    """
    hf_model  = IMAGE_MODEL_MAP.get(req.model, IMAGE_MODEL_MAP["sdxl-base"])
    device    = get_device()
    start     = time.time()
    generator = make_generator(req.seed, device)

    try:
        src_pil  = base64_to_pil(req.image)
        raw_mask = req.mask.split(",", 1)[-1] if "," in req.mask else req.mask
        mask_pil = Image.open(io.BytesIO(base64.b64decode(raw_mask + "=="))).convert("L")
        src_pil  = prepare_image(src_pil,  req.width, req.height)
        mask_pil = mask_pil.resize((req.width, req.height), Image.NEAREST)
    except Exception as e:
        raise HTTPException(400, f"Invalid image/mask: {e}")

    try:
        pipe = load_inpaint(hf_model, device)
        kwargs = dict(
            prompt              = req.prompt,
            image               = src_pil,
            mask_image          = mask_pil,
            width               = req.width,
            height              = req.height,
            num_inference_steps = req.steps,
            strength            = req.strength,
            guidance_scale      = req.guidance_scale,
            generator           = generator,
        )
        if req.negative_prompt:
            kwargs["negative_prompt"] = req.negative_prompt
        result = pipe(**kwargs)
    except RuntimeError as e:
        if "out of memory" in str(e).lower():
            evict_pipelines()
            raise HTTPException(503, "GPU OOM — retry.")
        raise HTTPException(500, str(e))

    return ImageResponse(
        model=req.model, mode="inpaint",
        generation_time=round(time.time() - start, 2),
        images=[
            GeneratedImage(base64=pil_to_base64(img), width=req.width,
                           height=req.height, seed=req.seed, mode="inpaint")
            for img in result.images
        ],
    )


@router.post("/upscale", response_model=ImageResponse, summary="AI 4× Upscaling")
async def upscale_image(req: UpscaleRequest):
    """
    Upscale an image 4× using Stable Diffusion x4 upscaler.
    Input should be ≤512px on the longest edge for best results.
    """
    device = get_device()
    start  = time.time()

    try:
        src_pil = base64_to_pil(req.image)
    except Exception as e:
        raise HTTPException(400, f"Invalid image: {e}")

    # Downscale input if too large
    MAX_INPUT = 512
    if max(src_pil.width, src_pil.height) > MAX_INPUT:
        r       = MAX_INPUT / max(src_pil.width, src_pil.height)
        src_pil = src_pil.resize((int(src_pil.width * r), int(src_pil.height * r)), Image.LANCZOS)

    try:
        pipe    = load_upscaler(device)
        result  = pipe(
            prompt      = req.prompt or "high resolution, sharp, detailed",
            image       = src_pil,
            noise_level = req.noise_level,
        )
        out_img = result.images[0]
    except RuntimeError as e:
        if "out of memory" in str(e).lower():
            evict_pipelines()
            raise HTTPException(503, "GPU OOM — retry.")
        raise HTTPException(500, str(e))

    return ImageResponse(
        model="sd-x4-upscaler", mode="upscale",
        generation_time=round(time.time() - start, 2),
        images=[
            GeneratedImage(base64=pil_to_base64(out_img), width=out_img.width,
                           height=out_img.height, mode="upscale")
        ],
    )


@router.post("/variations", response_model=ImageResponse, summary="Image Variations")
async def image_variations(req: Img2ImgRequest):
    """
    Create stylistic variations of an existing image.
    Lower strength preserves more of the original composition.
    """
    req.strength = min(req.strength, 0.65)
    return await image_to_image(req)


@router.delete("/pipelines", summary="Evict all cached pipelines (free GPU memory)")
async def clear_pipelines():
    count = len(_pipelines)
    evict_pipelines()
    return {"evicted": count, "message": "All pipelines cleared from memory"}


@router.get("/models", summary="List available image models")
async def list_models():
    return {
        "models": [
            {
                "id":              slug,
                "hf_model":        hf,
                "loaded_txt2img":  f"txt2img:{hf}" in _pipelines,
                "loaded_img2img":  f"img2img:{hf}" in _pipelines,
                "supports_img2img": True,
                "supports_inpaint": "sdxl" in hf.lower() or "stable-diffusion" in hf.lower(),
                "supports_upscale": False,
            }
            for slug, hf in IMAGE_MODEL_MAP.items()
        ] + [{
            "id":              "sd-x4-upscaler",
            "hf_model":        "stabilityai/stable-diffusion-x4-upscaler",
            "loaded_txt2img":  False,
            "loaded_img2img":  False,
            "supports_img2img": False,
            "supports_inpaint": False,
            "supports_upscale": True,
        }],
        "device":    get_device(),
        "endpoints": [
            "POST /v1/images/generate        — txt2img",
            "POST /v1/images/img2img         — img2img (base64 reference)",
            "POST /v1/images/img2img/upload  — img2img (file upload)",
            "POST /v1/images/inpaint         — inpainting",
            "POST /v1/images/upscale         — 4× AI upscale",
            "POST /v1/images/variations      — image variations",
        ],
    }
