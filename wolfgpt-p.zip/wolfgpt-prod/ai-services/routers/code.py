"""
Sandboxed code execution.

Strategy:
  1. Try Docker sandbox (safest — full isolation).
  2. Fall back to subprocess with strict resource limits.

Supported languages: Python, JavaScript (Node), TypeScript, Bash, Go, Rust.
"""

import asyncio
import logging
import os
import resource
import tempfile
import time
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from core.config import settings

logger = logging.getLogger(__name__)
router = APIRouter()

# ── Language config ───────────────────────────────────────────────────────────
LANG_CONFIG: dict[str, dict] = {
    "python": {
        "image":   "python:3.11-slim",
        "cmd":     ["python", "-u", "code.py"],
        "file":    "code.py",
        "compile": None,
    },
    "javascript": {
        "image":   "node:20-alpine",
        "cmd":     ["node", "code.js"],
        "file":    "code.js",
        "compile": None,
    },
    "typescript": {
        "image":   "node:20-alpine",
        "cmd":     ["sh", "-c", "npx ts-node --skip-project code.ts"],
        "file":    "code.ts",
        "compile": None,
    },
    "bash": {
        "image":   "bash:5",
        "cmd":     ["bash", "code.sh"],
        "file":    "code.sh",
        "compile": None,
    },
    "go": {
        "image":   "golang:1.22-alpine",
        "cmd":     ["go", "run", "code.go"],
        "file":    "code.go",
        "compile": None,
    },
    "rust": {
        "image":   "rust:1.77-alpine",
        "cmd":     ["sh", "-c", "rustc code.rs -o /tmp/prog && /tmp/prog"],
        "file":    "code.rs",
        "compile": None,
    },
}


# ── Schemas ───────────────────────────────────────────────────────────────────
class CodeRequest(BaseModel):
    code:     str = Field(..., min_length=1, max_length=50_000)
    language: str = "python"
    stdin:    str = ""
    timeout:  int = Field(30, ge=1, le=300)


class CodeResponse(BaseModel):
    output:         str
    error:          Optional[str]
    execution_time: float
    language:       str
    timed_out:      bool = False


# ── Docker sandbox ────────────────────────────────────────────────────────────
async def run_in_docker(req: CodeRequest, cfg: dict) -> CodeResponse:
    """Run code inside a disposable Docker container."""
    import docker  # type: ignore

    with tempfile.TemporaryDirectory() as tmpdir:
        code_file = os.path.join(tmpdir, cfg["file"])
        with open(code_file, "w") as f:
            f.write(req.code)

        start = time.time()
        timed_out = False
        output = ""
        error  = None

        try:
            client = docker.from_env(timeout=10)
            container = client.containers.run(
                cfg["image"],
                cfg["cmd"],
                volumes={tmpdir: {"bind": "/workspace", "mode": "ro"}},
                working_dir="/workspace",
                stdin_open=bool(req.stdin),
                detach=True,
                mem_limit="128m",
                nano_cpus=int(1e9),          # 1 CPU
                network_disabled=True,
                read_only=True,
                tmpfs={"/tmp": "size=64m"},
                environment={"PYTHONDONTWRITEBYTECODE": "1"},
            )

            try:
                result = container.wait(timeout=req.timeout)
                logs   = container.logs(stdout=True, stderr=True).decode("utf-8", errors="replace")
                output = logs[:settings.CODE_MAX_OUTPUT]
                if result["StatusCode"] != 0:
                    error = f"Exit code: {result['StatusCode']}"
            except Exception:
                container.kill()
                timed_out = True
                error = f"Execution timed out after {req.timeout}s"
            finally:
                container.remove(force=True)

        except docker.errors.DockerException as e:
            raise RuntimeError(f"Docker unavailable: {e}")

        elapsed = round(time.time() - start, 3)
        return CodeResponse(
            output=output,
            error=error,
            execution_time=elapsed,
            language=req.language,
            timed_out=timed_out,
        )


# ── Subprocess fallback (restricted) ─────────────────────────────────────────
async def run_subprocess(req: CodeRequest, cfg: dict) -> CodeResponse:
    """Fallback: subprocess with resource limits (Linux only)."""
    with tempfile.TemporaryDirectory() as tmpdir:
        code_file = os.path.join(tmpdir, cfg["file"])
        with open(code_file, "w") as f:
            f.write(req.code)

        # Map language commands to actual system commands
        cmd_map = {
            "python":     ["python3", code_file],
            "javascript": ["node",    code_file],
            "typescript": ["npx", "ts-node", "--skip-project", code_file],
            "bash":       ["bash",    code_file],
            "go":         ["go", "run", code_file],
            "rust":       ["sh", "-c", f"rustc {code_file} -o /tmp/wgprog && /tmp/wgprog"],
        }
        cmd = cmd_map.get(req.language, ["echo", "Unsupported language"])

        def set_limits():
            # 128 MB RAM, 30s CPU
            try:
                resource.setrlimit(resource.RLIMIT_AS, (128 * 1024 * 1024, 128 * 1024 * 1024))
                resource.setrlimit(resource.RLIMIT_CPU, (req.timeout, req.timeout))
            except Exception:
                pass

        start = time.time()
        timed_out = False

        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdin=asyncio.subprocess.PIPE  if req.stdin else asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                preexec_fn=set_limits,
            )

            stdin_bytes = req.stdin.encode() if req.stdin else None

            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(input=stdin_bytes),
                    timeout=req.timeout,
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.communicate()
                timed_out = True
                stdout, stderr = b"", b""

        except Exception as e:
            return CodeResponse(output="", error=str(e), execution_time=0, language=req.language)

        elapsed = round(time.time() - start, 3)
        out = stdout.decode("utf-8", errors="replace")[:settings.CODE_MAX_OUTPUT]
        err = stderr.decode("utf-8", errors="replace")[:5000] if stderr else None
        if timed_out:
            err = f"Execution timed out after {req.timeout}s"

        return CodeResponse(output=out, error=err, execution_time=elapsed, language=req.language, timed_out=timed_out)


# ── Route ─────────────────────────────────────────────────────────────────────
@router.post("/execute", response_model=CodeResponse)
async def execute_code(req: CodeRequest):
    cfg = LANG_CONFIG.get(req.language)
    if not cfg:
        raise HTTPException(status_code=400, detail=f"Unsupported language: {req.language}")

    # Try Docker first, fall back to subprocess
    try:
        return await run_in_docker(req, cfg)
    except RuntimeError as docker_err:
        logger.warning("Docker unavailable (%s), using subprocess fallback", docker_err)
        return await run_subprocess(req, cfg)
    except Exception as e:
        logger.error("Code execution error: %s", e)
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/languages")
async def list_languages():
    return {
        "languages": [
            {"id": k, "name": k.capitalize(), "image": v["image"]}
            for k, v in LANG_CONFIG.items()
        ]
    }
