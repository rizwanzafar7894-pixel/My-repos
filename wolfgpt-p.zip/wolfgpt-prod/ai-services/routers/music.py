"""
WolfGPT Music Generation Service — Legendary Edition
=====================================================
Powered by Meta's AudioCraft (MusicGen) — 100% free & open source.

Models (all run locally, no API key needed):
  • musicgen-small   — 300M params, fast, good quality
  • musicgen-medium  — 1.5B params, better quality
  • musicgen-large   — 3.3B params, best quality (needs ~8GB VRAM)
  • musicgen-melody  — melody-conditioned generation (hum/reference audio)
  • musicgen-stereo-small   — stereo output version

Endpoints:
  POST /v1/music/generate          — text-to-music
  POST /v1/music/continuation      — continue an existing audio clip
  POST /v1/music/melody            — generate from reference melody
  POST /v1/music/upload-melody     — multipart file upload for melody
  GET  /v1/music/models            — list available models
  DELETE /v1/music/models          — evict all cached models

All audio is returned as base64-encoded WAV bytes.
"""

from __future__ import annotations

import base64
import gc
import io
import logging
import time
from typing import Optional, Literal

import torch
import numpy as np
from fastapi import APIRouter, HTTPException, UploadFile, File, Form
from fastapi.responses import Response
from pydantic import BaseModel, Field, model_validator

logger = logging.getLogger(__name__)
router = APIRouter()

# ── Model Registry ────────────────────────────────────────────────────────────
_models: dict[str, object] = {}

MusicGenModel = Literal[
    "musicgen-small",
    "musicgen-medium",
    "musicgen-large",
    "musicgen-melody",
    "musicgen-stereo-small",
    "musicgen-stereo-medium",
]

MUSICGEN_HF_MAP: dict[str, str] = {
    "musicgen-small":         "facebook/musicgen-small",
    "musicgen-medium":        "facebook/musicgen-medium",
    "musicgen-large":         "facebook/musicgen-large",
    "musicgen-melody":        "facebook/musicgen-melody",
    "musicgen-stereo-small":  "facebook/musicgen-stereo-small",
    "musicgen-stereo-medium": "facebook/musicgen-stereo-medium",
}

MUSICGEN_INFO: dict[str, dict] = {
    "musicgen-small":  {
        "name": "MusicGen Small",  "params": "300M", "stereo": False,
        "melody": False, "vram_gb": 2,
        "description": "Fast generation, good quality. Best for quick iterations.",
    },
    "musicgen-medium": {
        "name": "MusicGen Medium", "params": "1.5B", "stereo": False,
        "melody": False, "vram_gb": 4,
        "description": "Balanced quality and speed. Recommended default.",
    },
    "musicgen-large":  {
        "name": "MusicGen Large",  "params": "3.3B", "stereo": False,
        "melody": False, "vram_gb": 8,
        "description": "Highest quality. Requires 8GB+ VRAM.",
    },
    "musicgen-melody": {
        "name": "MusicGen Melody", "params": "1.5B", "stereo": False,
        "melody": True,  "vram_gb": 4,
        "description": "Generates music conditioned on a reference melody (hum/audio).",
    },
    "musicgen-stereo-small": {
        "name": "MusicGen Stereo Small", "params": "300M", "stereo": True,
        "melody": False, "vram_gb": 2,
        "description": "Stereo output, fast. Great for spatial audio.",
    },
    "musicgen-stereo-medium": {
        "name": "MusicGen Stereo Medium", "params": "1.5B", "stereo": True,
        "melody": False, "vram_gb": 5,
        "description": "Stereo output, high quality.",
    },
}


def get_device() -> str:
    if torch.cuda.is_available():
        return "cuda"
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return "mps"
    return "cpu"


def evict_music_models():
    global _models
    _models.clear()
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    logger.warning("All music models evicted from memory.")


def load_musicgen(model_id: str):
    """Lazy-load and cache a MusicGen pipeline."""
    if model_id in _models:
        return _models[model_id]

    hf_name = MUSICGEN_HF_MAP.get(model_id)
    if not hf_name:
        raise HTTPException(400, f"Unknown model: {model_id!r}. Valid: {list(MUSICGEN_HF_MAP)}")

    device = get_device()
    logger.info("Loading MusicGen model: %s on %s", hf_name, device)

    try:
        from transformers import MusicgenForConditionalGeneration, AutoProcessor

        processor = AutoProcessor.from_pretrained(hf_name)
        model     = MusicgenForConditionalGeneration.from_pretrained(
            hf_name,
            torch_dtype=torch.float16 if device == "cuda" else torch.float32,
        )
        model.eval()
        model.to(device)

        _models[model_id] = {"model": model, "processor": processor, "device": device}
        logger.info("✅ MusicGen %s ready on %s", model_id, device)
        return _models[model_id]

    except ImportError:
        raise HTTPException(
            503,
            "transformers library not installed or missing audiocraft deps. "
            "Run: pip install transformers[audio] audiocraft",
        )
    except Exception as e:
        logger.error("Failed to load MusicGen %s: %s", model_id, e)
        raise HTTPException(503, f"Model load failed: {e}")


# ── Audio Utilities ───────────────────────────────────────────────────────────

def tensor_to_wav_base64(audio_tensor: torch.Tensor, sample_rate: int = 32000) -> str:
    """Convert a MusicGen output tensor to base64-encoded WAV bytes."""
    import scipy.io.wavfile as wavfile

    # Shape: (batch, channels, samples) or (batch, samples)
    if audio_tensor.dim() == 3:
        audio_np = audio_tensor[0].cpu().float().numpy()  # (channels, samples)
    elif audio_tensor.dim() == 2:
        audio_np = audio_tensor[0].cpu().float().numpy()  # (samples,)
        audio_np = audio_np[np.newaxis, :]                # → (1, samples)
    else:
        audio_np = audio_tensor.cpu().float().numpy()
        audio_np = audio_np[np.newaxis, :]

    # Normalise to int16
    audio_np = np.clip(audio_np, -1.0, 1.0)
    audio_int16 = (audio_np * 32767).astype(np.int16)

    # Transpose to (samples, channels) for scipy
    if audio_int16.ndim == 2:
        audio_int16 = audio_int16.T    # (samples, channels)

    buf = io.BytesIO()
    wavfile.write(buf, sample_rate, audio_int16)
    return base64.b64encode(buf.getvalue()).decode()


def audio_bytes_to_tensor(raw: bytes, target_sr: int = 32000) -> tuple[torch.Tensor, int]:
    """Load raw audio bytes → float32 tensor for MusicGen conditioning."""
    import soundfile as sf
    import librosa

    buf = io.BytesIO(raw)
    audio, sr = sf.read(buf, always_2d=False)

    # Resample to target sample rate
    if sr != target_sr:
        audio = librosa.resample(audio.astype(np.float32), orig_sr=sr, target_sr=target_sr)

    # Mono → (1, samples)
    if audio.ndim == 2:
        audio = audio.mean(axis=1)

    tensor = torch.FloatTensor(audio).unsqueeze(0)   # (1, samples)
    return tensor, target_sr


# ── Schemas ───────────────────────────────────────────────────────────────────

class MusicGenRequest(BaseModel):
    """Text-to-music generation request."""
    prompt:          str                      = Field(..., min_length=3, max_length=500,
                                                description="Describe the music: genre, mood, instruments, tempo...")
    model:           str                      = Field("musicgen-small",
                                                description="Model ID from /v1/music/models")
    duration:        float                    = Field(8.0,  ge=1.0, le=30.0,
                                                description="Duration in seconds (1–30s)")
    temperature:     float                    = Field(1.0,  ge=0.1, le=2.0,
                                                description="Sampling temperature (higher = more creative)")
    top_k:           int                      = Field(250,  ge=1,   le=1000)
    top_p:           float                    = Field(0.0,  ge=0.0, le=1.0,
                                                description="Nucleus sampling (0 = disabled)")
    cfg_coef:        float                    = Field(3.0,  ge=0.0, le=10.0,
                                                description="Classifier-free guidance strength")
    num_samples:     int                      = Field(1,    ge=1,   le=4,
                                                description="Number of variations to generate")
    seed:            Optional[int]            = None
    format:          Literal["wav", "mp3"]   = "wav"


class MelodyRequest(BaseModel):
    """Generate music conditioned on a reference melody (base64 audio)."""
    prompt:          str                      = Field(..., min_length=1, max_length=500)
    reference_audio: str                      = Field(..., min_length=20,
                                                description="Base64-encoded reference audio (wav/mp3/ogg)")
    model:           str                      = "musicgen-melody"
    duration:        float                    = Field(8.0,  ge=1.0, le=30.0)
    temperature:     float                    = Field(1.0,  ge=0.1, le=2.0)
    cfg_coef:        float                    = Field(3.0,  ge=0.0, le=10.0)
    seed:            Optional[int]            = None

    @model_validator(mode="after")
    def must_be_melody_model(self):
        if "melody" not in self.model:
            self.model = "musicgen-melody"
        return self


class ContinuationRequest(BaseModel):
    """Continue an existing audio clip."""
    prompt:          str                      = Field(..., min_length=1, max_length=500)
    audio_prompt:    str                      = Field(..., min_length=20,
                                                description="Base64 audio to continue from")
    model:           str                      = "musicgen-medium"
    duration:        float                    = Field(8.0, ge=1.0, le=30.0)
    temperature:     float                    = Field(1.0, ge=0.1, le=2.0)
    cfg_coef:        float                    = Field(3.0, ge=0.0, le=10.0)
    seed:            Optional[int]            = None


class GeneratedTrack(BaseModel):
    audio_base64:    str
    duration:        float
    sample_rate:     int
    format:          str
    model:           str
    prompt:          str
    seed:            Optional[int]  = None
    generation_time: float


class MusicResponse(BaseModel):
    tracks:          list[GeneratedTrack]
    model:           str
    mode:            str
    generation_time: float


# ── Routes ────────────────────────────────────────────────────────────────────

@router.post("/generate", response_model=MusicResponse, summary="Text-to-Music Generation")
async def generate_music(req: MusicGenRequest):
    """
    Generate music from a text description using Meta MusicGen.

    **Prompt tips:**
    - Include genre: *"upbeat electronic dance music"*
    - Add instruments: *"acoustic guitar and violin, folk style"*
    - Specify mood: *"melancholic piano, slow tempo, cinematic"*
    - Set tempo: *"fast-paced hip hop beat, 140 BPM"*
    - Mix it up: *"lo-fi hip hop, rainy day vibes, jazz chords, smooth bass"*
    """
    bundle = load_musicgen(req.model)
    model, processor, device = bundle["model"], bundle["processor"], bundle["device"]

    start = time.time()

    # Set seed for reproducibility
    if req.seed is not None:
        torch.manual_seed(req.seed)
        if device == "cuda":
            torch.cuda.manual_seed(req.seed)

    try:
        # Tokenise prompt(s)
        prompts  = [req.prompt] * req.num_samples
        inputs   = processor(text=prompts, return_tensors="pt", padding=True)
        inputs   = {k: v.to(device) for k, v in inputs.items()}

        # Samples per second for this model
        sample_rate   = model.config.audio_encoder.sampling_rate  # typically 32000
        max_new_tokens = int(req.duration * sample_rate / model.config.audio_encoder.frame_rate)

        with torch.inference_mode():
            audio_values = model.generate(
                **inputs,
                max_new_tokens  = max_new_tokens,
                do_sample       = True,
                temperature     = req.temperature,
                top_k           = req.top_k if req.top_k > 0 else None,
                top_p           = req.top_p if req.top_p > 0 else None,
                guidance_scale  = req.cfg_coef,
            )

    except RuntimeError as e:
        if "out of memory" in str(e).lower():
            evict_music_models()
            raise HTTPException(503, "GPU OOM — music models evicted. Retry with shorter duration or smaller model.")
        raise HTTPException(500, f"Generation error: {e}")

    gen_time = round(time.time() - start, 2)

    tracks: list[GeneratedTrack] = []
    for i in range(req.num_samples):
        single = audio_values[i].unsqueeze(0)   # (1, channels, samples) or (1, samples)
        b64    = tensor_to_wav_base64(single, sample_rate)
        actual_duration = single.shape[-1] / sample_rate

        tracks.append(GeneratedTrack(
            audio_base64    = b64,
            duration        = round(actual_duration, 2),
            sample_rate     = sample_rate,
            format          = "wav",
            model           = req.model,
            prompt          = req.prompt,
            seed            = req.seed,
            generation_time = gen_time,
        ))

    return MusicResponse(
        tracks          = tracks,
        model           = req.model,
        mode            = "txt2music",
        generation_time = gen_time,
    )


@router.post("/melody", response_model=MusicResponse, summary="Melody-Conditioned Generation")
async def melody_conditioned(req: MelodyRequest):
    """
    Generate music conditioned on a reference melody.
    Upload a hummed tune, whistled melody, or any audio clip as base64.
    MusicGen Melody will preserve the melodic structure while following your text prompt.
    """
    bundle = load_musicgen(req.model)
    model, processor, device = bundle["model"], bundle["processor"], bundle["device"]

    # Decode reference audio
    try:
        raw_bytes = base64.b64decode(req.reference_audio + "==")
        melody_tensor, sr = audio_bytes_to_tensor(raw_bytes, target_sr=32000)
        melody_tensor = melody_tensor.unsqueeze(0).to(device)   # (1, 1, samples)
    except Exception as e:
        raise HTTPException(400, f"Invalid reference_audio: {e}")

    start = time.time()
    if req.seed is not None:
        torch.manual_seed(req.seed)

    try:
        inputs = processor(
            audio             = melody_tensor,
            sampling_rate     = 32000,
            text              = [req.prompt],
            return_tensors    = "pt",
            padding           = True,
        )
        inputs = {k: v.to(device) for k, v in inputs.items()}

        sample_rate    = model.config.audio_encoder.sampling_rate
        max_new_tokens = int(req.duration * sample_rate / model.config.audio_encoder.frame_rate)

        with torch.inference_mode():
            audio_values = model.generate(
                **inputs,
                max_new_tokens = max_new_tokens,
                guidance_scale = req.cfg_coef,
                temperature    = req.temperature,
            )

    except RuntimeError as e:
        if "out of memory" in str(e).lower():
            evict_music_models()
            raise HTTPException(503, "GPU OOM — retry with smaller model.")
        raise HTTPException(500, str(e))

    gen_time = round(time.time() - start, 2)
    b64      = tensor_to_wav_base64(audio_values, sample_rate)
    duration = audio_values.shape[-1] / sample_rate

    return MusicResponse(
        tracks=[GeneratedTrack(
            audio_base64=b64, duration=round(duration, 2),
            sample_rate=sample_rate, format="wav",
            model=req.model, prompt=req.prompt, seed=req.seed,
            generation_time=gen_time,
        )],
        model=req.model, mode="melody", generation_time=gen_time,
    )


@router.post("/melody/upload", response_model=MusicResponse,
             summary="Melody-Conditioned via file upload")
async def melody_upload(
    prompt:          str        = Form(...),
    reference_audio: UploadFile = File(..., description="Reference melody file (wav/mp3/ogg)"),
    model:           str        = Form("musicgen-melody"),
    duration:        float      = Form(8.0),
    temperature:     float      = Form(1.0),
    cfg_coef:        float      = Form(3.0),
    seed:            Optional[int] = Form(None),
):
    """Multipart upload version of melody generation — accepts real audio files."""
    raw  = await reference_audio.read()
    b64  = base64.b64encode(raw).decode()
    req  = MelodyRequest(
        prompt=prompt, reference_audio=b64,
        model=model, duration=duration,
        temperature=temperature, cfg_coef=cfg_coef, seed=seed,
    )
    return await melody_conditioned(req)


@router.post("/continuation", response_model=MusicResponse,
             summary="Continue an existing audio clip")
async def continue_music(req: ContinuationRequest):
    """
    Continue a provided audio clip.  
    Feed the model the last few seconds of your track and it will generate
    a seamless continuation guided by your text prompt.
    """
    bundle = load_musicgen(req.model)
    model, processor, device = bundle["model"], bundle["processor"], bundle["device"]

    try:
        raw_bytes    = base64.b64decode(req.audio_prompt + "==")
        audio_tensor, _ = audio_bytes_to_tensor(raw_bytes, target_sr=32000)
        # Use only last 10 s as prompt to avoid OOM
        sr         = 32000
        max_prompt = sr * 10
        if audio_tensor.shape[-1] > max_prompt:
            audio_tensor = audio_tensor[..., -max_prompt:]
        audio_tensor = audio_tensor.unsqueeze(0).to(device)
    except Exception as e:
        raise HTTPException(400, f"Invalid audio_prompt: {e}")

    start = time.time()
    if req.seed is not None:
        torch.manual_seed(req.seed)

    try:
        inputs = processor(
            audio          = audio_tensor,
            sampling_rate  = 32000,
            text           = [req.prompt],
            return_tensors = "pt",
            padding        = True,
        )
        inputs = {k: v.to(device) for k, v in inputs.items()}

        sample_rate    = model.config.audio_encoder.sampling_rate
        max_new_tokens = int(req.duration * sample_rate / model.config.audio_encoder.frame_rate)

        with torch.inference_mode():
            audio_values = model.generate(
                **inputs,
                max_new_tokens = max_new_tokens,
                guidance_scale = req.cfg_coef,
                temperature    = req.temperature,
            )

    except RuntimeError as e:
        if "out of memory" in str(e).lower():
            evict_music_models()
            raise HTTPException(503, "GPU OOM — retry.")
        raise HTTPException(500, str(e))

    gen_time = round(time.time() - start, 2)
    b64      = tensor_to_wav_base64(audio_values, sample_rate)
    duration = audio_values.shape[-1] / sample_rate

    return MusicResponse(
        tracks=[GeneratedTrack(
            audio_base64=b64, duration=round(duration, 2),
            sample_rate=sample_rate, format="wav",
            model=req.model, prompt=req.prompt, seed=req.seed,
            generation_time=gen_time,
        )],
        model=req.model, mode="continuation", generation_time=gen_time,
    )


@router.get("/models", summary="List available MusicGen models")
async def list_models():
    return {
        "models": [
            {
                "id":          mid,
                "hf_model":    MUSICGEN_HF_MAP[mid],
                "loaded":      mid in _models,
                "device":      _models[mid]["device"] if mid in _models else None,
                **MUSICGEN_INFO.get(mid, {}),
            }
            for mid in MUSICGEN_HF_MAP
        ],
        "device":    get_device(),
        "endpoints": [
            "POST /v1/music/generate        — text to music",
            "POST /v1/music/melody          — melody conditioned (base64)",
            "POST /v1/music/melody/upload   — melody conditioned (file upload)",
            "POST /v1/music/continuation    — continue audio clip",
            "GET  /v1/music/models          — list models",
            "DELETE /v1/music/models        — evict loaded models",
        ],
    }


@router.delete("/models", summary="Evict all loaded music models (free memory)")
async def evict_models():
    count = len(_models)
    evict_music_models()
    return {"evicted": count, "message": "All music models cleared from memory"}
