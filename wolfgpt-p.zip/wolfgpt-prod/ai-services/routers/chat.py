"""
Chat completions — proxies to Ollama with streaming support.
Supports all Qwen 2.5 and LLaVA models.
"""

import json
import logging
from typing import AsyncGenerator

import httpx
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from core.config import settings, OLLAMA_MODEL_MAP

logger = logging.getLogger(__name__)
router = APIRouter()


# ── Schemas ───────────────────────────────────────────────────────────────────
class Message(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    messages:    list[Message]
    model:       str = "qwen-2.5-7b"
    temperature: float = Field(0.7, ge=0.0, le=2.0)
    max_tokens:  int   = Field(2048, ge=1, le=32768)
    stream:      bool  = False
    top_p:       float = Field(0.9, ge=0.0, le=1.0)


class ChatResponse(BaseModel):
    choices: list[dict]
    model:   str
    usage:   dict


# ── Helpers ───────────────────────────────────────────────────────────────────
def resolve_model(model_id: str) -> str:
    return OLLAMA_MODEL_MAP.get(model_id, settings.OLLAMA_MODEL)


async def stream_ollama(payload: dict) -> AsyncGenerator[bytes, None]:
    """Yield SSE chunks from Ollama's streaming API."""
    async with httpx.AsyncClient(timeout=120) as client:
        async with client.stream(
            "POST",
            f"{settings.OLLAMA_URL}/api/chat",
            json=payload,
        ) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if not line:
                    continue
                try:
                    chunk = json.loads(line)
                    content = chunk.get("message", {}).get("content", "")
                    done    = chunk.get("done", False)

                    if content:
                        data = json.dumps({"choices": [{"delta": {"content": content}, "finish_reason": None}]})
                        yield f"data: {data}\n\n".encode()

                    if done:
                        yield b"data: [DONE]\n\n"
                        return
                except json.JSONDecodeError:
                    continue


# ── Routes ────────────────────────────────────────────────────────────────────
@router.post("/completions")
async def chat_completions(req: ChatRequest):
    ollama_model = resolve_model(req.model)

    payload = {
        "model":    ollama_model,
        "messages": [m.model_dump() for m in req.messages],
        "stream":   req.stream,
        "options": {
            "temperature": req.temperature,
            "top_p":       req.top_p,
            "num_predict": req.max_tokens,
        },
    }

    # ── Streaming ─────────────────────────────────────────────────────────────
    if req.stream:
        return StreamingResponse(
            stream_ollama(payload),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
        )

    # ── Non-streaming ─────────────────────────────────────────────────────────
    try:
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(
                f"{settings.OLLAMA_URL}/api/chat",
                json=payload,
            )
            resp.raise_for_status()
            data = resp.json()
    except httpx.ConnectError:
        raise HTTPException(
            status_code=503,
            detail="Ollama not running. Start with: ollama serve",
        )
    except httpx.HTTPStatusError as e:
        raise HTTPException(status_code=e.response.status_code, detail=str(e))

    assistant_content = data.get("message", {}).get("content", "")
    prompt_tokens     = data.get("prompt_eval_count", 0)
    completion_tokens = data.get("eval_count", 0)

    return ChatResponse(
        model=req.model,
        choices=[{
            "index":   0,
            "message": {"role": "assistant", "content": assistant_content},
            "finish_reason": "stop",
        }],
        usage={
            "prompt_tokens":     prompt_tokens,
            "completion_tokens": completion_tokens,
            "total_tokens":      prompt_tokens + completion_tokens,
        },
    )
