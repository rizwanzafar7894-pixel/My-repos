"""
Voice services — Whisper STT + Coqui TTS.
Both models are loaded lazily and kept in memory.
"""

import io
import logging
import os
import tempfile
import time
from typing import Optional

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel, Field

from core.config import settings, WHISPER_MODEL_MAP

logger = logging.getLogger(__name__)
router = APIRouter()

# ── Lazy model handles ────────────────────────────────────────────────────────
_whisper_model = None
_tts_model     = None


def get_whisper(model_size: str = "base"):
    global _whisper_model
    size = WHISPER_MODEL_MAP.get(model_size, "base")
    if _whisper_model is None:
        logger.info("Loading Whisper model: %s", size)
        import whisper
        _whisper_model = whisper.load_model(
            size,
            device=settings.WHISPER_DEVICE,
            download_root=settings.WHISPER_CACHE_DIR,
        )
        logger.info("✅ Whisper ready")
    return _whisper_model


def get_tts():
    global _tts_model
    if _tts_model is None:
        logger.info("Loading Coqui TTS model: %s", settings.TTS_MODEL)
        from TTS.api import TTS
        _tts_model = TTS(model_name=settings.TTS_MODEL, progress_bar=False)
        logger.info("✅ Coqui TTS ready")
    return _tts_model


# ── Schemas ───────────────────────────────────────────────────────────────────
class STTResponse(BaseModel):
    text:       str
    language:   str
    duration:   Optional[float]
    confidence: float = 0.95


class TTSRequest(BaseModel):
    text:  str = Field(..., min_length=1, max_length=5000)
    voice: str = "en-US-female-1"
    speed: float = Field(1.0, ge=0.5, le=2.0)


# ── Routes ────────────────────────────────────────────────────────────────────
@router.post("/stt", response_model=STTResponse)
async def speech_to_text(
    audio:    UploadFile = File(...),
    language: str        = Form("en"),
    model:    str        = Form("base"),
):
    """Transcribe audio using OpenAI Whisper."""
    content = await audio.read()
    if len(content) > 25 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Audio file too large (max 25 MB)")

    # Write to temp file — Whisper requires a file path
    suffix = os.path.splitext(audio.filename or "audio.webm")[1] or ".webm"
    with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
        tmp.write(content)
        tmp_path = tmp.name

    try:
        whisper_model = get_whisper(model)

        lang = language if language != "auto" else None

        start  = time.time()
        result = whisper_model.transcribe(
            tmp_path,
            language=lang,
            fp16=False,                    # safe for CPU
            verbose=False,
        )
        duration = round(time.time() - start, 2)

        text            = result.get("text", "").strip()
        detected_lang   = result.get("language", language)

        return STTResponse(
            text=text,
            language=detected_lang,
            duration=duration,
            confidence=0.95,
        )

    except Exception as e:
        logger.error("Whisper STT error: %s", e)
        raise HTTPException(status_code=500, detail=f"STT failed: {e}")

    finally:
        os.unlink(tmp_path)


@router.post("/tts")
async def text_to_speech(req: TTSRequest):
    """Synthesise speech using Coqui TTS. Returns audio/mpeg bytes."""
    # Map speed to speaking_rate  (Coqui uses speed as a multiplier)
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
        out_path = tmp.name

    try:
        tts = get_tts()
        tts.tts_to_file(
            text=req.text,
            file_path=out_path,
            speed=req.speed,
        )

        with open(out_path, "rb") as f:
            audio_bytes = f.read()

        return Response(
            content=audio_bytes,
            media_type="audio/wav",
            headers={"Content-Length": str(len(audio_bytes))},
        )

    except Exception as e:
        logger.error("Coqui TTS error: %s", e)
        raise HTTPException(status_code=500, detail=f"TTS failed: {e}")

    finally:
        if os.path.exists(out_path):
            os.unlink(out_path)


@router.get("/voices")
async def list_voices():
    return {
        "voices": [
            {"id": "en-US-female-1", "name": "Emma",   "language": "en-US", "gender": "female"},
            {"id": "en-US-male-1",   "name": "James",  "language": "en-US", "gender": "male"},
            {"id": "en-GB-female-1", "name": "Sophie", "language": "en-GB", "gender": "female"},
            {"id": "en-GB-male-1",   "name": "Oliver", "language": "en-GB", "gender": "male"},
            {"id": "ur-PK-female-1", "name": "Ayesha", "language": "ur-PK", "gender": "female"},
        ]
    }


@router.get("/languages")
async def list_languages():
    return {
        "languages": [
            {"code": "en",  "name": "English",    "native": "English"},
            {"code": "ur",  "name": "Urdu",        "native": "اردو"},
            {"code": "ar",  "name": "Arabic",      "native": "العربية"},
            {"code": "zh",  "name": "Chinese",     "native": "中文"},
            {"code": "es",  "name": "Spanish",     "native": "Español"},
            {"code": "fr",  "name": "French",      "native": "Français"},
            {"code": "de",  "name": "German",      "native": "Deutsch"},
            {"code": "hi",  "name": "Hindi",       "native": "हिंदी"},
            {"code": "ja",  "name": "Japanese",    "native": "日本語"},
            {"code": "ko",  "name": "Korean",      "native": "한국어"},
            {"code": "pt",  "name": "Portuguese",  "native": "Português"},
            {"code": "ru",  "name": "Russian",     "native": "Русский"},
            {"code": "tr",  "name": "Turkish",     "native": "Türkçe"},
        ]
    }
