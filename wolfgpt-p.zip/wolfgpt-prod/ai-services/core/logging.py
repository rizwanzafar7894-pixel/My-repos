import logging
import sys
import os


def setup_logging() -> None:
    level = logging.DEBUG if os.getenv("DEBUG") else logging.INFO
    fmt   = "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"

    logging.basicConfig(
        level=level,
        format=fmt,
        datefmt=datefmt,
        handlers=[logging.StreamHandler(sys.stdout)],
    )

    # Silence noisy third-party loggers
    for lib in ("httpx", "httpcore", "urllib3", "diffusers", "transformers"):
        logging.getLogger(lib).setLevel(logging.WARNING)
