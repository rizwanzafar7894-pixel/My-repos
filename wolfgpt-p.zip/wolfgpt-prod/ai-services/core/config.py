"""Central configuration — reads from environment variables."""

import os
from typing import List
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # Server
    PORT:  int  = 8000
    DEBUG: bool = False

    # Ollama (chat models)
    OLLAMA_URL:   str = "http://localhost:11434"
    OLLAMA_MODEL: str = "qwen2.5:7b"        # default; overridden per-request

    # Image generation
    IMAGE_MODEL:     str = "black-forest-labs/FLUX.1-schnell"
    IMAGE_CACHE_DIR: str = "/app/models/images"
    USE_GPU:         bool = True

    # Whisper STT
    WHISPER_MODEL:     str = "base"          # tiny/base/small/medium/large-v3
    WHISPER_DEVICE:    str = "cpu"           # "cpu" or "cuda"
    WHISPER_CACHE_DIR: str = "/app/models/whisper"

    # Coqui TTS
    TTS_MODEL:     str = "tts_models/en/ljspeech/tacotron2-DDC"
    TTS_CACHE_DIR: str = "/app/models/tts"

    # Code sandbox
    CODE_TIMEOUT:    int = 30               # seconds
    CODE_MAX_OUTPUT: int = 50_000           # chars

    # Document parsing
    MAX_DOC_SIZE: int = 50 * 1024 * 1024    # 50 MB

    # CORS
    ALLOWED_ORIGINS: List[str] = ["http://localhost:4000", "http://backend:4000"]

    # Redis (optional — for response caching)
    REDIS_URL: str = "redis://localhost:6379"

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()


# ── Ollama model mapping ──────────────────────────────────────────────────────
OLLAMA_MODEL_MAP: dict[str, str] = {
    "qwen-2.5-7b":  "qwen2.5:7b",
    "qwen-2.5-32b": "qwen2.5:32b",
    "qwen-2.5-72b": "qwen2.5:72b",
    "llava-7b":     "llava:7b",
    "llava-13b":    "llava:13b",
    "llava-34b":    "llava:34b",
}

# ── Image model mapping ───────────────────────────────────────────────────────
IMAGE_MODEL_MAP: dict[str, str] = {
    "flux-schnell": "black-forest-labs/FLUX.1-schnell",
    "flux-dev":     "black-forest-labs/FLUX.1-dev",
    "flux-pro":     "black-forest-labs/FLUX.1-pro",
    "sdxl-base":    "stabilityai/stable-diffusion-xl-base-1.0",
    "sdxl-refiner": "stabilityai/stable-diffusion-xl-refiner-1.0",
}

# ── Whisper model sizes ───────────────────────────────────────────────────────
WHISPER_MODEL_MAP: dict[str, str] = {
    "tiny":    "tiny",
    "base":    "base",
    "small":   "small",
    "medium":  "medium",
    "large":   "large-v3",
    "whisper-large-v3": "large-v3",
}

# ── MusicGen settings ─────────────────────────────────────────────────────────
MUSICGEN_MODEL_MAP: dict[str, str] = {
    "musicgen-small":         "facebook/musicgen-small",
    "musicgen-medium":        "facebook/musicgen-medium",
    "musicgen-large":         "facebook/musicgen-large",
    "musicgen-melody":        "facebook/musicgen-melody",
    "musicgen-stereo-small":  "facebook/musicgen-stereo-small",
    "musicgen-stereo-medium": "facebook/musicgen-stereo-medium",
}
