"""
WolfGPT AI Services — FastAPI micro-service
Runs on port 8000, called by the Node.js backend.

Endpoints:
  POST /v1/chat/completions       → Qwen 2.5 via Ollama
  POST /v1/images/generate        → FLUX / SDXL via diffusers
  POST /v1/voice/stt              → Whisper STT
  POST /v1/voice/tts              → Coqui TTS
  POST /v1/code/execute           → Sandboxed code execution
  POST /v1/documents/parse        → PDF / DOCX / CSV text extraction
  POST /v1/music/generate         → MusicGen text-to-music
  GET  /health                    → Service health
"""

import logging
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn

from routers import chat, images, voice, code, documents, admin, music
from core.config import settings
from core.logging import setup_logging

# ── Logging ──────────────────────────────────────────────────────────────────
setup_logging()
logger = logging.getLogger(__name__)


# ── Lifespan (startup / shutdown) ────────────────────────────────────────────
@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🚀 WolfGPT AI Service starting …")
    logger.info("✅ AI Service ready  →  http://0.0.0.0:%s", settings.PORT)
    yield
    logger.info("🛑 AI Service shutting down")


# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="WolfGPT AI Services",
    version="1.0.0",
    description="AI micro-service: chat, images, voice, code, documents, music",
    lifespan=lifespan,
    # Disable docs in production for security
    docs_url="/docs" if os.environ.get("DEBUG", "").lower() in ("1", "true") else None,
    redoc_url=None,
)


# ── CORS ──────────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_methods=["POST", "GET"],
    allow_headers=["Content-Type", "Authorization"],
)


# ── Manual trusted-host guard (replaces TrustedHostMiddleware which breaks
#    in some Docker networking scenarios with internal hostnames) ──────────────
_TRUSTED_HOSTS = {
    h.strip()
    for h in os.environ.get("TRUSTED_HOSTS", "localhost,127.0.0.1,backend").split(",")
    if h.strip()
}

@app.middleware("http")
async def trusted_host_guard(request: Request, call_next):
    host = request.headers.get("host", "").split(":")[0]  # strip port
    if _TRUSTED_HOSTS and host not in _TRUSTED_HOSTS and host not in ("localhost", "127.0.0.1"):
        logger.warning("Blocked request from untrusted host: %s", host)
        return JSONResponse(status_code=400, content={"detail": "Invalid host header"})
    return await call_next(request)


# ── Global exception handler ──────────────────────────────────────────────────
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error("Unhandled exception on %s: %s", request.url.path, exc, exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal server error", "type": type(exc).__name__},
    )


# ── Routers ───────────────────────────────────────────────────────────────────
app.include_router(chat.router,      prefix="/v1/chat",      tags=["Chat"])
app.include_router(images.router,    prefix="/v1/images",    tags=["Images"])
app.include_router(voice.router,     prefix="/v1/voice",     tags=["Voice"])
app.include_router(code.router,      prefix="/v1/code",      tags=["Code"])
app.include_router(documents.router, prefix="/v1/documents", tags=["Documents"])
app.include_router(admin.router,     prefix="/admin",        tags=["Admin"])
app.include_router(music.router,     prefix="/v1/music",     tags=["Music"])


# ── Health ────────────────────────────────────────────────────────────────────
@app.get("/health", tags=["Health"])
async def health():
    return {
        "status":  "healthy",
        "service": "WolfGPT AI Services",
        "version": "1.0.0",
        "models": {
            "chat":  settings.OLLAMA_MODEL,
            "image": settings.IMAGE_MODEL,
            "stt":   settings.WHISPER_MODEL,
            "tts":   settings.TTS_MODEL,
            "music": "musicgen-small (lazy-loaded)",
        },
    }


# ── Entry point ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=settings.PORT,
        reload=settings.DEBUG,
        workers=1,           # 1 worker — GPU memory is not shareable
        log_level="info",
        access_log=not settings.DEBUG,
    )
