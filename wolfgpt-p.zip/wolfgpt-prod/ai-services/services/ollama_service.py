"""
OllamaService — manages Ollama model pulls and health checks.
Ensures required models are available before serving requests.
"""

import asyncio
import logging
from typing import AsyncGenerator, Optional

import httpx

from core.config import settings, OLLAMA_MODEL_MAP

logger = logging.getLogger(__name__)


class OllamaService:

    def __init__(self, base_url: str = None):
        self.base_url = base_url or settings.OLLAMA_URL

    async def is_running(self) -> bool:
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                r = await client.get(f"{self.base_url}/api/tags")
                return r.status_code == 200
        except Exception:
            return False

    async def list_models(self) -> list[str]:
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                r = await client.get(f"{self.base_url}/api/tags")
                r.raise_for_status()
                return [m["name"] for m in r.json().get("models", [])]
        except Exception as e:
            logger.error("Failed to list Ollama models: %s", e)
            return []

    async def pull_model(self, model_name: str) -> bool:
        """Pull a model if not already downloaded. Streams progress to logs."""
        logger.info("Pulling Ollama model: %s", model_name)
        try:
            async with httpx.AsyncClient(timeout=3600) as client:
                async with client.stream(
                    "POST",
                    f"{self.base_url}/api/pull",
                    json={"name": model_name, "stream": True},
                ) as resp:
                    resp.raise_for_status()
                    async for line in resp.aiter_lines():
                        if '"status":"success"' in line:
                            logger.info("✅ Model pulled: %s", model_name)
                            return True
            return True
        except Exception as e:
            logger.error("Failed to pull model %s: %s", model_name, e)
            return False

    async def ensure_model(self, model_id: str) -> bool:
        """Pull model if not present. model_id is the WolfGPT alias."""
        ollama_name = OLLAMA_MODEL_MAP.get(model_id, model_id)
        available   = await self.list_models()
        # Ollama model names can include tags — do prefix match
        if any(ollama_name.split(":")[0] in m for m in available):
            return True
        return await self.pull_model(ollama_name)

    async def chat(
        self,
        messages: list[dict],
        model:    str = "qwen2.5:7b",
        temperature: float = 0.7,
        max_tokens:  int   = 2048,
        stream:      bool  = False,
    ) -> dict | AsyncGenerator:
        payload = {
            "model":    model,
            "messages": messages,
            "stream":   stream,
            "options":  {"temperature": temperature, "num_predict": max_tokens},
        }
        if stream:
            return self._stream_chat(payload)

        async with httpx.AsyncClient(timeout=120) as client:
            r = await client.post(f"{self.base_url}/api/chat", json=payload)
            r.raise_for_status()
            return r.json()

    async def _stream_chat(self, payload: dict) -> AsyncGenerator[str, None]:
        async with httpx.AsyncClient(timeout=120) as client:
            async with client.stream("POST", f"{self.base_url}/api/chat", json=payload) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if line:
                        yield line


# Singleton
ollama_service = OllamaService()
