"""
ModelManager — singleton that lazy-loads AI models and tracks GPU memory.
Other routers should use this instead of loading models directly so we
avoid loading the same model twice and can free memory when needed.
"""

import logging
import threading
from typing import Any, Optional

import torch

logger = logging.getLogger(__name__)


class ModelManager:
    """Thread-safe model registry with lazy loading."""

    def __init__(self):
        self._models:  dict[str, Any] = {}
        self._locks:   dict[str, threading.Lock] = {}
        self._global   = threading.Lock()

    def _get_lock(self, key: str) -> threading.Lock:
        with self._global:
            if key not in self._locks:
                self._locks[key] = threading.Lock()
            return self._locks[key]

    def get(self, key: str) -> Optional[Any]:
        return self._models.get(key)

    def set(self, key: str, model: Any) -> None:
        self._models[key] = model

    def has(self, key: str) -> bool:
        return key in self._models

    def load_once(self, key: str, loader_fn):
        """Load model exactly once; subsequent calls return cached instance."""
        if self.has(key):
            return self.get(key)
        with self._get_lock(key):
            if self.has(key):          # double-checked locking
                return self.get(key)
            logger.info("Loading model: %s", key)
            model = loader_fn()
            self.set(key, model)
            logger.info("✅ Model loaded: %s", key)
            return model

    def unload(self, key: str) -> bool:
        """Remove a model from memory (useful after OOM errors)."""
        if key in self._models:
            del self._models[key]
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            logger.info("Unloaded model: %s", key)
            return True
        return False

    def unload_all(self) -> None:
        self._models.clear()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        logger.info("All models unloaded")

    def status(self) -> dict:
        mem = {}
        if torch.cuda.is_available():
            mem = {
                "allocated_gb": round(torch.cuda.memory_allocated() / 1e9, 2),
                "reserved_gb":  round(torch.cuda.memory_reserved()  / 1e9, 2),
            }
        return {
            "loaded_models": list(self._models.keys()),
            "gpu_memory":    mem,
        }


# Global singleton
model_manager = ModelManager()
