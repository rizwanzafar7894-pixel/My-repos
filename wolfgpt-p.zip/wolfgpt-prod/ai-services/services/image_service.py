"""
ImageService — wraps diffusers pipelines for FLUX and SDXL.
Uses ModelManager to cache pipelines; handles OOM gracefully.
"""

import base64
import io
import logging
import time
from typing import Optional

import torch
from PIL import Image

from core.config import settings, IMAGE_MODEL_MAP
from services.model_manager import model_manager

logger = logging.getLogger(__name__)


def _get_device() -> str:
    if settings.USE_GPU:
        if torch.cuda.is_available():
            return "cuda"
        if getattr(torch.backends, "mps", None) and torch.backends.mps.is_available():
            return "mps"
    return "cpu"


def _load_flux(hf_model: str, device: str):
    from diffusers import FluxPipeline
    dtype = torch.bfloat16 if device in ("cuda", "mps") else torch.float32
    pipe  = FluxPipeline.from_pretrained(
        hf_model,
        torch_dtype=dtype,
        cache_dir=settings.IMAGE_CACHE_DIR,
    ).to(device)
    if device == "cuda":
        try:
            pipe.enable_model_cpu_offload()
            pipe.enable_xformers_memory_efficient_attention()
        except Exception:
            pass
    return pipe


def _load_sdxl(hf_model: str, device: str):
    from diffusers import StableDiffusionXLPipeline
    dtype = torch.float16 if device == "cuda" else torch.float32
    pipe  = StableDiffusionXLPipeline.from_pretrained(
        hf_model,
        torch_dtype=dtype,
        use_safetensors=True,
        cache_dir=settings.IMAGE_CACHE_DIR,
    ).to(device)
    if device == "cuda":
        try:
            pipe.enable_model_cpu_offload()
        except Exception:
            pass
    return pipe


class ImageService:

    def get_pipeline(self, model_alias: str):
        hf_model = IMAGE_MODEL_MAP.get(model_alias)
        if not hf_model:
            raise ValueError(f"Unknown image model: {model_alias}")

        def loader():
            device = _get_device()
            logger.info("Loading image model %s on %s", hf_model, device)
            if "FLUX" in hf_model or "flux" in hf_model.lower():
                return _load_flux(hf_model, device)
            return _load_sdxl(hf_model, device)

        return model_manager.load_once(f"img:{model_alias}", loader)

    def generate(
        self,
        prompt:          str,
        model_alias:     str   = "flux-schnell",
        negative_prompt: Optional[str] = None,
        width:           int   = 1024,
        height:          int   = 1024,
        steps:           int   = 4,
        num_images:      int   = 1,
        guidance_scale:  float = 0.0,
        seed:            Optional[int] = None,
    ) -> list[dict]:
        pipe = self.get_pipeline(model_alias)

        generator = None
        if seed is not None:
            generator = torch.Generator().manual_seed(seed)

        kwargs: dict = dict(
            prompt=prompt,
            width=width,
            height=height,
            num_inference_steps=steps,
            num_images_per_prompt=num_images,
            generator=generator,
        )
        if negative_prompt:
            kwargs["negative_prompt"] = negative_prompt
        if guidance_scale > 0:
            kwargs["guidance_scale"] = guidance_scale

        try:
            start  = time.time()
            result = pipe(**kwargs)
            elapsed = round(time.time() - start, 2)

            output = []
            for img in result.images:
                buf = io.BytesIO()
                img.save(buf, format="PNG")
                b64 = base64.b64encode(buf.getvalue()).decode()
                output.append({
                    "base64":  b64,
                    "width":   width,
                    "height":  height,
                    "seed":    seed,
                })
            return output, elapsed

        except RuntimeError as e:
            if "out of memory" in str(e).lower():
                model_manager.unload(f"img:{model_alias}")
                raise RuntimeError("GPU out of memory — model unloaded, retry with smaller dimensions") from e
            raise


image_service = ImageService()
