"""
VoiceService — Whisper STT and Coqui TTS with shared ModelManager cache.
"""

import io
import logging
import os
import tempfile
import time
from typing import Optional

from core.config import settings, WHISPER_MODEL_MAP
from services.model_manager import model_manager

logger = logging.getLogger(__name__)


class WhisperService:

    def load(self, size: str = "base"):
        mapped = WHISPER_MODEL_MAP.get(size, "base")

        def loader():
            import whisper
            logger.info("Loading Whisper: %s", mapped)
            return whisper.load_model(
                mapped,
                device=settings.WHISPER_DEVICE,
                download_root=settings.WHISPER_CACHE_DIR,
            )

        return model_manager.load_once(f"whisper:{mapped}", loader)

    def transcribe(
        self,
        audio_bytes: bytes,
        suffix:      str = ".webm",
        language:    Optional[str] = None,
        model_size:  str = "base",
    ) -> dict:
        model = self.load(model_size)

        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            tmp.write(audio_bytes)
            tmp_path = tmp.name

        try:
            start  = time.time()
            result = model.transcribe(
                tmp_path,
                language=language if language and language != "auto" else None,
                fp16=False,
                verbose=False,
            )
            elapsed = round(time.time() - start, 2)

            return {
                "text":       result.get("text", "").strip(),
                "language":   result.get("language", language or "en"),
                "duration":   elapsed,
                "confidence": 0.95,
            }
        finally:
            os.unlink(tmp_path)


class CoquiTTSService:

    def load(self):
        def loader():
            from TTS.api import TTS
            logger.info("Loading Coqui TTS: %s", settings.TTS_MODEL)
            return TTS(model_name=settings.TTS_MODEL, progress_bar=False)

        return model_manager.load_once("coqui_tts", loader)

    def synthesize(self, text: str, speed: float = 1.0) -> bytes:
        tts = self.load()
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
            out_path = tmp.name
        try:
            tts.tts_to_file(text=text, file_path=out_path, speed=speed)
            with open(out_path, "rb") as f:
                return f.read()
        finally:
            if os.path.exists(out_path):
                os.unlink(out_path)


whisper_service = WhisperService()
tts_service     = CoquiTTSService()
