#!/usr/bin/env python3
"""
WolfGPT Model Download Script
Run once to pre-download all required AI models before starting the service.

Usage:
    python scripts/download_models.py                  # download all
    python scripts/download_models.py --whisper-only   # whisper only
    python scripts/download_models.py --tts-only       # tts only
    python scripts/download_models.py --skip-images    # skip image models
"""

import argparse
import os
import sys

# Add parent dir to path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from dotenv import load_dotenv
load_dotenv()


def banner(text: str):
    print(f"\n{'='*60}")
    print(f"  {text}")
    print(f"{'='*60}")


def download_whisper(model_size: str = "base"):
    banner(f"Downloading Whisper ({model_size})")
    try:
        import whisper
        cache_dir = os.getenv("WHISPER_CACHE_DIR", "./models/whisper")
        os.makedirs(cache_dir, exist_ok=True)
        model = whisper.load_model(model_size, download_root=cache_dir)
        print(f"✅ Whisper '{model_size}' downloaded successfully")
        del model
    except Exception as e:
        print(f"❌ Whisper download failed: {e}")


def download_tts(model_name: str = None):
    banner("Downloading Coqui TTS")
    try:
        from TTS.api import TTS
        model = model_name or os.getenv("TTS_MODEL", "tts_models/en/ljspeech/tacotron2-DDC")
        tts = TTS(model_name=model, progress_bar=True)
        print(f"✅ TTS model '{model}' downloaded successfully")
        del tts
    except Exception as e:
        print(f"❌ TTS download failed: {e}")


def download_flux(model_alias: str = "flux-schnell"):
    banner(f"Downloading FLUX image model ({model_alias})")
    model_map = {
        "flux-schnell": "black-forest-labs/FLUX.1-schnell",
        "flux-dev":     "black-forest-labs/FLUX.1-dev",
        "sdxl-base":    "stabilityai/stable-diffusion-xl-base-1.0",
    }
    hf_model  = model_map.get(model_alias)
    cache_dir = os.getenv("IMAGE_CACHE_DIR", "./models/images")
    os.makedirs(cache_dir, exist_ok=True)

    hf_token = os.getenv("HUGGINGFACE_TOKEN")

    try:
        if "FLUX" in hf_model:
            from diffusers import FluxPipeline
            FluxPipeline.from_pretrained(
                hf_model,
                cache_dir=cache_dir,
                token=hf_token,
            )
        else:
            from diffusers import StableDiffusionXLPipeline
            StableDiffusionXLPipeline.from_pretrained(
                hf_model,
                cache_dir=cache_dir,
                use_safetensors=True,
                token=hf_token,
            )
        print(f"✅ Image model '{hf_model}' downloaded successfully")
    except Exception as e:
        print(f"❌ Image model download failed: {e}")


def pull_ollama_models():
    banner("Pulling Ollama Models")
    import subprocess
    models = [
        ("qwen2.5:7b",  "Primary chat model (required)"),
        ("qwen2.5:32b", "Advanced chat model (optional, needs 20+ GB RAM)"),
        ("llava:7b",    "Vision model (optional)"),
    ]
    for model, desc in models:
        print(f"\n→ {model}  ({desc})")
        answer = input("   Pull this model? [y/N]: ").strip().lower()
        if answer == "y":
            try:
                subprocess.run(["ollama", "pull", model], check=True)
                print(f"✅ {model} pulled")
            except subprocess.CalledProcessError as e:
                print(f"❌ Failed: {e}")
            except FileNotFoundError:
                print("❌ Ollama not installed. Install from: https://ollama.ai")
                break


def main():
    parser = argparse.ArgumentParser(description="Download WolfGPT AI models")
    parser.add_argument("--whisper-only",  action="store_true")
    parser.add_argument("--tts-only",      action="store_true")
    parser.add_argument("--images-only",   action="store_true")
    parser.add_argument("--ollama-only",   action="store_true")
    parser.add_argument("--skip-images",   action="store_true")
    parser.add_argument("--skip-ollama",   action="store_true")
    parser.add_argument("--whisper-size",  default="base",
                        choices=["tiny", "base", "small", "medium", "large-v3"])
    parser.add_argument("--image-model",   default="flux-schnell",
                        choices=["flux-schnell", "flux-dev", "sdxl-base"])
    args = parser.parse_args()

    print("\n🐺 WolfGPT Model Downloader")
    print("This will download AI models required to run WolfGPT AI Services.\n")

    if args.whisper_only:
        download_whisper(args.whisper_size)
    elif args.tts_only:
        download_tts()
    elif args.images_only:
        download_flux(args.image_model)
    elif args.ollama_only:
        pull_ollama_models()
    else:
        # Download everything
        download_whisper(args.whisper_size)
        download_tts()
        if not args.skip_images:
            download_flux(args.image_model)
        if not args.skip_ollama:
            pull_ollama_models()

    print("\n✅ All done! You can now start the AI service with:")
    print("   python main.py\n")


if __name__ == "__main__":
    main()
