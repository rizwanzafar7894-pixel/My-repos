#!/bin/bash
set -e

echo "🚀 WolfGPT Production Deployment"
echo "================================="

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Configuration
ENVIRONMENT="production"
BACKUP_DIR="./backups/$(date +%Y%m%d_%H%M%S)"

# Functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_requirements() {
    log_info "Checking requirements..."
    command -v docker >/dev/null 2>&1 || { log_error "Docker is required but not installed."; exit 1; }
    command -v docker-compose >/dev/null 2>&1 || { log_error "Docker Compose is required."; exit 1; }
    log_info "✅ All requirements met"
}

backup_data() {
    log_info "Creating backup..."
    mkdir -p "$BACKUP_DIR"
    
    # Backup database
    if [ -f "./database/backups/latest.dump" ]; then
        cp ./database/backups/latest.dump "$BACKUP_DIR/"
    fi
    
    # Backup uploads
    if [ -d "./backend/uploads" ]; then
        tar -czf "$BACKUP_DIR/uploads.tar.gz" ./backend/uploads
    fi
    
    log_info "✅ Backup created at $BACKUP_DIR"
}

run_tests() {
    log_info "Running tests..."
    npm run test || { log_error "Tests failed!"; exit 1; }
    log_info "✅ All tests passed"
}

build_images() {
    log_info "Building Docker images..."
    docker-compose -f docker-compose.prod.yml build --parallel
    log_info "✅ Images built successfully"
}

run_migrations() {
    log_info "Running database migrations..."
    docker-compose -f docker-compose.prod.yml run --rm backend npm run migrate
    log_info "✅ Migrations completed"
}

deploy_services() {
    log_info "Deploying services..."
    docker-compose -f docker-compose.prod.yml up -d --no-deps --build
    log_info "✅ Services deployed"
}

health_check() {
    log_info "Running health checks..."
    sleep 15
    
    # Check frontend
    if curl -f http://localhost:3000/api/health >/dev/null 2>&1; then
        log_info "✅ Frontend healthy"
    else
        log_error "Frontend health check failed"
        return 1
    fi
    
    # Check backend
    if curl -f http://localhost:4000/health >/dev/null 2>&1; then
        log_info "✅ Backend healthy"
    else
        log_error "Backend health check failed"
        return 1
    fi
    
    # Check AI service
    if curl -f http://localhost:8000/health >/dev/null 2>&1; then
        log_info "✅ AI service healthy"
    else
        log_warn "AI service health check failed (may need GPU)"
    fi
    
    log_info "✅ Health checks passed"
}

cleanup_old_images() {
    log_info "Cleaning up old Docker images..."
    docker image prune -af --filter "until=24h"
    log_info "✅ Cleanup completed"
}

# Main deployment flow
main() {
    log_info "Starting production deployment..."
    
    check_requirements
    backup_data
    run_tests
    build_images
    run_migrations
    deploy_services
    
    if health_check; then
        cleanup_old_images
        log_info "🎉 Deployment successful!"
        log_info "Frontend: http://localhost:3000"
        log_info "Backend: http://localhost:4000"
        log_info "Admin: http://localhost:3001"
    else
        log_error "Health checks failed. Rolling back..."
        docker-compose -f docker-compose.prod.yml down
        exit 1
    fi
}

# Run deployment
main
