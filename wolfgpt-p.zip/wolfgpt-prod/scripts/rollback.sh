#!/bin/bash
set -e

BACKUP_TAG=${1:-previous}

echo "⏮️  Rolling back to: $BACKUP_TAG"

docker-compose -f docker-compose.prod.yml down
docker tag "wolfgpt-frontend:${BACKUP_TAG}" wolfgpt-frontend:latest
docker tag "wolfgpt-backend:${BACKUP_TAG}" wolfgpt-backend:latest
docker tag "wolfgpt-ai-service:${BACKUP_TAG}" wolfgpt-ai-service:latest
docker-compose -f docker-compose.prod.yml up -d

echo "✅ Rollback complete!"
