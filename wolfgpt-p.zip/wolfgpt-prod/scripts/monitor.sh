#!/usr/bin/env bash
# WolfGPT — Health Monitor & Auto-recovery
# Runs every 5 min via cron: */5 * * * * bash /var/www/wolfgpt/scripts/monitor.sh
set -euo pipefail

LOG="/var/log/wolfgpt-monitor.log"
ALERT_EMAIL="${ALERT_EMAIL:-}"
FRONTEND_URL="${FRONTEND_URL:-http://localhost:3000}"
BACKEND_URL="${BACKEND_URL:-http://localhost:4000}"
AI_URL="${AI_URL:-http://localhost:8000}"
MAX_LOG_LINES=5000

ts()  { date '+%Y-%m-%d %H:%M:%S'; }
log() { echo "$(ts) [$1] $2" | tee -a "$LOG"; }

# Trim log file
if [[ -f "$LOG" ]] && [[ $(wc -l < "$LOG") -gt $MAX_LOG_LINES ]]; then
    tail -n $MAX_LOG_LINES "$LOG" > "${LOG}.tmp" && mv "${LOG}.tmp" "$LOG"
fi

send_alert() {
    local subject="$1" body="$2"
    log "ALERT" "$subject"
    if [[ -n "$ALERT_EMAIL" ]] && command -v mail &>/dev/null; then
        echo "$body" | mail -s "🚨 WolfGPT: $subject" "$ALERT_EMAIL" 2>/dev/null || true
    fi
}

check_http() {
    local name="$1" url="$2"
    local code
    code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 "$url" 2>/dev/null || echo "000")
    if [[ "$code" == "200" ]]; then
        log "OK" "$name → HTTP $code"
        return 0
    else
        log "FAIL" "$name → HTTP $code"
        return 1
    fi
}

restart_service() {
    local svc="$1"
    log "RECOVER" "Restarting $svc…"
    cd /var/www/wolfgpt
    docker compose restart "$svc" 2>&1 | tee -a "$LOG"
    sleep 15
}

# ── Checks ────────────────────────────────────────────────────────────────────
FAILURES=0

check_http "Frontend"   "$FRONTEND_URL"           || { FAILURES=$((FAILURES+1)); restart_service frontend; }
check_http "Backend"    "$BACKEND_URL/health"      || { FAILURES=$((FAILURES+1)); restart_service backend; }
check_http "AI Service" "$AI_URL/health"            || { FAILURES=$((FAILURES+1)); restart_service ai-service; }

# Redis
if docker exec wolfgpt-redis redis-cli ping &>/dev/null; then
    log "OK" "Redis → PONG"
else
    FAILURES=$((FAILURES+1))
    log "FAIL" "Redis not responding"
    restart_service redis
fi

# Disk space
DISK=$(df / | awk 'NR==2{print $5}' | tr -d '%')
if [[ $DISK -gt 85 ]]; then
    send_alert "Disk space critical: ${DISK}%" "Disk usage on $(hostname) is at ${DISK}%"
    docker image prune -f &>/dev/null || true
fi

# Memory
MEM_FREE=$(free -m | awk 'NR==2{print $4}')
if [[ $MEM_FREE -lt 512 ]]; then
    log "WARN" "Low memory: ${MEM_FREE}MB free"
    send_alert "Low memory: ${MEM_FREE}MB free" "Server memory critically low"
fi

# Docker containers running
RUNNING=$(docker compose -f /var/www/wolfgpt/docker-compose.yml ps --format "{{.State}}" 2>/dev/null | grep -c "running" || echo "0")
log "INFO" "$RUNNING containers running"

if [[ $FAILURES -gt 0 ]]; then
    send_alert "$FAILURES service(s) failed and were restarted" "Check logs: docker compose logs"
    exit 1
fi

log "OK" "All services healthy ✅"
