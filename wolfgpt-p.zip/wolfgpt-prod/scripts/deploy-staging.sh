#!/bin/bash
set -e

echo "🚀 Deploying to Staging..."

# Build and deploy
docker-compose -f docker-compose.yml build
docker-compose -f docker-compose.yml up -d

# Wait and health check
sleep 10
curl -f http://localhost:3000/api/health || exit 1
curl -f http://localhost:4000/health || exit 1

echo "✅ Staging deployment successful!"
