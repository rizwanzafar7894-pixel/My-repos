#!/usr/bin/env bash
# ── WolfGPT Production Deploy ─────────────────────────────────────────────────
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${APP_DIR}"

echo "🐺 Starting WolfGPT production deployment..."
echo "   Directory: ${APP_DIR}"
echo "   Time: $(date -u '+%Y-%m-%d %H:%M:%S UTC')"

# ── Pre-flight checks ─────────────────────────────────────────────────────────
check_file() {
  [[ -f "$1" ]] || { echo "❌ Missing: $1"; exit 1; }
}

check_file "firebase-admin-key.json"
check_file "backend/.env"
check_file "frontend/.env.production"
check_file "ai-services/.env"

echo "✅ Pre-flight checks passed"

# ── Pull latest images ────────────────────────────────────────────────────────
echo "📥 Pulling base images..."
docker compose -f docker-compose.prod.yml pull --quiet 2>/dev/null || true

# ── Build with cache ──────────────────────────────────────────────────────────
echo "🔨 Building services..."
DOCKER_BUILDKIT=1 docker compose -f docker-compose.prod.yml build --parallel

# ── Rolling restart ───────────────────────────────────────────────────────────
echo "🚀 Starting services..."
docker compose -f docker-compose.prod.yml up -d

# ── Health check ──────────────────────────────────────────────────────────────
echo "⏳ Waiting for services to be healthy..."
RETRY=0
MAX_RETRIES=24  # 2 minutes total

until curl -sf http://localhost:4000/health > /dev/null 2>&1; do
  RETRY=$((RETRY + 1))
  if [[ ${RETRY} -ge ${MAX_RETRIES} ]]; then
    echo "❌ Backend health check failed after ${MAX_RETRIES} retries"
    docker compose -f docker-compose.prod.yml logs --tail=50 backend
    exit 1
  fi
  echo "   Waiting... (${RETRY}/${MAX_RETRIES})"
  sleep 5
done

echo "✅ Deployment complete!"
echo ""
echo "Services:"
docker compose -f docker-compose.prod.yml ps
echo ""
echo "Frontend → https://$(hostname -f 2>/dev/null || echo 'yourdomain.com')"
