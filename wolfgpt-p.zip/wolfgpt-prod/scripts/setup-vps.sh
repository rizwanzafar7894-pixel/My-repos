#!/usr/bin/env bash
# ── WolfGPT VPS Setup Script ──────────────────────────────────────────────────
# Run as root on a fresh Ubuntu 22.04 VPS
# Usage: curl -sL https://raw.githubusercontent.com/yourname/wolfgpt/main/scripts/setup-vps.sh | bash

set -euo pipefail

WOLFGPT_USER="wolfgpt"
APP_DIR="/home/${WOLFGPT_USER}/app"

echo "🐺 WolfGPT VPS Setup Starting..."

# ── 1. System update ──────────────────────────────────────────────────────────
apt-get update && apt-get upgrade -y
apt-get install -y curl wget git ufw fail2ban htop nano unzip

# ── 2. Firewall ───────────────────────────────────────────────────────────────
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable
echo "✅ Firewall configured"

# ── 3. Timezone ───────────────────────────────────────────────────────────────
timedatectl set-timezone UTC

# ── 4. Create application user ────────────────────────────────────────────────
if ! id "${WOLFGPT_USER}" &>/dev/null; then
  useradd -m -s /bin/bash "${WOLFGPT_USER}"
  usermod -aG sudo "${WOLFGPT_USER}"
  echo "✅ User ${WOLFGPT_USER} created"
fi

# ── 5. Docker ─────────────────────────────────────────────────────────────────
if ! command -v docker &>/dev/null; then
  curl -fsSL https://get.docker.com | sh
  usermod -aG docker "${WOLFGPT_USER}"
  systemctl enable docker
  echo "✅ Docker installed"
fi

# Docker Compose v2
if ! docker compose version &>/dev/null; then
  mkdir -p /usr/local/lib/docker/cli-plugins
  COMPOSE_VER=$(curl -s https://api.github.com/repos/docker/compose/releases/latest | grep '"tag_name"' | cut -d'"' -f4)
  curl -sL "https://github.com/docker/compose/releases/download/${COMPOSE_VER}/docker-compose-linux-$(uname -m)" \
    -o /usr/local/lib/docker/cli-plugins/docker-compose
  chmod +x /usr/local/lib/docker/cli-plugins/docker-compose
  echo "✅ Docker Compose installed: ${COMPOSE_VER}"
fi

# ── 6. Nginx + Certbot ────────────────────────────────────────────────────────
apt-get install -y nginx certbot python3-certbot-nginx
systemctl enable nginx
echo "✅ Nginx installed"

# ── 7. App directory ──────────────────────────────────────────────────────────
mkdir -p "${APP_DIR}"
chown -R "${WOLFGPT_USER}:${WOLFGPT_USER}" "${APP_DIR}"

# ── 8. Nginx SSL dirs ─────────────────────────────────────────────────────────
mkdir -p /home/${WOLFGPT_USER}/app/wolfgpt-ultimate/nginx/ssl
mkdir -p /home/${WOLFGPT_USER}/app/wolfgpt-ultimate/nginx/logs

# ── 9. Summary ────────────────────────────────────────────────────────────────
echo ""
echo "✅ VPS setup complete!"
echo ""
echo "Next steps:"
echo "  1. Copy project: scp -r . ${WOLFGPT_USER}@$(hostname -I | awk '{print $1}'):${APP_DIR}/"
echo "  2. SSH in as ${WOLFGPT_USER}: ssh ${WOLFGPT_USER}@$(hostname -I | awk '{print $1}')"
echo "  3. Fill in .env files (see SETUP.md)"
echo "  4. cd ${APP_DIR}/wolfgpt-ultimate && make deploy-prod"
echo "  5. SSL: sudo certbot --nginx -d yourdomain.com"
echo ""
echo "Server IP: $(hostname -I | awk '{print $1}')"
