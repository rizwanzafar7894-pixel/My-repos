#!/bin/bash
set -e

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="./database/backups"
mkdir -p "$BACKUP_DIR"

echo "📦 Creating database backup..."

# Firestore backup (if using Firebase)
if [ ! -z "$FIREBASE_PROJECT_ID" ]; then
    gcloud firestore export "gs://${FIREBASE_PROJECT_ID}-backups/firestore-${DATE}" \
        --project="$FIREBASE_PROJECT_ID"
fi

# Redis backup
docker exec wolfgpt-redis redis-cli BGSAVE
docker cp wolfgpt-redis:/data/dump.rdb "$BACKUP_DIR/redis-${DATE}.rdb"

# Keep only last 7 days of backups
find "$BACKUP_DIR" -name "*.rdb" -mtime +7 -delete

echo "✅ Backup created: ${DATE}"
