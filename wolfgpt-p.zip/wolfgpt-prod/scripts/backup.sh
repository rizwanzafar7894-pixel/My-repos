#!/usr/bin/env bash
# WolfGPT — Automated Backup Script
# Backs up: Redis data, logs, configs, env files (not secrets in plaintext)
# Schedule via cron: 0 2 * * * bash /var/www/wolfgpt/scripts/backup.sh
set -euo pipefail

BACKUP_ROOT="/var/backups/wolfgpt"
APP_DIR="/var/www/wolfgpt"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="$BACKUP_ROOT/backup_${TIMESTAMP}.tar.gz"
KEEP_DAYS="${KEEP_DAYS:-7}"

G='\033[0;32m'; R='\033[0;31m'; NC='\033[0m'
log() { echo -e "${G}[BACKUP]${NC} $1"; }
err() { echo -e "${R}[ERROR]${NC} $1"; }

mkdir -p "$BACKUP_ROOT"
log "Starting backup: $TIMESTAMP"

# ── Redis dump ────────────────────────────────────────────────────────────────
log "Flushing Redis to disk…"
docker exec wolfgpt-redis redis-cli BGSAVE 2>/dev/null || warn "Redis BGSAVE failed (non-fatal)"
sleep 2

# ── Application backup ────────────────────────────────────────────────────────
log "Archiving application files…"
tar -czf "$BACKUP_FILE" \
    --exclude="$APP_DIR/node_modules" \
    --exclude="$APP_DIR/frontend/.next" \
    --exclude="$APP_DIR/frontend/node_modules" \
    --exclude="$APP_DIR/backend/node_modules" \
    --exclude="$APP_DIR/ai-services/.venv" \
    --exclude="$APP_DIR/ai-services/models" \
    --exclude="$APP_DIR/ai-services/logs" \
    --exclude="$APP_DIR/backend/logs" \
    "$APP_DIR" \
    2>/dev/null || { err "Backup failed!"; exit 1; }

SIZE=$(du -sh "$BACKUP_FILE" | cut -f1)
log "Backup created: $BACKUP_FILE ($SIZE)"

# ── Upload to S3 (optional) ───────────────────────────────────────────────────
if [[ -n "${S3_BUCKET:-}" ]] && command -v aws &>/dev/null; then
    log "Uploading to S3: s3://$S3_BUCKET/wolfgpt/"
    aws s3 cp "$BACKUP_FILE" "s3://$S3_BUCKET/wolfgpt/" \
        --storage-class STANDARD_IA \
        --only-show-errors
    log "S3 upload complete"
fi

# ── Retention — delete old local backups ──────────────────────────────────────
log "Cleaning backups older than ${KEEP_DAYS} days…"
find "$BACKUP_ROOT" -name "backup_*.tar.gz" -mtime "+${KEEP_DAYS}" -delete
REMAINING=$(ls "$BACKUP_ROOT"/backup_*.tar.gz 2>/dev/null | wc -l)
log "$REMAINING backups retained"

# ── Verify backup integrity ───────────────────────────────────────────────────
log "Verifying backup…"
tar -tzf "$BACKUP_FILE" &>/dev/null && log "Backup integrity: OK" || err "Backup may be corrupt!"

log "✅ Backup complete: $BACKUP_FILE"
