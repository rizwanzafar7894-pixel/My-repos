#!/bin/bash

check_service() {
    if curl -f "$1" >/dev/null 2>&1; then
        echo "✅ $2 is healthy"
        return 0
    else
        echo "❌ $2 is unhealthy"
        return 1
    fi
}

echo "🏥 Health Check"
echo "==============="

check_service "http://localhost:3000/api/health" "Frontend"
check_service "http://localhost:4000/health" "Backend"
check_service "http://localhost:8000/health" "AI Service"
check_service "http://localhost:6379" "Redis"

echo ""
echo "Monitoring: http://localhost:3001 (Grafana)"
