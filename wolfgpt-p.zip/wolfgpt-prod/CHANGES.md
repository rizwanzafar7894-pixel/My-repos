# WolfGPT — Production Improvements Changelog

All bugs, security issues, and improvements applied to produce this
production-ready release from the original codebase.

---

## 🔴 Critical Bugs Fixed (would crash or break in production)

### 1. `routes/admin.routes.ts` — Startup crash
**Problem:** Imported `authenticateAdmin` from `middleware/auth` — this export
does not exist anywhere in the codebase. The server would crash immediately
on startup with `SyntaxError: The requested module … does not provide an export
named 'authenticateAdmin'`.

**Fix:** Replaced with the correct `authMiddleware` + `adminMiddleware` pipeline.

---

### 2. `backend/Dockerfile` — TypeScript build always failed
**Problem:** `RUN npm ci --only=production && npm ci` installs prod-only deps first,
then reinstalls everything. TypeScript (`tsc`) is a dev dependency — the build layer
never had it, so `npm run build` always errored.

**Fix:** Single `npm ci` to install all deps for the build stage, then a separate
`npm ci --only=production` after the build to produce a lean final image.

---

### 3. `controllers/admin.controller.ts` — Four functions referenced but never exported
**Problem:** `routes/admin.routes.ts` imports `suspendUser`, `activateUser`,
`getSystemStats`, and `exportData`, but none were properly implemented or exported.
All four would throw `TypeError: … is not a function` at runtime.

**Additional issues in the file:**
- Used `console.error` instead of the `logger` utility
- `getAnalytics` had hardcoded mock values (`growth: 23.5`, `uptime: 99.9%`,
  `avgResponseTime: 245`) served as real data
- `getAllUsers` returned raw `users` key instead of `data` (inconsistent API response shape)
- No TypeScript types on any function parameter
- `suspendUser` used `status: 'revoked'` on API keys — the field is `active: boolean`
- No pagination on `getAllUsers` (would fetch all users in one query)
- `exportData` had no sanitization — `stripeCustomerId` and `keyHash` would leak in CSV

**Fix:** Fully rewritten with proper TypeScript, real Firestore queries, correct
response shapes, pagination, `auth.revokeRefreshTokens()` on suspend, field
sanitization in CSV export, and `logger` throughout.

---

### 4. `server.ts` — Admin routes defined but never mounted
**Problem:** `admin.routes.ts` existed and was built, but was never imported or
`app.use()`-d in `server.ts`. All `/api/admin/*` endpoints returned 404.

**Fix:** Added `import adminRoutes` and `app.use('/api/admin', adminRoutes)`.

---

### 5. `routes/api/v1/chat.ts` — Route ordering bug
**Problem:** `router.delete('/clear', ...)` was defined **after**
`router.delete('/:id', ...)`. Express matches routes top-to-bottom, so the string
`"clear"` was being matched as an `:id` parameter. `clearConversations` was
unreachable — it would instead attempt to delete a conversation with ID `"clear"`,
return 404, and leave all conversations intact.

**Fix:** Moved `DELETE /clear` above `DELETE /:id`.

---

### 6. `frontend/package.json` — `firebase-admin` in browser bundle
**Problem:** `firebase-admin` is a Node.js server-side SDK (uses `fs`, `net`,
`tls`, and other Node built-ins). Including it as a frontend dependency caused
webpack build errors and would have leaked server configuration paths into the
client bundle.

**Fix:** Removed from `frontend/package.json`. Also added `firebase-admin` to
`webpack.externals` in `next.config.js` as a safety net against transitive pulls.

---

## 🔴 Security Vulnerabilities Fixed

### 7. `middleware/auth.ts` — Auth cache key collision
**Problem:** Cache key was `auth:${token.slice(-24)}` — only the last 24 characters
of the token. Firebase ID tokens are JWTs; their last 24 characters include only
the signature tail, which can collide across different users with similar key pairs.

**Fix:** `auth:${sha256(token).slice(0, 32)}` — full SHA-256 hash of the token,
making collision statistically impossible.

---

### 8. `controllers/authController.ts` — XSS via `displayName`
**Problem:** `updateMe` accepted any string for `displayName` and wrote it directly
to Firestore. A value like `<script>alert(1)</script>` would be stored and could
be rendered unsanitized in the UI, the admin dashboard, or email templates.

**Fix:** Strip HTML tags, trim whitespace, enforce 64-character maximum.

---

### 9. `controllers/authController.ts` — Open redirect via `photoURL`
**Problem:** `photoURL` accepted any string including `javascript:alert(1)` or
`http://evil.com/tracker.png`. If rendered as an `<img src>` or `<a href>`,
this enables XSS or mixed-content attacks.

**Fix:** Only HTTPS URLs accepted for `photoURL`.

---

### 10. `lib/api.ts` (frontend) — 401 redirect loop
**Problem:** The Axios response interceptor redirected to `/login` on any 401,
including 401s that happen *on* the login page itself (e.g. a failed token
verification). This caused an infinite redirect loop on the login page.

**Fix:** Only redirect if `window.location.pathname` does not already start with
`/login` or `/register`.

---

## 🟡 Logic Bugs Fixed

### 11. `components/chat/ChatInterface.tsx` — Abort signal not wired
**Problem:** An `AbortController` was created and its ref stored, but the signal
was never passed to the `fetch()` call inside `apiClient.chatStream()`. Clicking
"Stop" set local state variables but did not actually cancel the HTTP request —
the AI service kept streaming and the response kept arriving silently.

**Fix:** Added `signal?: AbortSignal` parameter to `chatStream()` and passed it
to `fetch()`. The Stop button now truly cancels the network request.

**Bonus fix:** On error, the user's message is restored to the input box so they
can retry without retyping.

---

### 12. `app/dashboard/settings/page.tsx` — Save button was a no-op
**Problem:** "Save Changes" button had no `onClick` handler and no state. Clicking
it did nothing. Changes typed into the display name field were silently discarded.

**Fix:** Wired to `apiClient.updateMe()` with loading state, success/error toasts,
disabled state when no changes made, and `updateUser()` to sync the Zustand store.

---

### 13. `app/dashboard/billing/page.tsx` — No actual payment integration
**Problem:** Upgrade buttons existed in the UI but had no `onClick` handlers.
No Stripe checkout session was ever created — clicking any upgrade button did nothing.

**Fix:** Full Stripe Checkout + Billing Portal integration with loading states,
error handling, and `?success=true` / `?cancelled=true` redirect handling.

---

### 14. `utils/cache.ts` — Race condition in `cacheIncr`
**Problem:** `cacheIncr` called `c.incr(key)` then `c.expire(key, ttl)` as two
separate commands. If the server crashed (or Redis restarted) between the two
calls, the key would exist forever with no TTL — causing rate-limit counters to
never reset and permanently blocking users.

**Fix:** Use Redis `MULTI`/`EXEC` pipeline to execute `INCR` + `EXPIRE NX`
atomically. `NX` flag ensures expiry is only set on first creation, not reset
on every increment.

---

### 15. `jobs/usageReset.ts` — Broken pagination + infinite loop risk
**Problem:** `resetField()` used `.select('uid')` (Firestore field mask) but many
documents may not have a `uid` top-level field (it's often nested). Also, the
`while(true)` loop had no break condition if `snap.size < PAGE_SIZE`, meaning a
collection of exactly 400 docs would cause an extra empty-result iteration on
every run, and a bug in Firestore could cause infinite looping.

**Fix:** Removed `.select()` field mask (not needed — only `doc.ref` is used),
added `if (snap.size < PAGE_SIZE) break` as a safe exit condition.

---

### 16. `middleware/rateLimit.ts` — Unsafe dynamic property key lookup
**Problem:** `limits[\`per${window.charAt(0).toUpperCase() + window.slice(1)}\`]`
built a property key dynamically with a type cast to `keyof typeof limits`. If
`window` was anything other than `'minute' | 'hour' | 'day'`, this would silently
return `undefined` (treated as `0`), blocking all requests.

**Fix:** Replaced with an explicit `limitFor(tier, window)` function using
`if/else` branches — zero dynamic key construction, fully type-safe.

---

### 17. `controllers/analyticsController.ts` — Unused dead import
**Problem:** `import { requireTier } from '../middleware/requireTier'` was present
but `requireTier` was never used in the file. TypeScript strict mode
(`noUnusedLocals: true` in tsconfig) would fail the build.

**Fix:** Removed the dead import.

---

## 🟠 Infrastructure & Configuration Fixes

### 18. `frontend/Dockerfile` — Missing build args caused blank pages
**Problem:** `NEXT_PUBLIC_APP_URL` and `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` were
not declared as `ARG` or exposed as `ENV` in the Dockerfile. Next.js bakes
`NEXT_PUBLIC_*` values into the client bundle at **build time** — if they're not
set as `ENV` during `next build`, the bundled code contains `undefined` for those
values, causing blank payment buttons and broken OG tags.

**Fix:** All `NEXT_PUBLIC_*` variables are now declared as `ARG` and re-exported
as `ENV` before `npm run build`.

---

### 19. `ai-services/main.py` — TrustedHostMiddleware breaks in Docker
**Problem:** Starlette's `TrustedHostMiddleware` uses strict host header matching.
Internal Docker networking uses container names (e.g. `wolfgpt-backend`) as
hostnames, which were not in the allowed list. This caused all health checks and
inter-service calls to return `400 Invalid Host Header`.

**Fix:** Replaced with a custom `@app.middleware("http")` guard that correctly
strips ports before comparing, logs blocked attempts, and works across all Docker
networking modes.

**Bonus:** API docs (`/docs`) are now hidden in production (`DEBUG=false`).

---

### 20. Missing `.env.example` files
**Problem:** All three services (`backend`, `frontend`, `ai-services`) required
environment variables that were not documented anywhere. Developers had no way
to know what variables were needed without reading all source files.

**Fix:** Created `backend/.env.example`, `frontend/.env.local.example`, and
`ai-services/.env.example` with every required variable, descriptions, and
example values.

---

### 21. Malformed stub directory names
**Problem:** The repository contained directories named with brace-expansion
syntax (e.g. `{components,pages,lib,hooks}`, `{unit,integration,e2e}`). These
are valid Unix filenames but are confusing noise — they were auto-generated
placeholder stubs, not real directories.

**Fix:** Removed all 20+ malformed stub directories.

---

### 22. `server.ts` — Redis not disconnected on graceful shutdown
**Problem:** `cacheDisconnect()` was never called in the shutdown handler. When
the process received `SIGTERM`, it closed the HTTP server but left the Redis
connection open. In containerized environments this can delay container stop and
trigger Redis `CLIENT_NO_TOUCH` errors.

**Fix:** `await cacheDisconnect()` is now called inside the `server.close()` callback.

---

### 23. `docker-compose.yml` — Frontend build args not passed
**Problem:** The frontend Docker service had no `build.args` block, so `NEXT_PUBLIC_*`
values were never passed to the Docker build context. Every Docker-built frontend
would have all public env vars as `undefined`.

**Fix:** Added `build.args` block with all required `NEXT_PUBLIC_*` variables.

---

## 📋 Summary

| Category | Count |
|----------|-------|
| 🔴 Critical (startup crash / feature broken) | 6 |
| 🔴 Security vulnerabilities | 4 |
| 🟡 Logic bugs | 7 |
| 🟠 Infrastructure / config | 6 |
| **Total** | **23** |
