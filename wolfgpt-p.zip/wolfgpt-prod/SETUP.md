# WolfGPT — Production Setup Guide

## Prerequisites

| Tool | Version | Notes |
|------|---------|-------|
| Node.js | ≥ 20 | For backend + frontend |
| Python | ≥ 3.11 | For AI services |
| Docker + Compose | ≥ 24 | For containerized deployment |
| Redis | ≥ 7 | Auth cache + rate limiting |
| Ollama | latest | Local LLM runner |
| NVIDIA GPU | Optional | 8GB+ VRAM recommended |

---

## 1. Clone & Environment Setup

```bash
git clone <your-repo> wolfgpt-pro
cd wolfgpt-pro

# Copy all env examples
cp backend/.env.example       backend/.env
cp frontend/.env.local.example frontend/.env.local
cp ai-services/.env.example   ai-services/.env
```

---

## 2. Firebase Setup

1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Create a project (or use existing)
3. **Authentication** → Enable Email/Password + Google providers
4. **Firestore** → Create database (production mode)
5. **Storage** → Enable Firebase Storage

### Backend key (Admin SDK)
- Project Settings → Service Accounts → **Generate new private key**
- Save as `firebase-admin-key.json` in project root
- Set `FIREBASE_SERVICE_ACCOUNT=./firebase-admin-key.json` in `backend/.env`
- Set `FIREBASE_STORAGE_BUCKET=your-project-id.appspot.com`

### Frontend key (Web SDK)
- Project Settings → Your Apps → Add Web App
- Copy the `firebaseConfig` values into `frontend/.env.local`

### Firestore Security Rules
Deploy the included rules:
```bash
npm install -g firebase-tools
firebase login
firebase deploy --only firestore:rules,storage
```

---

## 3. Stripe Setup (Payments)

1. Create account at [stripe.com](https://stripe.com)
2. Dashboard → Developers → **API Keys** → copy Secret key
3. Dashboard → Products → Create 3 products:
   - **Basic** — $99/year (create price, copy `price_...` ID)
   - **Premium** — $199/year
   - **Pro** — $399/year
4. Dashboard → Webhooks → Add endpoint:
   - URL: `https://yourdomain.com/api/payment/stripe/webhook`
   - Events: `checkout.session.completed`, `customer.subscription.updated`,
     `customer.subscription.deleted`, `customer.subscription.paused`,
     `invoice.payment_failed`, `invoice.payment_succeeded`
   - Copy **Signing secret**
5. Fill all `STRIPE_*` vars in `backend/.env`

---

## 4. Install Dependencies

```bash
# Backend
cd backend && npm install && cd ..

# Frontend
cd frontend && npm install && cd ..

# AI services
cd ai-services && pip install -r requirements.txt && cd ..
```

---

## 5. Pull Ollama Models

```bash
# Install Ollama: https://ollama.ai
ollama serve &

# Pull models (choose based on available RAM/VRAM)
ollama pull qwen2.5:7b      # 4.7 GB — works on most machines
# ollama pull qwen2.5:32b   # 19 GB — needs 24GB+ VRAM
# ollama pull qwen2.5:72b   # 41 GB — needs 48GB+ VRAM
# ollama pull llava:13b     # 8.0 GB — vision model
```

---

## 6. Run (Development)

### Option A — Docker Compose (recommended)
```bash
docker-compose up -d
# Visit http://localhost:3000
```

### Option B — Manual
```bash
# Terminal 1: Redis
docker run -d -p 6379:6379 redis:7-alpine

# Terminal 2: Ollama
ollama serve

# Terminal 3: AI services
cd ai-services && python main.py

# Terminal 4: Backend
cd backend && npm run dev

# Terminal 5: Frontend
cd frontend && npm run dev
```

---

## 7. Run (Production)

```bash
docker-compose -f docker-compose.prod.yml up -d --build
```

Or use the deploy script:
```bash
chmod +x scripts/deploy.sh
./scripts/deploy.sh
```

---

## 8. Admin Access

Set your email as admin in `backend/.env`:
```
ADMIN_EMAILS=you@yourdomain.com
```

Or set `role: "admin"` directly in Firestore on your user document.

Admin API is available at `POST /api/admin/*` (requires auth + admin role).

---

## 9. First Login

1. Open `http://localhost:3000`
2. Click **Get Started** → Register
3. After registering, your account is auto-created as `free` tier
4. To test payments locally, use [Stripe test cards](https://stripe.com/docs/testing)

---

## Environment Variable Reference

### `backend/.env`

| Variable | Required | Description |
|----------|----------|-------------|
| `FIREBASE_SERVICE_ACCOUNT` | ✅ | Path to JSON key or inline JSON |
| `FIREBASE_STORAGE_BUCKET` | ✅ | `your-project.appspot.com` |
| `REDIS_URL` | ✅ | `redis://localhost:6379` |
| `STRIPE_SECRET_KEY` | For payments | `sk_live_...` or `sk_test_...` |
| `STRIPE_WEBHOOK_SECRET` | For payments | `whsec_...` |
| `AI_SERVICE_URL` | ✅ | `http://localhost:8000` |
| `ALLOWED_ORIGINS` | ✅ | Comma-separated frontend URLs |
| `FRONTEND_URL` | ✅ | Frontend base URL for Stripe redirects |
| `ADMIN_EMAILS` | Recommended | Comma-separated admin emails |

### `frontend/.env.local`

All `NEXT_PUBLIC_FIREBASE_*` variables are required.
`NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` is required for payments.

---

## Troubleshooting

**Redis connection error**
- Ensure Redis is running: `redis-cli ping` should return `PONG`
- The app works without Redis (auth cache and rate limiting are disabled)

**Ollama model not found**
- Run `ollama list` to see pulled models
- Default model is `qwen2.5:7b` — pull it with `ollama pull qwen2.5:7b`

**Firebase permission denied**
- Check Firestore rules are deployed
- Ensure `FIREBASE_SERVICE_ACCOUNT` points to a valid JSON key

**Stripe webhook not firing**
- Use [Stripe CLI](https://stripe.com/docs/stripe-cli) for local testing:
  `stripe listen --forward-to localhost:4000/api/payment/stripe/webhook`

**GPU not detected by AI service**
- Ensure NVIDIA drivers + `nvidia-container-toolkit` are installed
- Test with: `docker run --gpus all nvidia/cuda:11.8.0-base-ubuntu22.04 nvidia-smi`
