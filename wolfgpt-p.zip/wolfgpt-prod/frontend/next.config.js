/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'standalone', // required for Docker production build

  reactStrictMode: true,

  images: {
    remotePatterns: [
      { protocol: 'https', hostname: 'storage.googleapis.com' },
      { protocol: 'https', hostname: 'lh3.googleusercontent.com' },
      { protocol: 'https', hostname: 'firebasestorage.googleapis.com' },
    ],
    formats: ['image/avif', 'image/webp'],
  },

  // Security headers applied to every response
  async headers() {
    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-DNS-Prefetch-Control',  value: 'on' },
          { key: 'X-Frame-Options',          value: 'SAMEORIGIN' },
          { key: 'X-Content-Type-Options',   value: 'nosniff' },
          { key: 'Referrer-Policy',          value: 'strict-origin-when-cross-origin' },
          { key: 'Permissions-Policy',       value: 'camera=(), microphone=(self), geolocation=()' },
        ],
      },
    ];
  },

  webpack: (config) => {
    // Avoid bundling server-only packages that may be pulled in transitively
    config.externals = [
      ...(config.externals || []),
      { canvas: 'canvas' },
      { 'firebase-admin': 'firebase-admin' },
    ];
    return config;
  },

  experimental: {
    serverActions: {
      // Guard against undefined env in docker build context
      allowedOrigins: [
        process.env.NEXT_PUBLIC_APP_URL || 'localhost:3000',
      ].filter(Boolean),
    },
  },
};

module.exports = nextConfig;
