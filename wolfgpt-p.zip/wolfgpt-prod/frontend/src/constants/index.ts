import { FeatureLimits, UserTier } from '@/types';

// ══════════════════════════════════════════════════════════════════════════════
//  FIREBASE WEB SDK CONFIGURATION
//  ─────────────────────────────────────────────────────────────────────────────
//  Setup Steps:
//  1. Go to: https://console.firebase.google.com
//  2. Your Project → Project Settings → Your Apps
//  3. Click "</>" (Web) → Register → copy the firebaseConfig object
//  4. Paste each value into frontend/.env.local:
//       NEXT_PUBLIC_FIREBASE_API_KEY=AIzaSy...
//       NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=project.firebaseapp.com
//       NEXT_PUBLIC_FIREBASE_PROJECT_ID=project-id
//       NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=project.appspot.com
//       NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
//       NEXT_PUBLIC_FIREBASE_APP_ID=1:123456:web:abc
// ══════════════════════════════════════════════════════════════════════════════
export const FIREBASE_CONFIG = {
  // ADD YOUR FIREBASE API KEY HERE (via env var) ↓
  apiKey:            process.env.NEXT_PUBLIC_FIREBASE_API_KEY,

  // ADD YOUR FIREBASE AUTH DOMAIN HERE ↓
  authDomain:        process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,

  // ADD YOUR FIREBASE PROJECT ID HERE ↓
  projectId:         process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,

  // ADD YOUR FIREBASE STORAGE BUCKET HERE ↓
  storageBucket:     process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,

  // ADD YOUR FIREBASE MESSAGING SENDER ID HERE ↓
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,

  // ADD YOUR FIREBASE APP ID HERE ↓
  appId:             process.env.NEXT_PUBLIC_FIREBASE_APP_ID,

  // ADD YOUR FIREBASE MEASUREMENT ID HERE (optional - for Analytics) ↓
  measurementId:     process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID,
};

// ══════════════════════════════════════════════════════════════════════════════
//  STRIPE CONFIGURATION
//  ─────────────────────────────────────────────────────────────────────────────
//  1. Go to: https://dashboard.stripe.com/apikeys
//  2. Copy "Publishable key" (starts with pk_test_ or pk_live_)
//  3. Add to frontend/.env.local:
//       NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
// ══════════════════════════════════════════════════════════════════════════════
export const STRIPE_CONFIG = {
  // ADD YOUR STRIPE PUBLISHABLE KEY HERE (via env var) ↓
  publishableKey: process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || '',
};

// ── API Configuration ─────────────────────────────────────────────────────────
export const API_CONFIG = {
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
};

// ── Pricing ───────────────────────────────────────────────────────────────────
export const PRICING = {
  free:    { monthly: 0,     yearly: 0    },
  basic:   { monthly: 9.99,  yearly: 99   },
  premium: { monthly: 19.99, yearly: 199  },
  pro:     { monthly: 39.99, yearly: 399  },
} as const;

export const CURRENCY_SYMBOLS = { USD: '$', PKR: 'Rs', EUR: '€', GBP: '£' } as const;

// ── Tier Limits ───────────────────────────────────────────────────────────────
export const TIER_LIMITS: Record<UserTier, FeatureLimits> = {
  free: {
    tier: 'free',
    chat:      { unlimited: true, model: ['qwen-2.5-7b'], contextWindow: 32000 },
    images:    { daily: 5,   models: ['flux-schnell'], maxResolution: 1024 },
    code:      { daily: 50,  languages: ['python','javascript','bash'], timeout: 30 },
    voice:     { unlimited: true, minutesPerMonth: undefined },
    api:       { enabled: false, requestsPerMonth: 0, rateLimit: 0, keys: 0 },
    storage:   { gb: 0.5 },
    projects:  { max: 3 },
    documents: { max: 5 },
    features:  ['chat','voice','web_search','summarize','translate','document_chat','tutor','templates'],
  },
  basic: {
    tier: 'basic',
    chat:      { unlimited: true, model: ['qwen-2.5-7b'], contextWindow: 64000 },
    images:    { daily: 25,  models: ['flux-schnell','flux-dev'], maxResolution: 1024 },
    code:      { daily: 200, languages: ['python','javascript','typescript','bash','go'], timeout: 60 },
    voice:     { unlimited: true, minutesPerMonth: 100 },
    api:       { enabled: true, requestsPerMonth: 1000, rateLimit: 10, keys: 1 },
    storage:   { gb: 5 },
    projects:  { max: 10 },
    documents: { max: 50 },
    features:  ['chat','voice','web_search','summarize','translate','document_chat','tutor','templates','api_access','code_review','sentiment_analysis'],
  },
  premium: {
    tier: 'premium',
    chat:      { unlimited: true, model: ['qwen-2.5-7b','qwen-2.5-32b','llava-13b'], contextWindow: 128000 },
    images:    { daily: 100, models: ['flux-schnell','flux-dev','sdxl-base','sdxl-refiner'], maxResolution: 2048 },
    code:      { daily: 500, languages: ['python','javascript','typescript','bash','go','rust'], timeout: 120 },
    voice:     { unlimited: true, minutesPerMonth: 500 },
    api:       { enabled: true, requestsPerMonth: 50000, rateLimit: 60, keys: 5 },
    storage:   { gb: 20 },
    projects:  { max: -1 },
    documents: { max: -1 },
    features:  ['chat','voice','web_search','summarize','translate','document_chat','tutor','templates','api_access','code_review','sentiment_analysis','priority_queue','analytics','video_transcription','custom_prompts','bookmarks','ad_free','email_support'],
  },
  pro: {
    tier: 'pro',
    chat:      { unlimited: true, model: ['qwen-2.5-7b','qwen-2.5-32b','qwen-2.5-72b','llava-13b','llava-34b'], contextWindow: 200000 },
    images:    { daily: -1, models: ['flux-schnell','flux-dev','flux-pro','sdxl-base','sdxl-refiner'], maxResolution: 4096 },
    code:      { daily: -1, languages: ['python','javascript','typescript','bash','go','rust'], timeout: 300 },
    voice:     { unlimited: true, minutesPerMonth: undefined },
    api:       { enabled: true, requestsPerMonth: -1, rateLimit: -1, keys: -1 },
    storage:   { gb: 100 },
    projects:  { max: -1 },
    documents: { max: -1 },
    features:  ['chat','voice','web_search','summarize','translate','document_chat','tutor','templates','api_access','code_review','sentiment_analysis','priority_queue','analytics','video_transcription','custom_prompts','bookmarks','ad_free','email_support','beta_features','ai_playground','knowledge_base','workflows','team_collaboration','custom_branding','priority_chat_support','video_call_support','dedicated_manager'],
  },
};

// ── Models ────────────────────────────────────────────────────────────────────
export const MODELS = {
  chat: {
    'qwen-2.5-7b':  { name: 'Qwen 2.5 7B',  description: 'Fast and efficient for everyday tasks',         contextWindow: 32000,  tier: ['free','basic','premium','pro']    },
    'qwen-2.5-32b': { name: 'Qwen 2.5 32B', description: 'Smarter responses for complex queries',         contextWindow: 128000, tier: ['premium','pro']                    },
    'qwen-2.5-72b': { name: 'Qwen 2.5 72B', description: 'Most powerful for advanced reasoning',          contextWindow: 200000, tier: ['pro']                               },
  },
  vision: {
    'llava-7b':  { name: 'LLaVA 7B',  description: 'Basic image understanding',     tier: ['free','basic']    },
    'llava-13b': { name: 'LLaVA 13B', description: 'Advanced vision capabilities',  tier: ['premium','pro']   },
    'llava-34b': { name: 'LLaVA 34B', description: 'Best-in-class image analysis',  tier: ['pro']             },
  },
  image: {
    'flux-schnell':  { name: 'FLUX Schnell',          description: 'Fast generation (2-4 steps)',         tier: ['free','basic','premium','pro'], steps: [2,4]     },
    'flux-dev':      { name: 'FLUX Dev',              description: 'Balanced quality and speed',          tier: ['basic','premium','pro'],        steps: [20,50]   },
    'flux-pro':      { name: 'FLUX Pro',              description: 'Professional quality images',         tier: ['pro'],                          steps: [50,100]  },
    'sdxl-base':     { name: 'Stable Diffusion XL',  description: 'High quality, versatile',             tier: ['premium','pro'],                steps: [30,50]   },
    'sdxl-refiner':  { name: 'SDXL Refiner',         description: 'Enhanced detail and quality',         tier: ['premium','pro'],                steps: [50,100]  },
  },
} as const;

// ── Voice ─────────────────────────────────────────────────────────────────────
export const VOICE_CONFIG = {
  stt: { model: 'whisper-large-v3', languages: ['en','es','fr','de','it','pt','ru','ja','ko','zh','ar','hi','ur'] },
  tts: {
    voices: [
      { id: 'en-US-male-1',   name: 'John (US)',    language: 'en-US', gender: 'male'   },
      { id: 'en-US-female-1', name: 'Emma (US)',    language: 'en-US', gender: 'female' },
      { id: 'en-GB-male-1',   name: 'Oliver (UK)',  language: 'en-GB', gender: 'male'   },
      { id: 'en-GB-female-1', name: 'Sophie (UK)',  language: 'en-GB', gender: 'female' },
      { id: 'ur-PK-male-1',   name: 'Ahmed (PK)',   language: 'ur-PK', gender: 'male'   },
      { id: 'ur-PK-female-1', name: 'Ayesha (PK)',  language: 'ur-PK', gender: 'female' },
    ],
    speeds: [0.75, 1.0, 1.25, 1.5, 2.0],
  },
};

// ── Languages ─────────────────────────────────────────────────────────────────
export const LANGUAGES = [
  { code: 'en', name: 'English',    native: 'English'    },
  { code: 'ur', name: 'Urdu',       native: 'اردو'       },
  { code: 'es', name: 'Spanish',    native: 'Español'    },
  { code: 'fr', name: 'French',     native: 'Français'   },
  { code: 'de', name: 'German',     native: 'Deutsch'    },
  { code: 'zh', name: 'Chinese',    native: '中文'        },
  { code: 'ja', name: 'Japanese',   native: '日本語'      },
  { code: 'ar', name: 'Arabic',     native: 'العربية'    },
  { code: 'hi', name: 'Hindi',      native: 'हिन्दी'     },
  { code: 'pt', name: 'Portuguese', native: 'Português'  },
] as const;

// ── Image Aspect Ratios ────────────────────────────────────────────────────────
export const IMAGE_ASPECT_RATIOS = [
  { label: '1:1 Square',      width: 1024, height: 1024 },
  { label: '16:9 Landscape',  width: 1344, height: 768  },
  { label: '9:16 Portrait',   width: 768,  height: 1344 },
  { label: '4:3 Standard',    width: 1152, height: 864  },
  { label: '3:2 Photo',       width: 1216, height: 832  },
] as const;

// ── Routes ────────────────────────────────────────────────────────────────────
export const ROUTES = {
  HOME:           '/',
  LOGIN:          '/login',
  REGISTER:       '/register',
  RESET_PASSWORD: '/reset-password',
  CHAT:           '/dashboard/chat',
  VOICE:          '/dashboard/voice',
  MUSIC:          '/dashboard/music',
  IMAGES:         '/dashboard/images',
  CODE:           '/dashboard/code',
  DOCUMENTS:      '/dashboard/documents',
  API_KEYS:       '/dashboard/api-keys',
  SETTINGS:       '/dashboard/settings',
  BILLING:        '/dashboard/billing',
  ANALYTICS:      '/dashboard/analytics',
} as const;

// ── Error / Success Messages ───────────────────────────────────────────────────
export const ERROR_MESSAGES = {
  NETWORK_ERROR:  'Network error. Please check your connection.',
  UNAUTHORIZED:   'Unauthorized. Please log in again.',
  RATE_LIMIT:     'Rate limit exceeded. Please try again later.',
  INVALID_INPUT:  'Invalid input. Please check your data.',
  SERVER_ERROR:   'Server error. Please try again later.',
  NOT_FOUND:      'Resource not found.',
  PAYMENT_FAILED: 'Payment failed. Please try again.',
  QUOTA_EXCEEDED: 'Usage quota exceeded. Please upgrade your plan.',
} as const;

export const SUCCESS_MESSAGES = {
  SAVED:           'Successfully saved!',
  DELETED:         'Successfully deleted!',
  UPDATED:         'Successfully updated!',
  COPIED:          'Copied to clipboard!',
  UPLOADED:        'Successfully uploaded!',
  PAYMENT_SUCCESS: 'Payment successful! Your plan has been upgraded.',
} as const;

export const STORAGE_KEYS = {
  THEME:          'wolfgpt-theme',
  LANGUAGE:       'wolfgpt-language',
  RECENT_PROMPTS: 'wolfgpt-recent-prompts',
  DRAFT_MESSAGES: 'wolfgpt-draft-messages',
  SETTINGS:       'wolfgpt-settings',
} as const;

// ── Code Themes ───────────────────────────────────────────────────────────────
export const CODE_THEMES = ['vs-dark','vs-light','github','monokai','dracula','nord','solarized-dark','solarized-light'] as const;
export const TEMPLATE_CATEGORIES = ['email','resume','cover-letter','blog','social-media','business','creative','academic'] as const;
