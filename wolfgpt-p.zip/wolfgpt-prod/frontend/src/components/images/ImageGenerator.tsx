'use client';

import React, { useState, useRef, useCallback, useEffect } from 'react';
import {
  Wand2, Upload, Image as ImageIcon, Eraser, ZoomIn, Layers,
  X, RefreshCw, Sliders, ChevronDown, ChevronUp, Sparkles,
  Copy, Info, AlertCircle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useToast } from '@/lib/hooks/use-toast';
import { useAuthStore } from '@/store/auth';
import { apiClient } from '@/lib/api';
import { ImageGeneration } from '@/types';
import ImageSettings from './ImageSettings';
import ImageGallery from './ImageGallery';
import LoadingSpinner from '@/components/shared/LoadingSpinner';
import { TIER_LIMITS } from '@/constants';
import { cn } from '@/lib/utils';

// ── Types ─────────────────────────────────────────────────────────────────────

type GenerationMode = 'txt2img' | 'img2img' | 'inpaint' | 'upscale' | 'variations';

interface GenerationSettings {
  model: string;
  width: number;
  height: number;
  steps: number;
  numImages: number;
  strength: number;
  guidanceScale: number;
  seed?: number;
}

const DEFAULT_SETTINGS: GenerationSettings = {
  model:         'flux-schnell',
  width:         1024,
  height:        1024,
  steps:         4,
  numImages:     1,
  strength:      0.75,
  guidanceScale: 7.5,
};

const MODE_META: Record<GenerationMode, { label: string; icon: React.ReactNode; desc: string; minTier?: string }> = {
  txt2img:    { label: 'Text to Image',    icon: <Wand2 className="w-4 h-4" />,    desc: 'Generate from a text description' },
  img2img:    { label: 'Image to Image',   icon: <RefreshCw className="w-4 h-4" />, desc: 'Transform a reference image with a prompt' },
  inpaint:    { label: 'Inpainting',       icon: <Eraser className="w-4 h-4" />,   desc: 'Replace masked regions with AI content', minTier: 'basic' },
  upscale:    { label: '4× Upscale',       icon: <ZoomIn className="w-4 h-4" />,   desc: 'Upscale any image 4× with AI enhancement', minTier: 'basic' },
  variations: { label: 'Variations',       icon: <Layers className="w-4 h-4" />,   desc: 'Create stylistic variations of an image', minTier: 'basic' },
};

const EXAMPLE_PROMPTS = [
  'A majestic silver wolf howling at a full moon, dramatic volumetric lighting, photorealistic',
  'Futuristic cyberpunk city skyline at night, neon reflections on wet streets, ultra-detailed',
  'Serene Japanese zen garden with cherry blossoms, golden hour, Studio Ghibli style',
  'Epic fantasy castle floating in the clouds, dragons circling, cinematic composition',
  'Underwater bioluminescent coral reef, ethereal blue glow, macro photography',
  'Ancient library with glowing spell books, mystical fog, fantasy art style',
];

const TIER_ORDER: Record<string, number> = { free: 0, basic: 1, premium: 2, pro: 3 };

// ── Sub-components ────────────────────────────────────────────────────────────

function DropZone({
  label, value, onChange, onClear, accept = 'image/png,image/jpeg,image/webp',
}: {
  label: string;
  value: File | null;
  onChange: (f: File) => void;
  onClear: () => void;
  accept?: string;
}) {
  const inputRef   = useRef<HTMLInputElement>(null);
  const [drag, setDrag] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);

  useEffect(() => {
    if (!value) { setPreview(null); return; }
    const url = URL.createObjectURL(value);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [value]);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDrag(false);
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith('image/')) onChange(file);
  }, [onChange]);

  return (
    <div className="space-y-2">
      <label className="text-sm font-medium text-foreground">{label}</label>

      {preview ? (
        <div className="relative rounded-xl overflow-hidden border border-border group">
          <img src={preview} alt="preview" className="w-full max-h-56 object-contain bg-black/5" />
          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
            <Button size="sm" variant="secondary" onClick={() => inputRef.current?.click()}>
              <Upload className="w-4 h-4 mr-1" /> Replace
            </Button>
            <Button size="sm" variant="destructive" onClick={onClear}>
              <X className="w-4 h-4 mr-1" /> Remove
            </Button>
          </div>
          <div className="absolute bottom-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded">
            {value?.name} · {value ? (value.size / 1024).toFixed(0) : 0} KB
          </div>
        </div>
      ) : (
        <div
          className={cn(
            'border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all',
            drag
              ? 'border-primary bg-primary/5 scale-[1.01]'
              : 'border-border hover:border-primary/60 hover:bg-muted/40',
          )}
          onClick={() => inputRef.current?.click()}
          onDragOver={e => { e.preventDefault(); setDrag(true); }}
          onDragLeave={() => setDrag(false)}
          onDrop={handleDrop}
        >
          <Upload className="w-8 h-8 mx-auto mb-3 text-muted-foreground" />
          <p className="text-sm font-medium">Drop image here or click to browse</p>
          <p className="text-xs text-muted-foreground mt-1">PNG, JPG, WEBP · max 20 MB</p>
        </div>
      )}

      <input
        ref={inputRef}
        type="file"
        accept={accept}
        className="hidden"
        onChange={e => { const f = e.target.files?.[0]; if (f) onChange(f); }}
      />
    </div>
  );
}

function StrengthSlider({ value, onChange }: { value: number; onChange: (v: number) => void }) {
  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <label className="text-sm font-medium">Transformation Strength</label>
        <span className="text-sm font-mono font-bold text-primary">{value.toFixed(2)}</span>
      </div>
      <input
        type="range" min={0.01} max={1} step={0.01} value={value}
        onChange={e => onChange(parseFloat(e.target.value))}
        className="w-full h-2 rounded-full accent-primary cursor-pointer"
      />
      <div className="flex justify-between text-xs text-muted-foreground">
        <span>Keep original</span>
        <span>Completely new</span>
      </div>
      <div className="grid grid-cols-3 gap-2 mt-1">
        {([['Subtle (0.3)', 0.3], ['Balanced (0.6)', 0.6], ['Creative (0.9)', 0.9]] as const).map(([lbl, v]) => (
          <button
            key={lbl}
            onClick={() => onChange(v)}
            className={cn(
              'text-xs py-1 rounded-lg border transition-colors',
              Math.abs(value - v) < 0.05
                ? 'border-primary bg-primary/10 text-primary font-semibold'
                : 'border-border hover:border-primary/60',
            )}
          >{lbl}</button>
        ))}
      </div>
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────

export default function ImageGenerator() {
  const { user }  = useAuthStore();
  const { toast } = useToast();

  const [mode, setMode]           = useState<GenerationMode>('txt2img');
  const [prompt, setPrompt]       = useState('');
  const [negPrompt, setNegPrompt] = useState('');
  const [settings, setSettings]   = useState<GenerationSettings>(DEFAULT_SETTINGS);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [advOpen, setAdvOpen]     = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImages, setGeneratedImages] = useState<ImageGeneration[]>([]);
  const [elapsed, setElapsed]     = useState(0);

  // Reference images for img2img / inpaint / upscale / variations
  const [refFile, setRefFile]     = useState<File | null>(null);
  const [maskFile, setMaskFile]   = useState<File | null>(null);

  // Timer
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const userTier  = user?.tier || 'free';
  const limits    = (TIER_LIMITS as any)[userTier]?.images || TIER_LIMITS.free.images;
  const usedToday = user?.usage?.images?.used || 0;
  const dailyLeft = limits.daily === -1 ? Infinity : limits.daily - usedToday;

  // File → base64
  const fileToBase64 = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload  = () => resolve((reader.result as string).split(',')[1]);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });

  const startTimer = () => {
    setElapsed(0);
    timerRef.current = setInterval(() => setElapsed(s => s + 1), 1000);
  };
  const stopTimer = () => {
    if (timerRef.current) clearInterval(timerRef.current);
  };

  const canUseMode = (m: GenerationMode) => {
    const min = MODE_META[m].minTier;
    if (!min) return true;
    return (TIER_ORDER[userTier] || 0) >= (TIER_ORDER[min] || 0);
  };

  // ── Generate ────────────────────────────────────────────────────────────
  const handleGenerate = async () => {
    if (!prompt.trim() && mode !== 'upscale') {
      toast({ variant: 'destructive', title: 'Prompt required', description: 'Please describe what you want to generate.' });
      return;
    }
    if (['img2img', 'inpaint', 'upscale', 'variations'].includes(mode) && !refFile) {
      toast({ variant: 'destructive', title: 'Image required', description: 'Please upload a reference image.' });
      return;
    }
    if (mode === 'inpaint' && !maskFile) {
      toast({ variant: 'destructive', title: 'Mask required', description: 'Please upload a mask image.' });
      return;
    }
    if (dailyLeft <= 0) {
      toast({ variant: 'destructive', title: 'Daily limit reached', description: 'Upgrade your plan for more generations.' });
      return;
    }

    setIsGenerating(true);
    startTimer();

    try {
      let result: any;

      if (mode === 'txt2img') {
        result = await apiClient.generateImage({
          ...settings, prompt: prompt.trim(),
          negativePrompt: negPrompt.trim() || undefined,
        });

      } else if (mode === 'img2img' || mode === 'variations') {
        const b64 = await fileToBase64(refFile!);
        const endpoint = mode === 'variations' ? '/api/v1/images/variations' : '/api/v1/images/img2img';
        result = await apiClient.post(endpoint, {
          prompt: prompt.trim(), referenceImage: b64,
          negativePrompt: negPrompt.trim() || undefined,
          ...settings,
        });

      } else if (mode === 'inpaint') {
        const imgB64  = await fileToBase64(refFile!);
        const maskB64 = await fileToBase64(maskFile!);
        result = await apiClient.post('/api/v1/images/inpaint', {
          prompt: prompt.trim(), image: imgB64, mask: maskB64,
          negativePrompt: negPrompt.trim() || undefined,
          ...settings,
        });

      } else if (mode === 'upscale') {
        const b64 = await fileToBase64(refFile!);
        result = await apiClient.post('/api/v1/images/upscale', {
          image: b64, prompt: prompt.trim(),
        });
      }

      stopTimer();

      if (result?.success && result.data?.images?.length > 0) {
        const newImgs = result.data.images;
        setGeneratedImages(prev => [...newImgs, ...prev]);
        toast({
          title: '✨ Generated!',
          description: `${newImgs.length} image${newImgs.length > 1 ? 's' : ''} ready in ${result.data.generationTime}s`,
        });
      }
    } catch (err: any) {
      stopTimer();
      toast({
        variant: 'destructive',
        title: 'Generation Failed',
        description: err.message || 'Something went wrong. Please try again.',
      });
    } finally {
      setIsGenerating(false);
    }
  };

  // ── Render ──────────────────────────────────────────────────────────────
  return (
    <div className="h-full flex flex-col bg-background">

      {/* ── Header ── */}
      <div className="flex items-center justify-between px-6 py-4 border-b bg-card/60 backdrop-blur sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-fuchsia-600 flex items-center justify-center shadow-lg">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-bold tracking-tight">AI Image Studio</h2>
            <p className="text-xs text-muted-foreground">Powered by FLUX & SDXL</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {/* Usage badge */}
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-muted text-sm">
            <div className={cn('w-2 h-2 rounded-full', dailyLeft > 0 ? 'bg-emerald-400' : 'bg-red-400')} />
            <span className="font-medium">
              {limits.daily === -1 ? '∞' : `${usedToday}/${limits.daily}`}
            </span>
            <span className="text-muted-foreground">today</span>
          </div>

          <Button variant="outline" size="sm" onClick={() => setSettingsOpen(true)}>
            <Sliders className="w-4 h-4 mr-1.5" /> Settings
          </Button>
        </div>
      </div>

      {/* ── Main ── */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-5xl mx-auto p-6 space-y-6">

          {/* ── Mode Selector ── */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
            {(Object.entries(MODE_META) as [GenerationMode, typeof MODE_META[GenerationMode]][]).map(([key, meta]) => {
              const allowed = canUseMode(key);
              return (
                <button
                  key={key}
                  disabled={!allowed}
                  onClick={() => allowed && setMode(key)}
                  className={cn(
                    'relative flex flex-col items-center gap-1.5 p-3 rounded-xl border text-xs font-medium transition-all',
                    mode === key
                      ? 'border-primary bg-primary/10 text-primary shadow-sm'
                      : allowed
                        ? 'border-border hover:border-primary/60 hover:bg-muted/60'
                        : 'border-border/40 opacity-40 cursor-not-allowed',
                  )}
                >
                  {meta.icon}
                  <span>{meta.label}</span>
                  {!allowed && (
                    <span className="absolute -top-1 -right-1 text-[9px] bg-amber-400 text-black px-1 rounded-full font-bold">
                      {meta.minTier?.toUpperCase()}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* ── Mode Description ── */}
          <div className="flex items-start gap-2 px-4 py-3 rounded-xl bg-muted/50 border border-border/60 text-sm text-muted-foreground">
            <Info className="w-4 h-4 mt-0.5 shrink-0 text-primary" />
            <span>{MODE_META[mode].desc}</span>
          </div>

          {/* ── Input Card ── */}
          <Card className="border shadow-sm">
            <CardContent className="pt-6 space-y-5">

              {/* Reference image upload (all modes except txt2img) */}
              {mode !== 'txt2img' && (
                <DropZone
                  label={mode === 'upscale' ? 'Image to Upscale' : 'Reference Image'}
                  value={refFile}
                  onChange={setRefFile}
                  onClear={() => setRefFile(null)}
                />
              )}

              {/* Mask upload (inpaint only) */}
              {mode === 'inpaint' && (
                <DropZone
                  label="Mask Image (white = repaint, black = keep)"
                  value={maskFile}
                  onChange={setMaskFile}
                  onClear={() => setMaskFile(null)}
                />
              )}

              {/* Strength slider (img2img / inpaint / variations) */}
              {['img2img', 'inpaint', 'variations'].includes(mode) && (
                <StrengthSlider
                  value={settings.strength}
                  onChange={v => setSettings(s => ({ ...s, strength: v }))}
                />
              )}

              {/* Prompt (all modes except upscale) */}
              {mode !== 'upscale' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium">Prompt</label>
                    <span className="text-xs text-muted-foreground">{prompt.length}/2000</span>
                  </div>
                  <Textarea
                    value={prompt}
                    onChange={e => setPrompt(e.target.value.slice(0, 2000))}
                    placeholder={
                      mode === 'img2img'
                        ? 'Describe how to transform the reference image...'
                        : mode === 'inpaint'
                          ? 'Describe what to generate in the masked area...'
                          : 'Describe the image you want to create...'
                    }
                    className="min-h-[100px] resize-none"
                    disabled={isGenerating}
                    onKeyDown={e => {
                      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) handleGenerate();
                    }}
                  />
                </div>
              )}

              {/* Advanced options */}
              <div>
                <button
                  className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
                  onClick={() => setAdvOpen(v => !v)}
                >
                  {advOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  Advanced Options
                </button>

                {advOpen && (
                  <div className="mt-4 space-y-4 pt-4 border-t">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Negative Prompt</label>
                      <Textarea
                        value={negPrompt}
                        onChange={e => setNegPrompt(e.target.value)}
                        placeholder="What to avoid: blurry, low quality, distorted, watermark..."
                        className="min-h-[70px] resize-none"
                        disabled={isGenerating}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-1.5">
                        <label className="text-sm font-medium">Seed (optional)</label>
                        <input
                          type="number"
                          value={settings.seed ?? ''}
                          onChange={e => setSettings(s => ({
                            ...s, seed: e.target.value ? parseInt(e.target.value) : undefined,
                          }))}
                          placeholder="Random"
                          className="w-full px-3 py-2 text-sm rounded-lg border bg-background"
                          disabled={isGenerating}
                        />
                        <p className="text-xs text-muted-foreground">Same seed = reproducible results</p>
                      </div>

                      <div className="space-y-1.5">
                        <label className="text-sm font-medium">Guidance Scale</label>
                        <input
                          type="number"
                          min={0} max={20} step={0.5}
                          value={settings.guidanceScale}
                          onChange={e => setSettings(s => ({ ...s, guidanceScale: parseFloat(e.target.value) }))}
                          className="w-full px-3 py-2 text-sm rounded-lg border bg-background"
                          disabled={isGenerating}
                        />
                        <p className="text-xs text-muted-foreground">Higher = follows prompt more strictly</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Quick settings row */}
              <div className="flex flex-wrap items-center gap-2 pt-1">
                {[
                  { label: settings.model,                   icon: '🤖' },
                  { label: `${settings.width}×${settings.height}`, icon: '📐' },
                  { label: `${settings.steps} steps`,        icon: '🔄' },
                  { label: `${settings.numImages} image${settings.numImages > 1 ? 's' : ''}`, icon: '🖼️' },
                ].map(({ label, icon }) => (
                  <button
                    key={label}
                    onClick={() => setSettingsOpen(true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-muted hover:bg-muted/80 text-xs font-medium transition-colors"
                  >
                    <span>{icon}</span>{label}
                  </button>
                ))}
              </div>

              {/* Generate Button */}
              <Button
                onClick={handleGenerate}
                disabled={isGenerating || dailyLeft <= 0}
                className="w-full h-12 text-base font-semibold bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 shadow-lg"
                size="lg"
              >
                {isGenerating ? (
                  <span className="flex items-center gap-2">
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    Generating… {elapsed}s
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5" />
                    {MODE_META[mode].label}
                    <span className="text-xs opacity-70 ml-1">⌘↵</span>
                  </span>
                )}
              </Button>

              {dailyLeft <= 0 && (
                <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 dark:bg-amber-950/30 px-4 py-2 rounded-lg border border-amber-200 dark:border-amber-800">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  Daily limit reached. <a href="/dashboard/billing" className="underline font-medium">Upgrade your plan →</a>
                </div>
              )}
            </CardContent>
          </Card>

          {/* ── Example Prompts (txt2img only) ── */}
          {mode === 'txt2img' && !isGenerating && generatedImages.length === 0 && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">✨ Example Prompts</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {EXAMPLE_PROMPTS.map((ex, i) => (
                    <button
                      key={i}
                      onClick={() => setPrompt(ex)}
                      className="group p-3 text-left text-sm rounded-xl border border-border hover:border-primary/60 hover:bg-primary/5 transition-all"
                    >
                      <span className="text-muted-foreground group-hover:text-foreground transition-colors line-clamp-2">
                        {ex}
                      </span>
                      <span className="flex items-center gap-1 mt-1.5 text-xs text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                        <Copy className="w-3 h-3" /> Use this prompt
                      </span>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* ── Loading State ── */}
          {isGenerating && (
            <Card className="border-primary/20 bg-primary/5">
              <CardContent className="py-10 text-center space-y-3">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-violet-500 to-fuchsia-600 flex items-center justify-center shadow-xl animate-pulse">
                  <Sparkles className="w-8 h-8 text-white" />
                </div>
                <p className="font-semibold text-lg">Creating your masterpiece…</p>
                <p className="text-sm text-muted-foreground">
                  {elapsed < 5  ? 'Warming up the AI…'
                  : elapsed < 15 ? 'Painting the details…'
                  : elapsed < 30 ? 'Adding finishing touches…'
                  : 'Almost there, large models take a moment…'}
                </p>
                <div className="flex justify-center gap-1 mt-2">
                  {[0,1,2,3,4].map(i => (
                    <div
                      key={i}
                      className="w-2 h-2 rounded-full bg-primary animate-bounce"
                      style={{ animationDelay: `${i * 0.1}s` }}
                    />
                  ))}
                </div>
                <p className="text-xs text-muted-foreground font-mono">{elapsed}s elapsed</p>
              </CardContent>
            </Card>
          )}

          {/* ── Results Gallery ── */}
          {generatedImages.length > 0 && !isGenerating && (
            <ImageGallery images={generatedImages} onDelete={id => setGeneratedImages(prev => prev.filter(i => i.id !== id))} />
          )}
        </div>
      </div>

      {/* ── Settings Dialog ── */}
      <ImageSettings
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={settings}
        onSettingsChange={setSettings}
        userTier={userTier}
        mode={mode}
      />
    </div>
  );
}
