'use client';

import React, { useState } from 'react';
import {
  Download, Share2, Trash2, ZoomIn, Copy, RefreshCw,
  X, Info, Maximize2,
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { useToast } from '@/lib/hooks/use-toast';
import { cn } from '@/lib/utils';

// Minimal type — only fields we actually render
interface GalleryImage {
  id: string;
  url: string;
  prompt: string;
  negativePrompt?: string;
  model?: string;
  width?: number;
  height?: number;
  steps?: number;
  strength?: number;
  mode?: string;
  referenceImageUrl?: string;
  seed?: number;
  createdAt?: any;
}

interface Props {
  images: GalleryImage[];
  onDelete?: (id: string) => void;
  onVariation?: (img: GalleryImage) => void;
}

const MODE_BADGE: Record<string, { label: string; color: string }> = {
  txt2img:    { label: 'Text→Image',    color: 'bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-300' },
  img2img:    { label: 'Img→Img',       color: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300' },
  inpaint:    { label: 'Inpaint',       color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300' },
  upscale:    { label: '4× Upscale',    color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300' },
  variations: { label: 'Variation',     color: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300' },
};

function formatTime(date: any): string {
  if (!date) return '';
  const d = date?.toDate?.() ?? new Date(date);
  const diff = (Date.now() - d.getTime()) / 1000;
  if (diff < 60)  return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return d.toLocaleDateString();
}

export default function ImageGallery({ images, onDelete, onVariation }: Props) {
  const [selected, setSelected] = useState<GalleryImage | null>(null);
  const { toast } = useToast();

  const handleDownload = async (img: GalleryImage, e?: React.MouseEvent) => {
    e?.stopPropagation();
    try {
      const res  = await fetch(img.url);
      const blob = await res.blob();
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href     = url;
      a.download = `wolfgpt-${img.id}.png`;
      document.body.appendChild(a);
      a.click();
      URL.revokeObjectURL(url);
      document.body.removeChild(a);
      toast({ title: '✅ Downloaded!' });
    } catch {
      toast({ variant: 'destructive', title: 'Download failed' });
    }
  };

  const handleShare = async (img: GalleryImage, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (navigator.share) {
      try {
        await navigator.share({ title: 'Made with WolfGPT', text: img.prompt, url: img.url });
        return;
      } catch { /* cancelled */ }
    }
    await navigator.clipboard.writeText(img.url);
    toast({ title: '🔗 Link copied!' });
  };

  const handleCopyPrompt = async (img: GalleryImage, e?: React.MouseEvent) => {
    e?.stopPropagation();
    await navigator.clipboard.writeText(img.prompt);
    toast({ title: '📋 Prompt copied!' });
  };

  const handleDelete = (img: GalleryImage, e?: React.MouseEvent) => {
    e?.stopPropagation();
    onDelete?.(img.id);
    if (selected?.id === img.id) setSelected(null);
    toast({ title: '🗑️ Removed from gallery' });
  };

  return (
    <>
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-base flex items-center gap-2">
              🖼️ Generated Images
              <Badge variant="secondary">{images.length}</Badge>
            </CardTitle>
          </div>
        </CardHeader>

        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {images.map(img => (
              <div
                key={img.id}
                className="group relative aspect-square rounded-xl overflow-hidden bg-muted cursor-pointer border border-border hover:border-primary/50 transition-all hover:shadow-lg hover:scale-[1.02]"
                onClick={() => setSelected(img)}
              >
                <img
                  src={img.url}
                  alt={img.prompt}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />

                {/* Mode badge */}
                {img.mode && MODE_BADGE[img.mode] && (
                  <div className={cn(
                    'absolute top-2 left-2 text-[10px] font-bold px-2 py-0.5 rounded-full',
                    MODE_BADGE[img.mode].color,
                  )}>
                    {MODE_BADGE[img.mode].label}
                  </div>
                )}

                {/* Hover overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-black/30 opacity-0 group-hover:opacity-100 transition-opacity">
                  {/* Top actions */}
                  <div className="absolute top-2 right-2 flex gap-1">
                    <button
                      onClick={e => handleDownload(img, e)}
                      className="w-7 h-7 rounded-lg bg-black/60 hover:bg-black/80 flex items-center justify-center text-white transition-colors"
                      title="Download"
                    ><Download className="w-3.5 h-3.5" /></button>
                    <button
                      onClick={e => handleShare(img, e)}
                      className="w-7 h-7 rounded-lg bg-black/60 hover:bg-black/80 flex items-center justify-center text-white transition-colors"
                      title="Share"
                    ><Share2 className="w-3.5 h-3.5" /></button>
                    {onDelete && (
                      <button
                        onClick={e => handleDelete(img, e)}
                        className="w-7 h-7 rounded-lg bg-red-600/80 hover:bg-red-600 flex items-center justify-center text-white transition-colors"
                        title="Delete"
                      ><Trash2 className="w-3.5 h-3.5" /></button>
                    )}
                  </div>

                  {/* Bottom info */}
                  <div className="absolute bottom-0 left-0 right-0 p-2">
                    <p className="text-white text-xs line-clamp-2 leading-tight">{img.prompt}</p>
                    {img.createdAt && (
                      <p className="text-white/60 text-[10px] mt-0.5">{formatTime(img.createdAt)}</p>
                    )}
                  </div>

                  {/* Centre zoom icon */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <Maximize2 className="w-8 h-8 text-white/80 drop-shadow-lg" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* ── Lightbox ── */}
      {selected && (
        <Dialog open onOpenChange={() => setSelected(null)}>
          <DialogContent className="max-w-5xl p-0 overflow-hidden">
            <div className="flex flex-col lg:flex-row">
              {/* Image */}
              <div className="flex-1 bg-black/90 flex items-center justify-center min-h-64 lg:min-h-[600px] relative">
                <img
                  src={selected.url}
                  alt={selected.prompt}
                  className="max-w-full max-h-[75vh] lg:max-h-[600px] object-contain"
                />
                <button
                  onClick={() => setSelected(null)}
                  className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/60 hover:bg-black/80 flex items-center justify-center text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Details panel */}
              <div className="w-full lg:w-72 p-5 space-y-5 overflow-y-auto border-t lg:border-t-0 lg:border-l max-h-[50vh] lg:max-h-[600px]">

                {/* Actions */}
                <div className="grid grid-cols-2 gap-2">
                  <Button variant="outline" size="sm" onClick={() => handleDownload(selected)}>
                    <Download className="w-4 h-4 mr-1" /> Save
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleShare(selected)}>
                    <Share2 className="w-4 h-4 mr-1" /> Share
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleCopyPrompt(selected)}>
                    <Copy className="w-4 h-4 mr-1" /> Prompt
                  </Button>
                  {onVariation && (
                    <Button variant="outline" size="sm" onClick={() => { onVariation(selected); setSelected(null); }}>
                      <RefreshCw className="w-4 h-4 mr-1" /> Vary
                    </Button>
                  )}
                </div>

                {/* Mode badge */}
                {selected.mode && MODE_BADGE[selected.mode] && (
                  <div>
                    <span className={cn('text-xs font-bold px-2 py-1 rounded-full', MODE_BADGE[selected.mode].color)}>
                      {MODE_BADGE[selected.mode].label}
                    </span>
                  </div>
                )}

                {/* Prompt */}
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">Prompt</p>
                  <p className="text-sm leading-relaxed">{selected.prompt}</p>
                </div>

                {selected.negativePrompt && (
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">Negative Prompt</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{selected.negativePrompt}</p>
                  </div>
                )}

                {/* Metadata grid */}
                <div className="grid grid-cols-2 gap-2">
                  {[
                    ['Model',   selected.model],
                    ['Size',    selected.width && selected.height ? `${selected.width}×${selected.height}` : undefined],
                    ['Steps',   selected.steps],
                    ['Strength',selected.strength ? selected.strength.toFixed(2) : undefined],
                    ['Seed',    selected.seed],
                  ]
                    .filter(([, v]) => v !== undefined && v !== null)
                    .map(([k, v]) => (
                      <div key={String(k)} className="p-2 rounded-lg bg-muted/60 text-center">
                        <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{k}</p>
                        <p className="text-xs font-semibold mt-0.5 truncate">{String(v)}</p>
                      </div>
                    ))}
                </div>

                {/* Reference image thumbnail */}
                {selected.referenceImageUrl && (
                  <div>
                    <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">Reference</p>
                    <img
                      src={selected.referenceImageUrl}
                      alt="reference"
                      className="w-full rounded-lg border object-cover max-h-28"
                    />
                  </div>
                )}

                {selected.createdAt && (
                  <p className="text-xs text-muted-foreground">{formatTime(selected.createdAt)}</p>
                )}

                {onDelete && (
                  <Button
                    variant="destructive" size="sm" className="w-full"
                    onClick={() => handleDelete(selected)}
                  >
                    <Trash2 className="w-4 h-4 mr-1" /> Delete
                  </Button>
                )}
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
