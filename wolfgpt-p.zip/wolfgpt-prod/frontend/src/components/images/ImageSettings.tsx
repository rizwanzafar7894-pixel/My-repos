'use client';

import React from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { TIER_LIMITS } from '@/constants';
import { cn } from '@/lib/utils';

type UserTier = 'free' | 'basic' | 'premium' | 'pro';
type GenerationMode = 'txt2img' | 'img2img' | 'inpaint' | 'upscale' | 'variations';

interface Settings {
  model: string;
  width: number;
  height: number;
  steps: number;
  numImages: number;
  strength: number;
  guidanceScale: number;
  seed?: number;
}

interface Props {
  open: boolean;
  onClose: () => void;
  settings: Settings;
  onSettingsChange: (s: Settings) => void;
  userTier: UserTier;
  mode?: GenerationMode;
}

// ── Static config ──────────────────────────────────────────────────────────

const MODELS: Record<string, { name: string; badge: string; badgeColor: string; steps: number[]; description: string; supportsImg2Img: boolean }> = {
  'flux-schnell': {
    name: 'FLUX Schnell',
    badge: 'Fast',
    badgeColor: 'bg-emerald-100 text-emerald-700',
    steps: [4, 8],
    description: 'Fastest FLUX model. Ideal for quick drafts and iteration.',
    supportsImg2Img: true,
  },
  'flux-dev': {
    name: 'FLUX Dev',
    badge: 'Balanced',
    badgeColor: 'bg-blue-100 text-blue-700',
    steps: [20, 30, 50],
    description: 'High quality with great prompt adherence. Best all-rounder.',
    supportsImg2Img: true,
  },
  'flux-pro': {
    name: 'FLUX Pro',
    badge: 'Premium',
    badgeColor: 'bg-purple-100 text-purple-700',
    steps: [30, 50],
    description: 'Top-tier FLUX quality. Exceptional photorealism.',
    supportsImg2Img: true,
  },
  'sdxl-base': {
    name: 'SDXL Base',
    badge: 'Versatile',
    badgeColor: 'bg-amber-100 text-amber-700',
    steps: [20, 30, 40],
    description: 'Stable Diffusion XL. Great for artistic styles & inpainting.',
    supportsImg2Img: true,
  },
  'sdxl-refiner': {
    name: 'SDXL Refiner',
    badge: 'Detail',
    badgeColor: 'bg-rose-100 text-rose-700',
    steps: [20, 30, 40],
    description: 'Two-stage SDXL with refiner pass. Maximum detail.',
    supportsImg2Img: true,
  },
};

const ASPECT_RATIOS = [
  { label: '1:1 Square',      width: 1024, height: 1024, icon: '⬜' },
  { label: '3:2 Landscape',   width: 1216, height: 832,  icon: '▬' },
  { label: '2:3 Portrait',    width: 832,  height: 1216, icon: '▯' },
  { label: '16:9 Widescreen', width: 1344, height: 768,  icon: '🖥️' },
  { label: '9:16 Mobile',     width: 768,  height: 1344, icon: '📱' },
  { label: '4:3 Classic',     width: 1152, height: 864,  icon: '🖼️' },
];

export default function ImageSettings({ open, onClose, settings, onSettingsChange, userTier, mode = 'txt2img' }: Props) {
  const tierLimits      = (TIER_LIMITS as any)[userTier]?.images;
  const availableModels = tierLimits?.models || ['flux-schnell'];
  const maxResolution   = tierLimits?.maxResolution || 1024;

  const currentModel = MODELS[settings.model];
  const currentRatio = ASPECT_RATIOS.find(r => r.width === settings.width && r.height === settings.height);

  const isImg2ImgMode = ['img2img', 'inpaint', 'variations'].includes(mode);

  const set = <K extends keyof Settings>(k: K, v: Settings[K]) =>
    onSettingsChange({ ...settings, [k]: v });

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[680px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            ⚙️ Generation Settings
          </DialogTitle>
          <DialogDescription>
            Configure model, resolution, and quality parameters
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-7 py-2">

          {/* ── Model ── */}
          <section className="space-y-3">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">AI Model</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {Object.entries(MODELS).map(([key, model]) => {
                const available = availableModels.includes(key);
                const active    = settings.model === key;
                const compatible = !isImg2ImgMode || model.supportsImg2Img;
                return (
                  <button
                    key={key}
                    disabled={!available || !compatible}
                    onClick={() => {
                      set('model', key);
                      set('steps', model.steps[Math.floor(model.steps.length / 2)]);
                    }}
                    className={cn(
                      'relative flex flex-col gap-1 p-3 rounded-xl border text-left transition-all',
                      active
                        ? 'border-primary bg-primary/8 ring-1 ring-primary/30'
                        : available && compatible
                          ? 'border-border hover:border-primary/50 hover:bg-muted/60'
                          : 'border-border/40 opacity-40 cursor-not-allowed',
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-sm">{model.name}</span>
                      <span className={cn('text-[10px] px-2 py-0.5 rounded-full font-semibold', model.badgeColor)}>
                        {model.badge}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed">{model.description}</p>
                    {!available && (
                      <span className="absolute top-2 right-2 text-[9px] bg-amber-400 text-black px-1.5 py-0.5 rounded-full font-bold">
                        UPGRADE
                      </span>
                    )}
                    {active && (
                      <span className="absolute top-2 left-2 text-[10px] bg-primary text-primary-foreground px-1.5 py-0.5 rounded-full font-bold">
                        ACTIVE
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </section>

          {/* ── Aspect Ratio ── */}
          <section className="space-y-3">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
              Aspect Ratio
              <span className="ml-2 text-xs normal-case font-normal text-muted-foreground">
                Max: {maxResolution}×{maxResolution}
              </span>
            </h3>
            <div className="grid grid-cols-3 gap-2">
              {ASPECT_RATIOS.map(ratio => {
                const oversized = Math.max(ratio.width, ratio.height) > maxResolution;
                const active    = currentRatio?.label === ratio.label;
                return (
                  <button
                    key={ratio.label}
                    disabled={oversized}
                    onClick={() => { set('width', ratio.width); set('height', ratio.height); }}
                    className={cn(
                      'flex flex-col items-center gap-1 p-3 rounded-xl border text-xs transition-all',
                      active
                        ? 'border-primary bg-primary/8 ring-1 ring-primary/30 font-semibold text-primary'
                        : oversized
                          ? 'border-border/40 opacity-40 cursor-not-allowed'
                          : 'border-border hover:border-primary/50 hover:bg-muted/60',
                    )}
                  >
                    <span className="text-xl">{ratio.icon}</span>
                    <span>{ratio.label}</span>
                    <span className="font-mono text-muted-foreground">{ratio.width}×{ratio.height}</span>
                  </button>
                );
              })}
            </div>
          </section>

          {/* ── Steps & Images ── */}
          <section className="grid grid-cols-2 gap-6">
            <div className="space-y-3">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Steps</h3>
              <div className="flex flex-wrap gap-2">
                {(currentModel?.steps || [4, 20, 30]).map(s => (
                  <button
                    key={s}
                    onClick={() => set('steps', s)}
                    className={cn(
                      'px-4 py-2 rounded-lg border text-sm font-medium transition-all',
                      settings.steps === s
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-border hover:border-primary/60',
                    )}
                  >
                    {s}
                    {s === (currentModel?.steps || [])[0] && (
                      <span className="ml-1 text-[10px] text-muted-foreground">(fast)</span>
                    )}
                  </button>
                ))}
              </div>
              <p className="text-xs text-muted-foreground">More steps = higher quality, slower</p>
            </div>

            <div className="space-y-3">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Images</h3>
              <div className="flex gap-2">
                {[1, 2, 3, 4].map(n => (
                  <button
                    key={n}
                    onClick={() => set('numImages', n)}
                    className={cn(
                      'w-11 h-11 rounded-lg border text-sm font-bold transition-all',
                      settings.numImages === n
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-border hover:border-primary/60',
                    )}
                  >{n}</button>
                ))}
              </div>
              <p className="text-xs text-muted-foreground">Generate multiple variations at once</p>
            </div>
          </section>

          {/* ── Plan Info ── */}
          <section className="p-4 rounded-xl bg-gradient-to-br from-muted/60 to-muted/30 border space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="font-semibold text-sm">Your Plan</h4>
              <Badge variant="outline" className="capitalize">{userTier}</Badge>
            </div>
            <div className="grid grid-cols-3 gap-3 text-xs">
              {[
                ['Daily Images', tierLimits?.daily === -1 ? '∞' : tierLimits?.daily ?? 5],
                ['Max Resolution', `${maxResolution}px`],
                ['Models', availableModels.length],
              ].map(([lbl, val]) => (
                <div key={String(lbl)} className="text-center p-2 rounded-lg bg-background/60">
                  <p className="font-bold text-base text-foreground">{val}</p>
                  <p className="text-muted-foreground">{lbl}</p>
                </div>
              ))}
            </div>
            {userTier !== 'pro' && (
              <Button asChild size="sm" className="w-full mt-2 bg-gradient-to-r from-violet-600 to-fuchsia-600">
                <a href="/dashboard/billing">Upgrade for More →</a>
              </Button>
            )}
          </section>
        </div>

        <div className="flex justify-end gap-3 pt-2 border-t">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button
            className="bg-gradient-to-r from-violet-600 to-fuchsia-600"
            onClick={onClose}
          >
            Apply Settings
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
