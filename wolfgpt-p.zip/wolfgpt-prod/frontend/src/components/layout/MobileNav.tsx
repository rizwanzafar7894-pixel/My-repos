'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  MessageSquare,
  Mic,
  Image,
  Code,
  FileText,
  MoreHorizontal,
} from 'lucide-react';
import { cn } from '@/lib/utils';

const navigation = [
  { name: 'Chat', href: '/dashboard/chat', icon: MessageSquare },
  { name: 'Voice', href: '/dashboard/voice', icon: Mic },
  { name: 'Images', href: '/dashboard/images', icon: Image },
  { name: 'Code', href: '/dashboard/code', icon: Code },
  { name: 'Docs', href: '/dashboard/documents', icon: FileText },
];

export default function MobileNav() {
  const pathname = usePathname();

  return (
    <nav className="mobile-nav md:hidden">
      <div className="flex items-center justify-around h-16 px-2">
        {navigation.map((item) => {
          const Icon = item.icon;
          const isActive = pathname === item.href;

          return (
            <Link
              key={item.name}
              href={item.href}
              className={cn(
                'flex flex-col items-center justify-center gap-1 flex-1 h-full transition-colors',
                isActive
                  ? 'text-wolf-500'
                  : 'text-muted-foreground hover:text-foreground'
              )}
            >
              <Icon className={cn('w-5 h-5', isActive && 'stroke-[2.5]')} />
              <span className="text-xs font-medium">{item.name}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
