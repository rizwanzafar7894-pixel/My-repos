'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  MessageSquare,
  Mic,
  Image,
  Code,
  FileText,
  Key,
  Settings,
  CreditCard,
  BarChart3,
  X,
  Music,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import Logo from '@/components/shared/Logo';
import { cn } from '@/lib/utils';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const navigation = [
  {
    name: 'Chat',
    href: '/dashboard/chat',
    icon: MessageSquare,
    description: 'AI conversation',
  },
  {
    name: 'Voice',
    href: '/dashboard/voice',
    icon: Mic,
    description: 'Speech to text & text to speech',
  },
  {
    name: 'Music',
    href: '/dashboard/music',
    icon: Music,
    description: 'AI music generation (MusicGen)',
  },
  {
    name: 'Images',
    href: '/dashboard/images',
    icon: Image,
    description: 'AI image generation',
  },
  {
    name: 'Code',
    href: '/dashboard/code',
    icon: Code,
    description: 'Code execution',
  },
  {
    name: 'Documents',
    href: '/dashboard/documents',
    icon: FileText,
    description: 'Document chat & analysis',
  },
];

const bottomNavigation = [
  {
    name: 'API Keys',
    href: '/dashboard/api-keys',
    icon: Key,
  },
  {
    name: 'Analytics',
    href: '/dashboard/analytics',
    icon: BarChart3,
  },
  {
    name: 'Billing',
    href: '/dashboard/billing',
    icon: CreditCard,
  },
  {
    name: 'Settings',
    href: '/dashboard/settings',
    icon: Settings,
  },
];

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const pathname = usePathname();

  return (
    <>
      {/* Overlay for mobile */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          'fixed top-0 left-0 z-50 h-full w-64 border-r glass-card transition-transform duration-300 lg:translate-x-0',
          isOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        {/* Close button for mobile */}
        <div className="flex items-center justify-between p-4 border-b lg:hidden">
          <Logo size="sm" showText />
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Desktop sidebar header with logo */}
        <div className="hidden lg:flex items-center p-4 border-b">
          <Logo size="sm" showText />
        </div>

        <div className="flex flex-col h-full">
          {/* Main Navigation */}
          <nav className="flex-1 overflow-y-auto p-4 space-y-1">
            <div className="mb-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-3">
                Features
              </p>
            </div>

            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = pathname === item.href;

              return (
                <Link
                  key={item.name}
                  href={item.href}
                  onClick={onClose}
                  className={cn(
                    'flex items-start gap-3 px-3 py-2 rounded-lg transition-colors group',
                    isActive
                      ? 'bg-wolf-500 text-white'
                      : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                  )}
                >
                  <Icon
                    className={cn(
                      'w-5 h-5 mt-0.5 flex-shrink-0',
                      isActive ? 'text-white' : 'text-muted-foreground group-hover:text-foreground'
                    )}
                  />
                  <div className="flex-1 min-w-0">
                    <p className={cn('font-medium text-sm', isActive && 'text-white')}>
                      {item.name}
                    </p>
                    <p
                      className={cn(
                        'text-xs mt-0.5 truncate',
                        isActive
                          ? 'text-white/80'
                          : 'text-muted-foreground'
                      )}
                    >
                      {item.description}
                    </p>
                  </div>
                </Link>
              );
            })}
          </nav>

          {/* Bottom Navigation */}
          <div className="border-t p-4 space-y-1">
            <div className="mb-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider px-3">
                Account
              </p>
            </div>

            {bottomNavigation.map((item) => {
              const Icon = item.icon;
              const isActive = pathname === item.href;

              return (
                <Link
                  key={item.name}
                  href={item.href}
                  onClick={onClose}
                  className={cn(
                    'flex items-center gap-3 px-3 py-2 rounded-lg transition-colors',
                    isActive
                      ? 'bg-wolf-500 text-white'
                      : 'hover:bg-gray-100 dark:hover:bg-gray-800'
                  )}
                >
                  <Icon
                    className={cn(
                      'w-5 h-5',
                      isActive ? 'text-white' : 'text-muted-foreground'
                    )}
                  />
                  <span className={cn('text-sm font-medium', isActive && 'text-white')}>
                    {item.name}
                  </span>
                </Link>
              );
            })}
          </div>
        </div>
      </aside>
    </>
  );
}
