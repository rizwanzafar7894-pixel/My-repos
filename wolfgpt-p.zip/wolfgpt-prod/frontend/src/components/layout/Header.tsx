'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  Menu,
  User,
  Settings,
  LogOut,
  CreditCard,
  Key,
  BarChart3,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import Logo from '@/components/shared/Logo';
import {
  Dialog,
  DialogContent,
  DialogTrigger,
} from '@/components/ui/dialog';
import { useAuthStore } from '@/store/auth';
import { cn } from '@/lib/utils';

interface HeaderProps {
  onMenuClick: () => void;
}

export default function Header({ onMenuClick }: HeaderProps) {
  const pathname = usePathname();
  const { user, logOut } = useAuthStore();
  const [userMenuOpen, setUserMenuOpen] = React.useState(false);

  const handleLogout = async () => {
    try {
      await logOut();
      window.location.href = '/login';
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b glass-card">
      <div className="flex h-16 items-center px-4 gap-4">
        {/* Mobile Menu Button */}
        <Button
          variant="ghost"
          size="icon"
          className="lg:hidden"
          onClick={onMenuClick}
        >
          <Menu className="h-5 w-5" />
        </Button>

        {/* Logo */}
        <Logo href="/dashboard" size="sm" showText className="hidden sm:flex" />
        <Logo href="/dashboard" size="xs" showText={false} className="sm:hidden" />

        {/* Spacer */}
        <div className="flex-1" />

        {/* User Tier Badge */}
        {user && (
          <div className={cn(
            'px-3 py-1 rounded-full text-xs font-medium',
            user.tier === 'free' && 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300',
            user.tier === 'basic' && 'bg-blue-100 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400',
            user.tier === 'premium' && 'bg-purple-100 dark:bg-purple-900/20 text-purple-700 dark:text-purple-400',
            user.tier === 'pro' && 'bg-amber-100 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400'
          )}>
            {user.tier.toUpperCase()}
          </div>
        )}

        {/* User Menu */}
        <Dialog open={userMenuOpen} onOpenChange={setUserMenuOpen}>
          <DialogTrigger asChild>
            <Button variant="ghost" size="icon" className="rounded-full">
              <div className="w-8 h-8 rounded-full bg-wolf-500 flex items-center justify-center">
                {user?.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName}
                    className="w-full h-full rounded-full object-cover"
                  />
                ) : (
                  <User className="w-4 h-4 text-white" />
                )}
              </div>
            </Button>
          </DialogTrigger>

          <DialogContent className="sm:max-w-[300px] p-0">
            {user && (
              <div className="p-4 border-b">
                <p className="font-semibold">{user.displayName}</p>
                <p className="text-sm text-muted-foreground">{user.email}</p>
              </div>
            )}

            <div className="p-2">
              <Link href="/dashboard/settings" onClick={() => setUserMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start" size="sm">
                  <Settings className="mr-2 h-4 w-4" />
                  Settings
                </Button>
              </Link>

              <Link href="/dashboard/billing" onClick={() => setUserMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start" size="sm">
                  <CreditCard className="mr-2 h-4 w-4" />
                  Billing
                </Button>
              </Link>

              <Link href="/dashboard/api-keys" onClick={() => setUserMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start" size="sm">
                  <Key className="mr-2 h-4 w-4" />
                  API Keys
                </Button>
              </Link>

              <Link href="/dashboard/analytics" onClick={() => setUserMenuOpen(false)}>
                <Button variant="ghost" className="w-full justify-start" size="sm">
                  <BarChart3 className="mr-2 h-4 w-4" />
                  Analytics
                </Button>
              </Link>

              <div className="my-2 border-t" />

              <Button
                variant="ghost"
                className="w-full justify-start text-destructive hover:text-destructive"
                size="sm"
                onClick={handleLogout}
              >
                <LogOut className="mr-2 h-4 w-4" />
                Log Out
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </header>
  );
}
