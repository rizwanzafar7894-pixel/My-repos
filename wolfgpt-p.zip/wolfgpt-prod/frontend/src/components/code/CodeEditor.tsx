'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Play, Download, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/lib/hooks/use-toast';
import { CodeLanguage } from '@/types';
import { cn } from '@/lib/utils';

interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  language: CodeLanguage;
  onLanguageChange: (language: CodeLanguage) => void;
  onExecute: () => void;
  isExecuting?: boolean;
  readOnly?: boolean;
}

const LANGUAGES: { value: CodeLanguage; label: string }[] = [
  { value: 'python', label: 'Python' },
  { value: 'javascript', label: 'JavaScript' },
  { value: 'typescript', label: 'TypeScript' },
  { value: 'bash', label: 'Bash' },
  { value: 'go', label: 'Go' },
  { value: 'rust', label: 'Rust' },
];

const CODE_TEMPLATES: Record<CodeLanguage, string> = {
  python: `# Python code
def hello_world():
    print("Hello from WolfGPT!")
    
hello_world()`,
  javascript: `// JavaScript code
function helloWorld() {
  console.log("Hello from WolfGPT!");
}

helloWorld();`,
  typescript: `// TypeScript code
function helloWorld(): void {
  console.log("Hello from WolfGPT!");
}

helloWorld();`,
  bash: `#!/bin/bash
# Bash script
echo "Hello from WolfGPT!"`,
  go: `package main

import "fmt"

func main() {
    fmt.Println("Hello from WolfGPT!")
}`,
  rust: `fn main() {
    println!("Hello from WolfGPT!");
}`,
};

export default function CodeEditor({
  value,
  onChange,
  language,
  onLanguageChange,
  onExecute,
  isExecuting = false,
  readOnly = false,
}: CodeEditorProps) {
  const [copied, setCopied] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    // Auto-resize textarea
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [value]);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      toast({
        variant: 'success',
        title: 'Copied!',
        description: 'Code copied to clipboard',
      });
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Failed to copy code',
      });
    }
  };

  const handleDownload = () => {
    const extensions: Record<CodeLanguage, string> = {
      python: 'py',
      javascript: 'js',
      typescript: 'ts',
      bash: 'sh',
      go: 'go',
      rust: 'rs',
    };

    const blob = new Blob([value], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `code.${extensions[language]}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    toast({
      variant: 'success',
      title: 'Downloaded!',
      description: 'Code saved to your device',
    });
  };

  const handleLoadTemplate = () => {
    onChange(CODE_TEMPLATES[language]);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // Tab key handling
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = e.currentTarget.selectionStart;
      const end = e.currentTarget.selectionEnd;
      const newValue = value.substring(0, start) + '  ' + value.substring(end);
      onChange(newValue);
      
      // Set cursor position
      setTimeout(() => {
        if (textareaRef.current) {
          textareaRef.current.selectionStart = start + 2;
          textareaRef.current.selectionEnd = start + 2;
        }
      }, 0);
    }

    // Ctrl+Enter to execute
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      onExecute();
    }
  };

  return (
    <div className="flex flex-col h-full border rounded-lg glass-card overflow-hidden">
      {/* Toolbar */}
      <div className="flex items-center justify-between p-2 border-b bg-gray-50 dark:bg-gray-900/50">
        <div className="flex items-center gap-2">
          <Select value={language} onValueChange={(val) => onLanguageChange(val as CodeLanguage)}>
            <SelectTrigger className="w-[150px] h-8">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {LANGUAGES.map((lang) => (
                <SelectItem key={lang.value} value={lang.value}>
                  {lang.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Button
            variant="ghost"
            size="sm"
            onClick={handleLoadTemplate}
            disabled={readOnly}
          >
            Load Template
          </Button>
        </div>

        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={handleCopy}
          >
            {copied ? (
              <Check className="h-4 w-4 text-green-500" />
            ) : (
              <Copy className="h-4 w-4" />
            )}
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8"
            onClick={handleDownload}
          >
            <Download className="h-4 w-4" />
          </Button>

          <div className="w-px h-6 bg-border mx-1" />

          <Button
            variant="wolf"
            size="sm"
            onClick={onExecute}
            disabled={isExecuting || !value.trim()}
            loading={isExecuting}
          >
            <Play className="h-4 w-4 mr-1" />
            Run
          </Button>
        </div>
      </div>

      {/* Code Area */}
      <div className="flex-1 relative overflow-hidden">
        {/* Line Numbers */}
        <div className="absolute left-0 top-0 bottom-0 w-12 bg-gray-100 dark:bg-gray-900 border-r flex flex-col text-xs text-muted-foreground font-mono pt-4 pr-2 text-right select-none">
          {value.split('\n').map((_, i) => (
            <div key={i} className="leading-6">
              {i + 1}
            </div>
          ))}
        </div>

        {/* Editor */}
        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={handleKeyDown}
          className={cn(
            'w-full h-full pl-14 pr-4 py-4 font-mono text-sm leading-6 resize-none',
            'bg-transparent focus:outline-none',
            'custom-scrollbar',
            readOnly && 'cursor-not-allowed opacity-60'
          )}
          placeholder={`Write ${language} code here...\n\nTip: Press Tab for indentation\nPress Ctrl+Enter to run`}
          spellCheck={false}
          readOnly={readOnly}
        />
      </div>

      {/* Footer */}
      <div className="p-2 border-t bg-gray-50 dark:bg-gray-900/50 text-xs text-muted-foreground">
        <div className="flex items-center justify-between">
          <span>
            Lines: {value.split('\n').length} • Characters: {value.length}
          </span>
          <span className="hidden sm:inline">
            Press Ctrl+Enter to run code
          </span>
        </div>
      </div>
    </div>
  );
}
