'use client';

import React from 'react';
import { CheckCircle, XCircle, Terminal } from 'lucide-react';
import { CodeExecution } from '@/types';
import { cn } from '@/lib/utils';

interface OutputDisplayProps {
  execution: CodeExecution;
}

export default function OutputDisplay({ execution }: OutputDisplayProps) {
  const hasError = !!execution.error;

  return (
    <div className="space-y-4">
      {/* Status */}
      <div className="flex items-center gap-2">
        {hasError ? (
          <>
            <XCircle className="w-5 h-5 text-red-500" />
            <span className="font-medium text-red-500">Execution Failed</span>
          </>
        ) : (
          <>
            <CheckCircle className="w-5 h-5 text-green-500" />
            <span className="font-medium text-green-500">Execution Successful</span>
          </>
        )}
        <span className="text-sm text-muted-foreground ml-auto">
          {execution.executionTime}ms
        </span>
      </div>

      {/* Output */}
      {execution.output && (
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm font-medium">
            <Terminal className="w-4 h-4" />
            Output
          </div>
          <pre
            className={cn(
              'p-4 rounded-lg font-mono text-sm overflow-x-auto custom-scrollbar',
              'bg-gray-900 text-gray-100 dark:bg-gray-950'
            )}
          >
            {execution.output}
          </pre>
        </div>
      )}

      {/* Error */}
      {execution.error && (
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm font-medium text-red-500">
            <XCircle className="w-4 h-4" />
            Error
          </div>
          <pre
            className={cn(
              'p-4 rounded-lg font-mono text-sm overflow-x-auto custom-scrollbar',
              'bg-red-50 dark:bg-red-900/20 text-red-900 dark:text-red-200 border border-red-200 dark:border-red-800'
            )}
          >
            {execution.error}
          </pre>
        </div>
      )}

      {/* Metadata */}
      <div className="flex flex-wrap gap-4 text-xs text-muted-foreground pt-2 border-t">
        <div>
          <span className="font-medium">Language:</span>{' '}
          <span className="capitalize">{execution.language}</span>
        </div>
        <div>
          <span className="font-medium">Execution Time:</span>{' '}
          {execution.executionTime}ms
        </div>
        <div>
          <span className="font-medium">Executed:</span>{' '}
          {new Date(execution.createdAt).toLocaleString()}
        </div>
      </div>
    </div>
  );
}
