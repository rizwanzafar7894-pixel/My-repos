'use client';

import React, { useState } from 'react';
import { Play, Terminal, AlertCircle, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/lib/hooks/use-toast';
import { useAuthStore } from '@/store/auth';
import { apiClient } from '@/lib/api';
import { CodeLanguage, CodeExecution } from '@/types';
import CodeEditor from './CodeEditor';
import OutputDisplay from './OutputDisplay';
import LoadingSpinner from '@/components/shared/LoadingSpinner';
import { TIER_LIMITS } from '@/constants';

export default function CodeExecutor() {
  const [code, setCode] = useState('');
  const [language, setLanguage] = useState<CodeLanguage>('python');
  const [isExecuting, setIsExecuting] = useState(false);
  const [execution, setExecution] = useState<CodeExecution | null>(null);
  const [executionHistory, setExecutionHistory] = useState<CodeExecution[]>([]);

  const { user } = useAuthStore();
  const { toast } = useToast();

  const userLimits = user ? TIER_LIMITS[user.tier].code : TIER_LIMITS.free.code;
  const canExecute = user?.usage.code.used < userLimits.daily || userLimits.daily === -1;

  const handleExecute = async () => {
    if (!code.trim()) {
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Please write some code first',
      });
      return;
    }

    if (!canExecute) {
      toast({
        variant: 'destructive',
        title: 'Daily Limit Reached',
        description: 'Upgrade your plan for more code executions',
      });
      return;
    }

    setIsExecuting(true);
    setExecution(null);

    try {
      const result = await apiClient.executeCode(code, language);

      if (result.success && result.data) {
        setExecution(result.data);
        setExecutionHistory((prev) => [result.data, ...prev].slice(0, 10));

        if (result.data.error) {
          toast({
            variant: 'destructive',
            title: 'Execution Error',
            description: 'Your code produced an error',
          });
        } else {
          toast({
            variant: 'success',
            title: 'Success!',
            description: `Executed in ${result.data.executionTime}ms`,
          });
        }
      }
    } catch (error: any) {
      console.error('Code execution error:', error);
      toast({
        variant: 'destructive',
        title: 'Execution Failed',
        description: error.message || 'Failed to execute code',
      });
    } finally {
      setIsExecuting(false);
    }
  };

  const handleClear = () => {
    setCode('');
    setExecution(null);
  };

  const examples = {
    python: `# Calculate Fibonacci sequence
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

for i in range(10):
    print(f"F({i}) = {fibonacci(i)}")`,
    javascript: `// Calculate factorial
function factorial(n) {
  if (n <= 1) return 1;
  return n * factorial(n - 1);
}

for (let i = 1; i <= 10; i++) {
  console.log(\`\${i}! = \${factorial(i)}\`);
}`,
    typescript: `// Sort array of numbers
const numbers: number[] = [64, 34, 25, 12, 22, 11, 90];

function bubbleSort(arr: number[]): number[] {
  const n = arr.length;
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n - i - 1; j++) {
      if (arr[j] > arr[j + 1]) {
        [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
      }
    }
  }
  return arr;
}

console.log("Original:", numbers);
console.log("Sorted:", bubbleSort([...numbers]));`,
    bash: `#!/bin/bash
# System information
echo "System Information:"
echo "=================="
echo "Hostname: $(hostname)"
echo "Date: $(date)"
echo "Uptime: $(uptime -p)"
echo "Current Directory: $(pwd)"
ls -lh`,
    go: `package main

import "fmt"

func isPrime(n int) bool {
    if n <= 1 {
        return false
    }
    for i := 2; i*i <= n; i++ {
        if n%i == 0 {
            return false
        }
    }
    return true
}

func main() {
    fmt.Println("Prime numbers up to 50:")
    for i := 2; i <= 50; i++ {
        if isPrime(i) {
            fmt.Printf("%d ", i)
        }
    }
    fmt.Println()
}`,
    rust: `fn main() {
    // Vector operations
    let mut numbers = vec![1, 2, 3, 4, 5];
    println!("Original: {:?}", numbers);
    
    numbers.push(6);
    println!("After push: {:?}", numbers);
    
    let sum: i32 = numbers.iter().sum();
    println!("Sum: {}", sum);
    
    let doubled: Vec<i32> = numbers.iter().map(|x| x * 2).collect();
    println!("Doubled: {:?}", doubled);
}`,
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b glass-card">
        <div className="flex items-center gap-2">
          <Terminal className="w-5 h-5 text-wolf-500" />
          <h2 className="text-lg font-semibold">Code Executor</h2>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">
            {user?.usage.code.used || 0} / {userLimits.daily === -1 ? '∞' : userLimits.daily} today
          </span>

          {code.trim() && (
            <Button variant="outline" size="sm" onClick={handleClear}>
              Clear
            </Button>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Editor */}
            <Card className="glass-card lg:col-span-2">
              <CardHeader>
                <CardTitle>Code Editor</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[400px]">
                  <CodeEditor
                    value={code}
                    onChange={setCode}
                    language={language}
                    onLanguageChange={setLanguage}
                    onExecute={handleExecute}
                    isExecuting={isExecuting}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Output */}
            {(execution || isExecuting) && (
              <Card className="glass-card lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Terminal className="w-5 h-5" />
                    Output
                    {execution && (
                      <span className="text-sm text-muted-foreground font-normal">
                        ({execution.executionTime}ms)
                      </span>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  {isExecuting ? (
                    <LoadingSpinner text="Executing your code..." />
                  ) : execution ? (
                    <OutputDisplay execution={execution} />
                  ) : null}
                </CardContent>
              </Card>
            )}

            {/* Examples */}
            {!execution && !isExecuting && (
              <Card className="glass-card lg:col-span-2">
                <CardHeader>
                  <CardTitle>Example Code</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground mb-4">
                      Load an example to get started:
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                      {Object.entries(examples).map(([lang, exampleCode]) => (
                        <button
                          key={lang}
                          onClick={() => {
                            setLanguage(lang as CodeLanguage);
                            setCode(exampleCode);
                          }}
                          className="p-4 text-left rounded-lg border hover:border-wolf-500 hover:bg-wolf-50 dark:hover:bg-wolf-900/10 transition-colors"
                        >
                          <p className="font-medium capitalize">{lang}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            Click to load example
                          </p>
                        </button>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Info */}
            <Card className="glass-card lg:col-span-2">
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div className="flex items-start gap-3">
                    <Terminal className="w-5 h-5 text-wolf-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">Safe Execution</p>
                      <p className="text-muted-foreground">
                        Code runs in isolated sandbox environment
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-wolf-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">Time Limit</p>
                      <p className="text-muted-foreground">
                        {userLimits.timeout} seconds max execution time
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-wolf-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-medium">Supported Languages</p>
                      <p className="text-muted-foreground">
                        {userLimits.languages.join(', ')}
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
