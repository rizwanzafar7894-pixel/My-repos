'use client';

import React from 'react';
import { Check, ChevronDown, Crown, Zap, Rocket } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { MODELS, TIER_LIMITS } from '@/constants';
import { UserTier, AIModel } from '@/types';
import { cn } from '@/lib/utils';

interface ModelSelectorProps {
  value: AIModel;
  onChange: (model: AIModel) => void;
  userTier: UserTier;
}

const tierIcons = {
  free: Zap,
  basic: Zap,
  premium: Crown,
  pro: Rocket,
};

const tierColors = {
  free: 'text-gray-500',
  basic: 'text-blue-500',
  premium: 'text-purple-500',
  pro: 'text-amber-500',
};

export default function ModelSelector({
  value,
  onChange,
  userTier,
}: ModelSelectorProps) {
  const [open, setOpen] = React.useState(false);
  
  const availableModels = TIER_LIMITS[userTier].chat.model;
  const currentModel = MODELS.chat[value as keyof typeof MODELS.chat];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2">
          <span className="hidden sm:inline">{currentModel?.name || value}</span>
          <span className="sm:hidden">Model</span>
          <ChevronDown className="h-4 w-4" />
        </Button>
      </DialogTrigger>

      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Select AI Model</DialogTitle>
          <DialogDescription>
            Choose the AI model that best fits your needs. Different models offer varying levels of capability and speed.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          {Object.entries(MODELS.chat).map(([modelId, model]) => {
            const isAvailable = availableModels.includes(modelId as AIModel);
            const isSelected = value === modelId;
            const requiredTier = model.tier[0] as UserTier;
            const TierIcon = tierIcons[requiredTier];

            return (
              <button
                key={modelId}
                onClick={() => {
                  if (isAvailable) {
                    onChange(modelId as AIModel);
                    setOpen(false);
                  }
                }}
                disabled={!isAvailable}
                className={cn(
                  'w-full p-4 rounded-lg border-2 text-left transition-all',
                  isSelected
                    ? 'border-wolf-500 bg-wolf-50 dark:bg-wolf-900/20'
                    : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600',
                  !isAvailable && 'opacity-50 cursor-not-allowed'
                )}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold">{model.name}</h3>
                      <TierIcon className={cn('w-4 h-4', tierColors[requiredTier])} />
                      {!isAvailable && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400">
                          Upgrade Required
                        </span>
                      )}
                    </div>
                    
                    <p className="text-sm text-muted-foreground">
                      {model.description}
                    </p>
                    
                    <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground">
                      <span>Context: {(model.contextWindow / 1000).toFixed(0)}K tokens</span>
                      <span>•</span>
                      <span className="capitalize">Available on: {model.tier.join(', ')}</span>
                    </div>
                  </div>

                  {isSelected && (
                    <div className="flex-shrink-0 ml-4">
                      <div className="w-6 h-6 rounded-full bg-wolf-500 flex items-center justify-center">
                        <Check className="w-4 h-4 text-white" />
                      </div>
                    </div>
                  )}
                </div>

                {!isAvailable && (
                  <div className="mt-3 pt-3 border-t">
                    <p className="text-xs text-muted-foreground">
                      Upgrade to <span className="font-semibold capitalize">{requiredTier}</span> tier to access this model
                    </p>
                  </div>
                )}
              </button>
            );
          })}
        </div>

        <div className="mt-4 p-4 rounded-lg bg-gray-50 dark:bg-gray-900/50 border">
          <h4 className="font-semibold text-sm mb-2">Your Current Plan</h4>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm capitalize font-medium">{userTier} Tier</p>
              <p className="text-xs text-muted-foreground">
                Access to {availableModels.length} model{availableModels.length > 1 ? 's' : ''}
              </p>
            </div>
            {userTier !== 'pro' && (
              <Button size="sm" variant="wolf">
                Upgrade Plan
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
