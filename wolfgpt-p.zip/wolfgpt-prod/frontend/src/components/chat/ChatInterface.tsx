'use client';

import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Send, StopCircle, Sparkles, Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/lib/hooks/use-toast';
import { useAuthStore } from '@/store/auth';
import { apiClient } from '@/lib/api';
import { ChatMessage } from '@/types';
import MessageList from './MessageList';
import ModelSelector from './ModelSelector';
import { cn, generateId } from '@/lib/utils';

interface ChatInterfaceProps {
  conversationId?: string;
  initialMessages?: ChatMessage[];
  onSave?: (messages: ChatMessage[]) => void;
}

const MAX_INPUT_CHARS = 32_000;

export default function ChatInterface({
  conversationId,
  initialMessages = [],
  onSave,
}: ChatInterfaceProps) {
  const [messages, setMessages] = useState<ChatMessage[]>(initialMessages);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedModel, setSelectedModel] = useState('qwen-2.5-7b');
  const [streamingContent, setStreamingContent] = useState('');

  const textareaRef      = useRef<HTMLTextAreaElement>(null);
  const abortRef         = useRef<AbortController | null>(null);
  const streamBuffer     = useRef('');

  const { user } = useAuthStore();
  const { toast } = useToast();

  // Auto-resize textarea
  useEffect(() => {
    const el = textareaRef.current;
    if (el) {
      el.style.height = 'auto';
      el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
    }
  }, [input]);

  const handleSend = useCallback(async () => {
    const trimmed = input.trim();
    if (!trimmed || isLoading) return;
    if (trimmed.length > MAX_INPUT_CHARS) {
      toast({ variant: 'destructive', title: 'Message too long', description: `Max ${MAX_INPUT_CHARS.toLocaleString()} characters.` });
      return;
    }

    const userMsg: ChatMessage = {
      id:        generateId('msg'),
      role:      'user',
      content:   trimmed,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);
    setStreamingContent('');
    streamBuffer.current = '';

    // Create a fresh AbortController for this request
    abortRef.current = new AbortController();

    try {
      // chatStream now accepts an AbortSignal so the fetch can truly be cancelled
      await apiClient.chatStream(
        [...messages, userMsg],
        selectedModel,
        (chunk) => {
          streamBuffer.current += chunk;
          setStreamingContent(streamBuffer.current);
        },
        {},
        abortRef.current.signal,   // ← pass signal to fetch
      );

      const assistantMsg: ChatMessage = {
        id:        generateId('msg'),
        role:      'assistant',
        content:   streamBuffer.current,
        timestamp: new Date(),
        model:     selectedModel,
      };

      setMessages(prev => [...prev, assistantMsg]);
      setStreamingContent('');

      if (onSave) onSave([...messages, userMsg, assistantMsg]);
    } catch (err: any) {
      // Don't show error toast for user-initiated abort
      if (err.name !== 'AbortError' && err.message !== 'Aborted') {
        toast({
          variant:     'destructive',
          title:       'Error',
          description: err?.response?.data?.error?.message || err.message || 'Failed to send message',
        });
        // Restore user's message on error so they can retry
        setInput(trimmed);
        setMessages(prev => prev.filter(m => m.id !== userMsg.id));
      }
    } finally {
      setIsLoading(false);
      setStreamingContent('');
      streamBuffer.current = '';
      abortRef.current     = null;
    }
  }, [input, isLoading, messages, selectedModel, onSave, toast]);

  const handleStop = useCallback(() => {
    if (abortRef.current) {
      abortRef.current.abort();
    }
  }, []);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handleNewChat = () => {
    if (isLoading) handleStop();
    setMessages([]);
    setInput('');
    setStreamingContent('');
  };

  const charsRemaining = MAX_INPUT_CHARS - input.length;

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b glass-card">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-wolf-500" />
          <h2 className="text-lg font-semibold">Chat with WolfGPT</h2>
        </div>

        <div className="flex items-center gap-2">
          <ModelSelector
            value={selectedModel}
            onChange={setSelectedModel}
            userTier={user?.tier || 'free'}
          />

          {messages.length > 0 && (
            <Button variant="ghost" size="sm" onClick={handleNewChat} title="New chat">
              <Plus className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>

      {/* Messages */}
      <MessageList
        messages={messages}
        streamingContent={streamingContent}
        isLoading={isLoading}
      />

      {/* Input area */}
      <div className="p-4 border-t glass-card">
        <div className="relative flex items-end gap-2">
          <div className="flex-1 relative">
            <Textarea
              ref={textareaRef}
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a message… (Enter to send, Shift+Enter for new line)"
              className="min-h-[52px] max-h-[200px] resize-none pr-4 py-3"
              disabled={isLoading}
              maxLength={MAX_INPUT_CHARS}
              aria-label="Chat message input"
            />
            {input.length > MAX_INPUT_CHARS * 0.9 && (
              <span className={cn(
                'absolute bottom-2 right-2 text-xs',
                charsRemaining < 0 ? 'text-destructive' : 'text-muted-foreground'
              )}>
                {charsRemaining.toLocaleString()}
              </span>
            )}
          </div>

          {isLoading ? (
            <Button
              variant="destructive"
              size="icon"
              onClick={handleStop}
              className="shrink-0 h-[52px] w-[52px]"
              title="Stop generation"
            >
              <StopCircle className="w-5 h-5" />
            </Button>
          ) : (
            <Button
              variant="wolf"
              size="icon"
              onClick={handleSend}
              disabled={!input.trim() || charsRemaining < 0}
              className="shrink-0 h-[52px] w-[52px]"
              title="Send message"
            >
              <Send className="w-5 h-5" />
            </Button>
          )}
        </div>

        <p className="text-xs text-muted-foreground mt-2 text-center">
          WolfGPT can make mistakes. Verify important information.
        </p>
      </div>
    </div>
  );
}
