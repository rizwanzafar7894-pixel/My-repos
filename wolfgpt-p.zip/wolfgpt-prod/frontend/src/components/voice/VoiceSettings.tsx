'use client';

import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { VOICE_CONFIG, LANGUAGES } from '@/constants';
import { Button } from '@/components/ui/button';

interface VoiceSettingsProps {
  open: boolean;
  onClose: () => void;
  settings: {
    voice: string;
    speed: number;
    language: string;
  };
  onSettingsChange: (settings: any) => void;
}

export default function VoiceSettings({
  open,
  onClose,
  settings,
  onSettingsChange,
}: VoiceSettingsProps) {
  const handleVoiceChange = (voice: string) => {
    onSettingsChange({ ...settings, voice });
  };

  const handleSpeedChange = (speed: string) => {
    onSettingsChange({ ...settings, speed: parseFloat(speed) });
  };

  const handleLanguageChange = (language: string) => {
    onSettingsChange({ ...settings, language });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Voice Settings</DialogTitle>
          <DialogDescription>
            Customize your voice chat experience
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Voice Selection */}
          <div className="space-y-2">
            <Label htmlFor="voice">Voice</Label>
            <Select value={settings.voice} onValueChange={handleVoiceChange}>
              <SelectTrigger id="voice">
                <SelectValue placeholder="Select a voice" />
              </SelectTrigger>
              <SelectContent>
                {VOICE_CONFIG.tts.voices.map((voice) => (
                  <SelectItem key={voice.id} value={voice.id}>
                    {voice.name} • {voice.gender}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Choose the voice that will read responses aloud
            </p>
          </div>

          {/* Speed Selection */}
          <div className="space-y-2">
            <Label htmlFor="speed">Speech Speed</Label>
            <Select 
              value={settings.speed.toString()} 
              onValueChange={handleSpeedChange}
            >
              <SelectTrigger id="speed">
                <SelectValue placeholder="Select speed" />
              </SelectTrigger>
              <SelectContent>
                {VOICE_CONFIG.tts.speeds.map((speed) => (
                  <SelectItem key={speed} value={speed.toString()}>
                    {speed}x {speed === 1.0 && '(Normal)'}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Adjust how fast the voice speaks
            </p>
          </div>

          {/* Language Selection */}
          <div className="space-y-2">
            <Label htmlFor="language">Speech Recognition Language</Label>
            <Select value={settings.language} onValueChange={handleLanguageChange}>
              <SelectTrigger id="language">
                <SelectValue placeholder="Select language" />
              </SelectTrigger>
              <SelectContent>
                {LANGUAGES.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    {lang.native} ({lang.name})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Language for speech-to-text transcription
            </p>
          </div>

          {/* Test Voice Button */}
          <div className="pt-4 border-t">
            <Button
              variant="outline"
              className="w-full"
              onClick={async () => {
                const testText = "Hello! This is a test of the selected voice.";
                try {
                  // This would call the TTS API
                  console.log('Testing voice:', settings.voice);
                } catch (error) {
                  console.error('Voice test error:', error);
                }
              }}
            >
              Test Voice
            </Button>
          </div>
        </div>

        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button variant="wolf" onClick={onClose}>
            Save Settings
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
