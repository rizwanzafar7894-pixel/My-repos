'use client';

import React, { useState, useRef } from 'react';
import { Mic, MicOff, Volume2, VolumeX, Settings as SettingsIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/lib/hooks/use-toast';
import { useAuthStore } from '@/store/auth';
import { apiClient } from '@/lib/api';
import AudioRecorder from './AudioRecorder';
import AudioPlayer from './AudioPlayer';
import VoiceSettings from './VoiceSettings';
import LoadingSpinner from '@/components/shared/LoadingSpinner';
import { ChatMessage } from '@/types';

export default function VoiceInterface() {
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [response, setResponse] = useState('');
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [conversation, setConversation] = useState<ChatMessage[]>([]);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [voiceSettings, setVoiceSettings] = useState({
    voice: 'en-US-female-1',
    speed: 1.0,
    language: 'en',
  });

  const { user } = useAuthStore();
  const { toast } = useToast();

  const handleRecordingComplete = async (blob: Blob) => {
    setAudioBlob(blob);
    setIsProcessing(true);

    try {
      // Speech to Text
      const sttResult = await apiClient.speechToText(blob, voiceSettings.language);
      
      if (sttResult.success && sttResult.data) {
        const transcribedText = sttResult.data.text;
        setTranscript(transcribedText);

        // Add user message to conversation
        const userMessage: ChatMessage = {
          id: Date.now().toString(),
          role: 'user',
          content: transcribedText,
          timestamp: new Date(),
        };
        setConversation(prev => [...prev, userMessage]);

        // Get AI response
        const chatResult = await apiClient.chat(
          [...conversation, userMessage],
          'qwen-2.5-7b'
        );

        if (chatResult.success && chatResult.data) {
          const aiResponse = chatResult.data.message;
          setResponse(aiResponse);

          // Add assistant message to conversation
          const assistantMessage: ChatMessage = {
            id: (Date.now() + 1).toString(),
            role: 'assistant',
            content: aiResponse,
            timestamp: new Date(),
          };
          setConversation(prev => [...prev, assistantMessage]);

          // Convert response to speech
          const ttsBlob = await apiClient.textToSpeech(
            aiResponse,
            voiceSettings.voice,
            voiceSettings.speed
          );

          // Play audio
          const audio = new Audio(URL.createObjectURL(ttsBlob));
          setIsSpeaking(true);
          audio.play();
          audio.onended = () => {
            setIsSpeaking(false);
          };
        }
      }
    } catch (error: any) {
      console.error('Voice processing error:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: error.message || 'Failed to process voice',
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleClearConversation = () => {
    setConversation([]);
    setTranscript('');
    setResponse('');
    setAudioBlob(null);
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b glass-card">
        <div className="flex items-center gap-2">
          <Mic className="w-5 h-5 text-wolf-500" />
          <h2 className="text-lg font-semibold">Voice Chat</h2>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setSettingsOpen(true)}
          >
            <SettingsIcon className="w-4 h-4 mr-2" />
            Settings
          </Button>
          
          {conversation.length > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleClearConversation}
            >
              Clear
            </Button>
          )}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Recording Area */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {isRecording ? (
                  <>
                    <MicOff className="w-5 h-5 text-red-500 animate-pulse" />
                    Recording...
                  </>
                ) : (
                  <>
                    <Mic className="w-5 h-5" />
                    Press to Speak
                  </>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <AudioRecorder
                isRecording={isRecording}
                onRecordingChange={setIsRecording}
                onRecordingComplete={handleRecordingComplete}
                disabled={isProcessing || isSpeaking}
              />
              
              {isProcessing && (
                <div className="mt-4">
                  <LoadingSpinner text="Processing your voice..." />
                </div>
              )}
            </CardContent>
          </Card>

          {/* Conversation Display */}
          {conversation.length > 0 && (
            <Card className="glass-card">
              <CardHeader>
                <CardTitle>Conversation</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {conversation.map((message, index) => (
                  <div
                    key={message.id}
                    className={`p-4 rounded-lg ${
                      message.role === 'user'
                        ? 'bg-wolf-500 text-white ml-8'
                        : 'bg-gray-100 dark:bg-gray-800 mr-8'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="flex-1">
                        <p className="text-sm font-medium mb-1">
                          {message.role === 'user' ? 'You' : 'WolfGPT'}
                        </p>
                        <p className="whitespace-pre-wrap">{message.content}</p>
                      </div>
                      {message.role === 'assistant' && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="flex-shrink-0"
                          onClick={async () => {
                            const blob = await apiClient.textToSpeech(
                              message.content,
                              voiceSettings.voice,
                              voiceSettings.speed
                            );
                            const audio = new Audio(URL.createObjectURL(blob));
                            audio.play();
                          }}
                        >
                          <Volume2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
                
                {isSpeaking && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Volume2 className="w-4 h-4 animate-pulse" />
                    <span className="text-sm">Speaking...</span>
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Empty State */}
          {conversation.length === 0 && !isProcessing && (
            <div className="text-center py-12">
              <div className="w-16 h-16 rounded-full bg-wolf-100 dark:bg-wolf-900/20 flex items-center justify-center mx-auto mb-4">
                <Mic className="w-8 h-8 text-wolf-500" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Start Voice Conversation</h3>
              <p className="text-muted-foreground max-w-md mx-auto mb-6">
                Press the microphone button to start recording. Your voice will be transcribed and sent to WolfGPT.
              </p>
              <div className="flex flex-wrap gap-2 justify-center text-sm text-muted-foreground">
                <div className="px-3 py-1 rounded-full bg-gray-100 dark:bg-gray-800">
                  🎤 Unlimited Voice - Free Forever
                </div>
                <div className="px-3 py-1 rounded-full bg-gray-100 dark:bg-gray-800">
                  🌍 100+ Languages Supported
                </div>
                <div className="px-3 py-1 rounded-full bg-gray-100 dark:bg-gray-800">
                  ⚡ Real-time Processing
                </div>
              </div>
            </div>
          )}

          {/* Usage Info */}
          <div className="text-center text-xs text-muted-foreground">
            {user?.tier === 'free' ? (
              <p>Free tier • Unlimited voice conversations • 15 minutes transcription per day</p>
            ) : (
              <p>{user?.tier} tier • Unlimited voice with extended transcription limits</p>
            )}
          </div>
        </div>
      </div>

      {/* Settings Dialog */}
      <VoiceSettings
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={voiceSettings}
        onSettingsChange={setVoiceSettings}
      />
    </div>
  );
}
