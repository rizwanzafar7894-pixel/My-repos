'use client';

import React, { useState, useRef, useCallback, useEffect } from 'react';
import {
  Music, Mic, Play, Pause, Download, Trash2, Wand2, RefreshCw,
  Upload, X, Layers, ChevronDown, ChevronUp, Sparkles, Copy,
  Volume2, VolumeX, SkipBack, Clock, Info, AlertCircle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/lib/hooks/use-toast';
import { useAuthStore } from '@/store/auth';
import { apiClient } from '@/lib/api';
import { cn } from '@/lib/utils';

// ── Types ─────────────────────────────────────────────────────────────────────
type StudioMode = 'generate' | 'melody' | 'continuation';

interface Track {
  id: string;
  url: string;
  prompt: string;
  model: string;
  duration: number;
  mode: string;
  referenceAudioUrl?: string;
  seed?: number;
  generationTime?: number;
  createdAt?: any;
}

interface MusicSettings {
  model:       string;
  duration:    number;
  temperature: number;
  cfgCoef:     number;
  topK:        number;
  numSamples:  number;
  seed?:       number;
}

const DEFAULT_SETTINGS: MusicSettings = {
  model:       'musicgen-small',
  duration:    8,
  temperature: 1.0,
  cfgCoef:     3.0,
  topK:        250,
  numSamples:  1,
};

const MODELS = [
  { id: 'musicgen-small',         name: 'Small',          badge: 'Fast',    color: 'bg-emerald-100 text-emerald-700', params: '300M', vram: '2GB',  melody: false, stereo: false, desc: 'Fastest generation. Great for quick sketches.' },
  { id: 'musicgen-medium',        name: 'Medium',         badge: 'Balanced',color: 'bg-blue-100 text-blue-700',       params: '1.5B', vram: '4GB',  melody: false, stereo: false, desc: 'Best quality/speed balance. Recommended default.' },
  { id: 'musicgen-large',         name: 'Large',          badge: 'Best',    color: 'bg-purple-100 text-purple-700',   params: '3.3B', vram: '8GB',  melody: false, stereo: false, desc: 'Highest quality. Needs 8GB+ VRAM.' },
  { id: 'musicgen-melody',        name: 'Melody',         badge: 'Melody',  color: 'bg-pink-100 text-pink-700',       params: '1.5B', vram: '4GB',  melody: true,  stereo: false, desc: 'Conditioned on a reference melody or hum.' },
  { id: 'musicgen-stereo-small',  name: 'Stereo Small',   badge: 'Stereo',  color: 'bg-amber-100 text-amber-700',     params: '300M', vram: '2GB',  melody: false, stereo: true,  desc: 'Fast stereo output for spatial audio.' },
  { id: 'musicgen-stereo-medium', name: 'Stereo Medium',  badge: 'Stereo+', color: 'bg-orange-100 text-orange-700',   params: '1.5B', vram: '5GB',  melody: false, stereo: true,  desc: 'High-quality stereo output.' },
];

const EXAMPLE_PROMPTS: Record<StudioMode, string[]> = {
  generate: [
    'Lo-fi hip hop, chill study beats, jazz chords, soft piano, warm bass',
    'Epic orchestral film score, dramatic strings, rising tension, cinematic',
    'Upbeat electronic dance music, 128 BPM, synth lead, punchy kick drum',
    'Acoustic fingerpicking guitar, peaceful, folk, warm and intimate',
    'Dark ambient drone, atmospheric pads, mysterious, slow evolving texture',
    'Punjabi bhangra fusion with modern trap beats, dhol percussion, energetic',
    'Bollywood romantic melody, sitar, tabla, emotional, 80s style',
    'Heavy metal riff, distorted guitar, double bass drum, aggressive',
  ],
  melody: [
    'Orchestral arrangement of the hummed melody, full strings section',
    'Jazz piano interpretation, swing rhythm, upright bass accompaniment',
    'Electronic dance remix of the melody, 4/4 beat, synths',
    'Acoustic folk arrangement, guitar and violin',
  ],
  continuation: [
    'Continue with a guitar solo, bluesy feel, expressive bends',
    'Build into a full orchestral crescendo, add brass and percussion',
    'Add a hip hop verse section, trap hi-hats, 808 bass',
    'Transition into a breakdown, strip back to just bass and drums',
  ],
};

const MODE_META: Record<StudioMode, { label: string; icon: React.ReactNode; desc: string }> = {
  generate:     { label: 'Text to Music',     icon: <Wand2 className="w-4 h-4" />,      desc: 'Generate music from a text description' },
  melody:       { label: 'Melody to Music',   icon: <Mic className="w-4 h-4" />,         desc: 'Upload a hummed tune or reference audio' },
  continuation: { label: 'Continue Music',    icon: <RefreshCw className="w-4 h-4" />,   desc: 'Extend an existing audio clip' },
};

// ── Audio Player Component ────────────────────────────────────────────────────
function AudioTrackPlayer({ track, onDelete }: { track: Track; onDelete: () => void }) {
  const audioRef  = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying]   = useState(false);
  const [progress, setProgress] = useState(0);
  const [muted, setMuted]       = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const { toast } = useToast();

  const model = MODELS.find(m => m.id === track.model);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;
    const onTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
      setProgress((audio.currentTime / (audio.duration || 1)) * 100);
    };
    const onEnded = () => { setPlaying(false); setProgress(0); setCurrentTime(0); };
    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('ended', onEnded);
    return () => { audio.removeEventListener('timeupdate', onTimeUpdate); audio.removeEventListener('ended', onEnded); };
  }, []);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;
    if (playing) { audio.pause(); setPlaying(false); }
    else         { audio.play(); setPlaying(true); }
  };

  const handleSeek = (e: React.MouseEvent<HTMLDivElement>) => {
    const audio = audioRef.current;
    if (!audio) return;
    const rect  = e.currentTarget.getBoundingClientRect();
    const ratio = (e.clientX - rect.left) / rect.width;
    audio.currentTime = ratio * audio.duration;
  };

  const handleDownload = async () => {
    try {
      const res  = await fetch(track.url);
      const blob = await res.blob();
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href     = url;
      a.download = `wolfgpt-music-${track.id}.wav`;
      document.body.appendChild(a); a.click();
      URL.revokeObjectURL(url); document.body.removeChild(a);
      toast({ title: '✅ Downloaded!' });
    } catch { toast({ variant: 'destructive', title: 'Download failed' }); }
  };

  const formatTime = (s: number) => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;

  return (
    <div className="group relative bg-card rounded-xl border hover:border-primary/40 transition-all p-4 space-y-3">
      <audio ref={audioRef} src={track.url} preload="metadata" muted={muted} />

      {/* Mode / Model badges */}
      <div className="flex items-center gap-2 flex-wrap">
        {model && (
          <span className={cn('text-[10px] font-bold px-2 py-0.5 rounded-full', model.color)}>
            {model.name}
          </span>
        )}
        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-300 capitalize">
          {track.mode}
        </span>
        {model?.stereo && (
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">
            STEREO
          </span>
        )}
        {track.duration && (
          <span className="text-[10px] text-muted-foreground ml-auto flex items-center gap-1">
            <Clock className="w-3 h-3" />{track.duration.toFixed(1)}s
          </span>
        )}
      </div>

      {/* Prompt */}
      <p className="text-sm font-medium line-clamp-2 leading-relaxed">{track.prompt}</p>

      {/* Waveform / Progress Bar */}
      <div
        className="relative h-10 bg-muted rounded-lg overflow-hidden cursor-pointer"
        onClick={handleSeek}
      >
        {/* Fake waveform bars */}
        <div className="absolute inset-0 flex items-center justify-center gap-px px-2">
          {Array.from({ length: 60 }, (_, i) => (
            <div
              key={i}
              className="w-1 rounded-full bg-primary/30 transition-all"
              style={{ height: `${20 + Math.sin(i * 0.4 + track.id.charCodeAt(0)) * 15 + Math.random() * 10}%` }}
            />
          ))}
        </div>
        {/* Progress overlay */}
        <div
          className="absolute inset-y-0 left-0 bg-primary/20 transition-all"
          style={{ width: `${progress}%` }}
        />
        {/* Cursor */}
        <div
          className="absolute top-0 bottom-0 w-0.5 bg-primary transition-all"
          style={{ left: `${progress}%` }}
        />
      </div>

      {/* Controls */}
      <div className="flex items-center gap-2">
        <Button size="icon" variant="ghost" className="w-9 h-9 rounded-full" onClick={() => {
          if (audioRef.current) { audioRef.current.currentTime = 0; setProgress(0); setCurrentTime(0); }
        }}>
          <SkipBack className="w-4 h-4" />
        </Button>

        <Button
          size="icon"
          className="w-10 h-10 rounded-full bg-gradient-to-br from-violet-600 to-fuchsia-600 shadow-lg"
          onClick={togglePlay}
        >
          {playing ? <Pause className="w-4 h-4 text-white" /> : <Play className="w-4 h-4 text-white ml-0.5" />}
        </Button>

        <span className="text-xs font-mono text-muted-foreground">
          {formatTime(currentTime)} / {formatTime(track.duration || 0)}
        </span>

        <div className="ml-auto flex items-center gap-1">
          <Button size="icon" variant="ghost" className="w-8 h-8" onClick={() => setMuted(v => !v)}>
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </Button>
          <Button size="icon" variant="ghost" className="w-8 h-8" onClick={handleDownload}>
            <Download className="w-4 h-4" />
          </Button>
          <Button size="icon" variant="ghost" className="w-8 h-8 text-red-500 hover:text-red-600" onClick={onDelete}>
            <Trash2 className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Gen time */}
      {track.generationTime && (
        <p className="text-[10px] text-muted-foreground">Generated in {track.generationTime}s</p>
      )}
    </div>
  );
}

// ── Drop Zone ─────────────────────────────────────────────────────────────────
function AudioDropZone({ value, onChange, onClear, label }: {
  value: File | null; onChange: (f: File) => void; onClear: () => void; label: string;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [drag, setDrag] = useState(false);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault(); setDrag(false);
    const file = e.dataTransfer.files[0];
    if (file) onChange(file);
  }, [onChange]);

  return (
    <div className="space-y-2">
      <label className="text-sm font-medium">{label}</label>
      {value ? (
        <div className="flex items-center gap-3 p-3 rounded-xl border bg-muted/40">
          <div className="w-9 h-9 rounded-lg bg-violet-100 dark:bg-violet-900/40 flex items-center justify-center">
            <Music className="w-5 h-5 text-violet-600" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">{value.name}</p>
            <p className="text-xs text-muted-foreground">{(value.size / 1024).toFixed(0)} KB</p>
          </div>
          <Button size="icon" variant="ghost" className="w-8 h-8 text-red-500" onClick={onClear}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      ) : (
        <div
          className={cn(
            'border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all',
            drag ? 'border-primary bg-primary/5 scale-[1.01]' : 'border-border hover:border-primary/60 hover:bg-muted/40',
          )}
          onClick={() => inputRef.current?.click()}
          onDragOver={e => { e.preventDefault(); setDrag(true); }}
          onDragLeave={() => setDrag(false)}
          onDrop={handleDrop}
        >
          <Upload className="w-7 h-7 mx-auto mb-2 text-muted-foreground" />
          <p className="text-sm font-medium">Drop audio here or click to browse</p>
          <p className="text-xs text-muted-foreground mt-1">WAV, MP3, OGG, FLAC · max 25 MB</p>
        </div>
      )}
      <input ref={inputRef} type="file" accept="audio/*" className="hidden"
        onChange={e => { const f = e.target.files?.[0]; if (f) onChange(f); }} />
    </div>
  );
}

// ── Main Studio ───────────────────────────────────────────────────────────────
export default function MusicStudio() {
  const { user }  = useAuthStore();
  const { toast } = useToast();

  const [mode, setMode]           = useState<StudioMode>('generate');
  const [prompt, setPrompt]       = useState('');
  const [settings, setSettings]   = useState<MusicSettings>(DEFAULT_SETTINGS);
  const [advOpen, setAdvOpen]     = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [tracks, setTracks]       = useState<Track[]>([]);
  const [elapsed, setElapsed]     = useState(0);
  const [refFile, setRefFile]     = useState<File | null>(null);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const userTier   = user?.tier || 'free';
  const usedToday  = user?.usage?.music?.used || 0;
  // Default daily limit — in real app this comes from MUSIC_TIER_LIMITS
  const dailyLimit = userTier === 'pro' ? -1 : userTier === 'premium' ? 60 : userTier === 'basic' ? 20 : 5;
  const dailyLeft  = dailyLimit === -1 ? Infinity : dailyLimit - usedToday;

  const activeModels = userTier === 'pro'
    ? MODELS
    : userTier === 'premium'
      ? MODELS.filter(m => m.id !== 'musicgen-large')
      : userTier === 'basic'
        ? MODELS.filter(m => ['musicgen-small','musicgen-medium','musicgen-stereo-small'].includes(m.id))
        : MODELS.filter(m => m.id === 'musicgen-small');

  const fileToBase64 = (file: File): Promise<string> =>
    new Promise((res, rej) => {
      const r = new FileReader();
      r.onload  = () => res((r.result as string).split(',')[1]);
      r.onerror = rej;
      r.readAsDataURL(file);
    });

  const startTimer = () => {
    setElapsed(0);
    timerRef.current = setInterval(() => setElapsed(s => s + 1), 1000);
  };
  const stopTimer = () => { if (timerRef.current) clearInterval(timerRef.current); };

  const handleGenerate = async () => {
    if (!prompt.trim() && mode !== 'continuation') {
      toast({ variant: 'destructive', title: 'Prompt required', description: 'Describe the music you want to generate.' }); return;
    }
    if ((mode === 'melody' || mode === 'continuation') && !refFile) {
      toast({ variant: 'destructive', title: 'Audio required', description: 'Please upload a reference audio file.' }); return;
    }
    if (dailyLeft <= 0) {
      toast({ variant: 'destructive', title: 'Limit reached', description: 'Upgrade for more music generations.' }); return;
    }

    setIsGenerating(true);
    startTimer();

    try {
      let result: any;

      if (mode === 'generate') {
        result = await apiClient.post('/api/v1/music/generate', {
          prompt: prompt.trim(), ...settings,
        });
      } else if (mode === 'melody') {
        const b64 = await fileToBase64(refFile!);
        result = await apiClient.post('/api/v1/music/melody', {
          prompt: prompt.trim(), referenceAudio: b64, ...settings,
          model: settings.model.includes('melody') ? settings.model : 'musicgen-melody',
        });
      } else if (mode === 'continuation') {
        const b64 = await fileToBase64(refFile!);
        result = await apiClient.post('/api/v1/music/continuation', {
          prompt: prompt.trim(), audioPrompt: b64, ...settings,
        });
      }

      stopTimer();

      if (result?.success && result.data?.tracks?.length > 0) {
        setTracks(prev => [...result.data.tracks, ...prev]);
        toast({ title: `🎵 ${result.data.tracks.length} track${result.data.tracks.length > 1 ? 's' : ''} generated!`, description: `Ready in ${result.data.generationTime}s` });
      }
    } catch (err: any) {
      stopTimer();
      toast({ variant: 'destructive', title: 'Generation Failed', description: err.message || 'Something went wrong.' });
    } finally {
      setIsGenerating(false);
    }
  };

  const set = <K extends keyof MusicSettings>(k: K, v: MusicSettings[K]) =>
    setSettings(s => ({ ...s, [k]: v }));

  const currentModel = MODELS.find(m => m.id === settings.model);

  return (
    <div className="h-full flex flex-col bg-background">

      {/* ── Header ── */}
      <div className="flex items-center justify-between px-6 py-4 border-b bg-card/60 backdrop-blur sticky top-0 z-10">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-600 to-pink-600 flex items-center justify-center shadow-lg">
            <Music className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-bold tracking-tight">AI Music Studio</h2>
            <p className="text-xs text-muted-foreground">Powered by Meta MusicGen • 100% Free & Local</p>
          </div>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-muted text-sm">
          <div className={cn('w-2 h-2 rounded-full', dailyLeft > 0 ? 'bg-emerald-400' : 'bg-red-400')} />
          <span className="font-medium">{dailyLimit === -1 ? '∞' : `${usedToday}/${dailyLimit}`}</span>
          <span className="text-muted-foreground">today</span>
        </div>
      </div>

      {/* ── Main ── */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto p-6 space-y-6">

          {/* Mode Selector */}
          <div className="grid grid-cols-3 gap-3">
            {(Object.entries(MODE_META) as [StudioMode, typeof MODE_META[StudioMode]][]).map(([key, meta]) => (
              <button
                key={key}
                onClick={() => { setMode(key); setRefFile(null); }}
                className={cn(
                  'flex flex-col items-center gap-2 p-4 rounded-xl border text-sm font-medium transition-all',
                  mode === key
                    ? 'border-primary bg-primary/10 text-primary shadow-sm'
                    : 'border-border hover:border-primary/60 hover:bg-muted/50',
                )}
              >
                {meta.icon}
                <span>{meta.label}</span>
                <span className="text-xs font-normal text-muted-foreground text-center hidden sm:block">{meta.desc}</span>
              </button>
            ))}
          </div>

          {/* Model Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {MODELS.map(m => {
              const allowed  = activeModels.some(am => am.id === m.id);
              const modeOk   = mode !== 'melody' || m.melody || m.id === 'musicgen-melody';
              const active   = settings.model === m.id;
              return (
                <button
                  key={m.id}
                  disabled={!allowed}
                  onClick={() => allowed && set('model', m.id)}
                  className={cn(
                    'relative flex flex-col gap-1 p-3 rounded-xl border text-left text-xs transition-all',
                    active    ? 'border-primary bg-primary/8 ring-1 ring-primary/30'
                    : allowed ? 'border-border hover:border-primary/50 hover:bg-muted/60'
                    :           'border-border/40 opacity-40 cursor-not-allowed',
                  )}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-sm">{m.name}</span>
                    <span className={cn('text-[10px] px-1.5 py-0.5 rounded-full font-bold', m.color)}>{m.badge}</span>
                  </div>
                  <p className="text-muted-foreground leading-tight line-clamp-2">{m.desc}</p>
                  <div className="flex gap-2 mt-1 text-[10px] text-muted-foreground">
                    <span>{m.params}</span>
                    <span>·</span>
                    <span>{m.vram}</span>
                    {m.stereo && <><span>·</span><span className="text-emerald-600 font-bold">STEREO</span></>}
                  </div>
                  {!allowed && (
                    <span className="absolute top-1.5 right-1.5 text-[9px] bg-amber-400 text-black px-1 rounded-full font-bold">
                      UPGRADE
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          {/* Input Card */}
          <Card className="border shadow-sm">
            <CardContent className="pt-6 space-y-5">

              {/* Reference audio upload */}
              {(mode === 'melody' || mode === 'continuation') && (
                <AudioDropZone
                  label={mode === 'melody' ? '🎵 Reference Melody (hum/whistle/instrument)' : '🔊 Audio to Continue'}
                  value={refFile}
                  onChange={setRefFile}
                  onClear={() => setRefFile(null)}
                />
              )}

              {/* Prompt */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium">Prompt</label>
                  <span className="text-xs text-muted-foreground">{prompt.length}/500</span>
                </div>
                <Textarea
                  value={prompt}
                  onChange={e => setPrompt(e.target.value.slice(0, 500))}
                  placeholder={
                    mode === 'melody'
                      ? 'Describe the style: e.g. "orchestral arrangement, full strings, dramatic"'
                      : mode === 'continuation'
                        ? 'How to continue: e.g. "add a guitar solo, bluesy feel"'
                        : 'Describe the music: genre, mood, instruments, tempo, style...'
                  }
                  className="min-h-[90px] resize-none"
                  disabled={isGenerating}
                  onKeyDown={e => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) handleGenerate(); }}
                />
              </div>

              {/* Duration slider */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <label className="text-sm font-medium">Duration</label>
                  <span className="text-sm font-mono font-bold text-primary">{settings.duration}s</span>
                </div>
                <input
                  type="range" min={1} max={30} step={1} value={settings.duration}
                  onChange={e => set('duration', parseInt(e.target.value))}
                  className="w-full h-2 rounded-full accent-primary cursor-pointer"
                  disabled={isGenerating}
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>1s (quick)</span><span>~{Math.ceil(settings.duration * 3)}s generation time</span><span>30s (max)</span>
                </div>
                <div className="grid grid-cols-4 gap-1.5">
                  {[[5,'5s'],[8,'8s'],[15,'15s'],[30,'30s']].map(([v, l]) => (
                    <button key={v}
                      onClick={() => set('duration', v as number)}
                      className={cn('text-xs py-1 rounded-lg border transition-colors',
                        settings.duration === v ? 'border-primary bg-primary/10 text-primary font-semibold' : 'border-border hover:border-primary/60'
                      )}>{l}</button>
                  ))}
                </div>
              </div>

              {/* Number of variations */}
              {mode === 'generate' && (
                <div className="space-y-2">
                  <label className="text-sm font-medium">Variations</label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4].map(n => (
                      <button key={n} onClick={() => set('numSamples', n)}
                        className={cn('w-11 h-11 rounded-lg border text-sm font-bold transition-all',
                          settings.numSamples === n ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:border-primary/60'
                        )}>{n}</button>
                    ))}
                  </div>
                </div>
              )}

              {/* Advanced */}
              <div>
                <button className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors"
                  onClick={() => setAdvOpen(v => !v)}>
                  {advOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  Advanced Parameters
                </button>
                {advOpen && (
                  <div className="mt-4 grid grid-cols-2 gap-5 pt-4 border-t">
                    {[
                      { label: 'Temperature', key: 'temperature' as const, min: 0.1, max: 2.0, step: 0.05, tip: 'Higher = more creative/random' },
                      { label: 'CFG Strength', key: 'cfgCoef' as const, min: 0, max: 10, step: 0.5, tip: 'Higher = follows prompt more' },
                    ].map(({ label, key, min, max, step, tip }) => (
                      <div key={key} className="space-y-1.5">
                        <div className="flex justify-between">
                          <label className="text-sm font-medium">{label}</label>
                          <span className="text-sm font-mono font-bold text-primary">{settings[key]}</span>
                        </div>
                        <input type="range" min={min} max={max} step={step} value={settings[key] as number}
                          onChange={e => set(key, parseFloat(e.target.value))}
                          className="w-full h-2 rounded-full accent-primary cursor-pointer" />
                        <p className="text-xs text-muted-foreground">{tip}</p>
                      </div>
                    ))}
                    <div className="space-y-1.5">
                      <label className="text-sm font-medium">Seed (optional)</label>
                      <input type="number" value={settings.seed ?? ''} placeholder="Random"
                        onChange={e => set('seed', e.target.value ? parseInt(e.target.value) : undefined)}
                        className="w-full px-3 py-2 text-sm rounded-lg border bg-background" />
                      <p className="text-xs text-muted-foreground">Same seed = reproducible output</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Generate Button */}
              <Button
                onClick={handleGenerate}
                disabled={isGenerating || dailyLeft <= 0}
                className="w-full h-12 text-base font-semibold bg-gradient-to-r from-violet-600 to-pink-600 hover:from-violet-500 hover:to-pink-500 shadow-lg"
                size="lg"
              >
                {isGenerating ? (
                  <span className="flex items-center gap-2">
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    Composing… {elapsed}s
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <Sparkles className="w-5 h-5" />
                    Generate Music
                    <span className="text-xs opacity-70 ml-1">⌘↵</span>
                  </span>
                )}
              </Button>

              {dailyLeft <= 0 && (
                <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 dark:bg-amber-950/30 px-4 py-2 rounded-lg border border-amber-200 dark:border-amber-800">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  Daily limit reached. <a href="/dashboard/billing" className="underline font-medium">Upgrade →</a>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Example prompts */}
          {!isGenerating && tracks.length === 0 && (
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">🎼 Example Prompts</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {EXAMPLE_PROMPTS[mode].map((ex, i) => (
                    <button key={i} onClick={() => setPrompt(ex)}
                      className="group p-3 text-left text-sm rounded-xl border border-border hover:border-primary/60 hover:bg-primary/5 transition-all">
                      <span className="text-muted-foreground group-hover:text-foreground transition-colors line-clamp-2">{ex}</span>
                      <span className="flex items-center gap-1 mt-1.5 text-xs text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                        <Copy className="w-3 h-3" /> Use this
                      </span>
                    </button>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Loading state */}
          {isGenerating && (
            <Card className="border-primary/20 bg-primary/5">
              <CardContent className="py-10 text-center space-y-3">
                <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-violet-600 to-pink-600 flex items-center justify-center shadow-xl">
                  <Music className="w-8 h-8 text-white animate-pulse" />
                </div>
                <p className="font-semibold text-lg">Composing your track…</p>
                <p className="text-sm text-muted-foreground">
                  {elapsed < 5 ? 'Initialising MusicGen model…'
                  : elapsed < 20 ? 'Generating audio tokens…'
                  : elapsed < 40 ? 'Decoding waveform…'
                  : 'Almost there, finalising…'}
                </p>
                <div className="flex justify-center gap-1">
                  {[0,1,2,3,4].map(i => (
                    <div key={i} className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: `${i * 0.12}s` }} />
                  ))}
                </div>
                <p className="text-xs font-mono text-muted-foreground">{elapsed}s elapsed</p>
              </CardContent>
            </Card>
          )}

          {/* Track Library */}
          {tracks.length > 0 && !isGenerating && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold flex items-center gap-2">
                  🎵 Generated Tracks <Badge variant="secondary">{tracks.length}</Badge>
                </h3>
                <Button variant="ghost" size="sm" onClick={() => setTracks([])}>
                  Clear All
                </Button>
              </div>
              {tracks.map(track => (
                <AudioTrackPlayer
                  key={track.id}
                  track={track}
                  onDelete={() => setTracks(prev => prev.filter(t => t.id !== track.id))}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
