'use client';

import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { cn } from '@/lib/utils';

interface LogoProps {
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  href?: string;
  className?: string;
  textClassName?: string;
}

const SIZES = {
  xs:  { img: 20, text: 'text-sm',  gap: 'gap-1.5' },
  sm:  { img: 28, text: 'text-base',gap: 'gap-2'   },
  md:  { img: 36, text: 'text-lg',  gap: 'gap-2.5' },
  lg:  { img: 48, text: 'text-2xl', gap: 'gap-3'   },
  xl:  { img: 64, text: 'text-3xl', gap: 'gap-4'   },
};

export default function Logo({
  size = 'md',
  showText = true,
  href = '/',
  className,
  textClassName,
}: LogoProps) {
  const { img, text, gap } = SIZES[size];

  const content = (
    <span className={cn('flex items-center', gap, className)}>
      <Image
        src="/logo.png"
        alt="WolfGPT Logo"
        width={img}
        height={img}
        priority
        className="rounded-full object-contain drop-shadow-[0_0_8px_rgba(124,58,237,0.6)]"
        style={{ width: img, height: img }}
      />
      {showText && (
        <span className={cn(
          'font-bold tracking-tight bg-gradient-to-r from-violet-400 via-fuchsia-300 to-blue-400 bg-clip-text text-transparent',
          text,
          textClassName,
        )}>
          WolfGPT
        </span>
      )}
    </span>
  );

  return href ? (
    <Link href={href} className="inline-flex items-center hover:opacity-90 transition-opacity">
      {content}
    </Link>
  ) : content;
}
