import type { Metadata, Viewport } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Toaster } from '@/components/ui/toaster';
import AuthProvider from '@/components/shared/AuthProvider';

const inter = Inter({ subsets: ['latin'], display: 'swap' });

const BASE_URL = process.env.NEXT_PUBLIC_APP_URL || 'https://wolfgpt.com';

export const viewport: Viewport = {
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#7c3aed' },
    { media: '(prefers-color-scheme: dark)',  color: '#000000' },
  ],
  width: 'device-width',
  initialScale: 1,
};

export const metadata: Metadata = {
  metadataBase: new URL(BASE_URL),
  title: {
    default:  'WolfGPT — Enterprise AI Platform',
    template: '%s | WolfGPT',
  },
  description: 'Self-hosted AI platform with chat, image generation, music, voice, and code execution. No per-token costs.',
  keywords: ['AI platform', 'ChatGPT alternative', 'WolfGPT', 'MusicGen', 'FLUX', 'self-hosted AI'],
  authors: [{ name: 'WolfGPT' }],
  icons: {
    icon:     [
      { url: '/favicon-16x16.png', sizes: '16x16', type: 'image/png' },
      { url: '/favicon-32x32.png', sizes: '32x32', type: 'image/png' },
      { url: '/favicon.ico',       sizes: 'any' },
    ],
    apple:    [{ url: '/apple-touch-icon.png', sizes: '180x180' }],
    shortcut: '/favicon.ico',
  },
  manifest: '/site.webmanifest',
  openGraph: {
    type:        'website',
    locale:      'en_US',
    url:         BASE_URL,
    siteName:    'WolfGPT',
    title:       'WolfGPT — Enterprise AI Platform',
    description: 'Self-hosted AI with chat, images, music, and voice. Free & open source models.',
    images:      [{ url: '/og-image.jpg', width: 1200, height: 630 }],
  },
  twitter: {
    card:        'summary_large_image',
    title:       'WolfGPT — Enterprise AI Platform',
    description: 'AI chat, images, voice, music & code. $99/year.',
    images:      ['/og-image.jpg'],
  },
  robots: { index: true, follow: true },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preload" href="/logo-128.png" as="image" type="image/png" />
      </head>
      <body className={inter.className}>
        <AuthProvider>
          {children}
        </AuthProvider>
        <Toaster />
      </body>
    </html>
  );
}
