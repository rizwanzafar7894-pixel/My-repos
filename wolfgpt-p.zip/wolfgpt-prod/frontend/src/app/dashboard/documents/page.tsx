'use client';

import React, { useState } from 'react';
import { FileText } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import DocumentUploader from '@/components/documents/DocumentUploader';
import { Document } from '@/types';
import EmptyState from '@/components/shared/EmptyState';

export default function DocumentsPage() {
  const [documents, setDocuments] = useState<Document[]>([]);

  const handleUploadComplete = (doc: Document) => {
    setDocuments((prev) => [doc, ...prev]);
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b glass-card">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-wolf-500" />
          <h2 className="text-lg font-semibold">Documents</h2>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-y-auto p-6">
        <div className="max-w-4xl mx-auto space-y-6">
          {/* Uploader */}
          <Card className="glass-card">
            <CardHeader>
              <CardTitle>Upload Document</CardTitle>
            </CardHeader>
            <CardContent>
              <DocumentUploader onUploadComplete={handleUploadComplete} />
            </CardContent>
          </Card>

          {/* Documents List */}
          {documents.length > 0 ? (
            <Card className="glass-card">
              <CardHeader>
                <CardTitle>Your Documents ({documents.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {documents.map((doc) => (
                    <div
                      key={doc.id}
                      className="p-4 rounded-lg border hover:border-wolf-500 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{doc.name}</p>
                          <p className="text-sm text-muted-foreground">
                            {doc.type.toUpperCase()} • {(doc.size / 1024).toFixed(2)} KB
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ) : (
            <EmptyState
              icon={FileText}
              title="No documents yet"
              description="Upload a document to get started with AI-powered document chat"
            />
          )}
        </div>
      </div>
    </div>
  );
}
