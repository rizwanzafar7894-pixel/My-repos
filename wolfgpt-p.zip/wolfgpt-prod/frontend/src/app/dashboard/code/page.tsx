import CodeExecutor from '@/components/code/CodeExecutor';

export default function CodePage() {
  return <CodeExecutor />;
}
