'use client';

import React, { useEffect, useState } from 'react';
import { CreditCard, Check, Crown, Zap, Rocket, ExternalLink, Loader2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/lib/hooks/use-toast';
import { useAuthStore } from '@/store/auth';
import { apiClient } from '@/lib/api';
import { PRICING, TIER_LIMITS } from '@/constants';
import type { UserTier } from '@/types';

const TIER_ORDER: UserTier[] = ['free', 'basic', 'premium', 'pro'];

const tierConfig: Record<UserTier, { icon: React.ElementType; color: string; label: string; description: string }> = {
  free:    { icon: Zap,    color: 'text-gray-500',   label: 'Free',    description: 'Great for getting started' },
  basic:   { icon: Zap,    color: 'text-blue-500',   label: 'Basic',   description: 'For regular users' },
  premium: { icon: Crown,  color: 'text-purple-500', label: 'Premium', description: 'For power users' },
  pro:     { icon: Rocket, color: 'text-yellow-500', label: 'Pro',     description: 'For teams and businesses' },
};

const PLAN_FEATURES: Record<UserTier, string[]> = {
  free:    ['Unlimited AI Chat', 'Unlimited Voice', '5 Images/day', '50 Code Executions/day', 'Document Chat', 'Web Search'],
  basic:   ['Everything in Free', '25 Images/day', '200 Code Executions/day', '1,000 API Req/month', '5GB Storage', 'Email Support'],
  premium: ['Everything in Basic', '100 Images/day', '500 Code Executions/day', '50,000 API Req/month', '20GB Storage', 'Priority Queue'],
  pro:     ['Everything in Premium', 'Unlimited Images', 'Unlimited Code', 'Unlimited API', '100GB Storage', 'Dedicated Support'],
};

export default function BillingPage() {
  const { user } = useAuthStore();
  const { toast } = useToast();
  const currentTier = (user?.tier || 'free') as UserTier;
  const limits = TIER_LIMITS[currentTier];

  const [loadingTier, setLoadingTier] = useState<UserTier | null>(null);
  const [loadingPortal, setLoadingPortal] = useState(false);

  // Handle success/cancel redirect from Stripe
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('success') === 'true') {
      toast({ title: '🎉 Payment successful!', description: 'Your plan has been upgraded. Refreshing…' });
      // Clear query params
      window.history.replaceState({}, '', window.location.pathname);
    }
    if (params.get('cancelled') === 'true') {
      toast({ variant: 'destructive', title: 'Payment cancelled', description: 'Your plan was not changed.' });
      window.history.replaceState({}, '', window.location.pathname);
    }
  }, [toast]);

  const handleUpgrade = async (tier: UserTier) => {
    if (tier === 'free') return;
    setLoadingTier(tier);
    try {
      const res = await apiClient.stripeCheckout(tier, 'yearly') as any;
      const url = res?.data?.url || res?.url;
      if (url) {
        window.location.href = url;
      } else {
        throw new Error('No checkout URL returned');
      }
    } catch (err: any) {
      toast({
        variant: 'destructive',
        title: 'Checkout failed',
        description: err?.response?.data?.error?.message || err.message || 'Could not start checkout.',
      });
    } finally {
      setLoadingTier(null);
    }
  };

  const handleManageBilling = async () => {
    setLoadingPortal(true);
    try {
      const res = await apiClient.stripeBillingPortal() as any;
      const url = res?.data?.url || res?.url;
      if (url) window.open(url, '_blank');
    } catch (err: any) {
      toast({
        variant: 'destructive',
        title: 'Could not open billing portal',
        description: err?.response?.data?.error?.message || err.message,
      });
    } finally {
      setLoadingPortal(false);
    }
  };

  const usagePercent = (used: number | undefined, limit: number) => {
    if (limit === -1 || !limit) return 0;
    return Math.min(Math.round(((used || 0) / limit) * 100), 100);
  };

  return (
    <div className="h-full overflow-y-auto">
      <div className="p-6 border-b glass-card">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CreditCard className="w-5 h-5 text-wolf-500" />
            <h2 className="text-lg font-semibold">Billing &amp; Plans</h2>
          </div>
          {currentTier !== 'free' && (
            <Button variant="outline" size="sm" onClick={handleManageBilling} disabled={loadingPortal}>
              {loadingPortal ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <ExternalLink className="w-4 h-4 mr-2" />}
              Manage Billing
            </Button>
          )}
        </div>
      </div>

      <div className="p-6">
        <div className="max-w-6xl mx-auto space-y-8">

          {/* Current Plan + Usage */}
          <Card className="glass-card border-wolf-500">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {React.createElement(tierConfig[currentTier].icon, { className: `w-5 h-5 ${tierConfig[currentTier].color}` })}
                  <CardTitle className="capitalize">{currentTier} Plan</CardTitle>
                </div>
                <Badge variant="wolf">Current Plan</Badge>
              </div>
              <CardDescription>{tierConfig[currentTier].description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Images Today</span>
                    <span className="font-medium">
                      {user?.usage?.images?.used ?? 0} / {limits.images.daily === -1 ? '∞' : limits.images.daily}
                    </span>
                  </div>
                  <Progress value={usagePercent(user?.usage?.images?.used, limits.images.daily)} />
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Code Runs Today</span>
                    <span className="font-medium">
                      {user?.usage?.code?.used ?? 0} / {limits.code.daily === -1 ? '∞' : limits.code.daily}
                    </span>
                  </div>
                  <Progress value={usagePercent(user?.usage?.code?.used, limits.code.daily)} />
                </div>
                {limits.api.enabled && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>API Requests (month)</span>
                      <span className="font-medium">
                        {user?.usage?.api?.used ?? 0} / {limits.api.requestsPerMonth === -1 ? '∞' : limits.api.requestsPerMonth}
                      </span>
                    </div>
                    <Progress value={usagePercent(user?.usage?.api?.used, limits.api.requestsPerMonth)} />
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Upgrade Plans */}
          <div>
            <h3 className="text-lg font-semibold mb-4">Available Plans</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {TIER_ORDER.map((tier) => {
                const cfg   = tierConfig[tier];
                const Icon  = cfg.icon;
                const price = PRICING[tier].yearly;
                const isCurrent = tier === currentTier;
                const isDowngrade = TIER_ORDER.indexOf(tier) < TIER_ORDER.indexOf(currentTier);
                const isLoading = loadingTier === tier;

                return (
                  <Card key={tier} className={`glass-card flex flex-col ${isCurrent ? 'border-wolf-500 ring-1 ring-wolf-500' : ''}`}>
                    <CardHeader className="pb-2">
                      <div className="flex items-center gap-2">
                        <Icon className={`w-5 h-5 ${cfg.color}`} />
                        <CardTitle className="text-base">{cfg.label}</CardTitle>
                      </div>
                      <div className="mt-1">
                        {price === 0
                          ? <span className="text-2xl font-bold">Free</span>
                          : <span className="text-2xl font-bold">${price}<span className="text-sm font-normal text-muted-foreground">/yr</span></span>
                        }
                      </div>
                    </CardHeader>
                    <CardContent className="flex flex-col flex-1">
                      <ul className="space-y-1.5 text-sm flex-1">
                        {PLAN_FEATURES[tier].map((feature) => (
                          <li key={feature} className="flex items-start gap-2">
                            <Check className="w-3.5 h-3.5 mt-0.5 text-green-500 shrink-0" />
                            <span>{feature}</span>
                          </li>
                        ))}
                      </ul>
                      <div className="mt-4">
                        {isCurrent ? (
                          <Button variant="outline" className="w-full" disabled>Current Plan</Button>
                        ) : isDowngrade ? (
                          <Button variant="outline" className="w-full" disabled>Downgrade</Button>
                        ) : tier === 'free' ? (
                          <Button variant="outline" className="w-full" disabled>Free</Button>
                        ) : (
                          <Button
                            variant="wolf"
                            className="w-full"
                            onClick={() => handleUpgrade(tier)}
                            disabled={isLoading}
                          >
                            {isLoading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                            {isLoading ? 'Redirecting…' : `Upgrade to ${cfg.label}`}
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
