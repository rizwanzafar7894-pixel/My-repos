import ImageGenerator from '@/components/images/ImageGenerator';

export default function ImagesPage() {
  return <ImageGenerator />;
}
