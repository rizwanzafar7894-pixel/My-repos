import MusicStudio from '@/components/music/MusicStudio';

export const metadata = { title: 'Music Studio — WolfGPT' };

export default function MusicPage() {
  return <MusicStudio />;
}
