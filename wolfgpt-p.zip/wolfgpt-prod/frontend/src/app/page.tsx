'use client';

import React from 'react';
import Link from 'next/link';
import Logo from '@/components/shared/Logo';
import { 
  Check, 
  Sparkles, 
  Mic, 
  Image as ImageIcon, 
  Code, 
  Zap,
  Crown,
  Rocket,
  ArrowRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PRICING } from '@/constants';

const features = [
  {
    icon: Mic,
    title: 'Unlimited Free Voice',
    description: 'First AI platform with completely free, unlimited voice chat. No subscriptions needed.',
    badge: 'FREE FOREVER',
  },
  {
    icon: Sparkles,
    title: 'Smart AI Chat',
    description: 'Powered by Qwen 2.5 models. Get intelligent responses for any task.',
  },
  {
    icon: ImageIcon,
    title: 'AI Image Generation',
    description: 'Create stunning images with FLUX and Stable Diffusion XL.',
  },
  {
    icon: Code,
    title: 'Code Execution',
    description: 'Run Python, JavaScript, and more in secure sandboxed environments.',
  },
];

const pricingTiers = [
  {
    name: 'Free',
    price: 0,
    period: 'Forever',
    icon: Zap,
    color: 'text-gray-500',
    features: [
      'Unlimited AI Chat',
      'Unlimited Voice (FREE!)',
      '5 Images/day',
      '50 Code Executions/day',
      'Document Chat',
      'Web Search',
      'Translation',
    ],
    cta: 'Start Free',
    popular: false,
  },
  {
    name: 'Basic',
    price: PRICING.basic.yearly,
    period: 'year',
    icon: Zap,
    color: 'text-blue-500',
    features: [
      'Everything in Free',
      '25 Images/day',
      '200 Code Executions/day',
      '1,000 API Requests/month',
      '5GB Storage',
      '10 Projects',
      'Email Support',
    ],
    cta: 'Get Basic',
    popular: false,
  },
  {
    name: 'Premium',
    price: PRICING.premium.yearly,
    period: 'year',
    icon: Crown,
    color: 'text-purple-500',
    features: [
      'Everything in Basic',
      '100 Images/day',
      'Advanced AI Models',
      '50,000 API Requests/month',
      '20GB Storage',
      'Unlimited Projects',
      'Priority Support',
      'Video Transcription',
    ],
    cta: 'Get Premium',
    popular: true,
  },
  {
    name: 'Pro/Ultra',
    price: PRICING.pro.yearly,
    period: 'year',
    icon: Rocket,
    color: 'text-amber-500',
    features: [
      'Everything in Premium',
      'Unlimited Images',
      'Most Powerful AI Models',
      'Unlimited API Requests',
      '100GB Storage',
      'Team Collaboration',
      'Custom Branding',
      'Dedicated Support',
    ],
    cta: 'Get Pro',
    popular: false,
  },
];

export default function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b glass-card">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Logo size="sm" showText href="/" />
            </div>

            <nav className="hidden md:flex items-center gap-6">
              <Link href="#features" className="text-sm hover:text-wolf-500 transition-colors">
                Features
              </Link>
              <Link href="#pricing" className="text-sm hover:text-wolf-500 transition-colors">
                Pricing
              </Link>
              <Link href="#api" className="text-sm hover:text-wolf-500 transition-colors">
                API
              </Link>
            </nav>

            <div className="flex items-center gap-2">
              <Link href="/login">
                <Button variant="ghost" size="sm">
                  Login
                </Button>
              </Link>
              <Link href="/register">
                <Button variant="wolf" size="sm">
                  Get Started Free
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 animated-bg opacity-10" />
        <div className="container mx-auto px-4 relative">
          <div className="max-w-4xl mx-auto text-center">
            <Badge variant="wolf" className="mb-4">
              🎙️ Unlimited Free Voice - Forever!
            </Badge>
            
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-wolf-500 to-wolf-600 bg-clip-text text-transparent">
              The Most Affordable AI Platform
            </h1>
            
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Chat, generate images, execute code, and access our full API — all starting at just $99/year. 
              <span className="font-semibold text-foreground"> Voice chat is FREE forever!</span>
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/register">
                <Button size="lg" variant="wolf" className="gap-2">
                  Start Free Now
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </Link>
              <Link href="#pricing">
                <Button size="lg" variant="outline">
                  View Pricing
                </Button>
              </Link>
            </div>

            <p className="text-sm text-muted-foreground mt-6">
              No credit card required • Free tier forever • Cancel anytime
            </p>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-gray-50 dark:bg-gray-900/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Everything You Need in One Platform
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              From unlimited free voice to powerful API access, WolfGPT gives you more for less
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
            {features.map((feature, index) => (
              <Card key={index} className="glass-card hover:border-wolf-500 transition-colors">
                <CardHeader>
                  <div className="w-12 h-12 rounded-lg bg-wolf-100 dark:bg-wolf-900/20 flex items-center justify-center mb-4">
                    <feature.icon className="w-6 h-6 text-wolf-500" />
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                  {feature.badge && (
                    <Badge variant="success" className="w-fit">
                      {feature.badge}
                    </Badge>
                  )}
                </CardHeader>
                <CardContent>
                  <CardDescription>{feature.description}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Simple, Transparent Pricing
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Pay up to 90% less than competitors. Full API access from just $99/year.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
            {pricingTiers.map((tier, index) => {
              const Icon = tier.icon;
              return (
                <Card 
                  key={index} 
                  className={`glass-card relative ${
                    tier.popular ? 'border-wolf-500 shadow-lg scale-105' : ''
                  }`}
                >
                  {tier.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                      <Badge variant="wolf">Most Popular</Badge>
                    </div>
                  )}
                  
                  <CardHeader>
                    <div className="flex items-center gap-2 mb-2">
                      <Icon className={`w-5 h-5 ${tier.color}`} />
                      <CardTitle>{tier.name}</CardTitle>
                    </div>
                    <div className="flex items-baseline gap-1">
                      <span className="text-4xl font-bold">
                        ${tier.price}
                      </span>
                      <span className="text-muted-foreground">/{tier.period}</span>
                    </div>
                  </CardHeader>

                  <CardContent>
                    <ul className="space-y-3 mb-6">
                      {tier.features.map((feature, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm">
                          <Check className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>

                    <Link href="/register">
                      <Button 
                        className="w-full" 
                        variant={tier.popular ? 'wolf' : 'outline'}
                      >
                        {tier.cta}
                      </Button>
                    </Link>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <p className="text-center text-sm text-muted-foreground mt-8">
            All plans include unlimited AI chat and free voice. No hidden fees.
          </p>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-wolf-500 to-wolf-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of users who chose the most affordable AI platform
          </p>
          <Link href="/register">
            <Button size="lg" variant="secondary" className="gap-2">
              Start Free Now
              <ArrowRight className="w-5 h-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="#features">Features</Link></li>
                <li><Link href="#pricing">Pricing</Link></li>
                <li><Link href="#api">API</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/about">About</Link></li>
                <li><Link href="/contact">Contact</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Legal</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/privacy">Privacy</Link></li>
                <li><Link href="/terms">Terms</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Connect</h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="#">Twitter</Link></li>
                <li><Link href="#">Discord</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t pt-8 text-center text-sm text-muted-foreground">
            <p>&copy; 2026 WolfGPT. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
