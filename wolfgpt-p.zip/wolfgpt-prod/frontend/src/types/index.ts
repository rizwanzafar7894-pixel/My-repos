// ── User ──────────────────────────────────────────────────────────────────────
export type UserTier = 'free' | 'basic' | 'premium' | 'pro';

export interface User {
  uid:         string;
  email:       string;
  displayName: string;
  photoURL?:   string | null;
  tier:        UserTier;
  subscription?: Subscription | null;
  usage:       UsageStats;
  createdAt:   any;
  updatedAt?:  any;
}

export interface Subscription {
  status:    'active' | 'cancelled' | 'past_due' | 'paused' | 'none';
  provider?: 'stripe' | 'jazzcash' | 'easypaisa';
  planId?:   string;
  expiresAt?: any;
  updatedAt?: any;
}

// ── Usage ─────────────────────────────────────────────────────────────────────
export interface UsageStats {
  chat?:   { used: number };
  images?: { used: number };
  code?:   { used: number };
  voice?:  { sttUsed: number; ttsUsed: number };
  music?:  { used: number };
  api?:    { used: number };
}

// ── Chat ──────────────────────────────────────────────────────────────────────
export interface ChatMessage {
  id?:       string;
  role:      'user' | 'assistant' | 'system';
  content:   string;
  timestamp?: Date;
  model?:    string;
}

export interface ChatConversation {
  id:        string;
  userId:    string;
  title?:    string;
  messages:  ChatMessage[];
  model:     string;
  archived?: boolean;
  pinned?:   boolean;
  createdAt: any;
  updatedAt: any;
}

// ── Images ────────────────────────────────────────────────────────────────────
export interface ImageGeneration {
  id:               string;
  userId:           string;
  url:              string;
  prompt:           string;
  negativePrompt?:  string | null;
  model:            string;
  width:            number;
  height:           number;
  steps?:           number | null;
  strength?:        number | null;
  mode:             'txt2img' | 'img2img' | 'inpaint' | 'upscale' | 'variations';
  referenceImageUrl?: string | null;
  seed?:            number | null;
  createdAt:        any;
}

export interface ImageGenerationRequest {
  prompt:          string;
  negativePrompt?: string;
  model?:          string;
  width?:          number;
  height?:         number;
  steps?:          number;
  numImages?:      number;
  guidanceScale?:  number;
  seed?:           number;
  strength?:       number;
}

// ── Music ─────────────────────────────────────────────────────────────────────
export interface MusicTrack {
  id:               string;
  userId:           string;
  url:              string;
  prompt:           string;
  model:            string;
  duration:         number;
  sampleRate:       number;
  format:           string;
  mode:             'txt2music' | 'melody' | 'continuation';
  referenceAudioUrl?: string | null;
  seed?:            number | null;
  generationTime?:  number;
  createdAt:        any;
}

// ── Code ──────────────────────────────────────────────────────────────────────
export interface CodeExecution {
  id:            string;
  userId:        string;
  code:          string;
  language:      string;
  output:        string;
  error:         string | null;
  executionTime: number;
  exitCode:      number | null;
  createdAt:     any;
}

// ── Documents ─────────────────────────────────────────────────────────────────
export interface Document {
  id:        string;
  userId:    string;
  fileName:  string;
  fileType:  string;
  fileSize:  number;
  content?:  string | null;
  pageCount?: number | null;
  wordCount?: number | null;
  parsed:    boolean;
  createdAt: any;
}

// ── API ───────────────────────────────────────────────────────────────────────
export interface APIResponse<T = any> {
  success: boolean;
  data?:   T;
  error?:  {
    code:      string;
    message:   string;
    requestId?: string;
  };
}

export interface ApiKey {
  id:        string;
  userId:    string;
  name:      string;
  keyPrefix: string;
  usage:     number;
  active:    boolean;
  createdAt: any;
  lastUsed?: any;
}
