import * as Sentry from "@sentry/nextjs";

export function initSentry() {
  Sentry.init({
    dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
    environment: process.env.NODE_ENV,
    
    // Performance monitoring
    tracesSampleRate: process.env.NODE_ENV === 'production' ? 0.1 : 1.0,
    
    // Session replay
    replaysSessionSampleRate: 0.1,
    replaysOnErrorSampleRate: 1.0,
    
    integrations: [
      new Sentry.Replay({
        maskAllText: true,
        blockAllMedia: true,
      }),
    ],
    
    // Release tracking
    release: process.env.NEXT_PUBLIC_APP_VERSION,
    
    // Error filtering
    beforeSend(event, hint) {
      // Don't send network errors in development
      if (process.env.NODE_ENV === 'development' && 
          event.exception?.values?.[0]?.type === 'NetworkError') {
        return null;
      }
      
      // Filter out browser extension errors
      if (event.exception?.values?.[0]?.value?.includes('extension')) {
        return null;
      }
      
      return event;
    },
    
    // Ignore certain errors
    ignoreErrors: [
      'ResizeObserver loop limit exceeded',
      'Non-Error promise rejection',
      'cancelled',
    ],
    
    // Tag context
    initialScope: {
      tags: {
        'app': 'wolfgpt-frontend',
        'framework': 'next.js',
      },
    },
  });
}

// Capture user feedback
export function showReportDialog() {
  Sentry.showReportDialog();
}

// Track page views
export function trackPageView(url: string) {
  Sentry.addBreadcrumb({
    category: 'navigation',
    message: `Navigated to ${url}`,
    level: 'info',
  });
}

// Track user actions
export function trackUserAction(action: string, data?: any) {
  Sentry.addBreadcrumb({
    category: 'user',
    message: action,
    level: 'info',
    data,
  });
}

// Set user context
export function identifyUser(user: { id: string; email?: string; tier?: string }) {
  Sentry.setUser({
    id: user.id,
    email: user.email,
    tier: user.tier,
  });
}

// Clear user context
export function clearUser() {
  Sentry.setUser(null);
}
