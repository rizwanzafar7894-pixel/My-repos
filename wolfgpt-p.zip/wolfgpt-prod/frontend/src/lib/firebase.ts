import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
import {
  getAuth, Auth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  sendPasswordResetEmail,
  GoogleAuthProvider,
  signInWithPopup,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  getFirestore, Firestore,
  doc, getDoc, setDoc, updateDoc, deleteDoc,
  collection, query, where, orderBy, limit,
  getDocs, onSnapshot, serverTimestamp,
} from 'firebase/firestore';
import { getStorage, Storage } from 'firebase/storage';
import { FIREBASE_CONFIG } from '@/constants';

// ── Initialize ────────────────────────────────────────────────────────────────
let app:     FirebaseApp;
let auth:    Auth;
let db:      Firestore;
let storage: Storage;

const apps = getApps();
if (!apps.length) {
  app     = initializeApp(FIREBASE_CONFIG);
} else {
  app     = apps[0];
}
auth    = getAuth(app);
db      = getFirestore(app);
storage = getStorage(app);

export { app, auth, db, storage };

// ── Auth functions ────────────────────────────────────────────────────────────

export const signIn = async (email: string, password: string) => {
  try {
    const cred = await signInWithEmailAndPassword(auth, email, password);
    return { user: cred.user, error: null };
  } catch (e: any) {
    return { user: null, error: e.message };
  }
};

export const signUp = async (email: string, password: string, displayName: string) => {
  try {
    const cred = await createUserWithEmailAndPassword(auth, email, password);
    return { user: cred.user, error: null };
  } catch (e: any) {
    return { user: null, error: e.message };
  }
};

export const signInWithGoogle = async () => {
  try {
    const provider = new GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    const cred = await signInWithPopup(auth, provider);
    return { user: cred.user, error: null };
  } catch (e: any) {
    return { user: null, error: e.message };
  }
};

export const logOut = async () => {
  try {
    await signOut(auth);
    return { error: null };
  } catch (e: any) {
    return { error: e.message };
  }
};

export const resetPassword = async (email: string) => {
  try {
    await sendPasswordResetEmail(auth, email);
    return { error: null };
  } catch (e: any) {
    return { error: e.message };
  }
};

export const onAuthChange = (callback: (user: FirebaseUser | null) => void) =>
  onAuthStateChanged(auth, callback);

// ── Firestore helpers ─────────────────────────────────────────────────────────

export const getUserData = async (uid: string) => {
  try {
    const snap = await getDoc(doc(db, 'users', uid));
    return snap.exists() ? { data: snap.data(), error: null } : { data: null, error: 'User not found' };
  } catch (e: any) {
    return { data: null, error: e.message };
  }
};

export const updateUserData = async (uid: string, data: Record<string, any>) => {
  try {
    await updateDoc(doc(db, 'users', uid), { ...data, updatedAt: serverTimestamp() });
    return { error: null };
  } catch (e: any) {
    return { error: e.message };
  }
};

export const subscribeToUserData = (uid: string, callback: (data: any) => void) =>
  onSnapshot(doc(db, 'users', uid), snap => {
    if (snap.exists()) callback({ id: snap.id, ...snap.data() });
  });

export const getConversations = async (uid: string, limitCount = 50) => {
  try {
    const q    = query(collection(db, 'conversations'), where('userId','==',uid), orderBy('updatedAt','desc'), limit(limitCount));
    const snap = await getDocs(q);
    return { data: snap.docs.map(d => ({ id: d.id, ...d.data() })), error: null };
  } catch (e: any) {
    return { data: [], error: e.message };
  }
};

export const subscribeToConversations = (uid: string, callback: (data: any[]) => void) => {
  const q = query(collection(db, 'conversations'), where('userId','==',uid), orderBy('updatedAt','desc'), limit(50));
  return onSnapshot(q, snap => callback(snap.docs.map(d => ({ id: d.id, ...d.data() }))));
};
