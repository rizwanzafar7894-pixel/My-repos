import { create } from 'zustand';
import { User } from '@/types';
import {
  signIn as fbSignIn,
  signUp as fbSignUp,
  signInWithGoogle as fbSignInWithGoogle,
  logOut as fbLogOut,
  onAuthChange,
} from '@/lib/firebase';
import { getAuth } from 'firebase/auth';

// ── Helper: sync Firebase user with backend ──────────────────────────────────
async function syncUserWithBackend(firebaseUser: any): Promise<User | null> {
  try {
    const token    = await firebaseUser.getIdToken();
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL || ''}/api/auth/verify`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ token }),
    });
    if (!response.ok) return null;
    const data = await response.json();
    return data.data as User;
  } catch {
    return null;
  }
}

// ── Auth Store ────────────────────────────────────────────────────────────────
interface AuthState {
  user:        User | null;
  loading:     boolean;
  error:       string | null;
  initialized: boolean;

  initialize:      () => () => void;   // returns unsubscribe fn
  signIn:          (email: string, password: string) => Promise<void>;
  signUp:          (email: string, password: string, displayName: string) => Promise<void>;
  signInWithGoogle:() => Promise<void>;
  logOut:          () => Promise<void>;
  updateUser:      (partial: Partial<User>) => void;
  refreshUser:     () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user:        null,
  loading:     true,
  error:       null,
  initialized: false,

  // Call once in root layout — sets up Firebase auth state listener
  initialize: () => {
    const unsubscribe = onAuthChange(async (firebaseUser) => {
      if (firebaseUser) {
        const user = await syncUserWithBackend(firebaseUser);
        set({ user, loading: false, initialized: true });
      } else {
        set({ user: null, loading: false, initialized: true });
      }
    });
    return unsubscribe;
  },

  signIn: async (email, password) => {
    set({ loading: true, error: null });
    try {
      const { user: fbUser, error } = await fbSignIn(email, password);
      if (error) throw new Error(error);
      const user = fbUser ? await syncUserWithBackend(fbUser) : null;
      set({ user, loading: false, error: null });
    } catch (err: any) {
      const message = err.message?.includes('wrong-password') || err.message?.includes('user-not-found')
        ? 'Invalid email or password'
        : err.message || 'Sign in failed';
      set({ error: message, loading: false });
      throw new Error(message);
    }
  },

  signUp: async (email, password, displayName) => {
    set({ loading: true, error: null });
    try {
      const { user: fbUser, error } = await fbSignUp(email, password, displayName);
      if (error) throw new Error(error);
      const user = fbUser ? await syncUserWithBackend(fbUser) : null;
      set({ user, loading: false, error: null });
    } catch (err: any) {
      const message = err.message?.includes('email-already-in-use')
        ? 'An account with this email already exists'
        : err.message || 'Registration failed';
      set({ error: message, loading: false });
      throw new Error(message);
    }
  },

  signInWithGoogle: async () => {
    set({ loading: true, error: null });
    try {
      const { user: fbUser, error } = await fbSignInWithGoogle();
      if (error) throw new Error(error);
      const user = fbUser ? await syncUserWithBackend(fbUser) : null;
      set({ user, loading: false, error: null });
    } catch (err: any) {
      const message = err.message?.includes('popup-closed') ? 'Sign in cancelled' : err.message || 'Google sign in failed';
      set({ error: message, loading: false });
      throw new Error(message);
    }
  },

  logOut: async () => {
    set({ loading: true, error: null });
    try {
      await fbLogOut();
      set({ user: null, loading: false, error: null });
    } catch (err: any) {
      set({ error: err.message, loading: false });
      throw err;
    }
  },

  updateUser: (partial) => {
    const current = get().user;
    if (current) set({ user: { ...current, ...partial } });
  },

  refreshUser: async () => {
    const fbUser = getAuth().currentUser;
    if (!fbUser) return;
    const user = await syncUserWithBackend(fbUser);
    if (user) set({ user });
  },
}));
