// ── Tier feature limits ───────────────────────────────────────────────────────
export const TIER_LIMITS = {
  free: {
    images:    { daily: 5,   models: ['flux-schnell'], maxResolution: 1024, maxSize: 5 * 1024 * 1024 },
    code:      { daily: 50,  timeout: 30 },
    documents: { max: 5,     maxSize: 5 * 1024 * 1024 },
    api:       { enabled: false, requestsPerMonth: 0, maxKeys: 0 },
  },
  basic: {
    images:    { daily: 25,  models: ['flux-schnell','flux-dev','sdxl-base'], maxResolution: 1280, maxSize: 10 * 1024 * 1024 },
    code:      { daily: 200, timeout: 60 },
    documents: { max: 50,    maxSize: 10 * 1024 * 1024 },
    api:       { enabled: true, requestsPerMonth: 1000, maxKeys: 1 },
  },
  premium: {
    images:    { daily: 100, models: ['flux-schnell','flux-dev','flux-pro','sdxl-base','sdxl-refiner'], maxResolution: 2048, maxSize: 20 * 1024 * 1024 },
    code:      { daily: 500, timeout: 120 },
    documents: { max: -1,    maxSize: 20 * 1024 * 1024 },
    api:       { enabled: true, requestsPerMonth: 50000, maxKeys: 5 },
  },
  pro: {
    images:    { daily: -1,  models: ['flux-schnell','flux-dev','flux-pro','sdxl-base','sdxl-refiner'], maxResolution: 4096, maxSize: 50 * 1024 * 1024 },
    code:      { daily: -1,  timeout: 300 },
    documents: { max: -1,    maxSize: 50 * 1024 * 1024 },
    api:       { enabled: true, requestsPerMonth: -1, maxKeys: -1 },
  },
} as const;

export type TierKey = keyof typeof TIER_LIMITS;
