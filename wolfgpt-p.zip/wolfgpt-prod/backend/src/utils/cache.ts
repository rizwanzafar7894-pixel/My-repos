import { createClient, RedisClientType } from 'redis';
import logger from './logger';

let _client: RedisClientType | null = null;
let _connected = false;
let _connectPromise: Promise<RedisClientType | null> | null = null;

// ── Singleton Redis client with reconnect strategy ────────────────────────────
async function getClient(): Promise<RedisClientType | null> {
  if (_connected && _client) return _client;
  if (_connectPromise) return _connectPromise;

  _connectPromise = (async () => {
    try {
      _client = createClient({
        url:      process.env.REDIS_URL     || 'redis://localhost:6379',
        password: process.env.REDIS_PASSWORD || undefined,
        socket: {
          reconnectStrategy: (retries) => {
            if (retries > 10) return false; // stop retrying after 10 attempts
            return Math.min(retries * 200, 5_000);
          },
          connectTimeout: 5_000,
        },
      }) as RedisClientType;

      _client.on('connect',      ()  => { _connected = true;  logger.info('✅ Redis connected'); });
      _client.on('disconnect',   ()  => { _connected = false; logger.warn('⚠️  Redis disconnected'); });
      _client.on('reconnecting', ()  => logger.info('🔄 Redis reconnecting…'));
      _client.on('error',        (e) => logger.warn('Redis error:', e.message));

      await _client.connect();
      return _client;
    } catch (err) {
      logger.warn('Redis unavailable — running without cache. Rate limiting and auth caching disabled.');
      _client          = null;
      _connectPromise  = null;
      return null;
    }
  })();

  return _connectPromise;
}

// ── Public API ────────────────────────────────────────────────────────────────

/** Get a JSON-parsed value. Returns null on miss or error. */
export const cacheGet = async <T = any>(key: string): Promise<T | null> => {
  try {
    const c = await getClient();
    if (!c) return null;
    const val = await c.get(key);
    return val ? (JSON.parse(val) as T) : null;
  } catch {
    return null;
  }
};

/** Store a JSON-serialised value with TTL in seconds. */
export const cacheSet = async (key: string, value: any, ttlSeconds = 300): Promise<void> => {
  try {
    const c = await getClient();
    if (!c) return;
    await c.setEx(key, ttlSeconds, JSON.stringify(value));
  } catch { /* ignore write failures */ }
};

/** Delete a key. */
export const cacheDel = async (key: string): Promise<void> => {
  try {
    const c = await getClient();
    if (!c) return;
    await c.del(key);
  } catch { }
};

/**
 * Atomic increment with TTL set in the same pipeline.
 * Uses MULTI/EXEC so there is no window between INCR and EXPIRE
 * where a server crash could leave a key with no expiry.
 */
export const cacheIncr = async (key: string, ttlSeconds?: number): Promise<number> => {
  try {
    const c = await getClient();
    if (!c) return 0;

    if (!ttlSeconds) {
      return await c.incr(key);
    }

    // Pipeline: INCR + EXPIRE atomically
    const multi  = c.multi();
    multi.incr(key);
    multi.expire(key, ttlSeconds, 'NX'); // NX = only set expiry if key has none yet
    const results = await multi.exec();
    return (results?.[0] as number) ?? 0;
  } catch {
    return 0;
  }
};

/** Delete all keys matching a glob pattern (uses SCAN to avoid blocking). */
export const cacheFlushPattern = async (pattern: string): Promise<void> => {
  try {
    const c = await getClient();
    if (!c) return;
    let cursor = 0;
    do {
      const result = await c.scan(cursor, { MATCH: pattern, COUNT: 100 });
      cursor = result.cursor;
      if (result.keys.length) await c.del(result.keys);
    } while (cursor !== 0);
  } catch { }
};

/** Gracefully disconnect (call on server shutdown). */
export const cacheDisconnect = async (): Promise<void> => {
  try {
    if (_client && _connected) {
      await _client.quit();
      logger.info('Redis disconnected cleanly');
    }
  } catch { }
};
