import winston from 'winston';
import path from 'path';

const { combine, timestamp, printf, colorize, errors, json } = winston.format;
const isProd = process.env.NODE_ENV === 'production';

// Pretty format for development
const devFormat = combine(
  colorize({ all: true }),
  timestamp({ format: 'HH:mm:ss' }),
  errors({ stack: true }),
  printf(({ level, message, timestamp: ts, stack }) =>
    `${ts} [${level}]: ${stack || message}`)
);

// JSON format for production (easier to parse with log aggregators)
const prodFormat = combine(
  timestamp(),
  errors({ stack: true }),
  json()
);

const logger = winston.createLogger({
  level:  process.env.LOG_LEVEL || (isProd ? 'warn' : 'debug'),
  format: isProd ? prodFormat : devFormat,
  defaultMeta: { service: 'wolfgpt-backend' },
  transports: [
    new winston.transports.Console(),
    ...(isProd ? [
      new winston.transports.File({
        filename:  path.join(process.env.LOG_DIR || 'logs', 'error.log'),
        level:     'error',
        maxsize:   5 * 1024 * 1024,  // 5 MB
        maxFiles:  5,
      }),
      new winston.transports.File({
        filename:  path.join(process.env.LOG_DIR || 'logs', 'combined.log'),
        maxsize:   20 * 1024 * 1024, // 20 MB
        maxFiles:  10,
      }),
    ] : []),
  ],
  exitOnError: false,
});

// Add http level for morgan
logger.add(new winston.transports.Console({
  level: 'http',
  silent: !process.env.HTTP_LOG,
}));

export default logger;
