import crypto from 'crypto';

/** Generate unique ID: prefix_timestamp_random (e.g. img_lz4bc_a3f9d2) */
export const generateId = (prefix = 'id'): string =>
  `${prefix}_${Date.now().toString(36)}_${crypto.randomBytes(4).toString('hex')}`;

/** SHA-256 hash of a string */
export const hashString = (str: string): string =>
  crypto.createHash('sha256').update(str).digest('hex');

/** Cryptographically secure random hex string */
export const randomString = (bytes = 32): string =>
  crypto.randomBytes(bytes).toString('hex');

/** Validate email format */
export const isValidEmail = (email: string): boolean =>
  /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

/** Sleep for ms milliseconds */
export const sleep = (ms: number): Promise<void> =>
  new Promise(resolve => setTimeout(resolve, ms));

/** Format bytes to human-readable (e.g. "4.2 MB") */
export const formatBytes = (bytes: number, decimals = 2): string => {
  if (bytes === 0) return '0 B';
  const k     = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i     = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(decimals))} ${sizes[i]}`;
};

/** Get lowercase file extension (without dot) */
export const getFileExtension = (filename: string): string =>
  (filename.split('.').pop() || '').toLowerCase();

/** Truncate string with ellipsis */
export const truncate = (str: string, len = 100): string =>
  str.length > len ? str.slice(0, len) + '…' : str;

/** Sanitize a string for use as a filename */
export const sanitizeFilename = (name: string): string =>
  name.replace(/[^a-zA-Z0-9._-]/g, '_').replace(/_{2,}/g, '_').toLowerCase();

/** Clamp a number between min and max */
export const clamp = (n: number, min: number, max: number): number =>
  Math.min(Math.max(n, min), max);

/** Check if a value is a non-empty string */
export const isNonEmptyString = (v: unknown): v is string =>
  typeof v === 'string' && v.trim().length > 0;

/** Omit keys from an object */
export const omit = <T extends object, K extends keyof T>(obj: T, keys: K[]): Omit<T, K> => {
  const result = { ...obj };
  keys.forEach(k => delete result[k]);
  return result;
};
