import { Request, Response } from 'express';
import { db, auth } from '../config/firebase';
import { asyncHandler, ApiError } from '../middleware/errorHandler';
import logger from '../utils/logger';

// ── Analytics ─────────────────────────────────────────────────────────────────
export const getAnalytics = asyncHandler(async (req: Request, res: Response) => {
  const range = Math.min(parseInt(req.query.range as string) || 30, 365);
  const since = new Date(Date.now() - range * 86_400_000);

  const [
    userCountSnap,
    activeUserSnap,
    chatSnap,
    imageSnap,
    codeSnap,
    musicSnap,
  ] = await Promise.all([
    db.collection('users').count().get(),
    db.collection('users')
      .where('updatedAt', '>=', new Date(Date.now() - 7 * 86_400_000))
      .count().get(),
    db.collection('conversations').where('createdAt', '>=', since).count().get(),
    db.collection('images').where('createdAt', '>=', since).count().get(),
    db.collection('code_executions').where('createdAt', '>=', since).count().get(),
    db.collection('music').where('createdAt', '>=', since).count().get(),
  ]);

  // Revenue from subscription tiers
  const paidUsersSnap = await db.collection('users')
    .where('subscription.status', '==', 'active')
    .get();

  const TIER_PRICE: Record<string, number> = { basic: 99, premium: 199, pro: 399 };
  let arr = 0;
  const tierBreakdown: Record<string, number> = { free: 0, basic: 0, premium: 0, pro: 0 };

  paidUsersSnap.forEach(doc => {
    const data = doc.data();
    const tier = data.tier as string;
    tierBreakdown[tier] = (tierBreakdown[tier] || 0) + 1;
    arr += TIER_PRICE[tier] || 0;
  });

  const mrr = Math.round(arr / 12);

  res.json({
    success: true,
    data: {
      period: { days: range, since: since.toISOString() },
      users: {
        total:  userCountSnap.data().count,
        active: activeUserSnap.data().count,
        tiers:  tierBreakdown,
      },
      revenue: { arr, mrr },
      usage: {
        conversations: chatSnap.data().count,
        images:        imageSnap.data().count,
        codeRuns:      codeSnap.data().count,
        musicTracks:   musicSnap.data().count,
      },
    },
  });
});

// ── Get all users (paginated) ─────────────────────────────────────────────────
export const getAllUsers = asyncHandler(async (req: Request, res: Response) => {
  const limit  = Math.min(parseInt(req.query.limit as string) || 50, 200);
  const cursor = req.query.cursor as string | undefined;

  let q: FirebaseFirestore.Query = db.collection('users')
    .orderBy('createdAt', 'desc')
    .limit(limit);

  if (cursor) {
    const cursorDoc = await db.collection('users').doc(cursor).get();
    if (cursorDoc.exists) q = q.startAfter(cursorDoc);
  }

  const snap  = await q.get();
  const users = snap.docs.map(d => {
    const data = d.data();
    // Never expose sensitive fields to admin panel
    const { stripeCustomerId: _sc, ...safe } = data as any;
    return { id: d.id, ...safe };
  });

  res.json({
    success: true,
    data: {
      users,
      nextCursor: snap.docs.length === limit ? snap.docs[snap.docs.length - 1].id : null,
    },
  });
});

// ── Suspend user ──────────────────────────────────────────────────────────────
export const suspendUser = asyncHandler(async (req: Request, res: Response) => {
  const { userId } = req.params;
  if (!userId) throw ApiError.badRequest('userId is required');

  const userDoc = await db.collection('users').doc(userId).get();
  if (!userDoc.exists) throw ApiError.notFound('User not found');

  // Revoke all active Firebase sessions
  await auth.revokeRefreshTokens(userId);

  // Deactivate all API keys in a batch
  const keysSnap = await db.collection('api_keys')
    .where('userId', '==', userId)
    .where('active', '==', true)
    .get();

  const batch = db.batch();
  keysSnap.forEach(doc => batch.update(doc.ref, { active: false, revokedAt: new Date() }));
  batch.update(db.collection('users').doc(userId), {
    status:      'suspended',
    suspendedAt: new Date(),
    updatedAt:   new Date(),
  });
  await batch.commit();

  logger.info(`Admin suspended user ${userId}`);
  res.json({ success: true, data: { userId, message: 'User suspended and sessions revoked' } });
});

// ── Activate user ─────────────────────────────────────────────────────────────
export const activateUser = asyncHandler(async (req: Request, res: Response) => {
  const { userId } = req.params;
  if (!userId) throw ApiError.badRequest('userId is required');

  const userDoc = await db.collection('users').doc(userId).get();
  if (!userDoc.exists) throw ApiError.notFound('User not found');

  await db.collection('users').doc(userId).update({
    status:      'active',
    activatedAt: new Date(),
    updatedAt:   new Date(),
  });

  logger.info(`Admin activated user ${userId}`);
  res.json({ success: true, data: { userId, message: 'User activated' } });
});

// ── System stats ──────────────────────────────────────────────────────────────
export const getSystemStats = asyncHandler(async (_req: Request, res: Response) => {
  const collections = ['users', 'api_keys', 'conversations', 'images', 'music', 'code_executions', 'documents'];

  const counts = await Promise.all(
    collections.map(col => db.collection(col).count().get().then(s => ({ col, count: s.data().count })))
  );

  const stats = counts.reduce<Record<string, number>>((acc, { col, count }) => {
    acc[col] = count;
    return acc;
  }, {});

  res.json({ success: true, data: { collections: stats } });
});

// ── Export data as CSV ────────────────────────────────────────────────────────
const EXPORTABLE = ['users', 'conversations', 'images', 'code_executions', 'music', 'documents'] as const;
type ExportType = typeof EXPORTABLE[number];

function toCSV(rows: Record<string, unknown>[]): string {
  if (!rows.length) return '';
  const headers = Object.keys(rows[0]);
  const escape  = (v: unknown) => {
    const s = v === null || v === undefined ? '' : String(v).replace(/"/g, '""');
    return /[",\n]/.test(s) ? `"${s}"` : s;
  };
  return [
    headers.join(','),
    ...rows.map(row => headers.map(h => escape(row[h])).join(',')),
  ].join('\n');
}

export const exportData = asyncHandler(async (req: Request, res: Response) => {
  const { dataType } = req.params;
  if (!EXPORTABLE.includes(dataType as ExportType)) {
    throw ApiError.badRequest(`Invalid dataType. Allowed: ${EXPORTABLE.join(', ')}`);
  }

  const limit = Math.min(parseInt(req.query.limit as string) || 5000, 10_000);
  const snap  = await db.collection(dataType as ExportType).limit(limit).get();
  const rows  = snap.docs.map(d => {
    const data = d.data();
    // Sanitize sensitive fields
    delete (data as any).stripeCustomerId;
    delete (data as any).keyHash;
    return { id: d.id, ...data };
  });

  const csv = toCSV(rows as Record<string, unknown>[]);
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${dataType}-export-${Date.now()}.csv"`);
  res.send(csv);
});
