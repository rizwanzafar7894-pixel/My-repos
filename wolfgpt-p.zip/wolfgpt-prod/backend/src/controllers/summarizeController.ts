import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
import { asyncHandler, ApiError } from '../middleware/errorHandler';
import axios from 'axios';

const AI_URL = process.env.AI_SERVICE_URL || 'http://localhost:8000';

export const summarizeController = {
  summarize: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { text, maxLength = 500, style = 'paragraph' } = req.body;

    const prompt =
      style === 'bullet'
        ? `Summarize the following text as clear bullet points (max ${maxLength} words):\n\n${text}`
        : style === 'tldr'
          ? `Provide a TL;DR summary in 2-3 sentences (max ${maxLength} words):\n\n${text}`
          : `Summarize the following text in a clear paragraph (max ${maxLength} words):\n\n${text}`;

    const aiRes = await axios.post(
      `${AI_URL}/v1/chat/completions`,
      {
        messages:   [{ role: 'user', content: prompt }],
        model:      'qwen-2.5-7b',
        max_tokens: maxLength * 2,
        stream:     false,
      },
      { timeout: 60_000 }
    );

    const summary = aiRes.data.choices?.[0]?.message?.content;
    if (!summary) throw ApiError.internal('AI service returned empty summary');

    res.json({ success: true, data: { summary, wordCount: summary.split(/\s+/).length } });
  }),
};
