import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
import { asyncHandler, ApiError } from '../middleware/errorHandler';
import { db, storage, FieldValue } from '../config/firebase';
import { TIER_LIMITS } from '../constants';
import { generateId, getFileExtension } from '../utils/helpers';
import axios from 'axios';
import FormData from 'form-data';
import logger from '../utils/logger';

const AI_URL = process.env.AI_SERVICE_URL || 'http://localhost:8000';
const ALLOWED_TYPES = ['application/pdf','application/vnd.openxmlformats-officedocument.wordprocessingml.document','text/plain','text/csv','application/json'];
const ALLOWED_EXTS  = ['pdf','docx','txt','csv','json','md'];

export const documentController = {

  uploadDocument: asyncHandler(async (req: AuthRequest, res: Response) => {
    const uid  = req.user!.uid;
    const tier = req.user!.tier;

    if (!req.file) throw ApiError.badRequest('Document file is required', 'MISSING_FILE');

    const ext = getFileExtension(req.file.originalname);
    if (!ALLOWED_EXTS.includes(ext)) {
      throw ApiError.badRequest(`File type .${ext} not supported. Allowed: ${ALLOWED_EXTS.join(', ')}`, 'INVALID_FILE_TYPE');
    }

    const limits = (TIER_LIMITS as any)[tier]?.documents || { max: 5, maxSize: 5 * 1024 * 1024 };

    if (req.file.size > limits.maxSize) {
      throw ApiError.badRequest(
        `File too large (${(req.file.size / 1024 / 1024).toFixed(1)}MB). Max: ${(limits.maxSize / 1024 / 1024).toFixed(0)}MB for ${tier} plan.`,
        'FILE_TOO_LARGE'
      );
    }

    if (limits.max !== -1) {
      const count = (await db.collection('documents').where('userId','==',uid).count().get()).data().count;
      if (count >= limits.max) {
        throw ApiError.tooMany(`Document limit (${limits.max}) reached. Upgrade for more.`, 'LIMIT_EXCEEDED');
      }
    }

    const docId    = generateId('doc');
    const fileName = `documents/${uid}/${docId}.${ext}`;

    // Upload to Firebase Storage (private — signed URL)
    const fileRef = storage.bucket().file(fileName);
    await fileRef.save(req.file.buffer, { metadata: { contentType: req.file.mimetype } });
    const [url] = await fileRef.getSignedUrl({
      action: 'read',
      expires: Date.now() + 7 * 24 * 3600_000,
    });

    // Parse with AI service
    const form = new FormData();
    form.append('file', req.file.buffer, {
      filename:    req.file.originalname,
      contentType: req.file.mimetype,
    });

    const parseRes = await axios.post(`${AI_URL}/v1/documents/parse`, form, {
      headers: form.getHeaders(),
      timeout: 120_000,
    }).catch(err => {
      logger.error('Document parse error:', err.message);
      return null; // don't block upload if parsing fails
    });

    const docRecord = {
      id: docId, userId: uid,
      fileName:     req.file.originalname,
      fileType:     ext,
      fileSize:     req.file.size,
      storageUrl:   url,
      storagePath:  fileName,
      content:      parseRes?.data?.text    || null,
      pageCount:    parseRes?.data?.pages   || null,
      wordCount:    parseRes?.data?.words   || null,
      parsed:       !!parseRes?.data?.text,
      createdAt:    new Date(),
    };

    await db.collection('documents').doc(docId).set(docRecord);

    res.status(201).json({ success: true, data: docRecord });
  }),

  getDocuments: asyncHandler(async (req: AuthRequest, res: Response) => {
    const uid   = req.user!.uid;
    const limit = Math.min(parseInt(req.query.limit as string) || 20, 100);
    const snap  = await db.collection('documents').where('userId','==',uid).orderBy('createdAt','desc').limit(limit).get();
    res.json({ success: true, data: snap.docs.map(d => d.data()) });
  }),

  getDocument: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const doc = await db.collection('documents').doc(id).get();
    if (!doc.exists) throw ApiError.notFound('Document not found');
    if (doc.data()!.userId !== req.user!.uid) throw ApiError.forbidden();
    res.json({ success: true, data: doc.data() });
  }),

  chatWithDocument: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id }       = req.params;
    const { question } = req.body;

    if (!question?.trim()) throw ApiError.badRequest('question is required');

    const doc = await db.collection('documents').doc(id).get();
    if (!doc.exists) throw ApiError.notFound('Document not found');
    if (doc.data()!.userId !== req.user!.uid) throw ApiError.forbidden();

    const content = doc.data()!.content;
    if (!content) throw ApiError.badRequest('Document has not been parsed yet', 'NOT_PARSED');

    const truncated = content.slice(0, 20000); // ~5k tokens context
    const prompt = `Based on the following document, answer this question:\n\nDocument:\n${truncated}\n\nQuestion: ${question}\n\nAnswer:`;

    const aiRes = await axios.post(
      `${AI_URL}/v1/chat/completions`,
      { messages: [{ role: 'user', content: prompt }], model: 'qwen-2.5-7b', max_tokens: 2048 },
      { timeout: 60_000 }
    );

    const answer = aiRes.data.choices?.[0]?.message?.content;
    if (!answer) throw ApiError.internal('AI returned empty answer');

    res.json({ success: true, data: { question, answer: answer.trim(), documentId: id } });
  }),

  deleteDocument: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const uid    = req.user!.uid;
    const doc    = await db.collection('documents').doc(id).get();
    if (!doc.exists) throw ApiError.notFound('Document not found');
    if (doc.data()!.userId !== uid) throw ApiError.forbidden();

    const path = doc.data()!.storagePath;
    if (path) {
      await storage.bucket().file(path).delete().catch(() => {}); // best-effort
    }
    await doc.ref.delete();
    res.json({ success: true, data: { id, message: 'Document deleted' } });
  }),
};
