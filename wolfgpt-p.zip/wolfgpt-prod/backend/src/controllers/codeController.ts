import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
import { asyncHandler, ApiError } from '../middleware/errorHandler';
import { db, FieldValue } from '../config/firebase';
import { generateId } from '../utils/helpers';
import { TIER_LIMITS } from '../constants';
import axios from 'axios';
import logger from '../utils/logger';

const AI_URL = process.env.AI_SERVICE_URL || 'http://localhost:8000';

const LANG_TIER: Record<string, string[]> = {
  python:     ['free','basic','premium','pro'],
  javascript: ['free','basic','premium','pro'],
  typescript: ['basic','premium','pro'],
  bash:       ['basic','premium','pro'],
  go:         ['premium','pro'],
  rust:       ['premium','pro'],
};

export const codeController = {

  executeCode: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { code, language = 'python', stdin = '' } = req.body;
    const userId   = req.user!.uid;
    const userTier = req.user!.tier;

    const allowedTiers = LANG_TIER[language];
    if (!allowedTiers) throw ApiError.badRequest(`Unsupported language: ${language}`, 'INVALID_LANGUAGE');
    if (!allowedTiers.includes(userTier)) {
      throw ApiError.forbidden(
        `${language} requires the ${allowedTiers[0]} plan or higher`,
        'TIER_REQUIRED'
      );
    }

    const limits  = (TIER_LIMITS as any)[userTier]?.code;
    const userDoc = await db.collection('users').doc(userId).get();
    const used    = userDoc.data()?.usage?.code?.used || 0;

    if (limits?.daily !== -1 && used >= (limits?.daily || 50)) {
      throw ApiError.tooMany(
        `Daily code execution limit reached (${used}/${limits?.daily}). Upgrade for more.`,
        'LIMIT_EXCEEDED'
      );
    }

    const timeout = limits?.timeout || 30;
    const start   = Date.now();

    const aiRes = await axios.post(
      `${AI_URL}/v1/code/execute`,
      { code, language, stdin, timeout },
      { timeout: (timeout + 15) * 1000 }
    ).catch(err => {
      if (err.code === 'ECONNABORTED') {
        throw ApiError.badRequest(`Execution timed out after ${timeout}s`, 'TIMEOUT');
      }
      throw ApiError.serviceUnavailable('Code execution service unavailable');
    });

    const execId  = generateId('exec');
    const elapsed = Date.now() - start;

    const record = {
      id: execId, userId, code, language,
      output:        aiRes.data.output        || '',
      error:         aiRes.data.error         || null,
      executionTime: elapsed,
      exitCode:      aiRes.data.exit_code     ?? null,
      createdAt:     new Date(),
    };

    await Promise.all([
      db.collection('code_executions').doc(execId).set(record),
      db.collection('users').doc(userId).update({
        'usage.code.used': FieldValue.increment(1),
      }),
    ]);

    res.json({ success: true, data: record });
  }),

  getHistory: asyncHandler(async (req: AuthRequest, res: Response) => {
    const userId = req.user!.uid;
    const limit  = Math.min(parseInt(req.query.limit as string) || 20, 100);
    const lang   = req.query.language as string | undefined;

    let query: any = db.collection('code_executions').where('userId', '==', userId);
    if (lang) query = query.where('language', '==', lang);

    const snap = await query.orderBy('createdAt', 'desc').limit(limit).get();
    res.json({ success: true, data: snap.docs.map((d: any) => d.data()) });
  }),

  getLanguages: asyncHandler(async (req: AuthRequest, res: Response) => {
    const tier = req.user!.tier;
    res.json({
      success: true,
      data: Object.entries(LANG_TIER).map(([id, tiers]) => ({
        id,
        available: tiers.includes(tier),
        requiredTier: tiers[0],
      })),
    });
  }),
};
