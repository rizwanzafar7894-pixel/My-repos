import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
import { asyncHandler, ApiError } from '../middleware/errorHandler';
import { db, FieldValue } from '../config/firebase';
import axios from 'axios';
import FormData from 'form-data';
import logger from '../utils/logger';

const AI_URL = process.env.AI_SERVICE_URL || 'http://localhost:8000';

const VOICES = [
  { id: 'en-US-female-1', name: 'Emma',   language: 'en-US', gender: 'female' },
  { id: 'en-US-male-1',   name: 'James',  language: 'en-US', gender: 'male'   },
  { id: 'en-GB-female-1', name: 'Sophie', language: 'en-GB', gender: 'female' },
  { id: 'en-GB-male-1',   name: 'Oliver', language: 'en-GB', gender: 'male'   },
  { id: 'ur-PK-female-1', name: 'Ayesha', language: 'ur-PK', gender: 'female' },
  { id: 'ur-PK-male-1',   name: 'Ali',    language: 'ur-PK', gender: 'male'   },
];

const LANGUAGES = [
  { code: 'en', name: 'English',    native: 'English'   },
  { code: 'ur', name: 'Urdu',       native: 'اردو'      },
  { code: 'ar', name: 'Arabic',     native: 'العربية'   },
  { code: 'zh', name: 'Chinese',    native: '中文'       },
  { code: 'es', name: 'Spanish',    native: 'Español'   },
  { code: 'fr', name: 'French',     native: 'Français'  },
  { code: 'de', name: 'German',     native: 'Deutsch'   },
  { code: 'hi', name: 'Hindi',      native: 'हिंदी'     },
  { code: 'ja', name: 'Japanese',   native: '日本語'     },
  { code: 'ko', name: 'Korean',     native: '한국어'     },
  { code: 'pt', name: 'Portuguese', native: 'Português' },
  { code: 'ru', name: 'Russian',    native: 'Русский'   },
  { code: 'tr', name: 'Turkish',    native: 'Türkçe'    },
];

export const voiceController = {

  speechToText: asyncHandler(async (req: AuthRequest, res: Response) => {
    const userId   = req.user!.uid;
    const language = req.body.language || 'en';

    if (!req.file) throw ApiError.badRequest('Audio file is required', 'MISSING_FILE');

    const form = new FormData();
    form.append('audio', req.file.buffer, {
      filename:    `audio.${req.file.originalname?.split('.').pop() || 'webm'}`,
      contentType: req.file.mimetype,
    });
    form.append('language', language);
    form.append('model',    req.body.model || 'base');

    const aiRes = await axios.post(`${AI_URL}/v1/voice/stt`, form, {
      headers: form.getHeaders(),
      timeout: 90_000,
    });

    await db.collection('users').doc(userId).update({
      'usage.voice.sttUsed': FieldValue.increment(1),
    });

    res.json({
      success: true,
      data: {
        text:       aiRes.data.text,
        language:   aiRes.data.language || language,
        duration:   aiRes.data.duration,
        confidence: aiRes.data.confidence,
      },
    });
  }),

  textToSpeech: asyncHandler(async (req: AuthRequest, res: Response) => {
    const userId              = req.user!.uid;
    const { text, voice = 'en-US-female-1', speed = 1.0 } = req.body;

    if (!VOICES.find(v => v.id === voice)) {
      throw ApiError.badRequest(`Invalid voice "${voice}". Valid voices: ${VOICES.map(v => v.id).join(', ')}`, 'INVALID_VOICE');
    }

    const aiRes = await axios.post(
      `${AI_URL}/v1/voice/tts`,
      { text: text.trim(), voice, speed },
      { responseType: 'arraybuffer', timeout: 60_000 }
    );

    await db.collection('users').doc(userId).update({
      'usage.voice.ttsUsed': FieldValue.increment(1),
    });

    const audioBuffer = Buffer.from(aiRes.data);
    res.setHeader('Content-Type',   'audio/wav');
    res.setHeader('Content-Length', audioBuffer.byteLength);
    res.send(audioBuffer);
  }),

  getVoices: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { language } = req.query;
    const voices = language
      ? VOICES.filter(v => v.language.startsWith(language as string))
      : VOICES;
    res.json({ success: true, data: voices });
  }),

  getLanguages: asyncHandler(async (_req: AuthRequest, res: Response) => {
    res.json({ success: true, data: LANGUAGES });
  }),
};
