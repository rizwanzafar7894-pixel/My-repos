import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
import { asyncHandler, ApiError } from '../middleware/errorHandler';
import { auth, db, FieldValue } from '../config/firebase';
import { generateId, hashString, randomString } from '../utils/helpers';
import { TIER_LIMITS } from '../constants';
import { cacheDel } from '../utils/cache';
import logger from '../utils/logger';

export const authController = {

  // Called after Firebase client-side login to create/sync user in Firestore
  verifyToken: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { token } = req.body;
    if (!token) throw ApiError.badRequest('token is required', 'MISSING_TOKEN');

    const decoded  = await auth.verifyIdToken(token).catch(() => {
      throw ApiError.unauthorized('Invalid token');
    });

    const userRef  = db.collection('users').doc(decoded.uid);
    const userSnap = await userRef.get();

    if (!userSnap.exists) {
      const newUser = {
        uid:         decoded.uid,
        email:       decoded.email        || '',
        displayName: decoded.name         || decoded.email?.split('@')[0] || 'User',
        photoURL:    decoded.picture      || null,
        tier:        'free' as const,
        subscription: { status: 'none', planId: null, expiresAt: null },
        usage: {
          chat:   { used: 0 },
          images: { used: 0 },
          code:   { used: 0 },
          voice:  { sttUsed: 0, ttsUsed: 0 },
          music:  { used: 0 },
          api:    { used: 0 },
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      await userRef.set(newUser);
      return res.status(201).json({ success: true, data: newUser });
    }

    await userRef.update({ updatedAt: new Date(), lastLoginAt: new Date() });
    res.json({ success: true, data: { id: userSnap.id, ...userSnap.data() } });
  }),

  getMe: asyncHandler(async (req: AuthRequest, res: Response) => {
    const uid = req.user!.uid;
    const doc = await db.collection('users').doc(uid).get();
    if (!doc.exists) throw ApiError.notFound('User not found');
    // Strip sensitive fields
    const { ...data } = doc.data() as any;
    res.json({ success: true, data: { id: doc.id, ...data } });
  }),

  updateMe: asyncHandler(async (req: AuthRequest, res: Response) => {
    const uid     = req.user!.uid;
    const allowed = ['displayName', 'photoURL'];
    const updates: Record<string, any> = { updatedAt: new Date() };
    allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });

    if (updates.displayName !== undefined) {
      if (typeof updates.displayName !== 'string') {
        throw ApiError.badRequest('displayName must be a string');
      }
      // Sanitize: strip HTML/script tags, trim, enforce length
      updates.displayName = updates.displayName
        .replace(/<[^>]*>/g, '')
        .trim()
        .slice(0, 64);
      if (!updates.displayName) throw ApiError.badRequest('displayName cannot be empty');
    }

    if (updates.photoURL !== undefined && updates.photoURL !== null) {
      if (typeof updates.photoURL !== 'string') {
        throw ApiError.badRequest('photoURL must be a string or null');
      }
      // Only allow https:// URLs
      if (!updates.photoURL.startsWith('https://')) {
        throw ApiError.badRequest('photoURL must be an HTTPS URL');
      }
    }

    await db.collection('users').doc(uid).update(updates);
    res.json({ success: true, data: { message: 'Profile updated', ...updates } });
  }),

  getUsage: asyncHandler(async (req: AuthRequest, res: Response) => {
    const uid  = req.user!.uid;
    const tier = req.user!.tier;
    const doc  = await db.collection('users').doc(uid).get();
    const data = doc.data();
    const lim  = (TIER_LIMITS as any)[tier];

    res.json({
      success: true,
      data: {
        tier,
        usage: data?.usage || {},
        limits: {
          images: { daily: lim?.images?.daily,   used: data?.usage?.images?.used    || 0 },
          code:   { daily: lim?.code?.daily,     used: data?.usage?.code?.used      || 0 },
          music:  { daily: lim?.music?.daily     || 5, used: data?.usage?.music?.used  || 0 },
          api:    { monthly: lim?.api?.requestsPerMonth, used: data?.usage?.api?.used   || 0 },
        },
      },
    });
  }),

  // ── API Key management ──────────────────────────────────────────────────────
  createApiKey: asyncHandler(async (req: AuthRequest, res: Response) => {
    const uid  = req.user!.uid;
    const tier = req.user!.tier;
    const name = (req.body.name || 'My API Key').slice(0, 60);

    const limits = (TIER_LIMITS as any)[tier]?.api;
    if (!limits?.enabled) {
      throw ApiError.forbidden('API access requires Basic plan or higher', 'UPGRADE_REQUIRED');
    }

    const maxKeys = limits.maxKeys;
    if (maxKeys !== -1) {
      const count = (await db.collection('api_keys')
        .where('userId', '==', uid)
        .where('active', '==', true)
        .count().get()).data().count;
      if (count >= maxKeys) {
        throw ApiError.tooMany(`API key limit (${maxKeys}) reached. Upgrade for more keys.`, 'LIMIT_EXCEEDED');
      }
    }

    const keyId   = generateId('key');
    const rawKey  = `wgpt_${randomString(32)}`;
    const keyHash = hashString(rawKey);

    const record = {
      id: keyId, userId: uid, name,
      keyHash,
      keyPrefix: rawKey.slice(0, 12) + '...',
      usage:     0,
      active:    true,
      createdAt: new Date(),
      lastUsed:  null,
    };

    await db.collection('api_keys').doc(keyId).set(record);

    // Return raw key ONLY on creation — never stored in plaintext
    res.status(201).json({
      success: true,
      data: { ...record, key: rawKey, keyHash: undefined },
    });
  }),

  getApiKeys: asyncHandler(async (req: AuthRequest, res: Response) => {
    const uid  = req.user!.uid;
    const snap = await db.collection('api_keys')
      .where('userId', '==', uid)
      .orderBy('createdAt', 'desc')
      .get();
    const keys = snap.docs.map(d => {
      const { keyHash: _omit, ...rest } = d.data();
      return rest;
    });
    res.json({ success: true, data: keys });
  }),

  revokeApiKey: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const uid    = req.user!.uid;
    const doc    = await db.collection('api_keys').doc(id).get();

    if (!doc.exists || doc.data()?.userId !== uid) {
      throw ApiError.notFound('API key not found');
    }

    await doc.ref.update({ active: false, revokedAt: new Date() });
    // Invalidate any cached auth for this key
    await cacheDel(`apikey:${doc.data()?.keyHash?.slice(0, 24) || ''}`);

    res.json({ success: true, data: { id, message: 'API key revoked' } });
  }),

  deleteApiKey: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const uid    = req.user!.uid;
    const doc    = await db.collection('api_keys').doc(id).get();

    if (!doc.exists || doc.data()?.userId !== uid) {
      throw ApiError.notFound('API key not found');
    }

    await cacheDel(`apikey:${doc.data()?.keyHash?.slice(0, 24) || ''}`);
    await doc.ref.delete();
    res.json({ success: true, data: { id, message: 'API key deleted' } });
  }),
};
