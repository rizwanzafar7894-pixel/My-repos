import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
import { asyncHandler, ApiError } from '../middleware/errorHandler';
import { db, storage, FieldValue } from '../config/firebase';
import { generateId } from '../utils/helpers';
import axios from 'axios';
import multer from 'multer';
import logger from '../utils/logger';

const AI_URL = process.env.AI_SERVICE_URL || 'http://localhost:8000';

const MUSIC_DAILY_LIMITS: Record<string, number> = {
  free: 5, basic: 20, premium: 60, pro: -1,
};

export const musicUpload = multer({
  storage: multer.memoryStorage(),
  limits:  { fileSize: 25 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const ok = /\.(wav|mp3|ogg|flac|webm|m4a)$/i.test(file.originalname) ||
               file.mimetype.startsWith('audio/');
    ok ? cb(null, true) : cb(new Error('Only audio files are allowed'));
  },
});

async function checkMusicLimit(uid: string, tier: string, count = 1): Promise<void> {
  const daily = MUSIC_DAILY_LIMITS[tier] ?? 5;
  if (daily === -1) return;
  const doc  = await db.collection('users').doc(uid).get();
  const used = doc.data()?.usage?.music?.used || 0;
  if (used + count > daily) {
    throw ApiError.tooMany(`Daily music limit reached (${used}/${daily}). Upgrade for more.`, 'LIMIT_EXCEEDED');
  }
}

async function saveTrack(
  uid: string,
  track: { audio_base64: string; duration: number; sample_rate: number; format: string; model: string; prompt: string; seed?: number; generation_time: number },
  meta: { mode: string; referenceAudioUrl?: string }
): Promise<object> {
  const id       = generateId('trk');
  const fileName = `music/${uid}/${id}.wav`;
  const buf      = Buffer.from(track.audio_base64, 'base64');

  const file = storage.bucket().file(fileName);
  await file.save(buf, { metadata: { contentType: 'audio/wav' } });
  await file.makePublic();

  const url = `https://storage.googleapis.com/${storage.bucket().name}/${fileName}`;
  const doc = {
    id, userId: uid, url,
    prompt:            track.prompt,
    model:             track.model,
    duration:          track.duration,
    sampleRate:        track.sample_rate,
    format:            track.format,
    seed:              track.seed ?? null,
    mode:              meta.mode,
    referenceAudioUrl: meta.referenceAudioUrl ?? null,
    generationTime:    track.generation_time,
    createdAt:         new Date(),
  };
  await db.collection('music').doc(id).set(doc);
  return doc;
}

export const musicController = {

  generateMusic: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { prompt, model = 'musicgen-small', duration = 8, temperature = 1.0, cfgCoef = 3.0, numSamples = 1, seed } = req.body;
    const uid  = req.user!.uid;
    const tier = req.user!.tier;

    if (!prompt?.trim()) throw ApiError.badRequest('prompt is required');
    await checkMusicLimit(uid, tier, numSamples);

    const aiRes = await axios.post(`${AI_URL}/v1/music/generate`,
      { prompt, model, duration, temperature, cfg_coef: cfgCoef, num_samples: numSamples, seed },
      { timeout: 300_000 }
    );

    const saved: object[] = [];
    for (const track of aiRes.data.tracks) {
      saved.push(await saveTrack(uid, track, { mode: 'txt2music' }));
    }
    await db.collection('users').doc(uid).update({ 'usage.music.used': FieldValue.increment(numSamples) });
    res.json({ success: true, data: { tracks: saved, generationTime: aiRes.data.generation_time, mode: 'txt2music' } });
  }),

  melodyConditioned: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { prompt, referenceAudio, model = 'musicgen-melody', duration = 8, temperature = 1.0, cfgCoef = 3.0, seed } = req.body;
    const uid  = req.user!.uid;
    const tier = req.user!.tier;

    if (!prompt?.trim()) throw ApiError.badRequest('prompt is required');
    if (!referenceAudio) throw ApiError.badRequest('referenceAudio (base64) is required', 'MISSING_AUDIO');
    await checkMusicLimit(uid, tier, 1);

    const aiRes = await axios.post(`${AI_URL}/v1/music/melody`,
      { prompt, reference_audio: referenceAudio, model, duration, temperature, cfg_coef: cfgCoef, seed },
      { timeout: 300_000 }
    );

    const saved: object[] = [];
    for (const track of aiRes.data.tracks) {
      saved.push(await saveTrack(uid, track, { mode: 'melody' }));
    }
    await db.collection('users').doc(uid).update({ 'usage.music.used': FieldValue.increment(1) });
    res.json({ success: true, data: { tracks: saved, generationTime: aiRes.data.generation_time, mode: 'melody' } });
  }),

  melodyUpload: asyncHandler(async (req: AuthRequest, res: Response) => {
    const file = (req as any).file as Express.Multer.File | undefined;
    if (!file) throw ApiError.badRequest('Reference audio file is required', 'MISSING_FILE');

    const uid  = req.user!.uid;
    const tier = req.user!.tier;
    const { prompt, model = 'musicgen-melody', duration = 8, temperature = 1.0, cfgCoef = 3.0, seed } = req.body;

    if (!prompt?.trim()) throw ApiError.badRequest('prompt is required');

    // Save reference audio
    const refId   = generateId('ref');
    const refPath = `music/reference/${uid}/${refId}`;
    const refFile = storage.bucket().file(refPath);
    await refFile.save(file.buffer, { metadata: { contentType: file.mimetype } });
    await refFile.makePublic();
    const refUrl = `https://storage.googleapis.com/${storage.bucket().name}/${refPath}`;

    await checkMusicLimit(uid, tier, 1);

    const b64    = file.buffer.toString('base64');
    const aiRes  = await axios.post(`${AI_URL}/v1/music/melody`,
      { prompt, reference_audio: b64, model, duration: Number(duration), temperature: Number(temperature), cfg_coef: Number(cfgCoef), seed: seed ? Number(seed) : undefined },
      { timeout: 300_000 }
    );

    const saved: object[] = [];
    for (const track of aiRes.data.tracks) {
      saved.push(await saveTrack(uid, track, { mode: 'melody', referenceAudioUrl: refUrl }));
    }
    await db.collection('users').doc(uid).update({ 'usage.music.used': FieldValue.increment(1) });
    res.json({ success: true, data: { tracks: saved, referenceAudioUrl: refUrl, generationTime: aiRes.data.generation_time, mode: 'melody' } });
  }),

  continuationMusic: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { prompt, audioPrompt, model = 'musicgen-medium', duration = 8, temperature = 1.0, cfgCoef = 3.0, seed } = req.body;
    const uid  = req.user!.uid;
    const tier = req.user!.tier;

    if (!prompt?.trim())  throw ApiError.badRequest('prompt is required');
    if (!audioPrompt)     throw ApiError.badRequest('audioPrompt (base64) is required', 'MISSING_AUDIO');
    await checkMusicLimit(uid, tier, 1);

    const aiRes = await axios.post(`${AI_URL}/v1/music/continuation`,
      { prompt, audio_prompt: audioPrompt, model, duration, temperature, cfg_coef: cfgCoef, seed },
      { timeout: 300_000 }
    );

    const saved: object[] = [];
    for (const track of aiRes.data.tracks) {
      saved.push(await saveTrack(uid, track, { mode: 'continuation' }));
    }
    await db.collection('users').doc(uid).update({ 'usage.music.used': FieldValue.increment(1) });
    res.json({ success: true, data: { tracks: saved, generationTime: aiRes.data.generation_time, mode: 'continuation' } });
  }),

  getLibrary: asyncHandler(async (req: AuthRequest, res: Response) => {
    const uid    = req.user!.uid;
    const limit  = Math.min(parseInt(req.query.limit as string) || 50, 200);
    const mode   = req.query.mode as string | undefined;
    let query: any = db.collection('music').where('userId', '==', uid);
    if (mode) query = query.where('mode', '==', mode);
    const snap = await query.orderBy('createdAt', 'desc').limit(limit).get();
    res.json({ success: true, data: snap.docs.map((d: any) => d.data()) });
  }),

  getTrack: asyncHandler(async (req: AuthRequest, res: Response) => {
    const doc = await db.collection('music').doc(req.params.id).get();
    if (!doc.exists) throw ApiError.notFound('Track not found');
    if (doc.data()!.userId !== req.user!.uid) throw ApiError.forbidden();
    res.json({ success: true, data: doc.data() });
  }),

  deleteTrack: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const uid    = req.user!.uid;
    const doc    = await db.collection('music').doc(id).get();
    if (!doc.exists) throw ApiError.notFound('Track not found');
    if (doc.data()!.userId !== uid) throw ApiError.forbidden();
    await storage.bucket().file(`music/${uid}/${id}.wav`).delete().catch(() => {});
    await doc.ref.delete();
    res.json({ success: true, data: { id, message: 'Track deleted' } });
  }),

  listModels: asyncHandler(async (_req: AuthRequest, res: Response) => {
    const aiRes = await axios.get(`${AI_URL}/v1/music/models`, { timeout: 10_000 });
    res.json({ success: true, data: aiRes.data });
  }),
};
