import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
import { asyncHandler, ApiError } from '../middleware/errorHandler';
import { db, FieldValue } from '../config/firebase';
import { generateId } from '../utils/helpers';
import axios from 'axios';
import crypto from 'crypto';
import logger from '../utils/logger';

const SUPPORTED_EVENTS = [
  'chat.completed',
  'image.generated',
  'music.generated',
  'code.executed',
  'document.uploaded',
  'webhook.test',
] as const;

const MAX_WEBHOOKS = 10;
const DELIVERY_TIMEOUT_MS = 10_000;

export const webhookController = {

  createWebhook: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { url, events, description = '' } = req.body;
    const userId = req.user!.uid;

    if (!url || !events?.length) {
      throw ApiError.badRequest('url and events[] are required', 'MISSING_FIELDS');
    }

    // Validate URL
    try { new URL(url); } catch {
      throw ApiError.badRequest('url must be a valid HTTPS URL', 'INVALID_URL');
    }
    if (!url.startsWith('https://')) {
      throw ApiError.badRequest('Webhook URL must use HTTPS', 'INSECURE_URL');
    }

    // Validate events
    const invalid = (events as string[]).filter(e => !SUPPORTED_EVENTS.includes(e as any));
    if (invalid.length) {
      throw ApiError.badRequest(
        `Invalid events: ${invalid.join(', ')}. Supported: ${SUPPORTED_EVENTS.join(', ')}`,
        'INVALID_EVENTS'
      );
    }

    // Enforce webhook limit
    const count = (await db.collection('webhooks').where('userId', '==', userId).count().get()).data().count;
    if (count >= MAX_WEBHOOKS) {
      throw ApiError.tooMany(`Webhook limit (${MAX_WEBHOOKS}) reached`, 'LIMIT_EXCEEDED');
    }

    const id     = generateId('wh');
    const secret = crypto.randomBytes(24).toString('hex');

    const webhook = {
      id, userId, url,
      events: [...new Set(events)], // deduplicate
      description: description.slice(0, 200),
      secret,
      active:     true,
      deliveries: 0,
      failures:   0,
      createdAt:  new Date(),
      updatedAt:  new Date(),
    };

    await db.collection('webhooks').doc(id).set(webhook);
    res.status(201).json({ success: true, data: webhook });
  }),

  getWebhooks: asyncHandler(async (req: AuthRequest, res: Response) => {
    const snap = await db.collection('webhooks')
      .where('userId', '==', req.user!.uid)
      .orderBy('createdAt', 'desc')
      .get();
    res.json({ success: true, data: snap.docs.map(d => d.data()) });
  }),

  getWebhook: asyncHandler(async (req: AuthRequest, res: Response) => {
    const doc = await db.collection('webhooks').doc(req.params.id).get();
    if (!doc.exists || doc.data()!.userId !== req.user!.uid) {
      throw ApiError.notFound('Webhook not found');
    }
    res.json({ success: true, data: doc.data() });
  }),

  updateWebhook: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const doc    = await db.collection('webhooks').doc(id).get();
    if (!doc.exists || doc.data()!.userId !== req.user!.uid) {
      throw ApiError.notFound('Webhook not found');
    }

    const allowed: Record<string, any> = { updatedAt: new Date() };
    if (req.body.url !== undefined) {
      try { new URL(req.body.url); } catch { throw ApiError.badRequest('Invalid URL'); }
      if (!req.body.url.startsWith('https://')) throw ApiError.badRequest('URL must use HTTPS');
      allowed.url = req.body.url;
    }
    if (req.body.events !== undefined) allowed.events = [...new Set(req.body.events)];
    if (req.body.description !== undefined) allowed.description = String(req.body.description).slice(0, 200);
    if (req.body.active !== undefined) allowed.active = Boolean(req.body.active);

    await doc.ref.update(allowed);
    res.json({ success: true, data: { id, ...allowed } });
  }),

  deleteWebhook: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const doc    = await db.collection('webhooks').doc(id).get();
    if (!doc.exists || doc.data()!.userId !== req.user!.uid) {
      throw ApiError.notFound('Webhook not found');
    }
    await doc.ref.delete();
    res.json({ success: true, data: { id, message: 'Webhook deleted' } });
  }),

  testWebhook: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const doc    = await db.collection('webhooks').doc(id).get();
    if (!doc.exists || doc.data()!.userId !== req.user!.uid) {
      throw ApiError.notFound('Webhook not found');
    }

    const wh = doc.data()!;
    if (!wh.active) throw ApiError.badRequest('Webhook is disabled', 'WEBHOOK_DISABLED');

    const payload = {
      event:     'webhook.test',
      webhookId: id,
      timestamp: new Date().toISOString(),
      data:      { message: 'Test event from WolfGPT' },
    };

    const body      = JSON.stringify(payload);
    const signature = `sha256=${crypto.createHmac('sha256', wh.secret).update(body).digest('hex')}`;

    try {
      const response = await axios.post(wh.url, payload, {
        headers: {
          'Content-Type':         'application/json',
          'X-WolfGPT-Signature':  signature,
          'X-WolfGPT-Event':      'webhook.test',
          'X-WolfGPT-Delivery':   generateId('del'),
          'User-Agent':           'WolfGPT-Webhook/1.0',
        },
        timeout: DELIVERY_TIMEOUT_MS,
      });

      await doc.ref.update({
        deliveries:   FieldValue.increment(1),
        lastDelivery: new Date(),
        lastStatus:   response.status,
      });

      res.json({
        success: true,
        data: { statusCode: response.status, message: 'Test delivered successfully' },
      });
    } catch (err: any) {
      await doc.ref.update({
        failures:    FieldValue.increment(1),
        lastFailure: new Date(),
        lastError:   err.message,
      });
      logger.warn(`Webhook test failed for ${id}:`, err.message);
      throw ApiError.badRequest(
        `Webhook delivery failed: ${err.message}`,
        'DELIVERY_FAILED'
      );
    }
  }),
};

// ── Utility: dispatch a webhook event to all matching subscriptions ─────────────
export async function dispatchWebhookEvent(
  userId: string,
  event: string,
  data: object
): Promise<void> {
  try {
    const snap = await db.collection('webhooks')
      .where('userId',  '==', userId)
      .where('active',  '==', true)
      .where('events', 'array-contains', event)
      .get();

    if (snap.empty) return;

    const payload = {
      event,
      timestamp: new Date().toISOString(),
      data,
    };
    const body = JSON.stringify(payload);

    await Promise.allSettled(snap.docs.map(async docSnap => {
      const wh        = docSnap.data();
      const signature = `sha256=${crypto.createHmac('sha256', wh.secret).update(body).digest('hex')}`;

      try {
        await axios.post(wh.url, payload, {
          headers: {
            'Content-Type':        'application/json',
            'X-WolfGPT-Signature': signature,
            'X-WolfGPT-Event':     event,
            'X-WolfGPT-Delivery':  generateId('del'),
            'User-Agent':          'WolfGPT-Webhook/1.0',
          },
          timeout: DELIVERY_TIMEOUT_MS,
        });
        await docSnap.ref.update({ deliveries: FieldValue.increment(1), lastDelivery: new Date() });
      } catch (err: any) {
        await docSnap.ref.update({ failures: FieldValue.increment(1), lastFailure: new Date() });
        logger.warn(`Webhook dispatch failed (${wh.url}):`, err.message);
      }
    }));
  } catch (err) {
    logger.error('dispatchWebhookEvent error:', err);
  }
}
