import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
import { asyncHandler, ApiError } from '../middleware/errorHandler';
import { db, storage, FieldValue } from '../config/firebase';
import { generateId } from '../utils/helpers';
import { TIER_LIMITS } from '../constants';
import axios from 'axios';
import multer from 'multer';
import logger from '../utils/logger';

const AI_URL = process.env.AI_SERVICE_URL || 'http://localhost:8000';

export const upload = multer({
  storage: multer.memoryStorage(),
  limits:  { fileSize: 20 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    ['image/png','image/jpeg','image/jpg','image/webp'].includes(file.mimetype)
      ? cb(null, true)
      : cb(new Error('Only PNG, JPEG, WEBP images are allowed'));
  },
});

// ── Helpers ───────────────────────────────────────────────────────────────────

async function checkImageLimit(uid: string, tier: string, count: number): Promise<void> {
  const daily = (TIER_LIMITS as any)[tier]?.images?.daily ?? 5;
  if (daily === -1) return;
  const doc  = await db.collection('users').doc(uid).get();
  const used = doc.data()?.usage?.images?.used || 0;
  if (used + count > daily) {
    throw ApiError.tooMany(
      `Daily image limit reached (${used}/${daily}). Upgrade for more.`,
      'LIMIT_EXCEEDED'
    );
  }
}

async function saveImages(
  uid: string,
  images: Array<{ base64: string; width: number; height: number; seed?: number; mode?: string }>,
  meta: Record<string, any>
): Promise<object[]> {
  const saved: object[] = [];
  for (const img of images) {
    const id       = generateId('img');
    const fileName = `images/${uid}/${id}.png`;
    const buf      = Buffer.from(img.base64, 'base64');

    const file = storage.bucket().file(fileName);
    await file.save(buf, { metadata: { contentType: 'image/png' } });
    await file.makePublic();

    const url = `https://storage.googleapis.com/${storage.bucket().name}/${fileName}`;
    const doc = { id, userId: uid, url, width: img.width, height: img.height, seed: img.seed ?? null, mode: img.mode || 'txt2img', ...meta, createdAt: new Date() };
    await db.collection('images').doc(id).set(doc);
    saved.push(doc);
  }
  return saved;
}

// ── Controllers ───────────────────────────────────────────────────────────────

export const imageController = {

  generateImage: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { prompt, negativePrompt, model = 'flux-schnell', width = 1024, height = 1024, steps = 4, numImages = 1, guidanceScale = 0, seed } = req.body;
    const uid  = req.user!.uid;
    const tier = req.user!.tier;

    if (!prompt?.trim()) throw ApiError.badRequest('prompt is required');
    await checkImageLimit(uid, tier, numImages);

    const aiRes = await axios.post(`${AI_URL}/v1/images/generate`,
      { prompt, negative_prompt: negativePrompt, model, width, height, steps, num_images: numImages, guidance_scale: guidanceScale, seed },
      { timeout: 180_000 }
    );

    const saved = await saveImages(uid, aiRes.data.images, { prompt, negativePrompt: negativePrompt || null, model, steps });
    await db.collection('users').doc(uid).update({ 'usage.images.used': FieldValue.increment(numImages) });
    res.json({ success: true, data: { images: saved, generationTime: aiRes.data.generation_time, mode: 'txt2img' } });
  }),

  imageToImage: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { prompt, referenceImage, negativePrompt, model = 'sdxl-base', width = 1024, height = 1024, steps = 30, strength = 0.75, guidanceScale = 7.5, numImages = 1, seed } = req.body;
    const uid  = req.user!.uid;
    const tier = req.user!.tier;

    if (!prompt?.trim())   throw ApiError.badRequest('prompt is required');
    if (!referenceImage)   throw ApiError.badRequest('referenceImage (base64) is required', 'MISSING_REFERENCE_IMAGE');
    await checkImageLimit(uid, tier, numImages);

    const aiRes = await axios.post(`${AI_URL}/v1/images/img2img`,
      { prompt, reference_image: referenceImage, negative_prompt: negativePrompt, model, width, height, steps, strength, guidance_scale: guidanceScale, num_images: numImages, seed },
      { timeout: 180_000 }
    );

    const saved = await saveImages(uid, aiRes.data.images, { prompt, negativePrompt: negativePrompt || null, model, steps, strength, mode: 'img2img' });
    await db.collection('users').doc(uid).update({ 'usage.images.used': FieldValue.increment(numImages) });
    res.json({ success: true, data: { images: saved, generationTime: aiRes.data.generation_time, mode: 'img2img' } });
  }),

  imageToImageUpload: asyncHandler(async (req: AuthRequest, res: Response) => {
    const file = (req as any).file as Express.Multer.File | undefined;
    if (!file) throw ApiError.badRequest('Reference image file is required', 'MISSING_FILE');

    const uid  = req.user!.uid;
    const tier = req.user!.tier;
    const { prompt, negativePrompt, model = 'sdxl-base', width = 1024, height = 1024, steps = 30, strength = 0.75, guidanceScale = 7.5, numImages = 1, seed } = req.body;

    if (!prompt?.trim()) throw ApiError.badRequest('prompt is required');
    await checkImageLimit(uid, tier, Number(numImages));

    // Save reference image
    const refId   = generateId('ref');
    const refPath = `reference/${uid}/${refId}`;
    const refFile = storage.bucket().file(refPath);
    await refFile.save(file.buffer, { metadata: { contentType: file.mimetype } });
    await refFile.makePublic();
    const refUrl = `https://storage.googleapis.com/${storage.bucket().name}/${refPath}`;

    const b64    = file.buffer.toString('base64');
    const aiRes  = await axios.post(`${AI_URL}/v1/images/img2img`,
      { prompt, reference_image: b64, negative_prompt: negativePrompt, model, width: Number(width), height: Number(height), steps: Number(steps), strength: Number(strength), guidance_scale: Number(guidanceScale), num_images: Number(numImages), seed: seed ? Number(seed) : undefined },
      { timeout: 180_000 }
    );

    const saved = await saveImages(uid, aiRes.data.images, { prompt, model, strength: Number(strength), mode: 'img2img', referenceImageUrl: refUrl });
    await db.collection('users').doc(uid).update({ 'usage.images.used': FieldValue.increment(Number(numImages)) });
    res.json({ success: true, data: { images: saved, referenceImageUrl: refUrl, generationTime: aiRes.data.generation_time, mode: 'img2img' } });
  }),

  inpaintImage: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { prompt, image, mask, negativePrompt, model = 'sdxl-base', width = 1024, height = 1024, steps = 30, strength = 0.99, guidanceScale = 7.5, seed } = req.body;
    const uid  = req.user!.uid;
    const tier = req.user!.tier;

    if (!prompt?.trim()) throw ApiError.badRequest('prompt is required');
    if (!image)          throw ApiError.badRequest('image (base64) is required');
    if (!mask)           throw ApiError.badRequest('mask (base64) is required');
    await checkImageLimit(uid, tier, 1);

    const aiRes = await axios.post(`${AI_URL}/v1/images/inpaint`,
      { prompt, image, mask, negative_prompt: negativePrompt, model, width, height, steps, strength, guidance_scale: guidanceScale, seed },
      { timeout: 180_000 }
    );

    const saved = await saveImages(uid, aiRes.data.images, { prompt, model, mode: 'inpaint' });
    await db.collection('users').doc(uid).update({ 'usage.images.used': FieldValue.increment(1) });
    res.json({ success: true, data: { images: saved, generationTime: aiRes.data.generation_time, mode: 'inpaint' } });
  }),

  upscaleImage: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { image, prompt = '', noiseLevel = 20 } = req.body;
    if (!image) throw ApiError.badRequest('image (base64) is required');

    const uid = req.user!.uid;
    const aiRes = await axios.post(`${AI_URL}/v1/images/upscale`,
      { image, prompt, noise_level: noiseLevel },
      { timeout: 300_000 }
    );

    const saved = await saveImages(uid, aiRes.data.images, { prompt: prompt || 'upscaled', model: 'sd-x4-upscaler', mode: 'upscale' });
    res.json({ success: true, data: { images: saved, generationTime: aiRes.data.generation_time, mode: 'upscale' } });
  }),

  imageVariations: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { prompt, referenceImage, negativePrompt, model = 'sdxl-base', width = 1024, height = 1024, steps = 30, numImages = 4, seed } = req.body;
    const uid  = req.user!.uid;
    const tier = req.user!.tier;

    if (!referenceImage) throw ApiError.badRequest('referenceImage (base64) is required', 'MISSING_REFERENCE_IMAGE');
    await checkImageLimit(uid, tier, numImages);

    const aiRes = await axios.post(`${AI_URL}/v1/images/variations`,
      { prompt: prompt || 'high quality variation', reference_image: referenceImage, negative_prompt: negativePrompt, model, width, height, steps, strength: 0.65, num_images: numImages, seed },
      { timeout: 180_000 }
    );

    const saved = await saveImages(uid, aiRes.data.images, { prompt: prompt || 'variation', model, mode: 'variations' });
    await db.collection('users').doc(uid).update({ 'usage.images.used': FieldValue.increment(numImages) });
    res.json({ success: true, data: { images: saved, generationTime: aiRes.data.generation_time, mode: 'variations' } });
  }),

  getGallery: asyncHandler(async (req: AuthRequest, res: Response) => {
    const uid    = req.user!.uid;
    const limit  = Math.min(parseInt(req.query.limit as string) || 50, 200);
    const mode   = req.query.mode as string | undefined;
    let query: any = db.collection('images').where('userId', '==', uid);
    if (mode) query = query.where('mode', '==', mode);
    const snap = await query.orderBy('createdAt', 'desc').limit(limit).get();
    res.json({ success: true, data: snap.docs.map((d: any) => d.data()) });
  }),

  getImage: asyncHandler(async (req: AuthRequest, res: Response) => {
    const doc = await db.collection('images').doc(req.params.id).get();
    if (!doc.exists) throw ApiError.notFound('Image not found');
    if (doc.data()!.userId !== req.user!.uid) throw ApiError.forbidden();
    res.json({ success: true, data: doc.data() });
  }),

  deleteImage: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { id } = req.params;
    const uid    = req.user!.uid;
    const doc    = await db.collection('images').doc(id).get();
    if (!doc.exists) throw ApiError.notFound('Image not found');
    if (doc.data()!.userId !== uid) throw ApiError.forbidden();
    await storage.bucket().file(`images/${uid}/${id}.png`).delete().catch(() => {});
    await doc.ref.delete();
    res.json({ success: true, data: { id, message: 'Image deleted' } });
  }),

  listModels: asyncHandler(async (_req: AuthRequest, res: Response) => {
    const aiRes = await axios.get(`${AI_URL}/v1/images/models`, { timeout: 10_000 });
    res.json({ success: true, data: aiRes.data });
  }),
};
