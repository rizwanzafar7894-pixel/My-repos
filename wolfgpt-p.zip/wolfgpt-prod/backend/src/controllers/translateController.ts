import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
import { asyncHandler, ApiError } from '../middleware/errorHandler';
import axios from 'axios';

const AI_URL = process.env.AI_SERVICE_URL || 'http://localhost:8000';

export const translateController = {
  translate: asyncHandler(async (req: AuthRequest, res: Response) => {
    const { text, targetLanguage, sourceLanguage } = req.body;

    const prompt = sourceLanguage
      ? `Translate the following text from ${sourceLanguage} to ${targetLanguage}. Output ONLY the translated text, no explanations:\n\n${text}`
      : `Translate the following text to ${targetLanguage}. Output ONLY the translated text, no explanations:\n\n${text}`;

    const aiRes = await axios.post(
      `${AI_URL}/v1/chat/completions`,
      {
        messages:   [{ role: 'user', content: prompt }],
        model:      'qwen-2.5-7b',
        max_tokens: Math.min(text.length * 3, 8192),
        temperature: 0.3, // lower temperature for accurate translation
        stream:     false,
      },
      { timeout: 60_000 }
    );

    const translated = aiRes.data.choices?.[0]?.message?.content;
    if (!translated) throw ApiError.internal('Translation service returned empty response');

    res.json({
      success: true,
      data: {
        original:       text,
        translated:     translated.trim(),
        targetLanguage,
        sourceLanguage: sourceLanguage || 'auto',
      },
    });
  }),
};
