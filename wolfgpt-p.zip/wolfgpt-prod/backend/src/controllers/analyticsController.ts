import { Response } from 'express';
import { AuthRequest } from '../middleware/auth';
import { asyncHandler, ApiError } from '../middleware/errorHandler';
import { db } from '../config/firebase';

export const analyticsController = {

  // Per-user analytics (available to all tiers)
  getUserAnalytics: asyncHandler(async (req: AuthRequest, res: Response) => {
    const uid   = req.user!.uid;
    const range = parseInt(req.query.days as string) || 30;
    const since = new Date(Date.now() - range * 86400_000);

    const [chatSnap, imgSnap, codeSnap, musicSnap, userSnap] = await Promise.all([
      db.collection('conversations').where('userId','==',uid).where('createdAt','>=',since).count().get(),
      db.collection('images')       .where('userId','==',uid).where('createdAt','>=',since).count().get(),
      db.collection('code_executions').where('userId','==',uid).where('createdAt','>=',since).count().get(),
      db.collection('music')        .where('userId','==',uid).where('createdAt','>=',since).count().get(),
      db.collection('users').doc(uid).get(),
    ]);

    const userData = userSnap.data();
    res.json({
      success: true,
      data: {
        period: { days: range, since: since.toISOString() },
        counts: {
          conversations: chatSnap.data().count,
          images:        imgSnap.data().count,
          codeRuns:      codeSnap.data().count,
          musicTracks:   musicSnap.data().count,
        },
        usage: userData?.usage || {},
        tier:  req.user!.tier,
      },
    });
  }),
};
