import { Response, NextFunction } from 'express';
import { AuthRequest } from './auth';
import { db } from '../config/firebase';
import { cacheGet, cacheSet } from '../utils/cache';

const ADMIN_EMAILS = (process.env.ADMIN_EMAILS || '').split(',').map(e => e.trim()).filter(Boolean);

export const adminMiddleware = async (
  req: AuthRequest, res: Response, next: NextFunction
): Promise<void> => {
  const uid = req.user?.uid;
  if (!uid) {
    res.status(401).json({ success: false, error: { code: 'UNAUTHORIZED', message: 'Authentication required' } });
    return;
  }

  // Check cache
  const cacheKey = `admin:${uid}`;
  const cached   = await cacheGet<boolean>(cacheKey);
  if (cached === true) return next();
  if (cached === false) {
    res.status(403).json({ success: false, error: { code: 'FORBIDDEN', message: 'Admin access required' } });
    return;
  }

  try {
    // Check Firestore for admin role
    const snap   = await db.collection('users').doc(uid).get();
    const isAdmin = snap.data()?.role === 'admin' || ADMIN_EMAILS.includes(snap.data()?.email || '');

    await cacheSet(cacheKey, isAdmin, 300);

    if (!isAdmin) {
      res.status(403).json({ success: false, error: { code: 'FORBIDDEN', message: 'Admin access required' } });
      return;
    }
    next();
  } catch {
    res.status(500).json({ success: false, error: { code: 'SERVER_ERROR', message: 'Admin check failed' } });
  }
};
