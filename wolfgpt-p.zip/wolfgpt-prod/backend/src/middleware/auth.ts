import { Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import { auth, db, FieldValue } from '../config/firebase';
import { cacheGet, cacheSet } from '../utils/cache';
import logger from '../utils/logger';

// ── Types ─────────────────────────────────────────────────────────────────────
export interface AuthUser {
  uid:   string;
  email: string;
  tier:  'free' | 'basic' | 'premium' | 'pro';
}

export interface AuthRequest extends Request {
  user?:      AuthUser;
  requestId?: string;
}

// ── Helpers ───────────────────────────────────────────────────────────────────
const hashKey = (k: string) => crypto.createHash('sha256').update(k).digest('hex');

async function getUserFromFirestore(uid: string): Promise<AuthUser | null> {
  try {
    const snap = await db.collection('users').doc(uid).get();
    if (!snap.exists) return null;
    const data = snap.data()!;
    return {
      uid,
      email: data.email || '',
      tier:  (data.tier as AuthUser['tier']) || 'free',
    };
  } catch (err) {
    logger.error('Firestore user fetch error:', err);
    return null;
  }
}

// ── Firebase token middleware ─────────────────────────────────────────────────
export const authMiddleware = async (
  req: AuthRequest, res: Response, next: NextFunction
): Promise<void> => {
  const header = req.headers.authorization;

  if (!header?.startsWith('Bearer ')) {
    res.status(401).json({
      success: false,
      error: { code: 'MISSING_TOKEN', message: 'Authorization: Bearer <token> header required' },
    });
    return;
  }

  const token    = header.slice(7);
  // Hash the full token for a collision-safe cache key (never store raw token)
  const cacheKey = `auth:${hashKey(token).slice(0, 32)}`;

  try {
    // Cache hit
    const cached = await cacheGet(cacheKey);
    if (cached) {
      req.user = cached;
      return next();
    }

    // Verify with Firebase Admin
    const decoded = await auth.verifyIdToken(token, true); // checkRevoked=true for security

    // Get user data from Firestore
    const user = await getUserFromFirestore(decoded.uid);
    if (!user) {
      // Auto-create user if missing (e.g. first login after Google OAuth)
      const newUser: AuthUser = {
        uid:   decoded.uid,
        email: decoded.email || '',
        tier:  'free',
      };
      // Create user document in background (don't block response)
      db.collection('users').doc(decoded.uid).set({
        uid:         decoded.uid,
        email:       decoded.email || '',
        displayName: decoded.name  || decoded.email?.split('@')[0] || 'User',
        photoURL:    decoded.picture || null,
        tier:        'free',
        usage: {
          chat:   { used: 0 },
          images: { used: 0 },
          code:   { used: 0 },
          voice:  { sttUsed: 0, ttsUsed: 0 },
          music:  { used: 0 },
          api:    { used: 0 },
        },
        createdAt: new Date(),
        updatedAt: new Date(),
      }, { merge: true }).catch(e => logger.error('Auto user create failed:', e));

      await cacheSet(cacheKey, newUser, 300);
      req.user = newUser;
      return next();
    }

    // Cache for 5 minutes
    await cacheSet(cacheKey, user, 300);
    req.user = user;
    next();
  } catch (err: unknown) {
    const code = (err as any)?.code === 'auth/id-token-revoked'
      ? 'TOKEN_REVOKED'
      : (err as any)?.code === 'auth/id-token-expired'
        ? 'TOKEN_EXPIRED'
        : 'INVALID_TOKEN';

    res.status(401).json({
      success: false,
      error: { code, message: 'Invalid or expired authentication token' },
    });
  }
};

// ── API key middleware ────────────────────────────────────────────────────────
export const apiKeyMiddleware = async (
  req: AuthRequest, res: Response, next: NextFunction
): Promise<void> => {
  const apiKey = (req.headers['x-api-key'] as string | undefined)
    || (req.query.api_key as string | undefined);

  if (!apiKey) {
    res.status(401).json({
      success: false,
      error: { code: 'MISSING_API_KEY', message: 'x-api-key header or api_key query parameter required' },
    });
    return;
  }

  const keyHash  = hashKey(apiKey);
  const cacheKey = `apikey:${keyHash.slice(0, 24)}`;

  try {
    // Cache hit
    const cached = await cacheGet(cacheKey);
    if (cached) {
      req.user = cached;
      // Async usage update — don't block the request
      db.collection('api_keys')
        .where('keyHash', '==', keyHash)
        .where('active', '==', true)
        .limit(1)
        .get()
        .then(snap => {
          if (!snap.empty) {
            snap.docs[0].ref.update({
              lastUsed:  new Date(),
              usage:     FieldValue.increment(1),
            });
          }
        })
        .catch(e => logger.warn('API key usage update failed:', e));
      return next();
    }

    // Look up key in Firestore
    const snap = await db
      .collection('api_keys')
      .where('keyHash', '==', keyHash)
      .where('active',  '==', true)
      .limit(1)
      .get();

    if (snap.empty) {
      res.status(401).json({
        success: false,
        error: { code: 'INVALID_API_KEY', message: 'Invalid or inactive API key' },
      });
      return;
    }

    const keyData  = snap.docs[0].data();
    const userSnap = await db.collection('users').doc(keyData.userId).get();

    if (!userSnap.exists) {
      res.status(401).json({
        success: false,
        error: { code: 'USER_NOT_FOUND', message: 'User associated with API key not found' },
      });
      return;
    }

    const userData = userSnap.data()!;
    const user: AuthUser = {
      uid:   keyData.userId,
      email: userData.email || '',
      tier:  (userData.tier as AuthUser['tier']) || 'free',
    };

    await cacheSet(cacheKey, user, 300);
    req.user = user;

    // Update usage stats async
    snap.docs[0].ref.update({
      lastUsed: new Date(),
      usage:    FieldValue.increment(1),
    }).catch(e => logger.warn('API key update failed:', e));

    next();
  } catch (err) {
    logger.error('API key auth error:', err);
    res.status(401).json({
      success: false,
      error: { code: 'AUTH_ERROR', message: 'API key authentication failed' },
    });
  }
};

// ── Optional auth (doesn't reject if no token) ────────────────────────────────
export const optionalAuth = async (
  req: AuthRequest, _res: Response, next: NextFunction
): Promise<void> => {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) return next();

  const token    = header.slice(7);
  const cacheKey = `auth:${hashKey(token).slice(0, 32)}`;

  try {
    const cached = await cacheGet(cacheKey);
    if (cached) { req.user = cached; return next(); }

    const decoded = await auth.verifyIdToken(token);
    const user    = await getUserFromFirestore(decoded.uid);
    if (user) {
      await cacheSet(cacheKey, user, 300);
      req.user = user;
    }
  } catch {
    // Silently ignore — optional auth
  }
  next();
};
