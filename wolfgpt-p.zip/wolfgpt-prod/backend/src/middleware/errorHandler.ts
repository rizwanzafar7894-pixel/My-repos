import { Request, Response, NextFunction } from 'express';
import logger from '../utils/logger';

// ── Custom API Error class ────────────────────────────────────────────────────
export class ApiError extends Error {
  readonly statusCode: number;
  readonly code:       string;
  readonly isOperational: boolean;

  constructor(statusCode: number, message: string, code = 'API_ERROR', isOperational = true) {
    super(message);
    this.name            = 'ApiError';
    this.statusCode      = statusCode;
    this.code            = code;
    this.isOperational   = isOperational;
    Object.setPrototypeOf(this, ApiError.prototype);
  }

  static badRequest(msg: string, code = 'BAD_REQUEST')      { return new ApiError(400, msg, code); }
  static unauthorized(msg = 'Unauthorized')                  { return new ApiError(401, msg, 'UNAUTHORIZED'); }
  static forbidden(msg = 'Access denied')                    { return new ApiError(403, msg, 'FORBIDDEN'); }
  static notFound(msg = 'Resource not found')                { return new ApiError(404, msg, 'NOT_FOUND'); }
  static conflict(msg: string, code = 'CONFLICT')            { return new ApiError(409, msg, code); }
  static tooMany(msg = 'Too many requests', code = 'RATE_LIMIT_EXCEEDED') { return new ApiError(429, msg, code); }
  static internal(msg = 'Internal server error')             { return new ApiError(500, msg, 'SERVER_ERROR', false); }
  static serviceUnavailable(msg = 'Service unavailable')     { return new ApiError(503, msg, 'SERVICE_UNAVAILABLE'); }
}

// ── Async handler wrapper ─────────────────────────────────────────────────────
export const asyncHandler = (
  fn: (req: any, res: Response, next: NextFunction) => Promise<any>
) => (req: Request, res: Response, next: NextFunction) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

// ── Global error handler middleware ───────────────────────────────────────────
export const errorHandler = (
  err: any,
  req: Request,
  res: Response,
  _next: NextFunction
): void => {
  const isDev     = process.env.NODE_ENV !== 'production';
  const requestId = (req as any).requestId || 'unknown';

  // Operational errors (expected, user-facing)
  if (err instanceof ApiError && err.isOperational) {
    res.status(err.statusCode).json({
      success: false,
      error: {
        code:      err.code,
        message:   err.message,
        requestId,
      },
    });
    return;
  }

  // Multer file size error
  if (err.code === 'LIMIT_FILE_SIZE') {
    res.status(413).json({
      success: false,
      error: { code: 'FILE_TOO_LARGE', message: 'File exceeds size limit', requestId },
    });
    return;
  }

  // Joi / express-validator validation error
  if (err.name === 'ValidationError' || err.isJoi) {
    res.status(400).json({
      success: false,
      error: { code: 'VALIDATION_ERROR', message: err.message, requestId },
    });
    return;
  }

  // Firebase auth errors
  if (err.code?.startsWith?.('auth/')) {
    res.status(401).json({
      success: false,
      error: { code: 'AUTH_ERROR', message: err.message, requestId },
    });
    return;
  }

  // CORS error
  if (err.message?.startsWith?.('CORS:')) {
    res.status(403).json({
      success: false,
      error: { code: 'CORS_ERROR', message: err.message, requestId },
    });
    return;
  }

  // SyntaxError in JSON body
  if (err instanceof SyntaxError && 'body' in err) {
    res.status(400).json({
      success: false,
      error: { code: 'INVALID_JSON', message: 'Invalid JSON in request body', requestId },
    });
    return;
  }

  // Unknown / unexpected errors
  logger.error(`[${requestId}] Unhandled error:`, {
    error:   err.message,
    stack:   err.stack,
    path:    req.path,
    method:  req.method,
    userId:  (req as any).user?.uid,
  });

  res.status(500).json({
    success: false,
    error: {
      code:      'SERVER_ERROR',
      message:   isDev ? err.message : 'An unexpected error occurred',
      requestId,
      ...(isDev && { stack: err.stack }),
    },
  });
};
