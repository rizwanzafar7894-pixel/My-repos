import { Response, NextFunction } from 'express';
import { AuthRequest } from './auth';
import { cacheIncr } from '../utils/cache';
import logger from '../utils/logger';

// ── Rate limit config per tier ────────────────────────────────────────────────
const RATE_LIMITS: Record<string, { perMinute: number; perHour: number; perDay: number }> = {
  free:    { perMinute: 10,  perHour: 100,   perDay:  500   },
  basic:   { perMinute: 30,  perHour: 500,   perDay:  5_000  },
  premium: { perMinute: 60,  perHour: 3_000, perDay:  50_000 },
  pro:     { perMinute: -1,  perHour: -1,    perDay:  -1    }, // unlimited
  anon:    { perMinute: 5,   perHour: 30,    perDay:  100   }, // unauthenticated
};

type Window = 'minute' | 'hour' | 'day';

const WINDOW_TTL: Record<Window, number> = { minute: 60, hour: 3_600, day: 86_400 };

/** Build a time-bucketed Redis key that naturally expires with the window */
function windowKey(id: string, window: Window): string {
  const now  = new Date();
  const y    = now.getUTCFullYear();
  const mo   = now.getUTCMonth();
  const d    = now.getUTCDate();
  const h    = now.getUTCHours();
  const min  = now.getUTCMinutes();

  const bucket =
    window === 'minute' ? `${y}-${mo}-${d}-${h}-${min}` :
    window === 'hour'   ? `${y}-${mo}-${d}-${h}` :
                          `${y}-${mo}-${d}`;

  return `rl:${window}:${id}:${bucket}`;
}

/** Timestamp (ms) when the given window next resets */
function windowReset(window: Window): number {
  const now = new Date();
  if (window === 'minute') {
    return new Date(now.getFullYear(), now.getMonth(), now.getDate(),
      now.getHours(), now.getMinutes() + 1).getTime();
  }
  if (window === 'hour') {
    return new Date(now.getFullYear(), now.getMonth(), now.getDate(),
      now.getHours() + 1).getTime();
  }
  return new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1).getTime();
}

/** Safely resolve the per-window limit — no dynamic string key lookup */
function limitFor(tier: string, window: Window): number {
  const cfg = RATE_LIMITS[tier] ?? RATE_LIMITS.free;
  if (window === 'minute') return cfg.perMinute;
  if (window === 'hour')   return cfg.perHour;
  return cfg.perDay;
}

interface WindowResult {
  allowed: boolean;
  count:   number;
  limit:   number;
  reset:   number;
}

async function checkWindow(id: string, tier: string, window: Window): Promise<WindowResult> {
  const limit = limitFor(tier, window);
  const reset = windowReset(window);

  if (limit === -1) return { allowed: true, count: 0, limit: -1, reset };

  const count = await cacheIncr(windowKey(id, window), WINDOW_TTL[window]);
  return { allowed: count <= limit, count, limit, reset };
}

// ── Rate limiter middleware ────────────────────────────────────────────────────
export const rateLimiter = async (
  req: AuthRequest, res: Response, next: NextFunction
): Promise<void> => {
  try {
    const id   = req.user?.uid || (req.ip ?? 'anonymous');
    const tier = req.user?.tier || 'anon';

    const [minResult, hrResult, dayResult] = await Promise.all([
      checkWindow(id, tier, 'minute'),
      checkWindow(id, tier, 'hour'),
      checkWindow(id, tier, 'day'),
    ]);

    // Always expose rate-limit headers
    res.setHeader('X-RateLimit-Limit-Minute',    minResult.limit);
    res.setHeader('X-RateLimit-Remaining-Minute', Math.max(0, minResult.limit - minResult.count));
    res.setHeader('X-RateLimit-Reset-Minute',     minResult.reset);

    const violations: [WindowResult, string][] = [
      [minResult, 'Per-minute rate limit exceeded. Please slow down.'],
      [hrResult,  'Hourly rate limit exceeded. Please try again later.'],
      [dayResult, 'Daily rate limit exceeded. Upgrade your plan for more requests.'],
    ];

    for (const [result, message] of violations) {
      if (!result.allowed) {
        res.status(429).json({
          success: false,
          error: {
            code:       'RATE_LIMIT_EXCEEDED',
            message,
            retryAfter: Math.ceil((result.reset - Date.now()) / 1_000),
            limit:      result.limit,
            used:       result.count,
          },
        });
        return;
      }
    }

    next();
  } catch (err) {
    // Fail open on Redis errors — availability > rate limiting
    logger.warn('Rate limiter error (allowing request):', err);
    next();
  }
};
