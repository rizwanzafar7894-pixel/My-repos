import { Response, NextFunction } from 'express';
import { AuthRequest } from './auth';

const TIER_RANK: Record<string, number> = { free: 0, basic: 1, premium: 2, pro: 3 };

/**
 * Require a minimum subscription tier to access a route.
 * Usage: router.use(requireTier('premium'))
 */
export const requireTier = (minimum: 'free' | 'basic' | 'premium' | 'pro') =>
  (req: AuthRequest, res: Response, next: NextFunction): void => {
    const userTier  = req.user?.tier || 'free';
    const userRank  = TIER_RANK[userTier]  ?? 0;
    const minRank   = TIER_RANK[minimum]   ?? 0;

    if (userRank < minRank) {
      res.status(403).json({
        success: false,
        error: {
          code:         'UPGRADE_REQUIRED',
          message:      `This feature requires the ${minimum} plan or higher. Your current plan: ${userTier}.`,
          currentTier:  userTier,
          requiredTier: minimum,
          upgradeUrl:   '/dashboard/billing',
        },
      });
      return;
    }
    next();
  };
