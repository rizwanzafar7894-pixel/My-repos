import 'dotenv/config';
import express, { Express, Request, Response, NextFunction } from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan';

// Firebase Admin — init on import
import './config/firebase';

// Routes
import apiV1Routes     from './routes/api/v1';
import authRoutes      from './routes/auth';
import adminRoutes     from './routes/admin.routes';
import stripeRoutes    from './routes/payment/stripe';
import jazzCashRoutes  from './routes/payment/jazzcash';
import easyPaisaRoutes from './routes/payment/easypaisa';

// Middleware
import { errorHandler } from './middleware/errorHandler';

// Background jobs
import { startUsageResetCron, startMonthlyUsageResetCron } from './jobs/usageReset';

// Utils
import logger from './utils/logger';
import { cacheDisconnect } from './utils/cache';

// ── Validate required env vars at startup ─────────────────────────────────────
const REQUIRED_ENV = ['FIREBASE_SERVICE_ACCOUNT', 'FIREBASE_STORAGE_BUCKET', 'REDIS_URL'];
const missing = REQUIRED_ENV.filter(k => !process.env[k]);
if (missing.length && process.env.NODE_ENV === 'production') {
  logger.error(`Missing required environment variables: ${missing.join(', ')}`);
  process.exit(1);
}

const app: Express = express();
const PORT = Number(process.env.PORT) || 4000;
const isProd = process.env.NODE_ENV === 'production';

// ── Security headers ──────────────────────────────────────────────────────────
app.use(helmet({
  contentSecurityPolicy: isProd ? undefined : false,
  crossOriginEmbedderPolicy: false,
}));

// ── CORS ──────────────────────────────────────────────────────────────────────
const allowedOrigins = (process.env.ALLOWED_ORIGINS || 'http://localhost:3000')
  .split(',')
  .map(o => o.trim());

app.use(cors({
  origin: (origin, cb) => {
    // Allow requests with no origin (curl, Postman, server-to-server)
    if (!origin || allowedOrigins.includes(origin)) return cb(null, true);
    cb(new Error(`CORS: origin ${origin} not allowed`));
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-API-Key', 'X-Request-ID'],
  exposedHeaders: ['X-RateLimit-Limit-Minute', 'X-RateLimit-Remaining-Minute', 'X-RateLimit-Reset-Minute'],
  maxAge: 86400, // preflight cache 24h
}));

// ── Compression ───────────────────────────────────────────────────────────────
app.use(compression());

// ── Request logging ───────────────────────────────────────────────────────────
app.use(morgan(isProd ? 'combined' : 'dev', {
  stream: { write: (msg: string) => logger.http(msg.trim()) },
  skip: (_req, res) => isProd && res.statusCode < 400, // prod: only log errors
}));

// ── Trust proxy (for rate limiting behind nginx) ──────────────────────────────
app.set('trust proxy', 1);

// ── Request ID ────────────────────────────────────────────────────────────────
app.use((req: Request, _res: Response, next: NextFunction) => {
  (req as any).requestId = req.headers['x-request-id'] || 
    `req_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
  next();
});

// ── Body parsing ──────────────────────────────────────────────────────────────
// Stripe webhook MUST receive raw body before express.json()
app.use('/api/payment/stripe/webhook', express.raw({ type: 'application/json' }));
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// ── Health check ──────────────────────────────────────────────────────────────
app.get('/health', (_req: Request, res: Response) => {
  res.json({
    status:    'healthy',
    service:   'wolfgpt-backend',
    version:   process.env.npm_package_version || '1.0.0',
    timestamp: new Date().toISOString(),
    uptime:    Math.floor(process.uptime()),
    env:       process.env.NODE_ENV || 'development',
  });
});

// ── API routes ────────────────────────────────────────────────────────────────
app.use('/api/v1',                apiV1Routes);
app.use('/api/auth',              authRoutes);
app.use('/api/admin',             adminRoutes);
app.use('/api/payment/stripe',    stripeRoutes);
app.use('/api/payment/jazzcash',  jazzCashRoutes);
app.use('/api/payment/easypaisa', easyPaisaRoutes);

// ── 404 handler ───────────────────────────────────────────────────────────────
app.use((req: Request, res: Response) => {
  res.status(404).json({
    success: false,
    error: {
      code:    'NOT_FOUND',
      message: `${req.method} ${req.path} not found`,
    },
  });
});

// ── Global error handler ──────────────────────────────────────────────────────
app.use(errorHandler);

// ── Start server ──────────────────────────────────────────────────────────────
const server = app.listen(PORT, () => {
  logger.info(`🐺  WolfGPT Backend      → http://localhost:${PORT}`);
  logger.info(`📡  API v1               → /api/v1`);
  logger.info(`💳  Payments             → /api/payment/{stripe|jazzcash|easypaisa}`);
  logger.info(`🌍  Environment          → ${process.env.NODE_ENV || 'development'}`);

  // Start background cron jobs
  startUsageResetCron();
  startMonthlyUsageResetCron();
});

// ── Graceful shutdown ─────────────────────────────────────────────────────────
const shutdown = (signal: string) => {
  logger.info(`${signal} received — shutting down gracefully`);
  server.close(async () => {
    await cacheDisconnect();
    logger.info('✅ HTTP server closed');
    process.exit(0);
  });
  // Force exit after 10s if connections don't close
  setTimeout(() => {
    logger.error('Forced exit after 10s timeout');
    process.exit(1);
  }, 10_000);
};

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));

// Catch unhandled errors — log but don't crash in production
process.on('uncaughtException',  (err) => {
  logger.error('Uncaught exception:', err);
  if (!isProd) process.exit(1);
});
process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled rejection:', reason);
});

export default app;
