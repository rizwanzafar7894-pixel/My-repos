import { Request, Response, NextFunction } from 'express';
import Joi from 'joi';

const VALID_MODELS = ['flux-schnell','flux-dev','flux-pro','sdxl-base','sdxl-refiner'];
const VALID_SIZES  = [256,512,768,1024,1280,1536,2048];

// ── Schemas ──────────────────────────────────────────────────────────────────

const txt2imgSchema = Joi.object({
  prompt:        Joi.string().required().min(3).max(2000),
  negativePrompt:Joi.string().optional().allow('').max(1000),
  model:         Joi.string().valid(...VALID_MODELS).optional(),
  width:         Joi.number().valid(...VALID_SIZES).optional(),
  height:        Joi.number().valid(...VALID_SIZES).optional(),
  steps:         Joi.number().integer().min(1).max(150).optional(),
  numImages:     Joi.number().integer().min(1).max(4).optional(),
  seed:          Joi.number().integer().optional(),
  guidanceScale: Joi.number().min(0).max(20).optional(),
});

const img2imgSchema = Joi.object({
  prompt:         Joi.string().required().min(1).max(2000),
  referenceImage: Joi.string().required().min(20)
    .description('Base64-encoded image (PNG/JPG/WEBP)'),
  negativePrompt: Joi.string().optional().allow('').max(1000),
  model:          Joi.string().valid(...VALID_MODELS).optional(),
  width:          Joi.number().valid(...VALID_SIZES).optional(),
  height:         Joi.number().valid(...VALID_SIZES).optional(),
  steps:          Joi.number().integer().min(1).max(150).optional(),
  strength:       Joi.number().min(0.01).max(1.0).optional()
    .description('0 = keep original, 1 = completely new image'),
  guidanceScale:  Joi.number().min(0).max(20).optional(),
  numImages:      Joi.number().integer().min(1).max(4).optional(),
  seed:           Joi.number().integer().optional(),
});

const inpaintSchema = Joi.object({
  prompt:         Joi.string().required().min(1).max(2000),
  image:          Joi.string().required().min(20).description('Base64 source image'),
  mask:           Joi.string().required().min(20).description('Base64 mask (white=repaint, black=keep)'),
  negativePrompt: Joi.string().optional().allow('').max(1000),
  model:          Joi.string().valid(...VALID_MODELS).optional(),
  width:          Joi.number().valid(...VALID_SIZES).optional(),
  height:         Joi.number().valid(...VALID_SIZES).optional(),
  steps:          Joi.number().integer().min(1).max(150).optional(),
  strength:       Joi.number().min(0.01).max(1.0).optional(),
  guidanceScale:  Joi.number().min(0).max(20).optional(),
  seed:           Joi.number().integer().optional(),
});

// ── Middleware factories ──────────────────────────────────────────────────────

function makeValidator(schema: Joi.ObjectSchema) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const { error } = schema.validate(req.body, { abortEarly: false });
    if (error) {
      res.status(400).json({
        success: false,
        error: {
          code: 'VALIDATION_ERROR',
          message: error.details.map(d => d.message).join('; '),
          fields: error.details.map(d => ({ field: d.path.join('.'), message: d.message })),
        },
      });
      return;
    }
    next();
  };
}

export const validateImageGeneration = makeValidator(txt2imgSchema);
export const validateImg2Img         = makeValidator(img2imgSchema);
export const validateInpaint         = makeValidator(inpaintSchema);
