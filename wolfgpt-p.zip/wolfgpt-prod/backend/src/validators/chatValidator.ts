import { Request, Response, NextFunction } from 'express';
import Joi from 'joi';

const messageSchema = Joi.object({
  role:    Joi.string().valid('user', 'assistant', 'system').required(),
  content: Joi.string().min(1).max(32000).required(),
});

const chatSchema = Joi.object({
  messages:     Joi.array().items(messageSchema).min(1).max(100).required(),
  model:        Joi.string().max(50).optional(),
  temperature:  Joi.number().min(0).max(2).optional(),
  maxTokens:    Joi.number().integer().min(1).max(32768).optional(),
  systemPrompt: Joi.string().max(4000).optional(),
});

const validate = (schema: Joi.Schema) =>
  (req: Request, res: Response, next: NextFunction): void => {
    const { error } = schema.validate(req.body, { abortEarly: false, stripUnknown: true });
    if (error) {
      res.status(400).json({
        success: false,
        error: {
          code:    'VALIDATION_ERROR',
          message: error.details.map(d => d.message).join('; '),
          fields:  error.details.map(d => ({ field: d.path.join('.'), message: d.message })),
        },
      });
      return;
    }
    next();
  };

export const validateChatCompletion = validate(chatSchema);
