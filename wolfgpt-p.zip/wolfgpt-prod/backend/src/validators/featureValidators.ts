import { Request, Response, NextFunction } from 'express';
import Joi from 'joi';

const makeValidator = (schema: Joi.Schema) =>
  (req: Request, res: Response, next: NextFunction): void => {
    const { error, value } = schema.validate(req.body, { abortEarly: false, stripUnknown: true });
    if (error) {
      res.status(400).json({
        success: false,
        error: {
          code:    'VALIDATION_ERROR',
          message: error.details.map(d => d.message).join('; '),
          fields:  error.details.map(d => ({ field: d.path.join('.'), message: d.message })),
        },
      });
      return;
    }
    req.body = value; // replace with stripped/validated values
    next();
  };

// Voice
export const validateSTT = makeValidator(Joi.object({
  language: Joi.string().length(2).optional().default('en'),
  model:    Joi.string().valid('tiny','base','small','medium','large','whisper-large-v3').optional(),
}));

export const validateTTS = makeValidator(Joi.object({
  text:  Joi.string().min(1).max(5000).required(),
  voice: Joi.string().max(50).optional(),
  speed: Joi.number().min(0.5).max(2.0).optional().default(1.0),
}));

// Code
export const validateCodeExecution = makeValidator(Joi.object({
  code:     Joi.string().min(1).max(50000).required(),
  language: Joi.string().valid('python','javascript','typescript','bash','go','rust').optional().default('python'),
  stdin:    Joi.string().max(10000).optional().allow('').default(''),
  timeout:  Joi.number().integer().min(1).max(300).optional(),
}));

// Summarize
export const validateSummarize = makeValidator(Joi.object({
  text:      Joi.string().min(50).max(100000).required(),
  maxLength: Joi.number().integer().min(50).max(5000).optional(),
  style:     Joi.string().valid('bullet', 'paragraph', 'tldr').optional().default('paragraph'),
}));

// Translate
export const validateTranslate = makeValidator(Joi.object({
  text:           Joi.string().min(1).max(50000).required(),
  targetLanguage: Joi.string().min(2).max(10).required(),
  sourceLanguage: Joi.string().min(2).max(10).optional(),
}));

// Music
export const validateMusicGenerate = makeValidator(Joi.object({
  prompt:      Joi.string().min(3).max(500).required(),
  model:       Joi.string().valid('musicgen-small','musicgen-medium','musicgen-large','musicgen-melody','musicgen-stereo-small','musicgen-stereo-medium').optional(),
  duration:    Joi.number().min(1).max(30).optional().default(8),
  temperature: Joi.number().min(0.1).max(2.0).optional().default(1.0),
  cfgCoef:     Joi.number().min(0).max(10).optional().default(3.0),
  numSamples:  Joi.number().integer().min(1).max(4).optional().default(1),
  seed:        Joi.number().integer().optional(),
}));

export const validateMelody = makeValidator(Joi.object({
  prompt:         Joi.string().min(1).max(500).required(),
  referenceAudio: Joi.string().min(20).required(),
  model:          Joi.string().optional(),
  duration:       Joi.number().min(1).max(30).optional().default(8),
  temperature:    Joi.number().min(0.1).max(2.0).optional().default(1.0),
  cfgCoef:        Joi.number().min(0).max(10).optional().default(3.0),
  seed:           Joi.number().integer().optional(),
}));
