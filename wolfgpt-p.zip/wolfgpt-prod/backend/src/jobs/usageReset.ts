import cron from 'node-cron';
import { db, FieldValue } from '../config/firebase';
import logger from '../utils/logger';

const PAGE_SIZE = 400; // Firestore batch write limit is 500

/**
 * Page through all users and reset a usage counter.
 * Uses FieldValue.delete() pattern — sets the field to 0 atomically.
 * dotted-path keys like 'usage.images.used' are supported by Firestore batch.update().
 */
async function resetUsageField(field: string, label: string): Promise<void> {
  let processed = 0;
  let lastDoc: FirebaseFirestore.QueryDocumentSnapshot | null = null;

  while (true) {
    // Only fetch the document reference — we don't need field data
    let q: FirebaseFirestore.Query = db.collection('users').limit(PAGE_SIZE);
    if (lastDoc) q = q.startAfter(lastDoc);

    const snap = await q.get();
    if (snap.empty) break;

    const batch = db.batch();
    snap.docs.forEach(doc => {
      batch.update(doc.ref, {
        [field]:               0,
        [`${field}ResetAt`]:   new Date(),
        'updatedAt':           new Date(),
      });
    });
    await batch.commit();

    processed += snap.size;
    lastDoc    = snap.docs[snap.docs.length - 1];

    // If we got fewer docs than page size, we're done
    if (snap.size < PAGE_SIZE) break;
  }

  logger.info(`✅ ${label} reset for ${processed} users`);
}

/** Reset daily usage counters — runs at 00:00 UTC every day */
export function startUsageResetCron(): void {
  cron.schedule('0 0 * * *', async () => {
    logger.info('⏰ Daily usage reset starting…');
    try {
      await Promise.all([
        resetUsageField('usage.images.used',    'Daily images'),
        resetUsageField('usage.code.used',       'Daily code'),
        resetUsageField('usage.music.used',      'Daily music'),
        resetUsageField('usage.voice.sttUsed',   'Daily STT'),
        resetUsageField('usage.voice.ttsUsed',   'Daily TTS'),
      ]);
      logger.info('✅ Daily usage reset complete');
    } catch (err) {
      logger.error('Daily usage reset failed:', err);
    }
  }, { timezone: 'UTC' });

  logger.info('⏰ Daily usage reset cron registered (00:00 UTC)');
}

/** Reset monthly API usage — runs on the 1st of each month at 00:05 UTC */
export function startMonthlyUsageResetCron(): void {
  cron.schedule('5 0 1 * *', async () => {
    logger.info('⏰ Monthly API usage reset starting…');
    try {
      await resetUsageField('usage.api.used', 'Monthly API');
      logger.info('✅ Monthly API usage reset complete');
    } catch (err) {
      logger.error('Monthly API reset failed:', err);
    }
  }, { timezone: 'UTC' });

  logger.info('⏰ Monthly API usage reset cron registered (1st of month, 00:05 UTC)');
}
