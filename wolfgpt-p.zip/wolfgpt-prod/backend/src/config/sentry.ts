import * as Sentry from "@sentry/node";
import { ProfilingIntegration } from "@sentry/profiling-node";
import { nodeProfilingIntegration } from '@sentry/profiling-node';

export function initSentry() {
  Sentry.init({
    dsn: process.env.SENTRY_DSN,
    environment: process.env.NODE_ENV || 'development',
    
    // Performance Monitoring
    tracesSampleRate: process.env.NODE_ENV === 'production' ? 0.1 : 1.0,
    
    // Profiling
    profilesSampleRate: process.env.NODE_ENV === 'production' ? 0.1 : 1.0,
    integrations: [
      nodeProfilingIntegration(),
    ],
    
    // Release tracking
    release: process.env.npm_package_version,
    
    // Error filtering
    beforeSend(event, hint) {
      // Don't send 404 errors
      if (event.exception?.values?.[0]?.type === 'NotFoundError') {
        return null;
      }
      
      // Don't send validation errors in production
      if (process.env.NODE_ENV === 'production' && 
          event.exception?.values?.[0]?.type === 'ValidationError') {
        return null;
      }
      
      return event;
    },
    
    // Ignore certain errors
    ignoreErrors: [
      'Non-Error exception captured',
      'Non-Error promise rejection captured',
    ],
    
    // Tag additional context
    initialScope: {
      tags: {
        'service': 'wolfgpt-backend',
        'node_version': process.version,
      },
    },
  });
}

// Express error handler middleware
export const sentryErrorHandler = Sentry.Handlers.errorHandler();

// Express request handler middleware
export const sentryRequestHandler = Sentry.Handlers.requestHandler();

// Express tracing handler
export const sentryTracingHandler = Sentry.Handlers.tracingHandler();

// Capture exceptions manually
export function captureException(error: Error, context?: any) {
  Sentry.withScope((scope) => {
    if (context) {
      scope.setContext('additional', context);
    }
    Sentry.captureException(error);
  });
}

// Capture messages
export function captureMessage(message: string, level: Sentry.SeverityLevel = 'info') {
  Sentry.captureMessage(message, level);
}

// Add breadcrumb
export function addBreadcrumb(breadcrumb: Sentry.Breadcrumb) {
  Sentry.addBreadcrumb(breadcrumb);
}

// Set user context
export function setUser(user: { id: string; email?: string; username?: string }) {
  Sentry.setUser(user);
}

// Clear user context
export function clearUser() {
  Sentry.setUser(null);
}
