import * as admin from 'firebase-admin';

// ══════════════════════════════════════════════════════════════════════════════
//  FIREBASE ADMIN SDK CONFIGURATION
//  ─────────────────────────────────────────────────────────────────────────────
//  Setup Steps:
//  1. Go to: https://console.firebase.google.com
//  2. Select your project → Project Settings (gear icon)
//  3. Service Accounts tab → "Generate new private key" → Download JSON
//  4. Save the downloaded file as:  firebase-admin-key.json  in project root
//  5. Set in backend/.env:
//       FIREBASE_SERVICE_ACCOUNT=./firebase-admin-key.json
//       FIREBASE_STORAGE_BUCKET=your-project-id.appspot.com
// ══════════════════════════════════════════════════════════════════════════════

const serviceAccount = process.env.FIREBASE_SERVICE_ACCOUNT
  ? JSON.parse(
      // Support both file path and inline JSON string
      process.env.FIREBASE_SERVICE_ACCOUNT.startsWith('{')
        ? process.env.FIREBASE_SERVICE_ACCOUNT
        : require('fs').readFileSync(process.env.FIREBASE_SERVICE_ACCOUNT, 'utf8')
    )
  : undefined;

if (!admin.apps.length) {
  admin.initializeApp({
    credential: serviceAccount
      ? admin.credential.cert(serviceAccount)
      : admin.credential.applicationDefault(), // fallback for GCP/Cloud Run

    // ADD YOUR FIREBASE STORAGE BUCKET HERE (in .env file) ↓
    // Format: your-project-id.appspot.com
    storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
  });
}

export const db        = admin.firestore();
export const auth      = admin.auth();
export const storage   = admin.storage();
export const FieldValue = admin.firestore.FieldValue;

export default admin;
