import express from 'express';
import crypto from 'crypto';
import { authMiddleware } from '../../middleware/auth';
import { asyncHandler } from '../../middleware/errorHandler';
import { db, FieldValue } from '../../config/firebase';
import { AuthRequest } from '../../middleware/auth';
import logger from '../../utils/logger';

// ══════════════════════════════════════════════════════════════════════════════
//  JAZZCASH PAYMENT GATEWAY (Pakistan)
//  ─────────────────────────────────────────────────────────────────────────────
//  Setup Steps:
//  1. Register at: https://sandbox.jazzcash.com.pk  (for testing)
//               or https://jazzcash.com.pk → "Become a Merchant" (for live)
//  2. After approval you will receive via email:
//     - Merchant ID (MC followed by numbers)
//     - Password
//     - Integrity Salt
//  3. Add to backend/.env:
//       JAZZCASH_MERCHANT_ID=MCxxxxxxxx
//       JAZZCASH_PASSWORD=your_password
//       JAZZCASH_INTEGRITY_SALT=your_salt
//       JAZZCASH_RETURN_URL=https://yourdomain.com/payment/jazzcash/callback
//  4. PKR amounts below — update if pricing changes
//     Basic: Rs.27,800/yr | Premium: Rs.55,600/yr | Pro: Rs.1,11,200/yr
// ══════════════════════════════════════════════════════════════════════════════

const router = express.Router();

const JAZZCASH_CONFIG = {
  merchantId:     process.env.JAZZCASH_MERCHANT_ID    || '',
  password:       process.env.JAZZCASH_PASSWORD        || '',
  integritySalt:  process.env.JAZZCASH_INTEGRITY_SALT  || '',
  returnUrl:      process.env.JAZZCASH_RETURN_URL       || '',
  // Sandbox vs live
  apiUrl: process.env.NODE_ENV === 'production'
    ? 'https://payments.jazzcash.com.pk/CustomerPortal/transactionmanagement/merchantform'
    : 'https://sandbox.jazzcash.com.pk/CustomerPortal/transactionmanagement/merchantform',
};

const PLAN_AMOUNTS: Record<string, Record<string, number>> = {
  basic:   { yearly: 27800 },   // PKR amounts
  premium: { yearly: 55600 },
  pro:     { yearly: 111200 },
};

const generateSecureHash = (params: Record<string, string>): string => {
  const sortedKeys = Object.keys(params).sort();
  const hashStr    = sortedKeys
    .filter(k => params[k] !== '')
    .map(k => params[k])
    .join('&');

  return crypto
    .createHmac('sha256', JAZZCASH_CONFIG.integritySalt)
    .update(`${JAZZCASH_CONFIG.integritySalt}&${hashStr}`)
    .digest('hex')
    .toUpperCase();
};

// Initiate JazzCash payment
router.post('/initiate', authMiddleware, asyncHandler(async (req: AuthRequest, res) => {
  const { tier, period = 'yearly' } = req.body;
  const userId = req.user!.uid;

  const amount = PLAN_AMOUNTS[tier]?.[period];
  if (!amount) {
    return res.status(400).json({ success: false, error: { message: 'Invalid plan', code: 'INVALID_PLAN' } });
  }

  const userDoc = await db.collection('users').doc(userId).get();
  const txnRef  = `WGPT-${Date.now()}-${userId.slice(0, 6)}`;
  const txnDate = new Date().toISOString().replace(/[-:T.]/g, '').slice(0, 14);
  const expiry  = new Date(Date.now() + 30 * 60 * 1000)
    .toISOString().replace(/[-:T.]/g, '').slice(0, 14);

  const params: Record<string, string> = {
    pp_Version:        '1.1',
    pp_TxnType:        'MWALLET',
    pp_Language:       'EN',
    pp_MerchantID:     JAZZCASH_CONFIG.merchantId,
    pp_Password:       JAZZCASH_CONFIG.password,
    pp_TxnRefNo:       txnRef,
    pp_Amount:         (amount * 100).toString(), // paisas
    pp_TxnCurrency:    'PKR',
    pp_TxnDateTime:    txnDate,
    pp_BillReference:  `wolfgpt_${tier}`,
    pp_Description:    `WolfGPT ${tier} plan (${period})`,
    pp_TxnExpiryDateTime: expiry,
    pp_ReturnURL:      JAZZCASH_CONFIG.returnUrl,
    pp_MobileNumber:   userDoc.data()?.phone || '',
    pp_CNIC:           '',
  };

  params.pp_SecureHash = generateSecureHash(params);

  // Store pending transaction
  await db.collection('pending_payments').doc(txnRef).set({
    userId, tier, period, amount, provider: 'jazzcash',
    txnRef, status: 'pending', createdAt: new Date(),
  });

  res.json({
    success: true,
    data: {
      txnRef,
      amount,
      currency: 'PKR',
      paymentUrl: JAZZCASH_CONFIG.apiUrl,
      params,      // POST these fields to paymentUrl
    },
  });
}));

// JazzCash callback
router.post('/callback', asyncHandler(async (req, res) => {
  const { pp_TxnRefNo, pp_ResponseCode, pp_SecureHash, ...rest } = req.body;

  // Verify secure hash
  const expectedHash = generateSecureHash(rest);
  if (expectedHash !== pp_SecureHash) {
    logger.warn('JazzCash: invalid hash on callback', { pp_TxnRefNo });
    return res.status(400).json({ success: false, error: 'Invalid signature' });
  }

  const pending = await db.collection('pending_payments').doc(pp_TxnRefNo).get();
  if (!pending.exists) return res.status(404).json({ success: false, error: 'Transaction not found' });

  const { userId, tier } = pending.data()!;
  const success = pp_ResponseCode === '000';

  if (success) {
    const expiresAt = new Date();
    expiresAt.setFullYear(expiresAt.getFullYear() + 1);

    await db.collection('users').doc(userId).update({
      tier,
      'subscription.status':     'active',
      'subscription.provider':   'jazzcash',
      'subscription.planId':     tier,
      'subscription.txnRef':     pp_TxnRefNo,
      'subscription.expiresAt':  expiresAt,
      'subscription.updatedAt':  new Date(),
    });
    logger.info(`✅ JazzCash payment success: ${userId} → ${tier}`);
  }

  await db.collection('pending_payments').doc(pp_TxnRefNo).update({
    status:    success ? 'completed' : 'failed',
    responseCode: pp_ResponseCode,
    updatedAt: new Date(),
  });

  // Redirect user back to frontend
  const redirectUrl = success
    ? `${process.env.FRONTEND_URL}/dashboard/billing?success=true`
    : `${process.env.FRONTEND_URL}/dashboard/billing?error=payment_failed`;

  res.redirect(302, redirectUrl);
}));

export default router;
