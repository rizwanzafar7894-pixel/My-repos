import express from 'express';
import Stripe from 'stripe';
import { authMiddleware } from '../../middleware/auth';
import { asyncHandler, ApiError } from '../../middleware/errorHandler';
import { db } from '../../config/firebase';
import { AuthRequest } from '../../middleware/auth';
import { rateLimiter } from '../../middleware/rateLimit';
import logger from '../../utils/logger';

// ══════════════════════════════════════════════════════════════════════════════
//  STRIPE PAYMENT GATEWAY
//  ─────────────────────────────────────────────────────────────────────────────
//  1. Create account: https://stripe.com
//  2. Dashboard → Developers → API Keys → copy Secret key
//  3. Dashboard → Products → create Basic, Premium, Pro with yearly prices
//     Copy each Price ID (price_XXXX)
//  4. Dashboard → Webhooks → Add endpoint:
//     URL: https://yourdomain.com/api/payment/stripe/webhook
//     Events: checkout.session.completed, customer.subscription.deleted,
//             customer.subscription.paused, invoice.payment_failed
//     Copy "Signing secret"
//  5. Add to backend/.env:
//       STRIPE_SECRET_KEY=sk_live_...
//       STRIPE_WEBHOOK_SECRET=whsec_...
//       STRIPE_PRICE_BASIC_YEARLY=price_...
//       STRIPE_PRICE_PREMIUM_YEARLY=price_...
//       STRIPE_PRICE_PRO_YEARLY=price_...
// ══════════════════════════════════════════════════════════════════════════════

const router = express.Router();

// Guard: don't crash if Stripe key is missing (dev mode)
const stripe = process.env.STRIPE_SECRET_KEY
  ? new Stripe(process.env.STRIPE_SECRET_KEY, { apiVersion: '2024-04-10' })
  : null;

// Price ID map — loaded from env vars
const PRICE_IDS: Record<string, Record<string, string>> = {
  basic:   { monthly: process.env.STRIPE_PRICE_BASIC_MONTHLY   || '', yearly: process.env.STRIPE_PRICE_BASIC_YEARLY    || '' },
  premium: { monthly: process.env.STRIPE_PRICE_PREMIUM_MONTHLY || '', yearly: process.env.STRIPE_PRICE_PREMIUM_YEARLY  || '' },
  pro:     { monthly: process.env.STRIPE_PRICE_PRO_MONTHLY     || '', yearly: process.env.STRIPE_PRICE_PRO_YEARLY      || '' },
};

// Reverse lookup: priceId → tier name
const TIER_BY_PRICE: Record<string, string> = Object.entries(PRICE_IDS)
  .reduce((acc, [tier, periods]) => {
    Object.values(periods).forEach(id => { if (id) acc[id] = tier; });
    return acc;
  }, {} as Record<string, string>);

function requireStripe() {
  if (!stripe) throw ApiError.serviceUnavailable('Stripe payments are not configured. Set STRIPE_SECRET_KEY in .env');
}

// ── Create checkout session ───────────────────────────────────────────────────
router.post('/checkout', rateLimiter, authMiddleware, asyncHandler(async (req: AuthRequest, res) => {
  requireStripe();
  const { tier, period = 'yearly' } = req.body;

  if (!tier || !['basic','premium','pro'].includes(tier)) {
    throw ApiError.badRequest('Invalid tier. Must be basic, premium, or pro', 'INVALID_PLAN');
  }

  const priceId = PRICE_IDS[tier]?.[period];
  if (!priceId) {
    throw ApiError.badRequest(`Price not configured for ${tier}/${period}. Set STRIPE_PRICE_${tier.toUpperCase()}_${period.toUpperCase()} in .env`, 'PRICE_NOT_CONFIGURED');
  }

  const userId  = req.user!.uid;
  const userDoc = await db.collection('users').doc(userId).get();
  const email   = userDoc.data()?.email;

  // Reuse or create Stripe customer
  let customerId = userDoc.data()?.stripeCustomerId;
  if (!customerId) {
    const customer = await stripe!.customers.create({
      email,
      metadata: { userId },
    });
    customerId = customer.id;
    await db.collection('users').doc(userId).update({ stripeCustomerId: customerId });
  }

  const session = await stripe!.checkout.sessions.create({
    customer:             customerId,
    payment_method_types: ['card'],
    line_items:           [{ price: priceId, quantity: 1 }],
    mode:                 'subscription',
    allow_promotion_codes: true,
    success_url:          `${process.env.FRONTEND_URL}/dashboard/billing?success=true&session_id={CHECKOUT_SESSION_ID}`,
    cancel_url:           `${process.env.FRONTEND_URL}/dashboard/billing?cancelled=true`,
    metadata:             { userId, tier, period },
    subscription_data: {
      metadata: { userId, tier },
    },
  });

  res.json({ success: true, data: { sessionId: session.id, url: session.url } });
}));

// ── Billing portal ────────────────────────────────────────────────────────────
router.post('/portal', rateLimiter, authMiddleware, asyncHandler(async (req: AuthRequest, res) => {
  requireStripe();
  const userId  = req.user!.uid;
  const userDoc = await db.collection('users').doc(userId).get();
  const customerId = userDoc.data()?.stripeCustomerId;

  if (!customerId) {
    throw ApiError.badRequest('No billing account found. Please subscribe first.', 'NO_CUSTOMER');
  }

  const session = await stripe!.billingPortal.sessions.create({
    customer:   customerId,
    return_url: `${process.env.FRONTEND_URL}/dashboard/billing`,
  });

  res.json({ success: true, data: { url: session.url } });
}));

// ── Stripe webhook (raw body required — registered before express.json()) ─────
router.post('/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
  if (!stripe) {
    res.status(503).send('Stripe not configured');
    return;
  }

  const sig    = req.headers['stripe-signature'] as string;
  const secret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!secret) {
    logger.error('STRIPE_WEBHOOK_SECRET is not set');
    res.status(500).send('Webhook secret missing');
    return;
  }

  let event: Stripe.Event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, secret);
  } catch (err: any) {
    logger.warn('Stripe webhook signature verification failed:', err.message);
    res.status(400).send(`Webhook Error: ${err.message}`);
    return;
  }

  try {
    switch (event.type) {

      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session;
        const userId  = session.metadata?.userId;
        const tier    = session.metadata?.tier;
        const subId   = session.subscription as string;

        if (userId && tier) {
          await db.collection('users').doc(userId).update({
            tier,
            'subscription.status':      'active',
            'subscription.stripeSubId': subId,
            'subscription.planId':      tier,
            'subscription.provider':    'stripe',
            'subscription.updatedAt':   new Date(),
          });
          logger.info(`Stripe: upgraded ${userId} → ${tier}`);
        }
        break;
      }

      case 'customer.subscription.updated': {
        const sub = event.data.object as Stripe.Subscription;
        if (sub.status === 'active') {
          // Tier may have changed (upgrade/downgrade)
          const priceId = sub.items.data[0]?.price?.id;
          const newTier = priceId ? TIER_BY_PRICE[priceId] : undefined;
          if (!newTier) break;

          const users = await db.collection('users').where('stripeCustomerId', '==', sub.customer).limit(1).get();
          if (!users.empty) {
            await users.docs[0].ref.update({
              tier: newTier,
              'subscription.status': 'active',
              'subscription.updatedAt': new Date(),
            });
            logger.info(`Stripe: updated subscription to ${newTier}`);
          }
        }
        break;
      }

      case 'customer.subscription.deleted':
      case 'customer.subscription.paused': {
        const sub   = event.data.object as Stripe.Subscription;
        const users = await db.collection('users').where('stripeCustomerId', '==', sub.customer).limit(1).get();
        if (!users.empty) {
          await users.docs[0].ref.update({
            tier: 'free',
            'subscription.status':    event.type === 'customer.subscription.deleted' ? 'cancelled' : 'paused',
            'subscription.updatedAt': new Date(),
          });
          logger.info(`Stripe: subscription ${event.type} for customer ${sub.customer}`);
        }
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object as Stripe.Invoice;
        const users   = await db.collection('users').where('stripeCustomerId', '==', invoice.customer).limit(1).get();
        if (!users.empty) {
          await users.docs[0].ref.update({
            'subscription.status':    'past_due',
            'subscription.updatedAt': new Date(),
          });
          logger.warn(`Stripe: payment failed for customer ${invoice.customer}`);
        }
        break;
      }

      case 'invoice.payment_succeeded': {
        // Renewal succeeded — keep tier active
        const invoice = event.data.object as Stripe.Invoice;
        const users   = await db.collection('users').where('stripeCustomerId', '==', invoice.customer).limit(1).get();
        if (!users.empty) {
          await users.docs[0].ref.update({
            'subscription.status':    'active',
            'subscription.updatedAt': new Date(),
          });
        }
        break;
      }

      default:
        // Unhandled event type — ignore silently
        break;
    }

    res.json({ received: true });
  } catch (err) {
    logger.error('Stripe webhook handler error:', err);
    res.status(500).send('Handler error');
  }
});

export default router;
