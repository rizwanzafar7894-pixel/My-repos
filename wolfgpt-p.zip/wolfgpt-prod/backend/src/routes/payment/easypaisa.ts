import express from 'express';
import crypto from 'crypto';
import axios from 'axios';
import { authMiddleware } from '../../middleware/auth';
import { asyncHandler } from '../../middleware/errorHandler';
import { db, FieldValue } from '../../config/firebase';
import { AuthRequest } from '../../middleware/auth';
import logger from '../../utils/logger';

// ══════════════════════════════════════════════════════════════════════════════
//  EASYPAISA PAYMENT GATEWAY (Pakistan)
//  ─────────────────────────────────────────────────────────────────────────────
//  Setup Steps:
//  1. Register at: https://easypaisa.com.pk → "Merchant Account"
//     OR test at:  https://easypaystg.easypaisa.com.pk
//  2. After approval you will receive:
//     - Store ID (numbers)
//     - Secret/Hash Key
//  3. Add to backend/.env:
//       EASYPAISA_STORE_ID=00000
//       EASYPAISA_SECRET_KEY=your_secret_key
//       EASYPAISA_CALLBACK_URL=https://yourdomain.com/payment/easypaisa/callback
//  4. Test credentials (sandbox):
//     Store ID: 14182 | Hash Key: abc123  (replace with yours)
// ══════════════════════════════════════════════════════════════════════════════

const router = express.Router();

const EP_CONFIG = {
  storeId:    process.env.EASYPAISA_STORE_ID    || '',
  secretKey:  process.env.EASYPAISA_SECRET_KEY  || '',
  callbackUrl: process.env.EASYPAISA_CALLBACK_URL || '',
  apiUrl: process.env.NODE_ENV === 'production'
    ? 'https://easypay.easypaisa.com.pk/tpay/InitializeMerchantTransactionAPI.json'
    : 'https://easypaystg.easypaisa.com.pk/tpay/InitializeMerchantTransactionAPI.json',
};

const PLAN_AMOUNTS: Record<string, Record<string, number>> = {
  basic:   { yearly: 27800 },
  premium: { yearly: 55600 },
  pro:     { yearly: 111200 },
};

const buildHash = (payload: Record<string, string>): string => {
  const sorted = Object.keys(payload).sort().map(k => payload[k]).join('&');
  return crypto.createHmac('sha256', EP_CONFIG.secretKey).update(sorted).digest('hex');
};

// Initiate EasyPaisa payment
router.post('/initiate', authMiddleware, asyncHandler(async (req: AuthRequest, res) => {
  const { tier, period = 'yearly', mobileNumber } = req.body;
  const userId = req.user!.uid;

  if (!mobileNumber) {
    return res.status(400).json({ success: false, error: { message: 'mobileNumber is required', code: 'MISSING_MOBILE' } });
  }

  const amount = PLAN_AMOUNTS[tier]?.[period];
  if (!amount) {
    return res.status(400).json({ success: false, error: { message: 'Invalid plan', code: 'INVALID_PLAN' } });
  }

  const orderId   = `WGPT${Date.now()}`;
  const txnDate   = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  const expiryDt  = new Date(Date.now() + 30 * 60 * 1000)
    .toISOString().replace('T', ' ').slice(0, 19);

  const payload: Record<string, string> = {
    storeId:           EP_CONFIG.storeId,
    amount:            amount.toFixed(2),
    postBackURL:       EP_CONFIG.callbackUrl,
    orderRefNum:       orderId,
    mobileNum:         mobileNumber,
    emailAddr:         '',
    merchantPaymentMethod: 'MA', // Mobile Account
    transactionType:   'InitialRequest',
    tokenExpiry:       expiryDt,
  };
  payload.hashValue = buildHash(payload);

  try {
    const response = await axios.post(EP_CONFIG.apiUrl, payload, {
      headers: {
        'Content-Type': 'application/json',
        'Credentials': Buffer.from(`${EP_CONFIG.storeId}:${EP_CONFIG.secretKey}`).toString('base64'),
      },
      timeout: 30000,
    });

    await db.collection('pending_payments').doc(orderId).set({
      userId, tier, period, amount, provider: 'easypaisa',
      orderId, mobileNumber, status: 'pending', createdAt: new Date(),
    });

    res.json({ success: true, data: { orderId, amount, currency: 'PKR', response: response.data } });
  } catch (error: any) {
    logger.error('EasyPaisa initiation error:', error.response?.data || error.message);
    res.status(500).json({ success: false, error: { message: 'EasyPaisa payment initiation failed', code: 'EP_ERROR' } });
  }
}));

// EasyPaisa callback
router.post('/callback', asyncHandler(async (req, res) => {
  const { orderRefNum, responseCode, paymentMethod } = req.body;

  const pending = await db.collection('pending_payments').doc(orderRefNum).get();
  if (!pending.exists) return res.status(404).send('Transaction not found');

  const { userId, tier } = pending.data()!;
  const success = responseCode === '0000';

  if (success) {
    const expiresAt = new Date();
    expiresAt.setFullYear(expiresAt.getFullYear() + 1);

    await db.collection('users').doc(userId).update({
      tier,
      'subscription.status':    'active',
      'subscription.provider':  'easypaisa',
      'subscription.planId':    tier,
      'subscription.orderId':   orderRefNum,
      'subscription.expiresAt': expiresAt,
      'subscription.updatedAt': new Date(),
    });
    logger.info(`✅ EasyPaisa payment success: ${userId} → ${tier}`);
  }

  await db.collection('pending_payments').doc(orderRefNum).update({
    status: success ? 'completed' : 'failed',
    responseCode, updatedAt: new Date(),
  });

  res.redirect(302, success
    ? `${process.env.FRONTEND_URL}/dashboard/billing?success=true`
    : `${process.env.FRONTEND_URL}/dashboard/billing?error=payment_failed`
  );
}));

export default router;
