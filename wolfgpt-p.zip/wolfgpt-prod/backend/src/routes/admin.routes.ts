import express from 'express';
import {
  getAnalytics,
  getAllUsers,
  suspendUser,
  activateUser,
  getSystemStats,
  exportData,
} from '../controllers/admin.controller';
import { authMiddleware } from '../middleware/auth';
import { adminMiddleware } from '../middleware/admin';

const router = express.Router();

// All admin routes require Firebase auth AND admin role
router.use(authMiddleware, adminMiddleware);

// Analytics
router.get('/analytics', getAnalytics);
router.get('/stats', getSystemStats);

// User management
router.get('/users', getAllUsers);
router.post('/users/:userId/suspend', suspendUser);
router.post('/users/:userId/activate', activateUser);

// Data export
router.get('/export/:dataType', exportData);

export default router;
