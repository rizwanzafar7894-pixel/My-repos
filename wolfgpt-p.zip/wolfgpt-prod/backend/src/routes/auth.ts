import express from 'express';
import { authController } from '../controllers/authController';
import { authMiddleware } from '../middleware/auth';
import { rateLimiter } from '../middleware/rateLimit';

const router = express.Router();

// Public — verify Firebase token (call after client-side login)
router.post('/verify',     rateLimiter, authController.verifyToken);

// Protected
router.get('/me',          rateLimiter, authMiddleware, authController.getMe);
router.patch('/me',        rateLimiter, authMiddleware, authController.updateMe);
router.get('/usage',       rateLimiter, authMiddleware, authController.getUsage);

// API Keys
router.post('/api-keys',        rateLimiter, authMiddleware, authController.createApiKey);
router.get('/api-keys',         rateLimiter, authMiddleware, authController.getApiKeys);
router.patch('/api-keys/:id/revoke', rateLimiter, authMiddleware, authController.revokeApiKey);
router.delete('/api-keys/:id',  rateLimiter, authMiddleware, authController.deleteApiKey);

export default router;
