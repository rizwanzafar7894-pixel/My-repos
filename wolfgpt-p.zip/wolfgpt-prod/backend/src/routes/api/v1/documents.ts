import express from 'express';
import multer from 'multer';
import { documentController } from '../../../controllers/documentController';

const upload = multer({
  storage: multer.memoryStorage(),
  limits:  { fileSize: 50 * 1024 * 1024 }, // 50 MB
});

const router = express.Router();

router.post('/upload',      upload.single('document'),  documentController.uploadDocument);
router.get('/',                                          documentController.getDocuments);
router.get('/:id',                                       documentController.getDocument);
router.post('/:id/chat',                                 documentController.chatWithDocument);
router.delete('/:id',                                    documentController.deleteDocument);

export default router;
