import express from 'express';
import { chatController } from '../../../controllers/chatController';
import { validateChatCompletion } from '../../../validators/chatValidator';

const router = express.Router();

router.post('/completions',        validateChatCompletion, chatController.createCompletion);
router.post('/completions/stream', validateChatCompletion, chatController.createStreamingCompletion);

// NOTE: /clear MUST be defined before /:id to prevent "clear" being treated as an id
router.delete('/clear', chatController.clearConversations);

router.get('/',       chatController.getConversations);
router.get('/:id',    chatController.getConversation);
router.patch('/:id',  chatController.updateConversation);
router.delete('/:id', chatController.deleteConversation);

export default router;
