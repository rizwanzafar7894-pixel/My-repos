import express from 'express';
import { imageController, upload } from '../../../controllers/imageController';
import { validateImageGeneration, validateImg2Img, validateInpaint } from '../../../validators/imageValidator';
import { rateLimiter } from '../../../middleware/rateLimit';

// NOTE: authMiddleware is already applied upstream in routes/api/v1/index.ts
// Do NOT re-apply it here — that would double-verify tokens and double-charge rate limits.

const router = express.Router();

// ── Text-to-Image ─────────────────────────────────────────────────────────────
router.post('/generate',       rateLimiter, validateImageGeneration, imageController.generateImage);

// ── Image-to-Image ────────────────────────────────────────────────────────────
router.post('/img2img',        rateLimiter, validateImg2Img,         imageController.imageToImage);
router.post('/img2img/upload', rateLimiter, upload.single('reference_image'), imageController.imageToImageUpload);

// ── Inpainting ────────────────────────────────────────────────────────────────
router.post('/inpaint',        rateLimiter, validateInpaint,         imageController.inpaintImage);

// ── Upscaling / Variations ────────────────────────────────────────────────────
router.post('/upscale',        rateLimiter,                          imageController.upscaleImage);
router.post('/variations',     rateLimiter,                          imageController.imageVariations);

// ── Gallery / CRUD ────────────────────────────────────────────────────────────
router.get('/gallery',                                                imageController.getGallery);
router.get('/models',                                                 imageController.listModels);
router.get('/:id',                                                    imageController.getImage);
router.delete('/:id',                                                 imageController.deleteImage);

export default router;
