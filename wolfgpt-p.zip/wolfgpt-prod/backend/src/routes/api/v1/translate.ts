import express from 'express';
import { translateController } from '../../../controllers/translateController';
import { validateTranslate } from '../../../validators/featureValidators';

const router = express.Router();
router.post('/', validateTranslate, translateController.translate);
export default router;
