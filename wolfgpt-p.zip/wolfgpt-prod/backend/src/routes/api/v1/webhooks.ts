import express from 'express';
import { webhookController } from '../controllers/webhookController';
import { authMiddleware } from '../middleware/auth';
import { requireTier } from '../middleware/requireTier';

const router = express.Router();
router.use(authMiddleware);
router.use(requireTier('pro'));   // webhooks are Pro-only

// CRUD for webhook endpoints
router.post('/',      webhookController.createWebhook);
router.get('/',       webhookController.getWebhooks);
router.get('/:id',    webhookController.getWebhook);
router.patch('/:id',  webhookController.updateWebhook);
router.delete('/:id', webhookController.deleteWebhook);

// Test a webhook
router.post('/:id/test', webhookController.testWebhook);

export default router;
