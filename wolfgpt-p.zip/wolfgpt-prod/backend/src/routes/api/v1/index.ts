import express from 'express';
import { authMiddleware, apiKeyMiddleware } from '../../../middleware/auth';
import { rateLimiter } from '../../../middleware/rateLimit';

import chatRoutes      from './chat';
import imageRoutes     from './images';
import voiceRoutes     from './voice';
import codeRoutes      from './code';
import documentRoutes  from './documents';
import translateRoutes from './translate';
import summarizeRoutes from './summarize';
import webhookRoutes   from './webhooks';
import analyticsRoutes from './analytics';
import musicRoutes     from './music';

const router = express.Router();

// All v1 routes require authentication (Firebase token OR API key)
// and are rate-limited per user/tier
const authenticate = [
  (req: any, res: any, next: any) => {
    // Support both Bearer token (Firebase) and X-API-Key
    const hasApiKey = req.headers['x-api-key'] || req.query.api_key;
    return hasApiKey ? apiKeyMiddleware(req, res, next) : authMiddleware(req, res, next);
  },
  rateLimiter,
];

router.use('/chat',      ...authenticate, chatRoutes);
router.use('/images',    ...authenticate, imageRoutes);
router.use('/voice',     ...authenticate, voiceRoutes);
router.use('/music',     ...authenticate, musicRoutes);
router.use('/code',      ...authenticate, codeRoutes);
router.use('/documents', ...authenticate, documentRoutes);
router.use('/translate', ...authenticate, translateRoutes);
router.use('/summarize', ...authenticate, summarizeRoutes);
router.use('/webhooks',  ...authenticate, webhookRoutes);
router.use('/analytics', ...authenticate, analyticsRoutes);

// API v1 health check
router.get('/health', (_req, res) => {
  res.json({
    success:   true,
    version:   'v1',
    message:   'WolfGPT API v1 is running',
    timestamp: new Date().toISOString(),
    endpoints: [
      'POST   /api/v1/chat/completions',
      'POST   /api/v1/chat/completions/stream',
      'POST   /api/v1/images/generate',
      'POST   /api/v1/images/img2img',
      'POST   /api/v1/images/img2img/upload',
      'POST   /api/v1/images/inpaint',
      'POST   /api/v1/images/upscale',
      'POST   /api/v1/voice/stt',
      'POST   /api/v1/voice/tts',
      'POST   /api/v1/music/generate',
      'POST   /api/v1/music/melody',
      'POST   /api/v1/code/execute',
      'POST   /api/v1/documents/upload',
      'POST   /api/v1/translate',
      'POST   /api/v1/summarize',
    ],
  });
});

export default router;
