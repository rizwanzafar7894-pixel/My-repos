import express from 'express';
import { codeController } from '../../../controllers/codeController';
import { validateCodeExecution } from '../../../validators/featureValidators';

const router = express.Router();

router.post('/execute',   validateCodeExecution, codeController.executeCode);
router.get('/history',                           codeController.getHistory);
router.get('/languages',                         codeController.getLanguages);

export default router;
