import express from 'express';
import { analyticsController } from '../../../controllers/analyticsController';

const router = express.Router();
router.get('/', analyticsController.getUserAnalytics);
export default router;
