import express from 'express';
import { summarizeController } from '../../../controllers/summarizeController';
import { validateSummarize } from '../../../validators/featureValidators';

const router = express.Router();
router.post('/', validateSummarize, summarizeController.summarize);
export default router;
