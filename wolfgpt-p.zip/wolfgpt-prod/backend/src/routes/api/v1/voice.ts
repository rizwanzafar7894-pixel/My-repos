import express from 'express';
import multer from 'multer';
import { voiceController } from '../../../controllers/voiceController';
import { validateTTS } from '../../../validators/featureValidators';

const upload = multer({
  storage: multer.memoryStorage(),
  limits:  { fileSize: 25 * 1024 * 1024 }, // 25 MB
  fileFilter: (_req, file, cb) => {
    const allowed = ['audio/wav','audio/mpeg','audio/mp3','audio/ogg','audio/webm','audio/flac','audio/mp4'];
    if (allowed.includes(file.mimetype) || file.originalname.match(/\.(wav|mp3|ogg|webm|flac|m4a)$/i)) {
      cb(null, true);
    } else {
      cb(new Error('Only audio files are allowed (wav, mp3, ogg, webm, flac)'));
    }
  },
});

const router = express.Router();

router.post('/stt',       upload.single('audio'), voiceController.speechToText);
router.post('/tts',       validateTTS,             voiceController.textToSpeech);
router.get('/voices',                              voiceController.getVoices);
router.get('/languages',                           voiceController.getLanguages);

export default router;
