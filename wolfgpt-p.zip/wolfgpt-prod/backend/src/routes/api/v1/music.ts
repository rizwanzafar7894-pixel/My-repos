import express from 'express';
import { musicController, musicUpload } from '../../../controllers/musicController';
import { validateMusicGenerate, validateMelody } from '../../../validators/featureValidators';
import { requireTier } from '../../../middleware/requireTier';

const router = express.Router();

router.post('/generate',         requireTier('free'),  validateMusicGenerate,              musicController.generateMusic);
router.post('/melody',           requireTier('basic'), validateMelody,                     musicController.melodyConditioned);
router.post('/melody/upload',    requireTier('basic'), musicUpload.single('reference_audio'), musicController.melodyUpload);
router.post('/continuation',     requireTier('basic'),                                     musicController.continuationMusic);
router.get('/library',                                                                      musicController.getLibrary);
router.get('/models',                                                                       musicController.listModels);
router.get('/:id',                                                                          musicController.getTrack);
router.delete('/:id',                                                                       musicController.deleteTrack);

export default router;
