// API Configuration
export const API_CONFIG = {
  BASE_URL: process.env.EXPO_PUBLIC_API_URL || 'https://api.wolfgpt.com/v1',
  API_KEY: process.env.EXPO_PUBLIC_API_KEY || '',
  TIMEOUT: 30000,
};

// Validate configuration
if (!API_CONFIG.API_KEY && process.env.NODE_ENV === 'production') {
  console.warn('⚠️  API_KEY not configured. Please set EXPO_PUBLIC_API_KEY in .env');
}

export default API_CONFIG;
