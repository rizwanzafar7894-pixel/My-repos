import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './screens/HomeScreen';
import ChatScreen from './screens/ChatScreen';
import ImagesScreen from './screens/ImagesScreen';
import VoiceScreen from './screens/VoiceScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Home"
        screenOptions={{
          headerStyle: { backgroundColor: '#6366f1' },
          headerTintColor: '#fff',
          headerTitleStyle: { fontWeight: 'bold' },
        }}
      >
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'WolfGPT' }} />
        <Stack.Screen name="Chat" component={ChatScreen} />
        <Stack.Screen name="Images" component={ImagesScreen} />
        <Stack.Screen name="Voice" component={VoiceScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
