# WolfGPT Mobile App

React Native mobile app for WolfGPT AI platform.

## Setup

```bash
npm install
npm start
```

## Run on Device

**iOS:**
```bash
npm run ios
```

**Android:**
```bash
npm run android
```

## Features

✅ Chat with AI
✅ Image generation
✅ Voice features (STT + TTS)
✅ Works on iOS & Android

## Build for Production

**iOS:**
```bash
expo build:ios
```

**Android:**
```bash
expo build:android
```
