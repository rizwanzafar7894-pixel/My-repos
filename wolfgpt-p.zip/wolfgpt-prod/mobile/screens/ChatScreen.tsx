import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, StyleSheet, ActivityIndicator } from 'react-native';
import { apiClient } from '../lib/api';

interface Message {
  role: 'user' | 'assistant';
  content: string;
}

export default function ChatScreen() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  async function sendMessage() {
    if (!input.trim()) return;

    const userMessage: Message = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await apiClient.createChatCompletion([...messages, userMessage]);
      const assistantMessage: Message = {
        role: 'assistant',
        content: response.data.message,
      };
      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Chat error:', error);
      setMessages(prev => [...prev, { role: 'assistant', content: 'Error: Could not get response' }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <View style={styles.container}>
      <ScrollView style={styles.messages}>
        {messages.map((msg, index) => (
          <View key={index} style={[
            styles.message,
            msg.role === 'user' ? styles.userMessage : styles.assistantMessage
          ]}>
            <Text style={[styles.messageText, msg.role === 'user' && styles.userText]}>
              {msg.content}
            </Text>
          </View>
        ))}
        {loading && <ActivityIndicator size="large" color="#6366f1" style={{ marginTop: 16 }} />}
      </ScrollView>

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          value={input}
          onChangeText={setInput}
          placeholder="Type your message..."
          multiline
        />
        <TouchableOpacity style={styles.sendButton} onPress={sendMessage} disabled={loading}>
          <Text style={styles.sendButtonText}>Send</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f9fafb' },
  messages: { flex: 1, padding: 16 },
  message: { padding: 12, borderRadius: 12, marginBottom: 8, maxWidth: '80%' },
  userMessage: { backgroundColor: '#6366f1', alignSelf: 'flex-end' },
  assistantMessage: { backgroundColor: '#fff', alignSelf: 'flex-start', borderWidth: 1, borderColor: '#e5e7eb' },
  messageText: { fontSize: 16, color: '#1f2937' },
  userText: { color: '#fff' },
  inputContainer: { flexDirection: 'row', padding: 16, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#e5e7eb' },
  input: { flex: 1, borderWidth: 1, borderColor: '#d1d5db', borderRadius: 12, padding: 12, marginRight: 8, maxHeight: 100 },
  sendButton: { backgroundColor: '#6366f1', paddingHorizontal: 20, paddingVertical: 12, borderRadius: 12, justifyContent: 'center' },
  sendButtonText: { color: '#fff', fontWeight: 'bold' },
});
