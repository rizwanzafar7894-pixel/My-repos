import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';

export default function HomeScreen({ navigation }: any) {
  const features = [
    { title: 'Chat', icon: '💬', screen: 'Chat', description: 'AI-powered conversations' },
    { title: 'Images', icon: '🖼️', screen: 'Images', description: 'Generate AI images' },
    { title: 'Voice', icon: '🎙️', screen: 'Voice', description: 'Speech-to-text & TTS' },
  ];

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Welcome to WolfGPT</Text>
        <Text style={styles.subtitle}>Your AI companion on mobile</Text>
      </View>

      <View style={styles.features}>
        {features.map((feature, index) => (
          <TouchableOpacity
            key={index}
            style={styles.featureCard}
            onPress={() => navigation.navigate(feature.screen)}
          >
            <Text style={styles.featureIcon}>{feature.icon}</Text>
            <Text style={styles.featureTitle}>{feature.title}</Text>
            <Text style={styles.featureDescription}>{feature.description}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f9fafb' },
  header: { padding: 24, backgroundColor: '#6366f1', borderBottomLeftRadius: 30, borderBottomRightRadius: 30 },
  title: { fontSize: 28, fontWeight: 'bold', color: '#fff', marginBottom: 8 },
  subtitle: { fontSize: 16, color: '#e0e7ff' },
  features: { padding: 16 },
  featureCard: { backgroundColor: '#fff', padding: 20, borderRadius: 16, marginBottom: 16, shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 8, elevation: 3 },
  featureIcon: { fontSize: 40, marginBottom: 12 },
  featureTitle: { fontSize: 20, fontWeight: 'bold', color: '#1f2937', marginBottom: 8 },
  featureDescription: { fontSize: 14, color: '#6b7280' },
});
