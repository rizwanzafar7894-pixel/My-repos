import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image, StyleSheet, ActivityIndicator, ScrollView } from 'react-native';
import { apiClient } from '../lib/api';

export default function ImagesScreen() {
  const [prompt, setPrompt] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [loading, setLoading] = useState(false);

  async function generateImage() {
    if (!prompt.trim()) return;

    setLoading(true);
    setImageUrl('');

    try {
      const response = await apiClient.generateImage(prompt, {
        width: 512,
        height: 512,
        model: 'flux-schnell',
      });

      const base64Image = response.data.images[0].base64;
      setImageUrl(`data:image/png;base64,${base64Image}`);
    } catch (error) {
      console.error('Image generation error:', error);
      alert('Failed to generate image. Please check your API key.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>AI Image Generation</Text>
        
        <TextInput
          style={styles.input}
          value={prompt}
          onChangeText={setPrompt}
          placeholder="Describe the image you want to generate..."
          multiline
        />

        <TouchableOpacity style={styles.button} onPress={generateImage} disabled={loading}>
          <Text style={styles.buttonText}>
            {loading ? 'Generating...' : 'Generate Image'}
          </Text>
        </TouchableOpacity>

        {loading && <ActivityIndicator size="large" color="#6366f1" style={{ marginTop: 32 }} />}

        {imageUrl && (
          <View style={styles.imageContainer}>
            <Image source={{ uri: imageUrl }} style={styles.image} resizeMode="contain" />
          </View>
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f9fafb' },
  content: { padding: 16 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 16, color: '#1f2937' },
  input: { borderWidth: 1, borderColor: '#d1d5db', borderRadius: 12, padding: 12, marginBottom: 16, minHeight: 100, backgroundColor: '#fff' },
  button: { backgroundColor: '#6366f1', padding: 16, borderRadius: 12, alignItems: 'center' },
  buttonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  imageContainer: { marginTop: 24, borderRadius: 12, overflow: 'hidden', backgroundColor: '#fff' },
  image: { width: '100%', height: 400 },
});
