import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import Voice from '@react-native-voice/voice';
import { Audio } from 'expo-av';
import axios from 'axios';

export default function VoiceScreen() {
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [loading, setLoading] = useState(false);

  async function startRecording() {
    try {
      await Voice.start('en-US');
      setIsRecording(true);
    } catch (error) {
      console.error('Recording error:', error);
    }
  }

  async function stopRecording() {
    try {
      await Voice.stop();
      setIsRecording(false);
    } catch (error) {
      console.error('Stop recording error:', error);
    }
  }

  async function synthesizeSpeech() {
    if (!transcript) return;

    setLoading(true);
    try {
      const response = await axios.post('https://api.wolfgpt.com/v1/voice/tts', {
        text: transcript,
        voice: 'en-US-female-1',
      }, {
        headers: { 'X-API-Key': 'YOUR_API_KEY' },
        responseType: 'arraybuffer',
      });

      const sound = new Audio.Sound();
      await sound.loadAsync({ uri: `data:audio/wav;base64,${Buffer.from(response.data).toString('base64')}` });
      await sound.playAsync();
    } catch (error) {
      console.error('TTS error:', error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Voice Features</Text>

      <TouchableOpacity
        style={[styles.button, isRecording && styles.recordingButton]}
        onPress={isRecording ? stopRecording : startRecording}
      >
        <Text style={styles.buttonText}>
          {isRecording ? '🔴 Stop Recording' : '🎙️ Start Recording'}
        </Text>
      </TouchableOpacity>

      {transcript && (
        <View style={styles.transcriptContainer}>
          <Text style={styles.transcriptLabel}>Transcript:</Text>
          <Text style={styles.transcript}>{transcript}</Text>
        </View>
      )}

      {transcript && (
        <TouchableOpacity style={styles.button} onPress={synthesizeSpeech} disabled={loading}>
          <Text style={styles.buttonText}>
            {loading ? 'Processing...' : '🔊 Play as Speech'}
          </Text>
        </TouchableOpacity>
      )}

      {loading && <ActivityIndicator size="large" color="#6366f1" style={{ marginTop: 32 }} />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16, backgroundColor: '#f9fafb' },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 24, color: '#1f2937' },
  button: { backgroundColor: '#6366f1', padding: 16, borderRadius: 12, alignItems: 'center', marginBottom: 16 },
  recordingButton: { backgroundColor: '#ef4444' },
  buttonText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  transcriptContainer: { backgroundColor: '#fff', padding: 16, borderRadius: 12, marginBottom: 16 },
  transcriptLabel: { fontSize: 14, fontWeight: 'bold', color: '#6b7280', marginBottom: 8 },
  transcript: { fontSize: 16, color: '#1f2937' },
});
