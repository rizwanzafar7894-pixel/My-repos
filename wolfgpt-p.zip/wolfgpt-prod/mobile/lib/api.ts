import axios, { AxiosInstance } from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_CONFIG } from '../config';

class APIClient {
  private client: AxiosInstance;
  private apiKey: string = '';

  constructor() {
    this.client = axios.create({
      baseURL: API_CONFIG.BASE_URL,
      timeout: API_CONFIG.TIMEOUT,
      headers: { 'Content-Type': 'application/json' },
    });
    this.loadApiKey();
    this.setupInterceptors();
  }

  private async loadApiKey() {
    try {
      const storedKey = await AsyncStorage.getItem('api_key');
      this.apiKey = storedKey || API_CONFIG.API_KEY;
    } catch (error) {
      this.apiKey = API_CONFIG.API_KEY;
    }
  }

  async setApiKey(key: string) {
    this.apiKey = key;
    await AsyncStorage.setItem('api_key', key);
  }

  private setupInterceptors() {
    this.client.interceptors.request.use(async (config) => {
      if (this.apiKey) config.headers['X-API-Key'] = this.apiKey;
      return config;
    });
  }

  async createChatCompletion(messages: any[]) {
    const response = await this.client.post('/chat/completions', { messages });
    return response.data;
  }

  async generateImage(prompt: string, options = {}) {
    const response = await this.client.post('/images/generate', { prompt, ...options });
    return response.data;
  }

  async transcribeAudio(audioData: any) {
    const formData = new FormData();
    formData.append('audio', audioData);
    const response = await this.client.post('/voice/stt', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return response.data;
  }

  async synthesizeSpeech(text: string, voice = 'en-US-female-1') {
    const response = await this.client.post('/voice/tts', { text, voice }, {
      responseType: 'arraybuffer',
    });
    return response.data;
  }
}

export const apiClient = new APIClient();
