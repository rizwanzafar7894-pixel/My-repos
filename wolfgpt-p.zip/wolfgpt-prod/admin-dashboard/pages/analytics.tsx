'use client';

import { useState, useEffect } from 'react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import {
  Users,
  DollarSign,
  Activity,
  TrendingUp,
  MessageSquare,
  Image,
  Mic,
  Code,
  FileText,
  Globe,
  Zap,
} from 'lucide-react';

interface AnalyticsData {
  users: {
    total: number;
    active: number;
    new: number;
    growth: number;
  };
  revenue: {
    total: number;
    mrr: number;
    arr: number;
    growth: number;
  };
  usage: {
    apiCalls: number;
    chatMessages: number;
    imagesGenerated: number;
    voiceMinutes: number;
  };
  performance: {
    uptime: number;
    avgResponseTime: number;
    errorRate: number;
  };
}

export default function AnalyticsDashboard() {
  const [timeRange, setTimeRange] = useState<'24h' | '7d' | '30d' | '90d'>('7d');
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics();
  }, [timeRange]);

  async function fetchAnalytics() {
    setLoading(true);
    try {
      const response = await fetch(`/api/admin/analytics?range=${timeRange}`);
      const data = await response.json();
      setAnalytics(data);
    } catch (error) {
      console.error('Failed to fetch analytics:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading || !analytics) {
    return <div className="p-8">Loading analytics...</div>;
  }

  // Sample data for charts
  const userGrowthData = [
    { date: 'Jan', users: 1200, active: 800 },
    { date: 'Feb', users: 1800, active: 1200 },
    { date: 'Mar', users: 2400, active: 1600 },
    { date: 'Apr', users: 3200, active: 2100 },
    { date: 'May', users: 4100, active: 2800 },
    { date: 'Jun', users: 5300, active: 3600 },
  ];

  const revenueData = [
    { month: 'Jan', revenue: 12000, costs: 4000 },
    { month: 'Feb', revenue: 18000, costs: 5000 },
    { month: 'Mar', revenue: 24000, costs: 6000 },
    { month: 'Apr', revenue: 32000, costs: 7000 },
    { month: 'May', revenue: 41000, costs: 8000 },
    { month: 'Jun', revenue: 53000, costs: 9000 },
  ];

  const tierDistribution = [
    { name: 'Free', value: 1200, color: '#6366f1' },
    { name: 'Basic', value: 800, color: '#8b5cf6' },
    { name: 'Premium', value: 400, color: '#ec4899' },
    { name: 'Pro', value: 150, color: '#f59e0b' },
  ];

  const apiUsageData = [
    { feature: 'Chat', calls: 45000 },
    { feature: 'Images', calls: 12000 },
    { feature: 'Voice', calls: 8000 },
    { feature: 'Code', calls: 5000 },
    { feature: 'Docs', calls: 3000 },
    { feature: 'Translate', calls: 2000 },
    { feature: 'Summarize', calls: 1500 },
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Analytics Dashboard</h1>
        <p className="text-gray-600 mt-2">Monitor your platform performance and growth</p>
      </div>

      {/* Time Range Selector */}
      <div className="mb-6 flex gap-2">
        {(['24h', '7d', '30d', '90d'] as const).map((range) => (
          <button
            key={range}
            onClick={() => setTimeRange(range)}
            className={`px-4 py-2 rounded-lg font-medium transition ${
              timeRange === range
                ? 'bg-indigo-600 text-white'
                : 'bg-white text-gray-700 hover:bg-gray-100'
            }`}
          >
            {range === '24h' ? 'Last 24 Hours' : range === '7d' ? 'Last 7 Days' : range === '30d' ? 'Last 30 Days' : 'Last 90 Days'}
          </button>
        ))}
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <MetricCard
          title="Total Users"
          value={analytics.users.total.toLocaleString()}
          change={analytics.users.growth}
          icon={<Users />}
          color="indigo"
        />
        <MetricCard
          title="Monthly Revenue"
          value={`$${(analytics.revenue.mrr / 1000).toFixed(1)}K`}
          change={analytics.revenue.growth}
          icon={<DollarSign />}
          color="green"
        />
        <MetricCard
          title="API Calls"
          value={analytics.usage.apiCalls.toLocaleString()}
          change={12.5}
          icon={<Activity />}
          color="blue"
        />
        <MetricCard
          title="Uptime"
          value={`${analytics.performance.uptime}%`}
          change={0.2}
          icon={<Zap />}
          color="purple"
        />
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* User Growth Chart */}
        <ChartCard title="User Growth">
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={userGrowthData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Area type="monotone" dataKey="users" stackId="1" stroke="#6366f1" fill="#6366f1" />
              <Area type="monotone" dataKey="active" stackId="2" stroke="#8b5cf6" fill="#8b5cf6" />
            </AreaChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Revenue Chart */}
        <ChartCard title="Revenue & Costs">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="revenue" fill="#10b981" />
              <Bar dataKey="costs" fill="#ef4444" />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* Tier Distribution */}
        <ChartCard title="User Tier Distribution">
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={tierDistribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                outerRadius={100}
                fill="#8884d8"
                dataKey="value"
              >
                {tierDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </ChartCard>

        {/* API Usage */}
        <ChartCard title="API Usage by Feature">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={apiUsageData} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis type="number" />
              <YAxis dataKey="feature" type="category" />
              <Tooltip />
              <Bar dataKey="calls" fill="#6366f1" />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      {/* Recent Activity */}
      <div className="mt-8">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-xl font-semibold mb-4">Recent Activity</h3>
          <div className="space-y-4">
            <ActivityItem
              icon={<MessageSquare className="w-5 h-5 text-blue-600" />}
              title="High chat usage detected"
              description="Chat API usage increased by 45% in the last hour"
              time="5 minutes ago"
            />
            <ActivityItem
              icon={<Image className="w-5 h-5 text-purple-600" />}
              title="Image generation spike"
              description="1,200 images generated in the past hour"
              time="15 minutes ago"
            />
            <ActivityItem
              icon={<Users className="w-5 h-5 text-green-600" />}
              title="New users milestone"
              description="Reached 5,000 total users"
              time="1 hour ago"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function MetricCard({
  title,
  value,
  change,
  icon,
  color,
}: {
  title: string;
  value: string;
  change: number;
  icon: React.ReactNode;
  color: 'indigo' | 'green' | 'blue' | 'purple';
}) {
  const colorClasses = {
    indigo: 'bg-indigo-100 text-indigo-600',
    green: 'bg-green-100 text-green-600',
    blue: 'bg-blue-100 text-blue-600',
    purple: 'bg-purple-100 text-purple-600',
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <p className="text-sm font-medium text-gray-600">{title}</p>
        <div className={`p-2 rounded-lg ${colorClasses[color]}`}>{icon}</div>
      </div>
      <div className="flex items-baseline justify-between">
        <p className="text-2xl font-bold text-gray-900">{value}</p>
        <div className={`flex items-center text-sm font-medium ${change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
          <TrendingUp className="w-4 h-4 mr-1" />
          {change >= 0 ? '+' : ''}{change}%
        </div>
      </div>
    </div>
  );
}

function ChartCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h3 className="text-lg font-semibold mb-4">{title}</h3>
      {children}
    </div>
  );
}

function ActivityItem({
  icon,
  title,
  description,
  time,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
  time: string;
}) {
  return (
    <div className="flex items-start gap-4">
      <div className="flex-shrink-0">{icon}</div>
      <div className="flex-1">
        <p className="font-medium text-gray-900">{title}</p>
        <p className="text-sm text-gray-600">{description}</p>
        <p className="text-xs text-gray-400 mt-1">{time}</p>
      </div>
    </div>
  );
}
