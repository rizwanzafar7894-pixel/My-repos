# 🎬 Video Tutorial Scripts

Professional video tutorial scripts for WolfGPT.

---

## Video 1: Getting Started (5 minutes)

**Title:** "WolfGPT API - Get Started in 5 Minutes"

**Script:**

```
[0:00 - Intro]
Hi! I'm going to show you how to start using WolfGPT API in just 5 minutes.

[0:15 - Sign Up]
First, head to wolfgpt.com and create an account.
Click "Sign Up" and enter your email and password.

[0:30 - Get API Key]
Once logged in, go to the API Keys section.
Click "Generate New Key" and give it a name like "My First Key".
Copy your API key - you'll only see this once!

[0:45 - Install SDK]
Now let's install the SDK. Open your terminal.

For JavaScript:
npm install @wolfgpt/sdk

For Python:
pip install wolfgpt

[1:15 - First Request]
Create a new file called "test.js"

[Show code]
import WolfGPT from '@wolfgpt/sdk';

const client = new WolfGPT({ 
  apiKey: 'YOUR_API_KEY_HERE' 
});

const response = await client.chat.create({
  messages: [
    { role: 'user', content: 'Hello, World!' }
  ]
});

console.log(response.message);

[2:00 - Run Code]
Run it:
node test.js

And there's your first AI response!

[2:30 - Try Image Generation]
Let's try generating an image:

[Show code]
const result = await client.images.generate({
  prompt: 'A beautiful sunset over mountains'
});

// Save the image
const fs = require('fs');
const buffer = Buffer.from(result.images[0].base64, 'base64');
fs.writeFileSync('sunset.png', buffer);

[3:30 - Voice Feature]
WolfGPT has FREE unlimited voice.
Let's try text-to-speech:

[Show code]
const audio = await client.voice.synthesize({
  text: 'Hello from WolfGPT!'
});

fs.writeFileSync('hello.wav', audio);

[4:00 - Next Steps]
That's it! You now know:
✓ How to get your API key
✓ Make chat requests
✓ Generate images
✓ Use voice features

[4:30 - Outro]
Check out the full documentation at docs.wolfgpt.com
Join our Discord for help
Thanks for watching!

[End]
```

---

## Video 2: Building a Chatbot (10 minutes)

**Title:** "Build an AI Chatbot with WolfGPT in 10 Minutes"

**Script:**

```
[0:00 - Intro]
Today we're building a complete chatbot with conversation memory.

[0:30 - Setup]
We'll use Node.js and Express.
npm init -y
npm install @wolfgpt/sdk express

[1:00 - Basic Server]
[Show code for Express server setup]

[3:00 - Conversation Memory]
[Show how to maintain message history]

[5:00 - Streaming Responses]
[Demonstrate SSE streaming]

[7:00 - Error Handling]
[Add rate limiting and error handling]

[9:00 - Test & Deploy]
[Show testing and deployment]

[10:00 - Outro]
```

---

## Video 3: Image Generation Masterclass (15 minutes)

**Title:** "AI Image Generation with FLUX - Complete Guide"

**Topics:**
- Understanding different models (Schnell, Dev, Pro)
- Writing effective prompts
- Negative prompts
- Image dimensions and aspect ratios
- Batch generation
- Using seeds for consistency
- Best practices

---

## Video 4: Voice-Enabled Apps (12 minutes)

**Title:** "Add Voice to Your App with WolfGPT"

**Topics:**
- Recording audio in browser
- Speech-to-text integration
- Getting chat responses
- Text-to-speech synthesis
- Building voice chat loop
- Voice selection and customization

---

## Video 5: Advanced Features (20 minutes)

**Title:** "Advanced WolfGPT - Code Execution, Documents & More"

**Topics:**
- Code execution sandbox
- Document parsing and chat
- Translation API
- Summarization styles
- Combining multiple features
- Building complex workflows
