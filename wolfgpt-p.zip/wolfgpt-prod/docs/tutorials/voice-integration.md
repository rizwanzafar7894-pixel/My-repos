# 🎙️ Voice Integration

Build voice-enabled apps.

## Speech-to-Text
```javascript
const audioFile = fs.readFileSync('recording.wav');
const transcript = await client.voice.transcribe({
  audio: audioFile,
  language: 'en',
  model: 'base'
});
console.log(transcript.text);
```

## Text-to-Speech
```javascript
const audio = await client.voice.synthesize({
  text: 'Hello from WolfGPT!',
  voice: 'en-US-female-1',
  speed: 1.0
});
fs.writeFileSync('output.wav', audio);
```

## Available Voices
- `en-US-female-1` - American English Female
- `en-US-male-1` - American English Male
- `en-GB-female-1` - British English Female
- `es-ES-female-1` - Spanish Female

## Voice Chat Loop
```javascript
// 1. Record audio
// 2. Transcribe
const transcript = await client.voice.transcribe({ audio });

// 3. Get chat response
const response = await client.chat.create({
  messages: [{ role: 'user', content: transcript.text }]
});

// 4. Synthesize response
const audio = await client.voice.synthesize({ text: response.message });

// 5. Play audio
```
