# 🖼️ Image Generation Tutorial

Generate AI images with FLUX and SDXL.

## Basic Generation
```javascript
const result = await client.images.generate({
  prompt: 'A futuristic city at sunset',
  width: 1024,
  height: 1024
});

// Save image
const buffer = Buffer.from(result.images[0].base64, 'base64');
fs.writeFileSync('city.png', buffer);
```

## Advanced Options
```javascript
await client.images.generate({
  prompt: 'A cute cartoon wolf mascot',
  negative_prompt: 'realistic, scary',
  model: 'flux-schnell',
  width: 1024,
  height: 1024,
  steps: 4,
  num_images: 3,
  seed: 42 // For reproducibility
});
```

## Models Comparison

| Model | Speed | Quality | Cost |
|---|---|---|---|
| flux-schnell | Fastest | Good | Cheapest |
| flux-dev | Medium | Better | Medium |
| flux-pro | Slow | Best | Expensive |
| sdxl-base | Medium | Good | Medium |
