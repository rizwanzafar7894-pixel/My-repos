# 💬 Chat Tutorial

Learn to build conversational AI apps.

## Basic Chat
```javascript
const response = await client.chat.create({
  messages: [
    { role: 'user', content: 'What is Python?' }
  ]
});
```

## Multi-turn Conversation
```javascript
const messages = [];

// Turn 1
messages.push({ role: 'user', content: 'What is Python?' });
const res1 = await client.chat.create({ messages });
messages.push({ role: 'assistant', content: res1.message });

// Turn 2
messages.push({ role: 'user', content: 'Show me an example' });
const res2 = await client.chat.create({ messages });
```

## System Messages
```javascript
await client.chat.create({
  messages: [
    { role: 'system', content: 'You are a helpful coding assistant' },
    { role: 'user', content: 'Help me debug this code' }
  ]
});
```

## Streaming
```javascript
await client.chat.stream(
  { messages: [...] },
  (chunk) => process.stdout.write(chunk)
);
```
