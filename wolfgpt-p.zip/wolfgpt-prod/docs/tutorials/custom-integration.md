# 🔌 Custom Integration Guide

Build custom integrations with WolfGPT.

---

## Overview

This guide shows how to integrate WolfGPT into various platforms and frameworks.

---

## Next.js Integration

### API Route
```typescript
// pages/api/chat.ts
import type { NextApiRequest, NextApiResponse } from 'next';
import WolfGPT from '@wolfgpt/sdk';

const client = new WolfGPT({ apiKey: process.env.WOLFGPT_API_KEY! });

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { messages } = req.body;

  try {
    const response = await client.chat.create({ messages });
    res.status(200).json(response);
  } catch (error) {
    res.status(500).json({ error: 'Internal server error' });
  }
}
```

### Client Component
```typescript
'use client';
import { useState } from 'react';

export default function ChatWidget() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  const sendMessage = async () => {
    const newMessages = [...messages, { role: 'user', content: input }];
    
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages: newMessages })
    });
    
    const data = await response.json();
    setMessages([...newMessages, { role: 'assistant', content: data.message }]);
    setInput('');
  };

  return (
    <div>
      {messages.map((msg, i) => (
        <div key={i}>{msg.content}</div>
      ))}
      <input value={input} onChange={e => setInput(e.target.value)} />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
}
```

---

## React Integration

### Custom Hook
```typescript
import { useState, useCallback } from 'react';
import WolfGPT from '@wolfgpt/sdk';

export function useWolfGPT() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const client = new WolfGPT({ apiKey: process.env.REACT_APP_WOLFGPT_KEY });

  const chat = useCallback(async (messages) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await client.chat.create({ messages });
      return response;
    } catch (err) {
      setError(err);
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  return { chat, loading, error };
}
```

---

## Discord Bot Integration

```javascript
const { Client, GatewayIntentBits } = require('discord.js');
const WolfGPT = require('wolfgpt');

const discord = new Client({ 
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages] 
});

const wolfgpt = new WolfGPT({ apiKey: process.env.WOLFGPT_API_KEY });

discord.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  if (!message.content.startsWith('!wolf')) return;

  const prompt = message.content.slice(6);
  
  const response = await wolfgpt.chat.create({
    messages: [{ role: 'user', content: prompt }]
  });

  message.reply(response.message);
});

discord.login(process.env.DISCORD_TOKEN);
```

---

## Telegram Bot

```javascript
const TelegramBot = require('node-telegram-bot-api');
const WolfGPT = require('wolfgpt');

const telegram = new TelegramBot(process.env.TELEGRAM_TOKEN, { polling: true });
const wolfgpt = new WolfGPT({ apiKey: process.env.WOLFGPT_API_KEY });

telegram.onText(/\/start/, (msg) => {
  telegram.sendMessage(msg.chat.id, 'Hello! Send me a message and I\'ll respond using AI.');
});

telegram.on('message', async (msg) => {
  if (msg.text.startsWith('/')) return;

  const response = await wolfgpt.chat.create({
    messages: [{ role: 'user', content: msg.text }]
  });

  telegram.sendMessage(msg.chat.id, response.message);
});
```

---

## Slack Bot

```javascript
const { App } = require('@slack/bolt');
const WolfGPT = require('wolfgpt');

const app = new App({
  token: process.env.SLACK_BOT_TOKEN,
  signingSecret: process.env.SLACK_SIGNING_SECRET
});

const wolfgpt = new WolfGPT({ apiKey: process.env.WOLFGPT_API_KEY });

app.message(async ({ message, say }) => {
  const response = await wolfgpt.chat.create({
    messages: [{ role: 'user', content: message.text }]
  });

  await say(response.message);
});

app.start(process.env.PORT || 3000);
```

---

## WordPress Plugin

```php
<?php
/*
Plugin Name: WolfGPT Chat
Description: Add AI chat to your WordPress site
Version: 1.0
*/

function wolfgpt_chat_shortcode() {
    ?>
    <div id="wolfgpt-chat"></div>
    <script>
        // Load chat widget
        (function() {
            const script = document.createElement('script');
            script.src = 'https://cdn.wolfgpt.com/widget.js';
            script.dataset.apiKey = '<?php echo get_option('wolfgpt_api_key'); ?>';
            document.body.appendChild(script);
        })();
    </script>
    <?php
}

add_shortcode('wolfgpt_chat', 'wolfgpt_chat_shortcode');
```

---

## Mobile Apps

### React Native
```typescript
import WolfGPT from '@wolfgpt/sdk';

const client = new WolfGPT({ apiKey: 'YOUR_KEY' });

export async function getChatResponse(message: string) {
  const response = await client.chat.create({
    messages: [{ role: 'user', content: message }]
  });
  return response.message;
}
```

### Flutter
```dart
import 'package:http/http.dart' as http;
import 'dart:convert';

Future<String> getChatResponse(String message) async {
  final response = await http.post(
    Uri.parse('https://api.wolfgpt.com/v1/chat/completions'),
    headers: {
      'Content-Type': 'application/json',
      'X-API-Key': 'YOUR_KEY',
    },
    body: jsonEncode({
      'messages': [
        {'role': 'user', 'content': message}
      ]
    }),
  );

  final data = jsonDecode(response.body);
  return data['data']['message'];
}
```
