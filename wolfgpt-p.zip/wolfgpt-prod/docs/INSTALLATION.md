# Installation Guide

## Prerequisites

- Docker 24+ & Docker Compose
- Node.js 20+
- Python 3.11+
- 8GB RAM minimum
- 20GB disk space

## Quick Install (Recommended)

```bash
git clone https://github.com/yourusername/wolfgpt.git
cd wolfgpt
make install
make docker-up
```

Visit http://localhost:3000

## Manual Install

### 1. Install Dependencies

```bash
npm install
cd frontend && npm install
cd ../backend && npm install
cd ../admin && npm install
```

### 2. Configure Environment

```bash
cp frontend/.env.example frontend/.env.local
cp backend/.env.example backend/.env
cp ai-services/.env.example ai-services/.env
```

Edit each .env file with your credentials.

### 3. Start Services

```bash
# With Docker
docker-compose up -d

# Or manually
npm run dev
```

## Production Install

See [DEPLOYMENT.md](DEPLOYMENT.md)

## Troubleshooting

**Port conflicts:**
```bash
lsof -ti:3000 | xargs kill -9
```

**Docker issues:**
```bash
docker system prune -a
```

**Need help?** Open an issue or join [Discord](https://discord.gg/wolfgpt)
