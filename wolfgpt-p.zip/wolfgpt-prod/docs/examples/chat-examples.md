# 💬 Chat Examples

## Simple Q&A
```javascript
const response = await client.chat.create({
  messages: [{ role: 'user', content: 'What is the capital of France?' }]
});
```

## Code Assistant
```javascript
await client.chat.create({
  messages: [
    { role: 'system', content: 'You are an expert Python developer' },
    { role: 'user', content: 'How do I reverse a list in Python?' }
  ]
});
```

## Translation
```javascript
await client.chat.create({
  messages: [
    { role: 'system', content: 'Translate to Spanish' },
    { role: 'user', content: 'Hello, how are you?' }
  ]
});
```

## Creative Writing
```javascript
await client.chat.create({
  messages: [
    { role: 'system', content: 'You are a creative writer' },
    { role: 'user', content: 'Write a short story about a wolf' }
  ],
  temperature: 0.9 // More creative
});
```
