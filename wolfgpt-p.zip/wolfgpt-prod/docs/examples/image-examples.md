# 🖼️ Image Generation Examples

## Landscape
```javascript
await client.images.generate({
  prompt: 'Mountain landscape at golden hour, cinematic'
});
```

## Portrait
```javascript
await client.images.generate({
  prompt: 'Professional headshot, studio lighting',
  width: 512,
  height: 768
});
```

## Logo Design
```javascript
await client.images.generate({
  prompt: 'Modern tech company logo, minimalist, blue and white',
  width: 512,
  height: 512
});
```

## Multiple Variations
```javascript
const result = await client.images.generate({
  prompt: 'Cartoon wolf mascot',
  num_images: 4
});

result.images.forEach((img, i) => {
  fs.writeFileSync(`wolf_${i}.png`, Buffer.from(img.base64, 'base64'));
});
```
