# Production Deployment Guide

## Quick Deploy

```bash
./scripts/deploy-production.sh
```

## Prerequisites

- Ubuntu 22.04 LTS server
- 4+ CPU cores
- 16GB+ RAM
- 100GB+ SSD
- Domain name configured

## Step-by-Step

### 1. Server Setup

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Docker
curl -fsSL https://get.docker.com | sudo sh
sudo usermod -aG docker $USER

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
```

### 2. Clone & Configure

```bash
git clone https://github.com/yourusername/wolfgpt.git
cd wolfgpt
cp .env.production.example .env.production
nano .env.production  # Edit with production values
```

### 3. SSL Setup

```bash
sudo apt install -y certbot
sudo certbot certonly --standalone -d wolfgpt.com -d www.wolfgpt.com
```

### 4. Deploy

```bash
./scripts/deploy-production.sh
```

### 5. Monitoring

```bash
# Check health
./scripts/health-check.sh

# View logs
docker-compose -f docker-compose.prod.yml logs -f
```

## Kubernetes Deployment

```bash
kubectl apply -f infrastructure/kubernetes/
kubectl get pods -n production
```

## AWS Deployment

```bash
cd infrastructure/terraform/aws
terraform init
terraform apply
```

## Rollback

```bash
./scripts/rollback.sh previous
```

## Support

- Email: devops@wolfgpt.com
- Docs: https://docs.wolfgpt.com/deployment
