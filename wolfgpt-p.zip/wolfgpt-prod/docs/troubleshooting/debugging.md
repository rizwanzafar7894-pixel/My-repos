# 🐛 Debugging Guide

## Enable Debug Logging

**JavaScript:**
```javascript
const client = new WolfGPT({
  apiKey: 'YOUR_KEY',
  debug: true // Logs all requests
});
```

**Python:**
```python
import logging
logging.basicConfig(level=logging.DEBUG)

client = WolfGPT(api_key='YOUR_KEY')
```

## Check Request/Response

**cURL:**
```bash
curl -v https://api.wolfgpt.com/v1/chat/completions \
  -H "X-API-Key: YOUR_KEY" \
  -d '{"messages":[{"role":"user","content":"test"}]}'
```

## Common Issues

### Empty Responses
```javascript
// ❌ Wrong
const response = await client.chat.create({ messages: [] });

// ✅ Correct
const response = await client.chat.create({
  messages: [{ role: 'user', content: 'Hello' }]
});
```

### Invalid JSON
```javascript
// ❌ Wrong
await client.chat.create({
  messages: "test" // Should be array
});

// ✅ Correct
await client.chat.create({
  messages: [{ role: 'user', content: 'test' }]
});
```
