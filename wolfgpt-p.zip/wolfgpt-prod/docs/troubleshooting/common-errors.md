# 🔧 Common Errors

## 401 Unauthorized
**Error:**
```json
{"error": {"message": "Invalid API key"}}
```

**Solutions:**
- Check API key is correct
- Verify key format: `wolf_...`
- Ensure key hasn't been revoked
- Check header: `X-API-Key`

## 429 Rate Limit
**Error:**
```json
{"error": {"message": "Rate limit exceeded"}}
```

**Solutions:**
- Implement exponential backoff
- Upgrade your plan
- Cache responses
- Batch requests

## 500 Server Error
**Error:**
```json
{"error": {"message": "Internal server error"}}
```

**Solutions:**
- Retry after delay
- Check API status page
- Contact support if persists

## Timeout Errors
**Solutions:**
- Increase timeout setting
- Check network connection
- Use streaming for long responses
