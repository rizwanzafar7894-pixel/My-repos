# 🔒 Security Best Practices

## API Key Storage

**✅ DO:**
```javascript
// Environment variables
const apiKey = process.env.WOLFGPT_API_KEY;

// Secrets management (AWS, Azure, etc.)
const apiKey = await getSecret('wolfgpt-api-key');
```

**❌ DON'T:**
```javascript
// Hardcoded
const apiKey = 'wolf_123456'; // NEVER DO THIS

// In client-side code
// <script>const key = 'wolf_123';</script> // NEVER!
```

## Rate Limiting
```javascript
// Implement client-side rate limiting
class RateLimiter {
  constructor(maxRequests, interval) {
    this.maxRequests = maxRequests;
    this.interval = interval;
    this.requests = [];
  }
  
  async throttle() {
    const now = Date.now();
    this.requests = this.requests.filter(t => now - t < this.interval);
    
    if (this.requests.length >= this.maxRequests) {
      await sleep(this.interval - (now - this.requests[0]));
    }
    
    this.requests.push(Date.now());
  }
}
```

## Input Validation
```javascript
function validatePrompt(prompt) {
  if (typeof prompt !== 'string') throw new Error('Invalid prompt');
  if (prompt.length === 0) throw new Error('Empty prompt');
  if (prompt.length > 10000) throw new Error('Prompt too long');
  return prompt.trim();
}
```
