# ⚡ Performance Optimization

## Caching
```javascript
const cache = new Map();

async function getChatResponse(message) {
  const key = JSON.stringify(message);
  if (cache.has(key)) return cache.get(key);
  
  const response = await client.chat.create({ messages: [message] });
  cache.set(key, response);
  return response;
}
```

## Batch Requests
```javascript
// ✅ Good - Parallel
const promises = prompts.map(p => client.images.generate({ prompt: p }));
const results = await Promise.all(promises);

// ❌ Bad - Sequential
for (const prompt of prompts) {
  await client.images.generate({ prompt }); // Slow!
}
```

## Use Appropriate Models
```javascript
// For simple tasks, use smaller/faster models
await client.chat.create({
  messages: [...],
  model: 'qwen-2.5-7b' // Faster & cheaper
});

// For complex tasks, use larger models
await client.chat.create({
  messages: [...],
  model: 'qwen-2.5-72b' // Better quality
});
```

## Streaming for Long Responses
```javascript
// Better UX - show response as it generates
await client.chat.stream({ messages: [...] }, (chunk) => {
  display(chunk);
});
```
