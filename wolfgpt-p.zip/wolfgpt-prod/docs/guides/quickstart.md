# 🚀 Quick Start Guide

Get started with WolfGPT API in 5 minutes.

## Step 1: Get API Key
1. Sign up at [wolfgpt.com](https://wolfgpt.com)
2. Go to API Keys section
3. Generate new key
4. Copy & save securely

## Step 2: Install SDK

**JavaScript:**
```bash
npm install @wolfgpt/sdk
```

**Python:**
```bash
pip install wolfgpt
```

**Go:**
```bash
go get github.com/wolfgpt/wolfgpt-go
```

**PHP:**
```bash
composer require wolfgpt/sdk
```

## Step 3: First Request

**JavaScript:**
```javascript
import WolfGPT from '@wolfgpt/sdk';
const client = new WolfGPT({ apiKey: 'YOUR_KEY' });
const response = await client.chat.create({
  messages: [{ role: 'user', content: 'Hello!' }]
});
```

**Python:**
```python
from wolfgpt import WolfGPT
client = WolfGPT(api_key='YOUR_KEY')
response = client.chat.create(messages=[{"role": "user", "content": "Hello!"}])
```

## Next Steps
- [API Reference](../api/)
- [Tutorials](../tutorials/)
- [Examples](../examples/)
