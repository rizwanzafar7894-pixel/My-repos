# ⏱️ Rate Limits

Rate limits by tier:

| Tier | Requests/Hour | Monthly |
|---|---|---|
| Free | 50 | 1,000 |
| Basic | 100 | 10,000 |
| Premium | 500 | 100,000 |
| Pro | Unlimited | Unlimited |

## Handling Rate Limits

**Exponential Backoff:**
```javascript
async function retryWithBackoff(fn, maxRetries = 3) {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (error.status === 429 && i < maxRetries - 1) {
        await sleep(Math.pow(2, i) * 1000);
      } else throw error;
    }
  }
}
```

## Rate Limit Headers
```
X-RateLimit-Limit: 50
X-RateLimit-Remaining: 45
X-RateLimit-Reset: 1234567890
```
