# 🔐 Authentication

All API requests require authentication via API key.

## Header Format
```
X-API-Key: wolf_your_api_key_here
```

## Best Practices
✅ Store keys in environment variables
✅ Use different keys for dev/prod
✅ Rotate keys periodically
❌ Never commit keys to git
❌ Don't expose keys client-side

## Error Codes
- `401`: Invalid API key
- `429`: Rate limit exceeded
- `403`: Insufficient permissions
