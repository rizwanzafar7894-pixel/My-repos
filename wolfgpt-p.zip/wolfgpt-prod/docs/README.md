# 🐺 WolfGPT Developer Documentation

Welcome to the WolfGPT API documentation. The most affordable AI platform with full API access.

---

## 🚀 Quick Links

- **[Quick Start Guide](guides/quickstart.md)** — Get started in 5 minutes
- **[API Reference](api/)** — Complete API documentation
- **[Interactive Playground](api/index.html)** — Test APIs in browser
- **[Code Examples](examples/)** — Copy-paste ready code
- **[Tutorials](tutorials/)** — Step-by-step guides
- **[Troubleshooting](troubleshooting/)** — Common issues & solutions

---

## 📦 Official SDKs

| Language | Package | Documentation |
|---|---|---|
| **JavaScript/TypeScript** | `npm install @wolfgpt/sdk` | [Docs](../sdks/javascript/README.md) |
| **Python** | `pip install wolfgpt` | [Docs](../sdks/python/README.md) |
| **Go** | `go get github.com/wolfgpt/wolfgpt-go` | [Docs](../sdks/go/README.md) |
| **PHP** | `composer require wolfgpt/sdk` | [Docs](../sdks/php/README.md) |

---

## 🎯 Features

### 💬 Chat API
- **Models**: Qwen 2.5 (7B, 32B, 72B)
- **Streaming**: Real-time SSE responses
- **Context**: Up to 32K tokens
- **Use cases**: Chatbots, Q&A, code generation

**Quick Example:**
```javascript
const response = await client.chat.create({
  messages: [{ role: 'user', content: 'Hello!' }]
});
```

[→ Chat Tutorial](tutorials/chat-101.md) | [→ API Reference](api/openapi.yaml#/Chat)

---

### 🖼️ Image Generation
- **Models**: FLUX (Schnell, Dev, Pro), SDXL
- **Sizes**: 256×256 to 2048×2048
- **Features**: Negative prompts, seed control
- **Speed**: 2-10 seconds per image

**Quick Example:**
```javascript
const result = await client.images.generate({
  prompt: 'A beautiful sunset over mountains',
  width: 1024,
  height: 1024
});
```

[→ Image Tutorial](tutorials/image-generation.md) | [→ Examples](examples/image-examples.md)

---

### 🎙️ Voice API (FREE & Unlimited!)
- **STT**: Whisper (tiny, base, small, medium, large-v3)
- **TTS**: Coqui TTS (10+ voices)
- **Languages**: 50+ languages
- **Quality**: High-fidelity audio

**Quick Example:**
```javascript
// Speech-to-text
const transcript = await client.voice.transcribe({ audio: audioFile });

// Text-to-speech
const audio = await client.voice.synthesize({ text: 'Hello!' });
```

[→ Voice Tutorial](tutorials/voice-integration.md) | [→ API Reference](api/openapi.yaml#/Voice)

---

### 💻 Code Execution
- **Languages**: Python, JavaScript, TypeScript, Bash, Go, Rust
- **Timeout**: Up to 300 seconds
- **Sandboxed**: Secure Docker containers
- **Stdin/Stdout**: Full I/O support

**Quick Example:**
```javascript
const result = await client.code.execute({
  code: 'print("Hello, World!")',
  language: 'python'
});
```

---

### 📄 Document Processing
- **Formats**: PDF, DOCX, TXT, CSV
- **Features**: Parse, extract, chat with documents
- **Max size**: 10 MB
- **OCR**: Automatic for scanned PDFs

**Quick Example:**
```javascript
const doc = await client.documents.upload(pdfFile);
const answer = await client.documents.chat({
  documentId: doc.id,
  messages: [{ role: 'user', content: 'Summarize this document' }]
});
```

---

### 🌍 Translation
- **Languages**: 16+ (English, Spanish, French, German, Chinese, etc.)
- **Auto-detect**: Source language detection
- **Quality**: Neural machine translation

**Quick Example:**
```javascript
const result = await client.translate.translate({
  text: 'Hello, how are you?',
  targetLanguage: 'es'
});
// Result: "Hola, ¿cómo estás?"
```

---

### 📝 Summarization
- **Styles**: Brief, Detailed, Bullets, TL;DR, Academic
- **Lengths**: Custom word limits
- **Quality**: Extractive + abstractive

**Quick Example:**
```javascript
const summary = await client.summarize.summarize({
  text: longArticle,
  style: 'brief',
  maxLength: 200
});
```

---

## 💰 Pricing

| Tier | Price | Chat | Images | Voice | API |
|---|---|---|---|---|---|
| **Free** | $0 | 50/day | 5/day | Unlimited | ✅ |
| **Basic** | $99/year | Unlimited | 50/day | Unlimited | ✅ |
| **Premium** | $199/year | Unlimited | 500/day | Unlimited | ✅ |
| **Pro** | $399/year | Unlimited | Unlimited | Unlimited | ✅ |

**All tiers include API access!** (ChatGPT API costs $1,440/year)

[→ Pricing Details](https://wolfgpt.com/pricing) | [→ Rate Limits](guides/rate-limits.md)

---

## 📚 Documentation Structure

```
docs/
├── guides/                    # Getting started guides
│   ├── quickstart.md         # 5-minute setup
│   ├── authentication.md     # API key management
│   └── rate-limits.md        # Tier limits & handling
│
├── tutorials/                 # Step-by-step tutorials
│   ├── chat-101.md           # Building chat apps
│   ├── image-generation.md   # AI art generation
│   └── voice-integration.md  # Voice-enabled apps
│
├── examples/                  # Code examples
│   ├── chat-examples.md      # Chat use cases
│   └── image-examples.md     # Image prompts
│
├── troubleshooting/          # Problem solving
│   ├── common-errors.md      # Error codes & fixes
│   └── debugging.md          # Debug techniques
│
├── best-practices/           # Optimization guides
│   ├── optimization.md       # Performance tips
│   └── security.md           # Security practices
│
└── api/                      # API reference
    ├── openapi.yaml          # OpenAPI spec
    └── index.html            # Interactive docs
```

---

## 🎓 Learning Path

### Beginner
1. [Quick Start Guide](guides/quickstart.md)
2. [Authentication](guides/authentication.md)
3. [Chat Tutorial](tutorials/chat-101.md)
4. [First API Call](examples/chat-examples.md)

### Intermediate
1. [Image Generation](tutorials/image-generation.md)
2. [Voice Integration](tutorials/voice-integration.md)
3. [Rate Limits](guides/rate-limits.md)
4. [Error Handling](troubleshooting/common-errors.md)

### Advanced
1. [Performance Optimization](best-practices/optimization.md)
2. [Security Best Practices](best-practices/security.md)
3. [Custom Integrations](tutorials/custom-integration.md)
4. [Debugging Guide](troubleshooting/debugging.md)

---

## 🔗 Useful Links

### Developer Resources
- **[API Status](https://status.wolfgpt.com)** — Service uptime & incidents
- **[Changelog](https://wolfgpt.com/changelog)** — Latest updates
- **[GitHub](https://github.com/wolfgpt)** — Open source SDKs
- **[Postman Collection](https://wolfgpt.com/postman)** — Pre-built API requests

### Community & Support
- **[Discord](https://discord.gg/wolfgpt)** — Developer community
- **[Forum](https://forum.wolfgpt.com)** — Q&A and discussions
- **[Twitter](https://twitter.com/wolfgpt)** — Updates & announcements
- **[Email Support](mailto:support@wolfgpt.com)** — Technical help

### Legal
- **[Terms of Service](https://wolfgpt.com/terms)** — API usage terms
- **[Privacy Policy](https://wolfgpt.com/privacy)** — Data handling
- **[API SLA](https://wolfgpt.com/sla)** — Service guarantees

---

## ❓ Need Help?

### Quick Support
- 💬 **Chat**: Live chat on [wolfgpt.com](https://wolfgpt.com)
- 📧 **Email**: support@wolfgpt.com
- 🐛 **Bug Reports**: [GitHub Issues](https://github.com/wolfgpt/issues)

### Before Asking
1. Check [Common Errors](troubleshooting/common-errors.md)
2. Search [Forum](https://forum.wolfgpt.com)
3. Review [API Status](https://status.wolfgpt.com)

---

## 🎉 What's New

### v1.0.0 (March 2026)
- ✨ **4 Official SDKs** (JS, Python, Go, PHP)
- 🚀 **FLUX Pro** image model
- 🎙️ **Unlimited FREE voice** (STT + TTS)
- 💻 **Rust code execution**
- 📊 **Enhanced analytics dashboard**
- 🔐 **SOC 2 Type II compliance**

[→ Full Changelog](https://wolfgpt.com/changelog)

---

## 🏆 Why WolfGPT?

| Feature | WolfGPT | ChatGPT | Claude | Gemini |
|---|---|---|---|---|
| **API Access** | ✅ All tiers | ❌ Separate product | ❌ Limited | ❌ Limited |
| **Voice (Free)** | ✅ Unlimited | ❌ Paid only | ❌ No voice | ⚠️ Limited |
| **Price/Year** | $99+ | $240+ | $240+ | Varies |
| **Image Gen** | ✅ FLUX + SDXL | ❌ DALL-E (paid) | ❌ No images | ⚠️ Limited |
| **Code Exec** | ✅ 6 languages | ❌ No | ❌ No | ⚠️ Limited |
| **Open Source SDKs** | ✅ Yes | ⚠️ Community | ⚠️ Community | ⚠️ Limited |

**WolfGPT = Best value AI platform** 🐺

---

**Ready to build?** [Get your API key →](https://wolfgpt.com/api-keys)

© 2026 WolfGPT. All rights reserved.
