#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# WolfGPT — One-command startup script
# Usage: ./start.sh [dev|prod] [--no-gpu]
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

MODE="${1:-dev}"
NO_GPU="${2:-}"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'

log()  { echo -e "${GREEN}[WolfGPT]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
err()  { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

# ── Checks ────────────────────────────────────────────────────────────────────
command -v docker  &>/dev/null || err "Docker not installed"
command -v ollama  &>/dev/null || warn "Ollama not found — chat will fail until installed"

# ── Dev Mode ──────────────────────────────────────────────────────────────────
if [[ "$MODE" == "dev" ]]; then
    log "Starting in DEVELOPMENT mode..."

    # Redis
    if ! docker ps --format '{{.Names}}' | grep -q wolfgpt-redis; then
        log "Starting Redis..."
        docker run -d --name wolfgpt-redis -p 6379:6379 redis:7-alpine \
            redis-server --appendonly yes &>/dev/null || true
    fi

    # Ollama
    if command -v ollama &>/dev/null; then
        log "Starting Ollama..."
        ollama serve &>/dev/null &
        sleep 2
        # Pull default model if not present
        ollama list | grep -q "qwen2.5:7b" || ollama pull qwen2.5:7b
    fi

    log "Starting AI Service (port 8000)..."
    (cd ai-services && python main.py) &
    AI_PID=$!

    log "Starting Backend (port 4000)..."
    (cd backend && npm run dev) &
    BE_PID=$!

    log "Starting Frontend (port 3000)..."
    (cd frontend && npm run dev) &
    FE_PID=$!

    log "✅ All services starting..."
    log "   Frontend  → http://localhost:3000"
    log "   Backend   → http://localhost:4000"
    log "   AI API    → http://localhost:8000"
    log "   Ollama    → http://localhost:11434"
    log ""
    log "Press Ctrl+C to stop all services"

    trap "kill $AI_PID $BE_PID $FE_PID 2>/dev/null; exit 0" SIGINT SIGTERM
    wait

# ── Prod Mode ─────────────────────────────────────────────────────────────────
elif [[ "$MODE" == "prod" ]]; then
    log "Starting in PRODUCTION mode..."

    # Check env files
    [[ -f backend/.env ]]      || err "backend/.env not found — copy from .env.example"
    [[ -f ai-services/.env ]]  || err "ai-services/.env not found — copy from .env.example"
    [[ -f firebase-admin-key.json ]] || err "firebase-admin-key.json not found"

    COMPOSE_ARGS="docker compose"
    if [[ "$NO_GPU" == "--no-gpu" ]]; then
        warn "Running without GPU"
        COMPOSE_ARGS="$COMPOSE_ARGS -f docker-compose.yml -f docker-compose.cpu.yml"
    fi

    log "Building containers..."
    $COMPOSE_ARGS build

    log "Starting all services..."
    $COMPOSE_ARGS up -d

    log "Waiting for health checks..."
    sleep 10
    $COMPOSE_ARGS ps

    log ""
    log "✅ WolfGPT is running!"
    log "   Frontend  → http://localhost:3000"
    log "   Backend   → http://localhost:4000"
    log "   AI API    → http://localhost:8000"
    log ""
    log "Logs: docker compose logs -f"
    log "Stop: docker compose down"

else
    err "Unknown mode: $MODE. Use 'dev' or 'prod'"
fi
