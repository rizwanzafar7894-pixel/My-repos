# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 1.x.x   | ✅ Yes             |
| < 1.0   | ❌ No              |

## Reporting a Vulnerability

**DO NOT** create public GitHub issues for security vulnerabilities.

### How to Report

Email: **security@wolfgpt.com**

Include:
- Description of the vulnerability
- Steps to reproduce
- Potential impact
- Suggested fix (if any)

### Response Timeline

- **24 hours**: Initial response
- **7 days**: Status update
- **30 days**: Fix or mitigation

### Bug Bounty

We offer rewards for valid security findings:
- **Critical**: $500-$5,000
- **High**: $250-$1,000
- **Medium**: $100-$500
- **Low**: Recognition

## Security Measures

- ✅ TLS 1.3 encryption
- ✅ Rate limiting
- ✅ Input validation
- ✅ SQL injection prevention
- ✅ XSS protection
- ✅ CSRF tokens
- ✅ Security headers
- ✅ Regular audits
- ✅ Dependency scanning
- ✅ Penetration testing

## Compliance

- SOC 2 Type II
- GDPR
- HIPAA (healthcare)
- PCI DSS (payments)
