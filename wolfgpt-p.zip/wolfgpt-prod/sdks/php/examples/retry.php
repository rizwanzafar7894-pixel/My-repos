<?php
require 'vendor/autoload.php';
use WolfGPT\Client;

function retryWithBackoff(callable $fn, int $maxRetries = 3): mixed {
    $delay = 1000; // 1 second
    for ($i = 0; $i < $maxRetries; $i++) {
        try {
            return $fn();
        } catch (Exception $e) {
            if ($i === $maxRetries - 1) throw $e;
            echo "Retry " . ($i + 1) . "/{$maxRetries}...\n";
            usleep($delay * 1000);
            $delay *= 2; // Exponential backoff
        }
    }
}

$client = new Client($_ENV['WOLFGPT_API_KEY'] ?? 'test_key');

$result = retryWithBackoff(function() use ($client) {
    return $client->chat->create([['role' => 'user', 'content' => 'Hello']]);
});

echo "✓ Success after retries\n";
