<?php
// Voice example