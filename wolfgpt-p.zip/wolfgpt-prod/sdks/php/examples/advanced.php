<?php
require 'vendor/autoload.php';
use WolfGPT\Client;

$client = new Client($_ENV['WOLFGPT_API_KEY'] ?? 'test_key');

// Multi-turn conversation
$messages = [
    ['role' => 'system', 'content' => 'You are a helpful coding assistant.'],
    ['role' => 'user', 'content' => 'How do I reverse a string in PHP?']
];

$resp1 = $client->chat->create($messages);
echo "Assistant: " . $resp1['message'] . "\n\n";

$messages[] = ['role' => 'assistant', 'content' => $resp1['message']];
$messages[] = ['role' => 'user', 'content' => 'Show me without using strrev()'];

$resp2 = $client->chat->create($messages);
echo "Assistant: " . $resp2['message'] . "\n";

// Batch operations
echo "\nBatch image generation...\n";
$prompts = ['sunset', 'mountains', 'ocean'];
foreach ($prompts as $prompt) {
    $result = $client->images->generate($prompt);
    echo "✓ Generated: {$prompt}\n";
}
