<?php
require 'vendor/autoload.php';
use WolfGPT\Client;

$client = new Client($_ENV['WOLFGPT_API_KEY'] ?? 'test_key');

// Execute Python code
$result = $client->code->execute(
    'print("Hello from Python!")',
    'python'
);

echo "Output: " . $result['output'] . "\n";
echo "Execution time: " . $result['execution_time'] . "s\n";

// Execute JavaScript
$jsResult = $client->code->execute(
    'console.log([1,2,3].map(x => x * 2))',
    'javascript'
);

echo "JS Output: " . $jsResult['output'] . "\n";
