<?php
require 'vendor/autoload.php';
use WolfGPT\Client;

$client = new Client($_ENV['WOLFGPT_API_KEY'] ?? 'test_key');

$result = $client->images->generate(
    'A beautiful sunset over mountains',
    'flux-schnell'
);

echo "Generated in: " . $result['generation_time'] . "s\n";

// Save image
$imageData = base64_decode($result['images'][0]['base64']);
file_put_contents('output.png', $imageData);
echo "Image saved to output.png\n";
