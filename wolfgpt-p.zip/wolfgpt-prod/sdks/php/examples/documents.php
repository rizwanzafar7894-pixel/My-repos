<?php
require 'vendor/autoload.php';
use WolfGPT\Client;

$client = new Client($_ENV['WOLFGPT_API_KEY'] ?? 'test_key');

// Upload document
$pdfData = file_get_contents('sample.pdf');
$doc = $client->documents->upload($pdfData);

echo "Uploaded: {$doc['page_count']} pages\n";

// Chat with document
$response = $client->documents->chat(
    $doc['id'],
    [['role' => 'user', 'content' => 'Summarize this']]
);

echo "Summary: " . $response['message'] . "\n";
