<?php
require 'vendor/autoload.php';
use WolfGPT\Client;
use WolfGPT\WolfGPTException;

try {
    $client = new Client('invalid_key');
    $client->chat->create([['role' => 'user', 'content' => 'test']]);
} catch (WolfGPTException $e) {
    echo "✓ Error caught: " . $e->getMessage() . "\n";
}

// Graceful fallback
$client = new Client($_ENV['WOLFGPT_API_KEY'] ?? 'test_key');
try {
    $result = $client->images->generate('test', 'flux-pro');
} catch (WolfGPTException $e) {
    echo "Primary failed, trying fallback...\n";
    $result = $client->images->generate('test', 'flux-schnell');
    echo "✓ Fallback successful\n";
}
