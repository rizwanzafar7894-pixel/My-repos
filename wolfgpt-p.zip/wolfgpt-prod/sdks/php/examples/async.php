<?php
// Async example using ReactPHP
require 'vendor/autoload.php';

// Note: This requires composer require react/http-client
echo "For async in PHP, install ReactPHP:\n";
echo "composer require react/http-client\n";
echo "composer require clue/reactphp-buzz\n";
