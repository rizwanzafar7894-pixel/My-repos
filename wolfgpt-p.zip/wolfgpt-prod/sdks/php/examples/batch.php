<?php
require 'vendor/autoload.php';
use WolfGPT\Client;

$client = new Client($_ENV['WOLFGPT_API_KEY'] ?? 'test_key');

// Batch translations
$texts = ['Hello', 'Goodbye', 'Thank you'];
$translations = [];

foreach ($texts as $text) {
    $result = $client->translate->translate($text, 'es');
    $translations[] = "{$text} → {$result['translated']}";
}

foreach ($translations as $t) {
    echo $t . "\n";
}
