<?php
require 'vendor/autoload.php';
use WolfGPT\Client;

$client = new Client($_ENV['WOLFGPT_API_KEY'] ?? 'test_key');

$result = $client->translate->translate(
    'Hello, how are you?',
    'es'
);

echo "Original: " . $result['original'] . "\n";
echo "Translated: " . $result['translated'] . "\n";
echo "Language: {$result['source_language']} → {$result['target_language']}\n";
