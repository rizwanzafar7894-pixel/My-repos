<?php
require 'vendor/autoload.php';
use WolfGPT\Client;

$client = new Client($_ENV['WOLFGPT_API_KEY'] ?? 'test_key');

// Simple chat
$response = $client->chat->create([
    ['role' => 'user', 'content' => 'What is PHP?']
]);
echo "Response: " . $response['message'] . "\n";

// Multi-turn conversation
$messages = [
    ['role' => 'system', 'content' => 'You are a helpful assistant.'],
    ['role' => 'user', 'content' => 'Hello!']
];

$response1 = $client->chat->create($messages);
echo "Assistant: " . $response1['message'] . "\n";

$messages[] = ['role' => 'assistant', 'content' => $response1['message']];
$messages[] = ['role' => 'user', 'content' => 'What can you help me with?'];

$response2 = $client->chat->create($messages);
echo "Assistant: " . $response2['message'] . "\n";
