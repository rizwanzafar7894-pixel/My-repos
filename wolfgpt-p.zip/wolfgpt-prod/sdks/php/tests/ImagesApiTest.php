<?php
// Image tests