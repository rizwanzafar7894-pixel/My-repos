<?php
namespace WolfGPT\Tests;
use PHPUnit\Framework\TestCase;
class ChatApiTest extends TestCase {
    public function testBasic() {
        $this->assertTrue(true);
    }
}
