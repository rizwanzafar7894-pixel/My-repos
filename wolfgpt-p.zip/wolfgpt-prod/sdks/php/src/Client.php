<?php

namespace WolfGPT;

use GuzzleHttp\Client as GuzzleClient;
use GuzzleHttp\Exception\GuzzleException;

class Client
{
    private string $apiKey;
    private string $baseUrl;
    private GuzzleClient $httpClient;

    public ChatApi $chat;
    public ImagesApi $images;
    public CodeApi $code;

    public function __construct(string $apiKey, string $baseUrl = 'https://api.wolfgpt.com/v1')
    {
        if (empty($apiKey)) {
            throw new \InvalidArgumentException('API key is required');
        }

        $this->apiKey = $apiKey;
        $this->baseUrl = $baseUrl;
        $this->httpClient = new GuzzleClient([
            'base_uri' => $baseUrl,
            'timeout' => 60,
            'headers' => [
                'X-API-Key' => $apiKey,
                'Content-Type' => 'application/json',
                'User-Agent' => 'wolfgpt-php/1.0.0',
            ],
        ]);

        $this->chat = new ChatApi($this);
        $this->images = new ImagesApi($this);
        $this->code = new CodeApi($this);
    }

    public function request(string $method, string $path, array $options = []): array
    {
        try {
            $response = $this->httpClient->request($method, $path, $options);
            return json_decode($response->getBody()->getContents(), true);
        } catch (GuzzleException $e) {
            throw new WolfGPTException($e->getMessage(), $e->getCode());
        }
    }

    public function ping(): bool
    {
        try {
            $this->request('GET', '/health');
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }
}

class WolfGPTException extends \Exception {}
