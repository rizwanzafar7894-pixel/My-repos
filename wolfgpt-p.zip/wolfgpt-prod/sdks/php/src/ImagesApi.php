<?php
namespace WolfGPT;
class ImagesApi {
    private Client $client;
    public function __construct(Client $client) { $this->client = $client; }
    public function generate(string $prompt, string $model = 'flux-schnell'): array {
        return $this->client->request('POST', '/images/generate', [
            'json' => ['prompt' => $prompt, 'model' => $model, 'width' => 1024, 'height' => 1024]
        ])['data'] ?? [];
    }
}
