<?php
namespace WolfGPT;
class CodeApi {
    private Client $client;
    public function __construct(Client $client) { $this->client = $client; }
    public function execute(string $code, string $language): array {
        return $this->client->request('POST', '/code/execute', [
            'json' => ['code' => $code, 'language' => $language]
        ])['data'] ?? [];
    }
}
