<?php
namespace WolfGPT;
class ChatApi {
    private Client $client;
    public function __construct(Client $client) { $this->client = $client; }
    public function create(array $messages, string $model = 'qwen-2.5-7b'): array {
        return $this->client->request('POST', '/chat/completions', [
            'json' => ['messages' => $messages, 'model' => $model, 'stream' => false]
        ])['data'] ?? [];
    }
}
