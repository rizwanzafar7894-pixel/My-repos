# 🐺 WolfGPT PHP SDK

Official PHP SDK for WolfGPT API.

## Installation

```bash
composer require wolfgpt/sdk
```

## Quick Start

```php
<?php
require 'vendor/autoload.php';

use WolfGPT\Client;

$wolfgpt = new Client('YOUR_API_KEY');

// Chat
$response = $wolfgpt->chat->create([
    ['role' => 'user', 'content' => 'Hello!']
]);
echo $response['message'];

// Images
$result = $wolfgpt->images->generate('A serene landscape');
file_put_contents('image.png', base64_decode($result['images'][0]['base64']));

// Code
$output = $wolfgpt->code->execute('print("Hello")', 'python');
echo $output['output'];
```

## License
MIT
