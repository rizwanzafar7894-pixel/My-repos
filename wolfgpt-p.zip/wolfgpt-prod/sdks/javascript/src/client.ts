import axios, { AxiosInstance, AxiosRequestConfig } from 'axios';
import { ChatAPI } from './api/chat';
import { ImagesAPI } from './api/images';
import { VoiceAPI } from './api/voice';
import { CodeAPI } from './api/code';
import { DocumentsAPI } from './api/documents';
import { TranslateAPI } from './api/translate';
import { SummarizeAPI } from './api/summarize';
import type { WolfGPTConfig } from './types';

export class WolfGPT {
  private client: AxiosInstance;
  
  public chat: ChatAPI;
  public images: ImagesAPI;
  public voice: VoiceAPI;
  public code: CodeAPI;
  public documents: DocumentsAPI;
  public translate: TranslateAPI;
  public summarize: SummarizeAPI;

  constructor(config: WolfGPTConfig) {
    const { apiKey, baseURL = 'https://api.wolfgpt.com/v1', timeout = 60000 } = config;

    if (!apiKey) {
      throw new Error('WolfGPT API key is required. Get one at https://wolfgpt.com/api-keys');
    }

    this.client = axios.create({
      baseURL,
      timeout,
      headers: {
        'X-API-Key': apiKey,
        'Content-Type': 'application/json',
        'User-Agent': '@wolfgpt/sdk@1.0.0',
      },
    });

    // Intercept responses for consistent error handling
    this.client.interceptors.response.use(
      (response) => response,
      (error) => {
        if (error.response) {
          const { status, data } = error.response;
          const message = data?.error?.message || data?.message || error.message;
          
          if (status === 401) {
            throw new Error(`Authentication failed: ${message}`);
          } else if (status === 429) {
            throw new Error(`Rate limit exceeded: ${message}`);
          } else if (status >= 500) {
            throw new Error(`WolfGPT server error: ${message}`);
          }
          
          throw new Error(message);
        }
        throw error;
      }
    );

    // Initialize API modules
    this.chat      = new ChatAPI(this.client);
    this.images    = new ImagesAPI(this.client);
    this.voice     = new VoiceAPI(this.client);
    this.code      = new CodeAPI(this.client);
    this.documents = new DocumentsAPI(this.client);
    this.translate = new TranslateAPI(this.client);
    this.summarize = new SummarizeAPI(this.client);
  }

  /**
   * Make a custom request to the WolfGPT API
   */
  async request<T = any>(config: AxiosRequestConfig): Promise<T> {
    const response = await this.client.request<T>(config);
    return response.data;
  }

  /**
   * Get current API key usage stats
   */
  async getUsage() {
    return this.request({ method: 'GET', url: '/auth/usage' });
  }

  /**
   * Test API connectivity
   */
  async ping(): Promise<boolean> {
    try {
      await this.request({ method: 'GET', url: '/health' });
      return true;
    } catch {
      return false;
    }
  }
}

export default WolfGPT;
