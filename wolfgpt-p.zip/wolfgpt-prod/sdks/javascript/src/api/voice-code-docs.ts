import type { AxiosInstance } from 'axios';
import FormData from 'form-data';
import type {
  STTRequest,
  STTResponse,
  TTSRequest,
  CodeExecutionRequest,
  CodeExecutionResponse,
  DocumentParseResponse,
  DocumentChatRequest,
} from '../types';

// ── Voice API ─────────────────────────────────────────────────────────────────
export class VoiceAPI {
  constructor(private client: AxiosInstance) {}

  /**
   * Speech-to-text transcription
   */
  async transcribe(request: STTRequest): Promise<STTResponse> {
    const form = new FormData();
    form.append('audio', request.audio);
    if (request.language) form.append('language', request.language);
    if (request.model) form.append('model', request.model);

    const { data } = await this.client.post('/voice/stt', form, {
      headers: form.getHeaders?.() || { 'Content-Type': 'multipart/form-data' },
    });
    return data.data;
  }

  /**
   * Text-to-speech synthesis
   */
  async synthesize(request: TTSRequest): Promise<Buffer | ArrayBuffer> {
    const { data } = await this.client.post('/voice/tts', request, {
      responseType: 'arraybuffer',
    });
    return data;
  }

  /**
   * List available voices
   */
  async listVoices() {
    const { data } = await this.client.get('/voice/voices');
    return data.voices || data.data;
  }

  /**
   * List supported languages
   */
  async listLanguages() {
    const { data } = await this.client.get('/voice/languages');
    return data.languages || data.data;
  }
}

// ── Code API ──────────────────────────────────────────────────────────────────
export class CodeAPI {
  constructor(private client: AxiosInstance) {}

  /**
   * Execute code in a sandboxed environment
   */
  async execute(request: CodeExecutionRequest): Promise<CodeExecutionResponse> {
    const { data } = await this.client.post('/code/execute', request);
    return data.data;
  }

  /**
   * Get execution history
   */
  async getHistory(limit = 20) {
    const { data } = await this.client.get('/code/history', { params: { limit } });
    return data.data;
  }

  /**
   * List supported languages
   */
  async listLanguages() {
    const { data } = await this.client.get('/code/languages');
    return data.data;
  }
}

// ── Documents API ─────────────────────────────────────────────────────────────
export class DocumentsAPI {
  constructor(private client: AxiosInstance) {}

  /**
   * Upload and parse a document
   */
  async upload(file: Buffer | Blob | File): Promise<DocumentParseResponse> {
    const form = new FormData();
    form.append('document', file);

    const { data } = await this.client.post('/documents/upload', form, {
      headers: form.getHeaders?.() || { 'Content-Type': 'multipart/form-data' },
    });
    return data.data;
  }

  /**
   * Chat with a document
   */
  async chat(request: DocumentChatRequest) {
    const { documentId, ...rest } = request;
    const { data } = await this.client.post(`/documents/${documentId}/chat`, rest);
    return data.data;
  }

  /**
   * List user's documents
   */
  async list(limit = 50) {
    const { data } = await this.client.get('/documents', { params: { limit } });
    return data.data;
  }

  /**
   * Get a specific document
   */
  async get(id: string) {
    const { data } = await this.client.get(`/documents/${id}`);
    return data.data;
  }

  /**
   * Delete a document
   */
  async delete(id: string) {
    const { data } = await this.client.delete(`/documents/${id}`);
    return data.data;
  }
}
