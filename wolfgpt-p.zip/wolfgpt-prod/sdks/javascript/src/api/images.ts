import type { AxiosInstance } from 'axios';
import type { ImageGenerationRequest, ImageGenerationResponse } from '../types';

export class ImagesAPI {
  constructor(private client: AxiosInstance) {}

  /**
   * Generate images from text prompt
   */
  async generate(request: ImageGenerationRequest): Promise<ImageGenerationResponse> {
    const { data } = await this.client.post('/images/generate', request);
    return data.data;
  }

  /**
   * Get user's image gallery
   */
  async getGallery(limit = 50) {
    const { data } = await this.client.get('/images/gallery', { params: { limit } });
    return data.data;
  }

  /**
   * Get a specific image by ID
   */
  async getImage(id: string) {
    const { data } = await this.client.get(`/images/${id}`);
    return data.data;
  }

  /**
   * Delete an image
   */
  async deleteImage(id: string) {
    const { data } = await this.client.delete(`/images/${id}`);
    return data.data;
  }

  /**
   * Download image as Buffer (Node.js) or Blob (browser)
   */
  async download(id: string): Promise<Buffer | Blob> {
    const image = await this.getImage(id);
    const base64Data = image.base64.replace(/^data:image\/\w+;base64,/, '');
    
    if (typeof Buffer !== 'undefined') {
      return Buffer.from(base64Data, 'base64');
    }
    
    // Browser
    const byteCharacters = atob(base64Data);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: 'image/png' });
  }
}
