export { VoiceAPI } from './voice-code-docs';
