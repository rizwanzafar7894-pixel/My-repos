import type { AxiosInstance } from 'axios';
import type { TranslateRequest, TranslateResponse, SummarizeRequest, SummarizeResponse } from '../types';

export class TranslateAPI {
  constructor(private client: AxiosInstance) {}

  /**
   * Translate text to another language
   */
  async translate(request: TranslateRequest): Promise<TranslateResponse> {
    const { data } = await this.client.post('/translate', request);
    return data.data;
  }

  /**
   * Detect language of text
   */
  async detect(text: string) {
    const { data } = await this.client.post('/translate/detect', { text });
    return data.data;
  }

  /**
   * List supported languages
   */
  async listLanguages() {
    const { data } = await this.client.get('/translate/languages');
    return data.data;
  }
}

export class SummarizeAPI {
  constructor(private client: AxiosInstance) {}

  /**
   * Summarize text
   */
  async summarize(request: SummarizeRequest): Promise<SummarizeResponse> {
    const { data } = await this.client.post('/summarize', request);
    return data.data;
  }
}
