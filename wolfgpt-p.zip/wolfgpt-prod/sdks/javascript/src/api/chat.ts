import type { AxiosInstance } from 'axios';
import type {
  ChatCompletionRequest,
  ChatCompletionResponse,
  ChatStreamCallback,
  ChatMessage,
} from '../types';

export class ChatAPI {
  constructor(private client: AxiosInstance) {}

  /**
   * Create a chat completion (non-streaming)
   */
  async create(request: ChatCompletionRequest): Promise<ChatCompletionResponse> {
    const { data } = await this.client.post('/chat/completions', {
      ...request,
      stream: false,
    });
    return data.data;
  }

  /**
   * Create a streaming chat completion (SSE)
   */
  async stream(
    request: Omit<ChatCompletionRequest, 'stream'>,
    onChunk: ChatStreamCallback
  ): Promise<void> {
    const response = await this.client.post(
      '/chat/completions/stream',
      { ...request, stream: true },
      { responseType: 'stream' }
    );

    return new Promise((resolve, reject) => {
      response.data.on('data', (chunk: Buffer) => {
        const lines = chunk.toString().split('\n').filter((line) => line.trim());
        
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') {
              resolve();
              return;
            }
            try {
              const parsed = JSON.parse(data);
              const content = parsed.content || parsed.choices?.[0]?.delta?.content;
              if (content) onChunk(content);
            } catch (err) {
              // Skip invalid JSON
            }
          }
        }
      });

      response.data.on('error', reject);
    });
  }

  /**
   * Get conversation history
   */
  async listConversations(limit = 50) {
    const { data } = await this.client.get('/chat/conversations', { params: { limit } });
    return data.data;
  }

  /**
   * Get a specific conversation
   */
  async getConversation(id: string) {
    const { data } = await this.client.get(`/chat/conversations/${id}`);
    return data.data;
  }

  /**
   * Delete a conversation
   */
  async deleteConversation(id: string) {
    const { data } = await this.client.delete(`/chat/conversations/${id}`);
    return data.data;
  }

  /**
   * Delete all conversations
   */
  async clearConversations() {
    const { data } = await this.client.delete('/chat/conversations');
    return data.data;
  }
}
