export interface WolfGPTConfig {
  apiKey: string;
  baseURL?: string;
  timeout?: number;
}

// ── Chat ──────────────────────────────────────────────────────────────────────
export interface ChatMessage {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface ChatCompletionRequest {
  messages: ChatMessage[];
  model?: 'qwen-2.5-7b' | 'qwen-2.5-32b' | 'qwen-2.5-72b';
  temperature?: number;
  maxTokens?: number;
  stream?: boolean;
}

export interface ChatCompletionResponse {
  message: string;
  model: string;
  conversationId: string;
  usage: { prompt_tokens: number; completion_tokens: number; total_tokens: number };
}

export type ChatStreamCallback = (chunk: string) => void;

// ── Images ────────────────────────────────────────────────────────────────────
export interface ImageGenerationRequest {
  prompt: string;
  negativePrompt?: string;
  model?: 'flux-schnell' | 'flux-dev' | 'flux-pro' | 'sdxl-base';
  width?: number;
  height?: number;
  steps?: number;
  numImages?: number;
  seed?: number;
}

export interface GeneratedImage {
  base64: string;
  width: number;
  height: number;
  seed?: number;
}

export interface ImageGenerationResponse {
  images: GeneratedImage[];
  model: string;
  generationTime: number;
}

// ── Voice ─────────────────────────────────────────────────────────────────────
export interface STTRequest {
  audio: Buffer | Blob | File;
  language?: string;
  model?: 'tiny' | 'base' | 'small' | 'medium' | 'large-v3';
}

export interface STTResponse {
  text: string;
  language: string;
  duration: number;
  confidence: number;
}

export interface TTSRequest {
  text: string;
  voice?: string;
  speed?: number;
}

// ── Code ──────────────────────────────────────────────────────────────────────
export interface CodeExecutionRequest {
  code: string;
  language: 'python' | 'javascript' | 'typescript' | 'bash' | 'go' | 'rust';
  stdin?: string;
  timeout?: number;
}

export interface CodeExecutionResponse {
  output: string;
  error: string | null;
  executionTime: number;
  language: string;
  timedOut: boolean;
}

// ── Documents ─────────────────────────────────────────────────────────────────
export interface DocumentParseResponse {
  text: string;
  pageCount: number;
  wordCount: number;
  charCount: number;
  fileType: string;
  truncated: boolean;
}

export interface DocumentChatRequest {
  documentId: string;
  messages: ChatMessage[];
  model?: string;
}

// ── Translate ─────────────────────────────────────────────────────────────────
export interface TranslateRequest {
  text: string;
  targetLanguage: string;
  sourceLanguage?: string;
}

export interface TranslateResponse {
  original: string;
  translated: string;
  sourceLanguage: string;
  targetLanguage: string;
}

// ── Summarize ─────────────────────────────────────────────────────────────────
export interface SummarizeRequest {
  text: string;
  style?: 'brief' | 'detailed' | 'bullets' | 'tldr' | 'academic';
  maxLength?: number;
}

export interface SummarizeResponse {
  summary: string;
  style: string;
  wordCount: number;
  originalLength: number;
  compressionRatio: number;
}

// ── Errors ────────────────────────────────────────────────────────────────────
export class WolfGPTError extends Error {
  constructor(
    message: string,
    public code?: string,
    public statusCode?: number
  ) {
    super(message);
    this.name = 'WolfGPTError';
  }
}
