# 🐺 WolfGPT JavaScript/TypeScript SDK

Official SDK for WolfGPT API — the most affordable AI platform.

## Installation

```bash
npm install @wolfgpt/sdk
# or
yarn add @wolfgpt/sdk
# or
pnpm add @wolfgpt/sdk
```

## Quick Start

```typescript
import WolfGPT from '@wolfgpt/sdk';

const wolfgpt = new WolfGPT({
  apiKey: 'YOUR_API_KEY', // Get from https://wolfgpt.com/api-keys
});

// Chat completion
const response = await wolfgpt.chat.create({
  messages: [{ role: 'user', content: 'Hello!' }],
});
console.log(response.message);

// Streaming chat
await wolfgpt.chat.stream(
  { messages: [{ role: 'user', content: 'Tell me a story' }] },
  (chunk) => process.stdout.write(chunk)
);
```

## Features

- ✅ **Full TypeScript support** with type definitions
- ✅ **Streaming** chat completions (SSE)
- ✅ **Image generation** (FLUX, SDXL)
- ✅ **Voice** (STT + TTS)
- ✅ **Code execution** in 6 languages
- ✅ **Document parsing** (PDF, DOCX, CSV)
- ✅ **Translation** & **Summarization**
- ✅ Works in Node.js AND browsers

## API Reference

### Chat

```typescript
// Non-streaming
const response = await wolfgpt.chat.create({
  messages: [
    { role: 'system', content: 'You are a helpful assistant' },
    { role: 'user', content: 'What is 2+2?' },
  ],
  model: 'qwen-2.5-7b', // or qwen-2.5-32b, qwen-2.5-72b
  temperature: 0.7,
  maxTokens: 2048,
});

// Streaming
await wolfgpt.chat.stream(
  { messages: [...], model: 'qwen-2.5-32b' },
  (chunk) => console.log(chunk)
);

// List conversations
const conversations = await wolfgpt.chat.listConversations();

// Delete conversation
await wolfgpt.chat.deleteConversation('conv_123');
```

### Images

```typescript
const result = await wolfgpt.images.generate({
  prompt: 'A serene landscape at sunset',
  negativePrompt: 'blurry, low quality',
  model: 'flux-schnell', // flux-dev, flux-pro, sdxl-base
  width: 1024,
  height: 1024,
  steps: 4,
  numImages: 1,
});

// result.images[0].base64 contains the image
```

### Voice

```typescript
import fs from 'fs';

// Speech-to-text
const audioFile = fs.readFileSync('audio.mp3');
const transcription = await wolfgpt.voice.transcribe({
  audio: audioFile,
  language: 'en',
  model: 'base',
});
console.log(transcription.text);

// Text-to-speech
const audioBuffer = await wolfgpt.voice.synthesize({
  text: 'Hello, world!',
  voice: 'en-US-female-1',
  speed: 1.0,
});
fs.writeFileSync('output.wav', audioBuffer);
```

### Code Execution

```typescript
const result = await wolfgpt.code.execute({
  code: 'print("Hello from Python!")',
  language: 'python',
  stdin: '',
  timeout: 30,
});

console.log(result.output);
// Supported: python, javascript, typescript, bash, go, rust
```

### Documents

```typescript
const docFile = fs.readFileSync('document.pdf');

// Upload & parse
const parsed = await wolfgpt.documents.upload(docFile);
console.log(parsed.text); // Extracted text

// Chat with document
const answer = await wolfgpt.documents.chat({
  documentId: parsed.id,
  messages: [{ role: 'user', content: 'Summarize this document' }],
});
```

### Translation

```typescript
const translation = await wolfgpt.translate.translate({
  text: 'Hello, how are you?',
  targetLanguage: 'es',
  sourceLanguage: 'en', // optional
});
console.log(translation.translated); // "Hola, ¿cómo estás?"

// Detect language
const detected = await wolfgpt.translate.detect('Bonjour');
console.log(detected.language); // "fr"
```

### Summarization

```typescript
const summary = await wolfgpt.summarize.summarize({
  text: 'Your long text here...',
  style: 'brief', // brief, detailed, bullets, tldr, academic
  maxLength: 500,
});
console.log(summary.summary);
```

## Configuration

```typescript
const wolfgpt = new WolfGPT({
  apiKey: 'YOUR_API_KEY',
  baseURL: 'https://api.wolfgpt.com/v1', // optional, default shown
  timeout: 60000, // optional, in milliseconds
});
```

## Error Handling

```typescript
import { WolfGPTError } from '@wolfgpt/sdk';

try {
  await wolfgpt.chat.create({ messages: [...] });
} catch (error) {
  if (error instanceof WolfGPTError) {
    console.error('Code:', error.code);
    console.error('Status:', error.statusCode);
  }
  console.error(error.message);
}
```

## License

MIT
