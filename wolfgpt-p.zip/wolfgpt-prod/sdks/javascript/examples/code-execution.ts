// Code execution examples
import WolfGPT from '@wolfgpt/sdk';

const client = new WolfGPT({ apiKey: process.env.WOLFGPT_API_KEY! });

async function codeExamples() {
  // Python
  const pythonResult = await client.code.execute({
    code: `
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

for i in range(10):
    print(f"fib({i}) = {fibonacci(i)}")
`,
    language: 'python'
  });
  console.log('Python output:', pythonResult.output);
  
  // JavaScript
  const jsResult = await client.code.execute({
    code: 'console.log([1,2,3,4,5].map(x => x * x))',
    language: 'javascript'
  });
  console.log('JS output:', jsResult.output);
  
  // With stdin
  const stdinResult = await client.code.execute({
    code: 'name = input("Name: ")\nprint(f"Hello, {name}!")',
    language: 'python',
    stdin: 'Alice'
  });
  console.log('Stdin output:', stdinResult.output);
}

codeExamples();
