// Image generation examples
import WolfGPT from '@wolfgpt/sdk';
import fs from 'fs';

const client = new WolfGPT({ apiKey: process.env.WOLFGPT_API_KEY! });

async function imageExamples() {
  // Basic generation
  const result = await client.images.generate({
    prompt: 'A futuristic city at sunset, cyberpunk style, highly detailed',
    model: 'flux-schnell',
    width: 1024,
    height: 1024,
    steps: 4
  });
  
  // Save first image
  const img = result.images[0];
  const buffer = Buffer.from(img.base64, 'base64');
  fs.writeFileSync('city.png', buffer);
  console.log(`Generated in ${result.generationTime}s`);
  
  // Multiple images with seed
  const multiResult = await client.images.generate({
    prompt: 'A cute cartoon wolf mascot',
    model: 'flux-schnell',
    numImages: 3,
    seed: 12345
  });
  
  multiResult.images.forEach((img, i) => {
    const buf = Buffer.from(img.base64, 'base64');
    fs.writeFileSync(`wolf_${i}.png`, buf);
  });
  
  console.log(`Generated ${multiResult.images.length} images`);
}

imageExamples();
