import WolfGPT from '@wolfgpt/sdk';

const client = new WolfGPT({ apiKey: process.env.WOLFGPT_API_KEY! });

async function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  maxRetries = 3,
  baseDelay = 1000
): Promise<T> {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (i === maxRetries - 1) throw error;
      
      const delay = baseDelay * Math.pow(2, i);
      console.log(`⏱️  Retry ${i + 1}/${maxRetries} after ${delay}ms...`);
      await sleep(delay);
    }
  }
  throw new Error('Max retries exceeded');
}

async function retryExample() {
  console.log('🔄 Retry Logic Example\n');

  // Example 1: Retry on rate limit
  console.log('1. Retrying chat with exponential backoff...');
  try {
    const response = await retryWithBackoff(
      () => client.chat.create({
        messages: [{ role: 'user', content: 'Hello!' }]
      }),
      3,
      1000
    );
    console.log('✅ Success:', response.message);
  } catch (error) {
    console.log('❌ Failed after all retries:', error.message);
  }

  // Example 2: Retry image generation
  console.log('\n2. Retrying image generation...');
  try {
    const result = await retryWithBackoff(
      () => client.images.generate({ prompt: 'A sunset' }),
      5,
      2000
    );
    console.log(`✅ Generated ${result.images.length} image(s)`);
  } catch (error) {
    console.log('❌ Failed:', error.message);
  }

  // Example 3: Circuit breaker pattern
  class CircuitBreaker {
    private failures = 0;
    private lastFailTime = 0;
    private readonly threshold = 3;
    private readonly timeout = 60000; // 1 minute

    async execute<T>(fn: () => Promise<T>): Promise<T> {
      if (this.failures >= this.threshold) {
        const timeSinceLastFail = Date.now() - this.lastFailTime;
        if (timeSinceLastFail < this.timeout) {
          throw new Error('Circuit breaker open - service unavailable');
        }
        this.failures = 0; // Reset after timeout
      }

      try {
        const result = await fn();
        this.failures = 0;
        return result;
      } catch (error) {
        this.failures++;
        this.lastFailTime = Date.now();
        throw error;
      }
    }
  }

  console.log('\n3. Circuit breaker pattern...');
  const breaker = new CircuitBreaker();
  
  try {
    await breaker.execute(() => 
      client.chat.create({ messages: [{ role: 'user', content: 'test' }] })
    );
    console.log('✅ Request succeeded');
  } catch (error) {
    console.log('⚠️  Circuit breaker:', error.message);
  }

  console.log('\n✅ Retry logic demo complete!');
}

retryExample().catch(console.error);
