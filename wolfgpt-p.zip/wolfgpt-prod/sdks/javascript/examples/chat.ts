import WolfGPT from '@wolfgpt/sdk';

const wolfgpt = new WolfGPT({
  apiKey: process.env.WOLFGPT_API_KEY || 'your-api-key',
});

// ── Example 1: Simple chat ────────────────────────────────────────────────────
async function simpleChat() {
  console.log('🤖 Simple Chat Example\n');

  const response = await wolfgpt.chat.create({
    messages: [
      { role: 'user', content: 'What are the top 3 programming languages in 2024?' },
    ],
    model: 'qwen-2.5-7b',
  });

  console.log('Response:', response.message);
  console.log('\nTokens used:', response.usage.total_tokens);
}

// ── Example 2: Streaming chat ─────────────────────────────────────────────────
async function streamingChat() {
  console.log('\n🌊 Streaming Chat Example\n');

  process.stdout.write('Assistant: ');

  await wolfgpt.chat.stream(
    {
      messages: [
        { role: 'system', content: 'You are a helpful assistant that speaks concisely.' },
        { role: 'user', content: 'Write a haiku about coding.' },
      ],
      model: 'qwen-2.5-32b',
      temperature: 0.9,
    },
    (chunk) => process.stdout.write(chunk)
  );

  console.log('\n✅ Stream complete');
}

// ── Example 3: Multi-turn conversation ────────────────────────────────────────
async function conversation() {
  console.log('\n💬 Multi-turn Conversation Example\n');

  const messages = [
    { role: 'system', content: 'You are a helpful coding tutor.' },
    { role: 'user', content: 'How do I reverse a string in Python?' },
  ];

  const response1 = await wolfgpt.chat.create({ messages });
  console.log('User: How do I reverse a string in Python?');
  console.log('Assistant:', response1.message, '\n');

  messages.push(
    { role: 'assistant', content: response1.message },
    { role: 'user', content: 'Can you show me how to do it without slicing?' }
  );

  const response2 = await wolfgpt.chat.create({ messages });
  console.log('User: Can you show me how to do it without slicing?');
  console.log('Assistant:', response2.message);
}

// ── Run examples ──────────────────────────────────────────────────────────────
async function main() {
  try {
    await simpleChat();
    await streamingChat();
    await conversation();
  } catch (error) {
    console.error('Error:', error.message);
    process.exit(1);
  }
}

main();
