// Streaming chat example
import WolfGPT from '@wolfgpt/sdk';

const client = new WolfGPT({ apiKey: process.env.WOLFGPT_API_KEY! });

async function streamExample() {
  console.log('Assistant: ');
  
  await client.chat.stream(
    {
      messages: [
        { role: 'system', content: 'You are a helpful assistant.' },
        { role: 'user', content: 'Write a short poem about coding.' }
      ],
      model: 'qwen-2.5-32b',
      temperature: 0.8
    },
    (chunk) => process.stdout.write(chunk)
  );
  
  console.log('\n\nDone!');
}

streamExample();
