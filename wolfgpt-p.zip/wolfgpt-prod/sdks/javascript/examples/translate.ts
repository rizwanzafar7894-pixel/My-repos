import WolfGPT from '@wolfgpt/sdk';

const wolfgpt = new WolfGPT({ apiKey: process.env.WOLFGPT_API_KEY || '' });

async function main() {
  // Translate text
  const result = await wolfgpt.translate.translate({
    text: 'Hello, how are you?',
    targetLanguage: 'es',
  });
  console.log('Translation:', result.translated);

  // Detect language
  const detected = await wolfgpt.translate.detect('Bonjour le monde');
  console.log('Detected:', detected.language);
}

main();
