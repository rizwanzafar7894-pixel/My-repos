import WolfGPT from '@wolfgpt/sdk';
import fs from 'fs';

const wolfgpt = new WolfGPT({
  apiKey: process.env.WOLFGPT_API_KEY || 'your-api-key',
});

// ── Images ────────────────────────────────────────────────────────────────────
export async function generateImage() {
  console.log('🎨 Generating image...\n');

  const result = await wolfgpt.images.generate({
    prompt: 'A futuristic city at sunset, cyberpunk style',
    model: 'flux-schnell',
    width: 1024,
    height: 1024,
    steps: 4,
  });

  const image = result.images[0];
  const buffer = Buffer.from(image.base64, 'base64');
  fs.writeFileSync('output.png', buffer);

  console.log(`✅ Image saved to output.png (${result.generationTime}s)`);
}

// ── Voice STT ─────────────────────────────────────────────────────────────────
export async function transcribeAudio() {
  console.log('🎤 Transcribing audio...\n');

  const audioFile = fs.readFileSync('./test-audio.mp3'); // You need a test file

  const result = await wolfgpt.voice.transcribe({
    audio: audioFile,
    language: 'en',
    model: 'base',
  });

  console.log('Transcription:', result.text);
  console.log('Language:', result.language);
  console.log('Confidence:', result.confidence);
}

// ── Voice TTS ─────────────────────────────────────────────────────────────────
export async function synthesizeSpeech() {
  console.log('🔊 Synthesizing speech...\n');

  const audio = await wolfgpt.voice.synthesize({
    text: 'Hello! This is WolfGPT text-to-speech.',
    voice: 'en-US-female-1',
    speed: 1.0,
  });

  fs.writeFileSync('speech.wav', audio as Buffer);
  console.log('✅ Audio saved to speech.wav');
}

// ── Code Execution ────────────────────────────────────────────────────────────
export async function executeCode() {
  console.log('💻 Executing Python code...\n');

  const result = await wolfgpt.code.execute({
    code: `
import math

def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

for i in range(10):
    print(f"fib({i}) = {fibonacci(i)}")
`,
    language: 'python',
    timeout: 10,
  });

  console.log('Output:\n', result.output);
  console.log('Execution time:', result.executionTime, 'ms');

  if (result.error) {
    console.error('Error:', result.error);
  }
}

// ── Run all ───────────────────────────────────────────────────────────────────
async function main() {
  try {
    await generateImage();
    await synthesizeSpeech();
    await executeCode();
    // await transcribeAudio(); // Requires test-audio.mp3
  } catch (error) {
    console.error('Error:', error.message);
  }
}

main();
