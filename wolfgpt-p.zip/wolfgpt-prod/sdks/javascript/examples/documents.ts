import WolfGPT from '@wolfgpt/sdk';
import fs from 'fs';

const wolfgpt = new WolfGPT({ apiKey: process.env.WOLFGPT_API_KEY || '' });

async function main() {
  // Upload document
  const pdfFile = fs.readFileSync('./sample.pdf');
  const doc = await wolfgpt.documents.upload(pdfFile);
  console.log(`Uploaded: ${doc.pageCount} pages, ${doc.wordCount} words`);

  // Chat with document
  const answer = await wolfgpt.documents.chat({
    documentId: doc.id,
    messages: [{ role: 'user', content: 'Summarize this document in 3 sentences' }],
  });
  console.log('Summary:', answer.message);
}

main();
