import WolfGPT from '@wolfgpt/sdk';

const client = new WolfGPT({ apiKey: process.env.WOLFGPT_API_KEY! });

async function batchProcessing() {
  console.log('🔄 Batch Processing Example\n');

  // Batch image generation
  const prompts = [
    'A sunset over mountains',
    'A futuristic city',
    'A serene lake',
    'A cute cartoon wolf'
  ];

  console.log('Generating multiple images in batch...');
  const imagePromises = prompts.map(prompt => 
    client.images.generate({ prompt, model: 'flux-schnell' })
  );

  const results = await Promise.all(imagePromises);
  console.log(`✅ Generated ${results.length} images in parallel`);

  // Batch code execution
  const codeSnippets = [
    { code: 'print(sum([1,2,3,4,5]))', language: 'python' as const },
    { code: 'console.log([1,2,3].reduce((a,b) => a+b))', language: 'javascript' as const },
    { code: 'echo $((1+2+3+4+5))', language: 'bash' as const }
  ];

  console.log('\nExecuting code in batch...');
  const execPromises = codeSnippets.map(snippet => 
    client.code.execute(snippet)
  );

  const execResults = await Promise.all(execPromises);
  execResults.forEach((result, i) => {
    console.log(`${codeSnippets[i].language}: ${result.output.trim()}`);
  });

  // Batch translations
  const texts = ['Hello', 'Goodbye', 'Thank you'];
  const targetLang = 'es';

  console.log(`\nTranslating ${texts.length} texts to ${targetLang}...`);
  const transPromises = texts.map(text => 
    client.translate.translate({ text, targetLanguage: targetLang })
  );

  const translations = await Promise.all(transPromises);
  translations.forEach((t, i) => {
    console.log(`${texts[i]} → ${t.translated}`);
  });

  console.log('\n✅ Batch processing complete!');
}

batchProcessing().catch(console.error);
