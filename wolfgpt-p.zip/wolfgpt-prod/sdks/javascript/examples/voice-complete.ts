// Complete voice example
import WolfGPT from '@wolfgpt/sdk';
import fs from 'fs';

const client = new WolfGPT({ apiKey: process.env.WOLFGPT_API_KEY! });

async function voiceExample() {
  // List available voices
  const voices = await client.voice.listVoices();
  console.log('Available voices:', voices.length);
  
  // Text to speech
  const audio = await client.voice.synthesize({
    text: 'Hello! This is WolfGPT text to speech.',
    voice: 'en-US-female-1',
    speed: 1.0
  });
  fs.writeFileSync('output.wav', audio as Buffer);
  console.log('Audio saved to output.wav');
  
  // Speech to text (if you have an audio file)
  if (fs.existsSync('test-audio.mp3')) {
    const transcript = await client.voice.transcribe({
      audio: fs.readFileSync('test-audio.mp3'),
      language: 'en',
      model: 'base'
    });
    console.log('Transcript:', transcript.text);
  }
}

voiceExample();
