import WolfGPT from '@wolfgpt/sdk';

const client = new WolfGPT({ apiKey: process.env.WOLFGPT_API_KEY! });

async function errorHandlingExamples() {
  console.log('⚠️  Error Handling Examples\n');

  // 1. Invalid API key
  try {
    const badClient = new WolfGPT({ apiKey: '' });
    await badClient.chat.create({ messages: [] });
  } catch (error) {
    console.log('❌ Invalid API key caught:', error.message);
  }

  // 2. Rate limit handling
  try {
    // Simulate many requests
    const promises = Array(100).fill(0).map(() => 
      client.chat.create({ messages: [{ role: 'user', content: 'test' }] })
    );
    await Promise.all(promises);
  } catch (error) {
    if (error.message.includes('Rate limit')) {
      console.log('⏱️  Rate limit caught - implement backoff');
    }
  }

  // 3. Network timeout
  try {
    const slowClient = new WolfGPT({ 
      apiKey: process.env.WOLFGPT_API_KEY!,
      timeout: 100 // Very short timeout
    });
    await slowClient.chat.create({ messages: [{ role: 'user', content: 'test' }] });
  } catch (error) {
    console.log('⏱️  Timeout caught:', error.message);
  }

  // 4. Invalid parameters
  try {
    await client.images.generate({ 
      prompt: 'test',
      width: 99999 // Invalid size
    });
  } catch (error) {
    console.log('❌ Validation error caught:', error.message);
  }

  // 5. Graceful degradation
  async function generateWithFallback(prompt: string) {
    try {
      return await client.images.generate({ prompt, model: 'flux-pro' });
    } catch (error) {
      console.log('⚠️  Primary model failed, trying fallback...');
      return await client.images.generate({ prompt, model: 'flux-schnell' });
    }
  }

  await generateWithFallback('A beautiful sunset');
  console.log('✅ Fallback successful');

  console.log('\n✅ Error handling demo complete!');
}

errorHandlingExamples().catch(console.error);
