// Advanced SDK usage
import WolfGPT from '@wolfgpt/sdk';

const client = new WolfGPT({
  apiKey: process.env.WOLFGPT_API_KEY!,
  timeout: 120000, // 2 minutes
});

async function advancedExamples() {
  // Multi-turn conversation
  const messages = [
    { role: 'system' as const, content: 'You are a helpful coding tutor.' },
    { role: 'user' as const, content: 'How do I reverse a string in Python?' }
  ];
  
  const response1 = await client.chat.create({ messages });
  console.log('Assistant:', response1.message);
  
  messages.push(
    { role: 'assistant' as const, content: response1.message },
    { role: 'user' as const, content: 'Can you show me without using slicing?' }
  );
  
  const response2 = await client.chat.create({ messages });
  console.log('Assistant:', response2.message);
  
  // Translation chain
  const original = 'Hello, how are you?';
  const spanish = await client.translate.translate({
    text: original,
    targetLanguage: 'es'
  });
  console.log('Spanish:', spanish.translated);
  
  const french = await client.translate.translate({
    text: spanish.translated,
    sourceLanguage: 'es',
    targetLanguage: 'fr'
  });
  console.log('French:', french.translated);
  
  // Summarize with different styles
  const longText = 'Your long text here...'.repeat(100);
  
  const briefSummary = await client.summarize.summarize({
    text: longText,
    style: 'brief',
    maxLength: 200
  });
  console.log('Brief:', briefSummary.summary);
  
  const bulletSummary = await client.summarize.summarize({
    text: longText,
    style: 'bullets'
  });
  console.log('Bullets:', bulletSummary.summary);
}

advancedExamples();
