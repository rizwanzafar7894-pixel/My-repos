# Changelog

## [1.0.0] - 2026-02-21

### Added
- Initial release
- Complete TypeScript SDK for WolfGPT API
- Support for Chat, Images, Voice, Code, Documents, Translate, Summarize APIs
- Streaming support (SSE) for chat completions
- Full type definitions
- Comprehensive examples
- Test suite with 90%+ coverage
