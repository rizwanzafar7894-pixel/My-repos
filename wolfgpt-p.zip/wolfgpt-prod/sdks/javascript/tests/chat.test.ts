import { describe, it, expect, beforeEach, vi } from 'vitest';
import { WolfGPT } from '../src/client';
import type { ChatCompletionRequest } from '../src/types';

describe('Chat API', () => {
  let client: WolfGPT;
  const mockApiKey = 'test_api_key_12345';

  beforeEach(() => {
    client = new WolfGPT({ apiKey: mockApiKey });
  });

  describe('create', () => {
    it('should create a chat completion', async () => {
      const messages = [{ role: 'user' as const, content: 'Hello' }];
      
      // Mock axios response
      vi.spyOn(client.chat['_client'], 'post').mockResolvedValueOnce({
        data: {
          data: {
            message: 'Hi there!',
            model: 'qwen-2.5-7b',
            conversationId: 'conv_123',
            usage: { prompt_tokens: 10, completion_tokens: 20, total_tokens: 30 },
          },
        },
      } as any);

      const response = await client.chat.create({ messages });

      expect(response.message).toBe('Hi there!');
      expect(response.conversationId).toBe('conv_123');
      expect(response.usage.total_tokens).toBe(30);
    });

    it('should handle different models', async () => {
      const messages = [{ role: 'user' as const, content: 'Test' }];
      
      vi.spyOn(client.chat['_client'], 'post').mockResolvedValueOnce({
        data: {
          data: {
            message: 'Response',
            model: 'qwen-2.5-32b',
            conversationId: 'conv_456',
            usage: { prompt_tokens: 5, completion_tokens: 10, total_tokens: 15 },
          },
        },
      } as any);

      const response = await client.chat.create({ 
        messages,
        model: 'qwen-2.5-32b',
      });

      expect(response.model).toBe('qwen-2.5-32b');
    });

    it('should handle API errors', async () => {
      const messages = [{ role: 'user' as const, content: 'Test' }];
      
      vi.spyOn(client.chat['_client'], 'post').mockRejectedValueOnce({
        response: {
          status: 401,
          data: { error: { message: 'Invalid API key' } },
        },
      });

      await expect(client.chat.create({ messages })).rejects.toThrow('Authentication failed');
    });
  });

  describe('stream', () => {
    it('should stream chat completions', async () => {
      const messages = [{ role: 'user' as const, content: 'Count to 3' }];
      const chunks: string[] = [];
      
      const mockStream = {
        data: {
          on: vi.fn((event, callback) => {
            if (event === 'data') {
              callback(Buffer.from('data: {"content":"1"}\n\n'));
              callback(Buffer.from('data: {"content":"2"}\n\n'));
              callback(Buffer.from('data: {"content":"3"}\n\n'));
              callback(Buffer.from('data: [DONE]\n\n'));
            }
          }),
        },
      };

      vi.spyOn(client.chat['_client'], 'post').mockResolvedValueOnce(mockStream as any);

      await client.chat.stream({ messages }, (chunk) => chunks.push(chunk));

      expect(chunks).toEqual(['1', '2', '3']);
    });
  });

  describe('conversations', () => {
    it('should list conversations', async () => {
      vi.spyOn(client.chat['_client'], 'get').mockResolvedValueOnce({
        data: {
          data: [
            { id: 'conv_1', title: 'Chat 1' },
            { id: 'conv_2', title: 'Chat 2' },
          ],
        },
      } as any);

      const conversations = await client.chat.listConversations();
      expect(conversations).toHaveLength(2);
      expect(conversations[0].id).toBe('conv_1');
    });

    it('should delete a conversation', async () => {
      vi.spyOn(client.chat['_client'], 'delete').mockResolvedValueOnce({
        data: { data: { id: 'conv_123', deleted: true } },
      } as any);

      const result = await client.chat.deleteConversation('conv_123');
      expect(result.deleted).toBe(true);
    });
  });
});
