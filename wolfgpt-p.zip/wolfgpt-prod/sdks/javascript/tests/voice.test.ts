import { describe, it, expect, beforeEach, vi } from 'vitest';
import { WolfGPT } from '../src/client';

describe('Voice API', () => {
  let client: WolfGPT;

  beforeEach(() => {
    client = new WolfGPT({ apiKey: 'test_key' });
  });

  it('should transcribe audio', async () => {
    vi.spyOn(client.voice['_client'], 'post').mockResolvedValue({
      data: { data: { text: 'Hello world', language: 'en', duration: 1.5, confidence: 0.95 } }
    } as any);

    const result = await client.voice.transcribe({ audio: Buffer.from('audio') });
    expect(result.text).toBe('Hello world');
    expect(result.confidence).toBe(0.95);
  });

  it('should synthesize speech', async () => {
    vi.spyOn(client.voice['_client'], 'post').mockResolvedValue({ data: Buffer.from('audio') } as any);
    const audio = await client.voice.synthesize({ text: 'Hello' });
    expect(audio).toBeInstanceOf(Buffer);
  });

  it('should list voices', async () => {
    vi.spyOn(client.voice['_client'], 'get').mockResolvedValue({
      data: { voices: [{ id: 'v1', name: 'Emma' }] }
    } as any);
    const voices = await client.voice.listVoices();
    expect(voices).toHaveLength(1);
  });
});
