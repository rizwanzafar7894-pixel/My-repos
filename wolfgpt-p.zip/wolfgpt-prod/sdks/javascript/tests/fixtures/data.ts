// Test fixtures and mock data

export const mockChatMessage = {
  role: 'user' as const,
  content: 'Hello, how are you?'
};

export const mockChatResponse = {
  message: 'I am doing well, thank you!',
  model: 'qwen-2.5-7b',
  conversationId: 'conv_test123',
  usage: {
    prompt_tokens: 10,
    completion_tokens: 15,
    total_tokens: 25
  }
};

export const mockImageResponse = {
  images: [{
    base64: 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==',
    width: 1024,
    height: 1024,
    seed: 12345
  }],
  model: 'flux-schnell',
  generationTime: 2.5
};

export const mockVoiceTranscript = {
  text: 'Hello world',
  language: 'en',
  duration: 1.5,
  confidence: 0.95
};

export const mockCodeExecution = {
  output: 'Hello from Python!',
  error: null,
  executionTime: 0.5,
  language: 'python',
  timedOut: false
};

export const mockDocument = {
  id: 'doc_test123',
  text: 'Sample document content...',
  pageCount: 5,
  wordCount: 1000,
  charCount: 5000,
  fileType: 'pdf',
  truncated: false
};

export const mockTranslation = {
  original: 'Hello',
  translated: 'Hola',
  sourceLanguage: 'en',
  targetLanguage: 'es'
};

export const mockSummary = {
  summary: 'This is a brief summary of the text.',
  style: 'brief',
  wordCount: 10,
  originalLength: 100,
  compressionRatio: 10
};

export const mockApiError = {
  response: {
    status: 401,
    data: {
      error: {
        message: 'Invalid API key',
        code: 'INVALID_API_KEY'
      }
    }
  }
};

export const mockRateLimitError = {
  response: {
    status: 429,
    data: {
      error: {
        message: 'Rate limit exceeded',
        code: 'RATE_LIMIT_EXCEEDED'
      }
    }
  }
};
