import { describe, it, expect, beforeEach, vi } from 'vitest';
import { WolfGPT } from '../src/client';

describe('Images API', () => {
  let client: WolfGPT;

  beforeEach(() => {
    client = new WolfGPT({ apiKey: 'test_key' });
  });

  it('should generate images', async () => {
    vi.spyOn(client.images['_client'], 'post').mockResolvedValueOnce({
      data: {
        data: {
          images: [{ base64: 'base64data', width: 1024, height: 1024, seed: 123 }],
          model: 'flux-schnell',
          generationTime: 2.5,
        },
      },
    } as any);

    const result = await client.images.generate({ prompt: 'A sunset' });
    expect(result.images).toHaveLength(1);
    expect(result.generationTime).toBe(2.5);
  });

  it('should handle image generation errors', async () => {
    vi.spyOn(client.images['_client'], 'post').mockRejectedValueOnce({
      response: { status: 429, data: { error: { message: 'Rate limit exceeded' } } },
    });

    await expect(client.images.generate({ prompt: 'Test' })).rejects.toThrow('Rate limit exceeded');
  });
});

describe('Voice API', () => {
  let client: WolfGPT;

  beforeEach(() => {
    client = new WolfGPT({ apiKey: 'test_key' });
  });

  it('should transcribe audio', async () => {
    const audioBuffer = Buffer.from('fake audio data');
    
    vi.spyOn(client.voice['_client'], 'post').mockResolvedValueOnce({
      data: {
        data: {
          text: 'Hello world',
          language: 'en',
          duration: 1.5,
          confidence: 0.95,
        },
      },
    } as any);

    const result = await client.voice.transcribe({ audio: audioBuffer });
    expect(result.text).toBe('Hello world');
    expect(result.confidence).toBe(0.95);
  });

  it('should synthesize speech', async () => {
    vi.spyOn(client.voice['_client'], 'post').mockResolvedValueOnce({
      data: Buffer.from('audio bytes'),
    } as any);

    const audio = await client.voice.synthesize({ text: 'Hello' });
    expect(audio).toBeInstanceOf(Buffer);
  });
});

describe('Code API', () => {
  let client: WolfGPT;

  beforeEach(() => {
    client = new WolfGPT({ apiKey: 'test_key' });
  });

  it('should execute code', async () => {
    vi.spyOn(client.code['_client'], 'post').mockResolvedValueOnce({
      data: {
        data: {
          output: 'Hello from Python!',
          error: null,
          executionTime: 0.5,
          language: 'python',
          timedOut: false,
        },
      },
    } as any);

    const result = await client.code.execute({
      code: 'print("Hello from Python!")',
      language: 'python',
    });

    expect(result.output).toBe('Hello from Python!');
    expect(result.error).toBeNull();
  });

  it('should handle execution errors', async () => {
    vi.spyOn(client.code['_client'], 'post').mockResolvedValueOnce({
      data: {
        data: {
          output: '',
          error: 'SyntaxError: invalid syntax',
          executionTime: 0.1,
          language: 'python',
          timedOut: false,
        },
      },
    } as any);

    const result = await client.code.execute({
      code: 'print("broken',
      language: 'python',
    });

    expect(result.error).toContain('SyntaxError');
  });
});

describe('Client', () => {
  it('should require API key', () => {
    expect(() => new WolfGPT({ apiKey: '' })).toThrow('API key is required');
  });

  it('should ping API', async () => {
    const client = new WolfGPT({ apiKey: 'test_key' });
    vi.spyOn(client['_client'], 'request').mockResolvedValueOnce({ data: {} } as any);
    
    const result = await client.ping();
    expect(result).toBe(true);
  });

  it('should handle ping failures', async () => {
    const client = new WolfGPT({ apiKey: 'test_key' });
    vi.spyOn(client['_client'], 'request').mockRejectedValueOnce(new Error('Network error'));
    
    const result = await client.ping();
    expect(result).toBe(false);
  });
});
