import { describe, it, expect, beforeEach, vi } from 'vitest';
import { WolfGPT } from '../src/client';

describe('Documents API', () => {
  let client: WolfGPT;

  beforeEach(() => {
    client = new WolfGPT({ apiKey: 'test_key' });
  });

  it('should upload document', async () => {
    vi.spyOn(client.documents['_client'], 'post').mockResolvedValue({
      data: { data: { id: 'doc_123', text: 'content', pageCount: 5, wordCount: 1000 } }
    } as any);

    const doc = await client.documents.upload(Buffer.from('pdf'));
    expect(doc.id).toBe('doc_123');
    expect(doc.pageCount).toBe(5);
  });

  it('should chat with document', async () => {
    vi.spyOn(client.documents['_client'], 'post').mockResolvedValue({
      data: { data: { message: 'Summary of document' } }
    } as any);

    const response = await client.documents.chat({
      documentId: 'doc_123',
      messages: [{ role: 'user', content: 'Summarize' }]
    });

    expect(response.message).toBe('Summary of document');
  });

  it('should list documents', async () => {
    vi.spyOn(client.documents['_client'], 'get').mockResolvedValue({
      data: { data: [{ id: 'doc_1' }, { id: 'doc_2' }] }
    } as any);

    const docs = await client.documents.list();
    expect(docs).toHaveLength(2);
  });

  it('should delete document', async () => {
    vi.spyOn(client.documents['_client'], 'delete').mockResolvedValue({
      data: { data: { deleted: true } }
    } as any);

    const result = await client.documents.delete('doc_123');
    expect(result.deleted).toBe(true);
  });
});
