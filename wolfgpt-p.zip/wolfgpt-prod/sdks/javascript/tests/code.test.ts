import { describe, it, expect, beforeEach, vi } from 'vitest';
import { WolfGPT } from '../src/client';

describe('Code API', () => {
  let client: WolfGPT;

  beforeEach(() => {
    client = new WolfGPT({ apiKey: 'test_key' });
  });

  it('should execute Python code', async () => {
    vi.spyOn(client.code['_client'], 'post').mockResolvedValue({
      data: { data: { output: 'Hello', error: null, executionTime: 0.5, language: 'python', timedOut: false } }
    } as any);

    const result = await client.code.execute({ code: 'print("Hello")', language: 'python' });
    expect(result.output).toBe('Hello');
    expect(result.error).toBeNull();
  });

  it('should handle timeout', async () => {
    vi.spyOn(client.code['_client'], 'post').mockResolvedValue({
      data: { data: { output: '', error: 'Timeout', executionTime: 30, language: 'python', timedOut: true } }
    } as any);

    const result = await client.code.execute({ code: 'while True: pass', language: 'python' });
    expect(result.timedOut).toBe(true);
  });

  it('should get execution history', async () => {
    vi.spyOn(client.code['_client'], 'get').mockResolvedValue({
      data: { data: [{ id: 'exec_1' }, { id: 'exec_2' }] }
    } as any);

    const history = await client.code.getHistory();
    expect(history).toHaveLength(2);
  });
});
