import { describe, it, expect, beforeEach, vi } from 'vitest';
import { WolfGPT } from '../src/client';

describe('Images API', () => {
  let client: WolfGPT;

  beforeEach(() => {
    client = new WolfGPT({ apiKey: 'test_key' });
  });

  it('should generate single image', async () => {
    vi.spyOn(client.images['_client'], 'post').mockResolvedValue({
      data: { data: { images: [{ base64: 'abc', width: 1024, height: 1024 }], model: 'flux-schnell', generationTime: 2.1 } }
    } as any);

    const result = await client.images.generate({ prompt: 'test' });
    expect(result.images).toHaveLength(1);
  });

  it('should generate multiple images', async () => {
    vi.spyOn(client.images['_client'], 'post').mockResolvedValue({
      data: { data: { images: [{}, {}, {}], model: 'flux-schnell', generationTime: 5.0 } }
    } as any);

    const result = await client.images.generate({ prompt: 'test', numImages: 3 });
    expect(result.images).toHaveLength(3);
  });

  it('should handle different models', async () => {
    const models = ['flux-schnell', 'flux-dev', 'sdxl-base'];
    for (const model of models) {
      vi.spyOn(client.images['_client'], 'post').mockResolvedValue({
        data: { data: { images: [], model, generationTime: 1.0 } }
      } as any);
      const result = await client.images.generate({ prompt: 'test', model: model as any });
      expect(result.model).toBe(model);
    }
  });

  it('should download image', async () => {
    vi.spyOn(client.images['_client'], 'get').mockResolvedValue({
      data: { data: { id: 'img_123', base64: Buffer.from('test').toString('base64') } }
    } as any);

    const buffer = await client.images.download('img_123');
    expect(buffer).toBeInstanceOf(Buffer);
  });
});
