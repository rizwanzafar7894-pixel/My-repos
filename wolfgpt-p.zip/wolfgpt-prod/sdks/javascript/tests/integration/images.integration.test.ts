import { describe, it, expect, beforeAll } from 'vitest';
import { WolfGPT } from '../../src/client';

describe('Images Integration Tests', () => {
  let client: WolfGPT;

  beforeAll(() => {
    const apiKey = process.env.WOLFGPT_TEST_API_KEY || 'test_key';
    client = new WolfGPT({ apiKey });
  });

  it.skip('should generate image with FLUX', async () => {
    const result = await client.images.generate({
      prompt: 'A beautiful sunset over mountains',
      model: 'flux-schnell',
      width: 512,
      height: 512,
      steps: 4
    });

    expect(result.images).toHaveLength(1);
    expect(result.images[0].base64).toBeTruthy();
    expect(result.generationTime).toBeGreaterThan(0);
  });

  it.skip('should generate multiple images', async () => {
    const result = await client.images.generate({
      prompt: 'A cute cartoon wolf',
      numImages: 2
    });

    expect(result.images).toHaveLength(2);
  });
});
