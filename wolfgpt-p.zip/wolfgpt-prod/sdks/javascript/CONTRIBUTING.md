# Contributing to WolfGPT SDK

Thank you for your interest in contributing!

## Development Setup

```bash
git clone https://github.com/wolfgpt/wolfgpt-sdk-js.git
cd wolfgpt-sdk-js
npm install
npm run dev
```

## Testing

```bash
npm test
npm run test:coverage
```

## Code Style

We use ESLint and Prettier:

```bash
npm run lint
npm run format
```

## Pull Request Process

1. Fork the repo
2. Create a feature branch
3. Make your changes
4. Add tests
5. Run tests and linting
6. Submit PR

## Reporting Bugs

Please use GitHub Issues and include:
- SDK version
- Node.js version
- Code to reproduce
- Expected vs actual behavior
