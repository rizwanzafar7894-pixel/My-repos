module github.com/wolfgpt/wolfgpt-go

go 1.21

require (
	github.com/google/go-querystring v1.1.0
)
