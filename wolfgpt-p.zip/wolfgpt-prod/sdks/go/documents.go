package wolfgpt

import (
	"bytes"
	"encoding/json"
	"io"
	"mime/multipart"
)

type DocumentsService struct {
	client *Client
}

type DocumentParseResponse struct {
	ID        string `json:"id"`
	Text      string `json:"text"`
	PageCount int    `json:"page_count"`
	WordCount int    `json:"word_count"`
	FileType  string `json:"file_type"`
}

type DocumentChatRequest struct {
	DocumentID string        `json:"document_id"`
	Messages   []ChatMessage `json:"messages"`
}

// Upload uploads and parses a document
func (s *DocumentsService) Upload(file []byte, filename string) (*DocumentParseResponse, error) {
	var buf bytes.Buffer
	writer := multipart.NewWriter(&buf)

	part, err := writer.CreateFormFile("document", filename)
	if err != nil {
		return nil, err
	}
	
	_, err = io.Copy(part, bytes.NewReader(file))
	if err != nil {
		return nil, err
	}
	
	writer.Close()

	resp, err := s.client.doRequest("POST", "/documents/upload", buf.Bytes())
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result struct {
		Data DocumentParseResponse `json:"data"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	
	return &result.Data, nil
}

// Chat chats with a document
func (s *DocumentsService) Chat(req DocumentChatRequest) (*ChatResponse, error) {
	resp, err := s.client.doRequest("POST", "/documents/"+req.DocumentID+"/chat", req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result struct {
		Data ChatResponse `json:"data"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	
	return &result.Data, nil
}

// List lists user's documents
func (s *DocumentsService) List() ([]DocumentParseResponse, error) {
	resp, err := s.client.doRequest("GET", "/documents", nil)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result struct {
		Data []DocumentParseResponse `json:"data"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	
	return result.Data, nil
}

// Delete deletes a document
func (s *DocumentsService) Delete(id string) error {
	resp, err := s.client.doRequest("DELETE", "/documents/"+id, nil)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	return nil
}
