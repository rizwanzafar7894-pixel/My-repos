package wolfgpt

import "testing"

func TestNewClient(t *testing.T) {
	client := NewClient("test_api_key")
	if client == nil {
		t.Fatal("client is nil")
	}
	if client.apiKey != "test_api_key" {
		t.Errorf("expected apiKey to be 'test_api_key', got '%s'", client.apiKey)
	}
}

func TestNewClientWithConfig(t *testing.T) {
	config := Config{
		APIKey:  "test_key",
		BaseURL: "https://custom.api.com",
		Timeout: 30000,
	}
	client := NewClientWithConfig(config)
	
	if client.apiKey != "test_key" {
		t.Errorf("expected apiKey to be 'test_key', got '%s'", client.apiKey)
	}
	if client.baseURL != "https://custom.api.com" {
		t.Errorf("expected baseURL to be 'https://custom.api.com', got '%s'", client.baseURL)
	}
}

func TestClientPanic(t *testing.T) {
	defer func() {
		if r := recover(); r == nil {
			t.Error("expected panic for empty API key")
		}
	}()
	NewClient("")
}
