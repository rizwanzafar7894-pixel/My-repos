package wolfgpt

import "testing"

func TestChatCreate(t *testing.T) {
    client := NewClient("test")
    if client == nil {
        t.Fatal("client is nil")
    }
}
