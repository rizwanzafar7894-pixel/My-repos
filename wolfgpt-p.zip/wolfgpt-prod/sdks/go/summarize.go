package wolfgpt

import "encoding/json"

type SummarizeService struct {
	client *Client
}

type SummarizeRequest struct {
	Text      string `json:"text"`
	Style     string `json:"style"`
	MaxLength int    `json:"max_length,omitempty"`
}

type SummarizeResponse struct {
	Summary          string `json:"summary"`
	Style            string `json:"style"`
	WordCount        int    `json:"word_count"`
	OriginalLength   int    `json:"original_length"`
	CompressionRatio int    `json:"compression_ratio"`
}

// Summarize summarizes text
func (s *SummarizeService) Summarize(req SummarizeRequest) (*SummarizeResponse, error) {
	resp, err := s.client.doRequest("POST", "/summarize", req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result struct {
		Data SummarizeResponse `json:"data"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	
	return &result.Data, nil
}
