package wolfgpt

import "encoding/json"

type TranslateService struct {
	client *Client
}

type TranslateRequest struct {
	Text           string `json:"text"`
	TargetLanguage string `json:"target_language"`
	SourceLanguage string `json:"source_language,omitempty"`
}

type TranslateResponse struct {
	Original       string `json:"original"`
	Translated     string `json:"translated"`
	SourceLanguage string `json:"source_language"`
	TargetLanguage string `json:"target_language"`
}

// Translate translates text
func (s *TranslateService) Translate(req TranslateRequest) (*TranslateResponse, error) {
	resp, err := s.client.doRequest("POST", "/translate", req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result struct {
		Data TranslateResponse `json:"data"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	
	return &result.Data, nil
}

// DetectLanguage detects the language of text
func (s *TranslateService) DetectLanguage(text string) (string, error) {
	resp, err := s.client.doRequest("POST", "/translate/detect", map[string]string{"text": text})
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()

	var result struct {
		Data struct {
			Language string `json:"language"`
		} `json:"data"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return "", err
	}
	
	return result.Data.Language, nil
}
