package wolfgpt

import (
	"os"
	"testing"

	wolfgpt "github.com/wolfgpt/wolfgpt-go"
)

func TestIntegration(t *testing.T) {
	apiKey := os.Getenv("WOLFGPT_TEST_API_KEY")
	if apiKey == "" {
		t.Skip("WOLFGPT_TEST_API_KEY not set")
	}

	client := wolfgpt.NewClient(apiKey)

	t.Run("Chat", func(t *testing.T) {
		resp, err := client.Chat.Create(wolfgpt.ChatRequest{
			Messages: []wolfgpt.ChatMessage{
				{Role: "user", Content: "Hello"},
			},
		})
		if err != nil {
			t.Fatal(err)
		}
		if resp.Message == "" {
			t.Error("expected non-empty message")
		}
	})

	t.Run("Ping", func(t *testing.T) {
		err := client.Ping()
		if err != nil {
			t.Fatal(err)
		}
	})
}
