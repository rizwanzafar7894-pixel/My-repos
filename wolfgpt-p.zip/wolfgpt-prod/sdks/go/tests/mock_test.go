package wolfgpt

import "testing"

type MockClient struct {
	APIKey string
}

func TestMock(t *testing.T) {
	mock := &MockClient{APIKey: "test"}
	if mock.APIKey != "test" {
		t.Fail()
	}
}
