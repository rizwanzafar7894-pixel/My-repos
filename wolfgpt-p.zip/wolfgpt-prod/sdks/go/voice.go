package wolfgpt

import (
	"bytes"
	"encoding/json"
	"io"
	"mime/multipart"
)

type VoiceService struct {
	client *Client
}

type STTResponse struct {
	Text       string  `json:"text"`
	Language   string  `json:"language"`
	Duration   float64 `json:"duration"`
	Confidence float64 `json:"confidence"`
}

type TTSRequest struct {
	Text  string  `json:"text"`
	Voice string  `json:"voice"`
	Speed float64 `json:"speed"`
}

type Voice struct {
	ID       string `json:"id"`
	Name     string `json:"name"`
	Language string `json:"language"`
}

// Transcribe performs speech-to-text
func (s *VoiceService) Transcribe(audioData []byte, language string) (*STTResponse, error) {
	var buf bytes.Buffer
	writer := multipart.NewWriter(&buf)

	part, err := writer.CreateFormFile("audio", "audio.wav")
	if err != nil {
		return nil, err
	}
	
	_, err = io.Copy(part, bytes.NewReader(audioData))
	if err != nil {
		return nil, err
	}
	
	if language != "" {
		writer.WriteField("language", language)
	}
	
	writer.Close()

	resp, err := s.client.doRequest("POST", "/voice/stt", buf.Bytes())
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result struct {
		Data STTResponse `json:"data"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	
	return &result.Data, nil
}

// Synthesize performs text-to-speech
func (s *VoiceService) Synthesize(req TTSRequest) ([]byte, error) {
	resp, err := s.client.doRequest("POST", "/voice/tts", req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	return io.ReadAll(resp.Body)
}

// ListVoices lists available voices
func (s *VoiceService) ListVoices() ([]Voice, error) {
	resp, err := s.client.doRequest("GET", "/voice/voices", nil)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result struct {
		Voices []Voice `json:"voices"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	
	return result.Voices, nil
}
