package wolfgpt

import "testing"

func TestImageGenerate(t *testing.T) {
	client := NewClient("test_key")
	if client.Images == nil {
		t.Fatal("Images service is nil")
	}
}
