package wolfgpt

import "encoding/json"

type CodeService struct {
	client *Client
}

type CodeRequest struct {
	Code     string `json:"code"`
	Language string `json:"language"`
	Stdin    string `json:"stdin,omitempty"`
	Timeout  int    `json:"timeout,omitempty"`
}

type CodeResponse struct {
	Output        string  `json:"output"`
	Error         *string `json:"error"`
	ExecutionTime float64 `json:"execution_time"`
	Language      string  `json:"language"`
	TimedOut      bool    `json:"timed_out"`
}

func (s *CodeService) Execute(req CodeRequest) (*CodeResponse, error) {
	resp, err := s.client.doRequest("POST", "/code/execute", req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result struct {
		Data CodeResponse `json:"data"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	return &result.Data, nil
}
