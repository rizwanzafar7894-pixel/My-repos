package wolfgpt

import (
	"bufio"
	"encoding/json"
)

type ChatService struct {
	client *Client
}

type ChatMessage struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type ChatRequest struct {
	Messages    []ChatMessage `json:"messages"`
	Model       string        `json:"model,omitempty"`
	Temperature float64       `json:"temperature,omitempty"`
	MaxTokens   int           `json:"max_tokens,omitempty"`
	Stream      bool          `json:"stream"`
}

type ChatResponse struct {
	Message        string `json:"message"`
	Model          string `json:"model"`
	ConversationID string `json:"conversation_id"`
}

func (s *ChatService) Create(req ChatRequest) (*ChatResponse, error) {
	req.Stream = false
	resp, err := s.client.doRequest("POST", "/chat/completions", req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result struct {
		Data ChatResponse `json:"data"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	return &result.Data, nil
}

func (s *ChatService) Stream(req ChatRequest, onChunk func(string)) error {
	req.Stream = true
	resp, err := s.client.doRequest("POST", "/chat/completions/stream", req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	scanner := bufio.NewScanner(resp.Body)
	for scanner.Scan() {
		line := scanner.Text()
		if len(line) > 6 && line[:6] == "data: " {
			data := line[6:]
			if data == "[DONE]" {
				return nil
			}
			var chunk map[string]interface{}
			if json.Unmarshal([]byte(data), &chunk) == nil {
				if content, ok := chunk["content"].(string); ok {
					onChunk(content)
				}
			}
		}
	}
	return scanner.Err()
}
