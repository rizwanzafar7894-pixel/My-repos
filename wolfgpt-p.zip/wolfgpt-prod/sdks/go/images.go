package wolfgpt

import "encoding/json"

type ImagesService struct {
	client *Client
}

type ImageRequest struct {
	Prompt         string  `json:"prompt"`
	NegativePrompt string  `json:"negative_prompt,omitempty"`
	Model          string  `json:"model,omitempty"`
	Width          int     `json:"width,omitempty"`
	Height         int     `json:"height,omitempty"`
	Steps          int     `json:"steps,omitempty"`
	NumImages      int     `json:"num_images,omitempty"`
	Seed           *int    `json:"seed,omitempty"`
}

type GeneratedImage struct {
	Base64 string `json:"base64"`
	Width  int    `json:"width"`
	Height int    `json:"height"`
	Seed   *int   `json:"seed"`
}

type ImageResponse struct {
	Images         []GeneratedImage `json:"images"`
	Model          string           `json:"model"`
	GenerationTime float64          `json:"generation_time"`
}

func (s *ImagesService) Generate(req ImageRequest) (*ImageResponse, error) {
	resp, err := s.client.doRequest("POST", "/images/generate", req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result struct {
		Data ImageResponse `json:"data"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	return &result.Data, nil
}
