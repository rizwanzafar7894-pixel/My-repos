// Package wolfgpt provides the official Go SDK for WolfGPT API
package wolfgpt

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

const (
	DefaultBaseURL = "https://api.wolfgpt.com/v1"
	SDKVersion     = "1.0.0"
)

// Client is the main WolfGPT client
type Client struct {
	apiKey     string
	baseURL    string
	httpClient *http.Client

	Chat      *ChatService
	Images    *ImagesService
	Voice     *VoiceService
	Code      *CodeService
	Documents *DocumentsService
	Translate *TranslateService
	Summarize *SummarizeService
}

// Config holds client configuration
type Config struct {
	APIKey  string
	BaseURL string
	Timeout time.Duration
}

// NewClient creates a new WolfGPT client
func NewClient(apiKey string) *Client {
	return NewClientWithConfig(Config{
		APIKey:  apiKey,
		BaseURL: DefaultBaseURL,
		Timeout: 60 * time.Second,
	})
}

// NewClientWithConfig creates a client with custom config
func NewClientWithConfig(config Config) *Client {
	if config.APIKey == "" {
		panic("API key is required. Get one at https://wolfgpt.com/api-keys")
	}

	if config.BaseURL == "" {
		config.BaseURL = DefaultBaseURL
	}

	if config.Timeout == 0 {
		config.Timeout = 60 * time.Second
	}

	c := &Client{
		apiKey:  config.APIKey,
		baseURL: config.BaseURL,
		httpClient: &http.Client{
			Timeout: config.Timeout,
		},
	}

	// Initialize services
	c.Chat = &ChatService{client: c}
	c.Images = &ImagesService{client: c}
	c.Voice = &VoiceService{client: c}
	c.Code = &CodeService{client: c}
	c.Documents = &DocumentsService{client: c}
	c.Translate = &TranslateService{client: c}
	c.Summarize = &SummarizeService{client: c}

	return c
}

// doRequest executes an HTTP request
func (c *Client) doRequest(method, path string, body interface{}) (*http.Response, error) {
	var reqBody io.Reader
	if body != nil {
		jsonData, err := json.Marshal(body)
		if err != nil {
			return nil, fmt.Errorf("marshal request: %w", err)
		}
		reqBody = bytes.NewReader(jsonData)
	}

	req, err := http.NewRequest(method, c.baseURL+path, reqBody)
	if err != nil {
		return nil, fmt.Errorf("create request: %w", err)
	}

	req.Header.Set("X-API-Key", c.apiKey)
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("User-Agent", "wolfgpt-go/"+SDKVersion)

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("execute request: %w", err)
	}

	if resp.StatusCode >= 400 {
		defer resp.Body.Close()
		body, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("API error %d: %s", resp.StatusCode, string(body))
	}

	return resp, nil
}

// Ping tests API connectivity
func (c *Client) Ping() error {
	resp, err := c.doRequest("GET", "/health", nil)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	return nil
}

// GetUsage gets API key usage stats
func (c *Client) GetUsage() (map[string]interface{}, error) {
	resp, err := c.doRequest("GET", "/auth/usage", nil)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result map[string]interface{}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return nil, err
	}
	return result, nil
}

// APIError represents an API error
type APIError struct {
	StatusCode int
	Message    string
	Code       string
}

func (e *APIError) Error() string {
	return fmt.Sprintf("wolfgpt: %s (status %d, code %s)", e.Message, e.StatusCode, e.Code)
}
