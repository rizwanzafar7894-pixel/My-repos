package wolfgpt

import "testing"

func TestVoiceService(t *testing.T) {
	client := NewClient("test_key")
	if client.Voice == nil {
		t.Fatal("Voice service is nil")
	}
}
