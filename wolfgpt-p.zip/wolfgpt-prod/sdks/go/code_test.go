package wolfgpt

import "testing"

func TestCodeService(t *testing.T) {
	client := NewClient("test_key")
	if client.Code == nil {
		t.Fatal("Code service is nil")
	}
}
