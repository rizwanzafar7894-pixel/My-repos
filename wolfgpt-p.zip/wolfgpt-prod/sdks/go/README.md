# 🐺 WolfGPT Go SDK

Official Go SDK for WolfGPT API.

## Installation

```bash
go get github.com/wolfgpt/wolfgpt-go
```

## Quick Start

```go
package main

import (
	"fmt"
	"github.com/wolfgpt/wolfgpt-go"
)

func main() {
	client := wolfgpt.NewClient("YOUR_API_KEY")

	// Chat
	resp, _ := client.Chat.Create(wolfgpt.ChatRequest{
		Messages: []wolfgpt.ChatMessage{
			{Role: "user", Content: "Hello!"},
		},
	})
	fmt.Println(resp.Message)

	// Images
	img, _ := client.Images.Generate(wolfgpt.ImageRequest{
		Prompt: "A serene landscape",
		Model:  "flux-schnell",
	})
	fmt.Printf("Generated %d images\n", len(img.Images))

	// Code
	result, _ := client.Code.Execute(wolfgpt.CodeRequest{
		Code:     "print('Hello')",
		Language: "python",
	})
	fmt.Println(result.Output)
}
```

## License
MIT
