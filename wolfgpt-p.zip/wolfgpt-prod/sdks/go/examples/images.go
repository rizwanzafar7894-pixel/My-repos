package main

import (
	"encoding/base64"
	"fmt"
	"os"

	"github.com/wolfgpt/wolfgpt-go"
)

func main() {
	client := wolfgpt.NewClient(os.Getenv("WOLFGPT_API_KEY"))

	result, err := client.Images.Generate(wolfgpt.ImageRequest{
		Prompt: "A futuristic city at sunset, highly detailed",
		Model:  "flux-schnell",
		Width:  1024,
		Height: 1024,
		Steps:  4,
	})

	if err != nil {
		panic(err)
	}

	fmt.Printf("Generated %d image(s) in %.2fs\n", len(result.Images), result.GenerationTime)

	// Save first image
	if len(result.Images) > 0 {
		imgData, err := base64.StdEncoding.DecodeString(result.Images[0].Base64)
		if err != nil {
			panic(err)
		}

		err = os.WriteFile("output.png", imgData, 0644)
		if err != nil {
			panic(err)
		}

		fmt.Println("Image saved to output.png")
	}
}
