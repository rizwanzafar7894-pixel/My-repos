package main

import (
	"fmt"
	"os"

	"github.com/wolfgpt/wolfgpt-go"
)

func main() {
	client := wolfgpt.NewClient(os.Getenv("WOLFGPT_API_KEY"))

	// Simple chat
	resp, err := client.Chat.Create(wolfgpt.ChatRequest{
		Messages: []wolfgpt.ChatMessage{
			{Role: "user", Content: "What is Go programming language?"},
		},
		Model:       "qwen-2.5-7b",
		Temperature: 0.7,
	})

	if err != nil {
		panic(err)
	}

	fmt.Println("Response:", resp.Message)
	fmt.Printf("Model: %s, Conversation: %s\n", resp.Model, resp.ConversationID)

	// Streaming chat
	fmt.Println("\nStreaming response:")
	err = client.Chat.Stream(
		wolfgpt.ChatRequest{
			Messages: []wolfgpt.ChatMessage{
				{Role: "user", Content: "Count from 1 to 5"},
			},
		},
		func(chunk string) {
			fmt.Print(chunk)
		},
	)

	if err != nil {
		panic(err)
	}

	fmt.Println("\nDone!")
}
