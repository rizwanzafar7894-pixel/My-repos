package main

import (
	"fmt"
	"os"

	"github.com/wolfgpt/wolfgpt-go"
)

func main() {
	client := wolfgpt.NewClient(os.Getenv("WOLFGPT_API_KEY"))

	// Text-to-speech
	audioData, err := client.Voice.Synthesize(wolfgpt.TTSRequest{
		Text:  "Hello from WolfGPT!",
		Voice: "en-US-female-1",
		Speed: 1.0,
	})

	if err != nil {
		panic(err)
	}

	err = os.WriteFile("output.wav", audioData, 0644)
	if err != nil {
		panic(err)
	}

	fmt.Println("Audio saved to output.wav")

	// Speech-to-text (if you have an audio file)
	if _, err := os.Stat("test-audio.wav"); err == nil {
		audioBytes, _ := os.ReadFile("test-audio.wav")
		
		transcript, err := client.Voice.Transcribe(audioBytes, "en")
		if err != nil {
			panic(err)
		}

		fmt.Printf("Transcript: %s\n", transcript.Text)
		fmt.Printf("Language: %s, Confidence: %.2f\n", transcript.Language, transcript.Confidence)
	}
}
