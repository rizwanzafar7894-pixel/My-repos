package main

import (
	"fmt"
	"os"

	"github.com/wolfgpt/wolfgpt-go"
)

func main() {
	client := wolfgpt.NewClient(os.Getenv("WOLFGPT_API_KEY"))

	// Upload document
	pdfData, err := os.ReadFile("sample.pdf")
	if err != nil {
		fmt.Println("Error: Please provide sample.pdf")
		return
	}

	doc, err := client.Documents.Upload(pdfData, "sample.pdf")
	if err != nil {
		panic(err)
	}

	fmt.Printf("Uploaded: %d pages, %d words\n", doc.PageCount, doc.WordCount)

	// Chat with document
	chatResp, err := client.Documents.Chat(wolfgpt.DocumentChatRequest{
		DocumentID: doc.ID,
		Messages: []wolfgpt.ChatMessage{
			{Role: "user", Content: "Summarize this document in 3 sentences"},
		},
	})

	if err != nil {
		panic(err)
	}

	fmt.Println("\nSummary:", chatResp.Message)

	// List documents
	docs, err := client.Documents.List()
	if err != nil {
		panic(err)
	}

	fmt.Printf("\nTotal documents: %d\n", len(docs))
}
