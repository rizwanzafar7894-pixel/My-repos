package main

import (
	"fmt"
	"os"
	"sync"
	"time"

	"github.com/wolfgpt/wolfgpt-go"
)

func main() {
	client := wolfgpt.NewClient(os.Getenv("WOLFGPT_API_KEY"))

	start := time.Now()
	
	// Run 5 concurrent chat requests
	var wg sync.WaitGroup
	for i := 0; i < 5; i++ {
		wg.Add(1)
		go func(id int) {
			defer wg.Done()
			_, err := client.Chat.Create(wolfgpt.ChatRequest{
				Messages: []wolfgpt.ChatMessage{
					{Role: "user", Content: fmt.Sprintf("Request %d", id)},
				},
			})
			if err == nil {
				fmt.Printf("✓ Request %d completed\n", id)
			} else {
				fmt.Printf("✗ Request %d failed: %v\n", id, err)
			}
		}(i)
	}

	wg.Wait()
	elapsed := time.Since(start)
	fmt.Printf("\nCompleted 5 concurrent requests in %v\n", elapsed)
}
