package main

import (
	"fmt"
	"os"

	"github.com/wolfgpt/wolfgpt-go"
)

func main() {
	client := wolfgpt.NewClient(os.Getenv("WOLFGPT_API_KEY"))

	// Execute Python code
	result, err := client.Code.Execute(wolfgpt.CodeRequest{
		Code: `
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n-1) + fibonacci(n-2)

for i in range(10):
    print(f"fib({i}) = {fibonacci(i)}")
`,
		Language: "python",
	})

	if err != nil {
		panic(err)
	}

	fmt.Println("Output:", result.Output)
	fmt.Printf("Execution time: %.3fs\n", result.ExecutionTime)

	if result.Error != nil {
		fmt.Println("Error:", *result.Error)
	}

	// Execute JavaScript
	jsResult, _ := client.Code.Execute(wolfgpt.CodeRequest{
		Code:     "console.log([1,2,3,4,5].map(x => x * x))",
		Language: "javascript",
	})

	fmt.Println("\nJavaScript output:", jsResult.Output)
}
