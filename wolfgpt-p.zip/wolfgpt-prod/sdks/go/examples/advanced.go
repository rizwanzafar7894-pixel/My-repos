package main

import (
	"fmt"
	"os"
	"sync"

	"github.com/wolfgpt/wolfgpt-go"
)

func main() {
	client := wolfgpt.NewClient(os.Getenv("WOLFGPT_API_KEY"))

	// Concurrent image generation
	prompts := []string{
		"A sunset over mountains",
		"A futuristic city",
		"A serene lake",
	}

	var wg sync.WaitGroup
	results := make(chan string, len(prompts))

	for _, prompt := range prompts {
		wg.Add(1)
		go func(p string) {
			defer wg.Done()
			result, err := client.Images.Generate(wolfgpt.ImageRequest{
				Prompt: p,
				Model:  "flux-schnell",
			})
			if err != nil {
				results <- fmt.Sprintf("Error: %v", err)
			} else {
				results <- fmt.Sprintf("Generated image for: %s (%.2fs)", p, result.GenerationTime)
			}
		}(prompt)
	}

	wg.Wait()
	close(results)

	fmt.Println("Concurrent generation results:")
	for result := range results {
		fmt.Println("-", result)
	}

	// Multi-turn conversation
	messages := []wolfgpt.ChatMessage{
		{Role: "system", Content: "You are a helpful assistant."},
		{Role: "user", Content: "What is the capital of France?"},
	}

	resp1, _ := client.Chat.Create(wolfgpt.ChatRequest{Messages: messages})
	fmt.Println("\nUser: What is the capital of France?")
	fmt.Println("Assistant:", resp1.Message)

	messages = append(messages,
		wolfgpt.ChatMessage{Role: "assistant", Content: resp1.Message},
		wolfgpt.ChatMessage{Role: "user", Content: "What's its population?"},
	)

	resp2, _ := client.Chat.Create(wolfgpt.ChatRequest{Messages: messages})
	fmt.Println("\nUser: What's its population?")
	fmt.Println("Assistant:", resp2.Message)
}
