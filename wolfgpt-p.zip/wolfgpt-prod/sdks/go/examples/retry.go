package main

import (
	"fmt"
	"os"
	"time"

	"github.com/wolfgpt/wolfgpt-go"
)

func retryWithBackoff(fn func() error, maxRetries int) error {
	var err error
	for i := 0; i < maxRetries; i++ {
		err = fn()
		if err == nil {
			return nil
		}

		if i < maxRetries-1 {
			delay := time.Duration(1<<uint(i)) * time.Second
			fmt.Printf("Retry %d/%d after %v...\n", i+1, maxRetries, delay)
			time.Sleep(delay)
		}
	}
	return err
}

func main() {
	client := wolfgpt.NewClient(os.Getenv("WOLFGPT_API_KEY"))

	fmt.Println("Retrying with exponential backoff...")
	
	err := retryWithBackoff(func() error {
		_, err := client.Chat.Create(wolfgpt.ChatRequest{
			Messages: []wolfgpt.ChatMessage{
				{Role: "user", Content: "Hello!"},
			},
		})
		return err
	}, 3)

	if err != nil {
		fmt.Println("Failed after retries:", err)
	} else {
		fmt.Println("✓ Success!")
	}
}
