package main

import (
	"fmt"
	"os"
	"sync"

	"github.com/wolfgpt/wolfgpt-go"
)

func main() {
	client := wolfgpt.NewClient(os.Getenv("WOLFGPT_API_KEY"))

	// Batch translations
	texts := []string{"Hello", "Goodbye", "Thank you", "Please"}
	var wg sync.WaitGroup
	results := make(chan string, len(texts))

	for _, text := range texts {
		wg.Add(1)
		go func(t string) {
			defer wg.Done()
			result, err := client.Translate.Translate(wolfgpt.TranslateRequest{
				Text:           t,
				TargetLanguage: "es",
			})
			if err != nil {
				results <- fmt.Sprintf("%s: error", t)
			} else {
				results <- fmt.Sprintf("%s → %s", t, result.Translated)
			}
		}(text)
	}

	wg.Wait()
	close(results)

	fmt.Println("Batch translations:")
	for result := range results {
		fmt.Println("-", result)
	}
}
