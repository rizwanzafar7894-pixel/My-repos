package main

import (
	"fmt"
	"os"

	"github.com/wolfgpt/wolfgpt-go"
)

func main() {
	// Example 1: Invalid API key
	fmt.Println("1. Testing invalid API key...")
	invalidClient := wolfgpt.NewClient("invalid_key")
	_, err := invalidClient.Chat.Create(wolfgpt.ChatRequest{
		Messages: []wolfgpt.ChatMessage{{Role: "user", Content: "test"}},
	})
	if err != nil {
		fmt.Println("✓ Error caught:", err)
	}

	// Example 2: Graceful degradation
	client := wolfgpt.NewClient(os.Getenv("WOLFGPT_API_KEY"))
	
	fmt.Println("\n2. Fallback pattern...")
	_, err = client.Images.Generate(wolfgpt.ImageRequest{
		Prompt: "test",
		Model:  "flux-pro",
	})
	if err != nil {
		fmt.Println("Primary model failed, trying fallback...")
		_, err = client.Images.Generate(wolfgpt.ImageRequest{
			Prompt: "test",
			Model:  "flux-schnell",
		})
		if err == nil {
			fmt.Println("✓ Fallback successful")
		}
	}

	fmt.Println("\n✓ Error handling demo complete!")
}
