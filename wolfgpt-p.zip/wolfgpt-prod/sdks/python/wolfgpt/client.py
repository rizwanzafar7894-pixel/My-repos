"""WolfGPT Python SDK — Official client for WolfGPT API."""

from typing import Optional
import httpx

from wolfgpt.api.chat import ChatAPI
from wolfgpt.api.images import ImagesAPI
from wolfgpt.api.voice import VoiceAPI
from wolfgpt.api.code import CodeAPI
from wolfgpt.api.documents import DocumentsAPI
from wolfgpt.api.translate import TranslateAPI
from wolfgpt.api.summarize import SummarizeAPI


class WolfGPT:
    """Main WolfGPT client."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.wolfgpt.com/v1",
        timeout: float = 60.0,
    ):
        """
        Initialize WolfGPT client.

        Args:
            api_key: Your WolfGPT API key (get from https://wolfgpt.com/api-keys)
            base_url: Base API URL (default: https://api.wolfgpt.com/v1)
            timeout: Request timeout in seconds (default: 60)
        """
        if not api_key:
            raise ValueError("API key is required. Get one at https://wolfgpt.com/api-keys")

        self._client = httpx.Client(
            base_url=base_url,
            timeout=timeout,
            headers={
                "X-API-Key": api_key,
                "Content-Type": "application/json",
                "User-Agent": "wolfgpt-python/1.0.0",
            },
        )

        # Initialize API modules
        self.chat = ChatAPI(self._client)
        self.images = ImagesAPI(self._client)
        self.voice = VoiceAPI(self._client)
        self.code = CodeAPI(self._client)
        self.documents = DocumentsAPI(self._client)
        self.translate = TranslateAPI(self._client)
        self.summarize = SummarizeAPI(self._client)

    def close(self):
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def get_usage(self) -> dict:
        """Get API key usage statistics."""
        response = self._client.get("/auth/usage")
        response.raise_for_status()
        return response.json()

    def ping(self) -> bool:
        """Test API connectivity."""
        try:
            response = self._client.get("/health")
            return response.status_code == 200
        except Exception:
            return False


class AsyncWolfGPT:
    """Async WolfGPT client for async/await usage."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.wolfgpt.com/v1",
        timeout: float = 60.0,
    ):
        if not api_key:
            raise ValueError("API key is required")

        self._client = httpx.AsyncClient(
            base_url=base_url,
            timeout=timeout,
            headers={
                "X-API-Key": api_key,
                "Content-Type": "application/json",
                "User-Agent": "wolfgpt-python/1.0.0",
            },
        )

        # Async API modules would go here
        # For simplicity, we're focusing on sync API in this SDK

    async def close(self):
        await self._client.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
