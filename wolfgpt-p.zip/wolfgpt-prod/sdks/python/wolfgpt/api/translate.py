from wolfgpt.api import TranslateAPI
