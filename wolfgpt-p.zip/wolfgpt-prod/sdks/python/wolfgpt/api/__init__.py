"""WolfGPT API modules."""

from typing import Callable, List, Optional, BinaryIO, Union
import httpx
from pathlib import Path

from wolfgpt.types import (
    ChatMessage,
    ChatCompletionResponse,
    ImageGenerationRequest,
    ImageGenerationResponse,
    STTResponse,
    CodeExecutionRequest,
    CodeExecutionResponse,
    TranslateRequest,
    TranslateResponse,
    SummarizeRequest,
    SummarizeResponse,
)


# ── Chat API ──────────────────────────────────────────────────────────────────
class ChatAPI:
    def __init__(self, client: httpx.Client):
        self._client = client

    def create(
        self,
        messages: List[ChatMessage],
        model: str = "qwen-2.5-7b",
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> ChatCompletionResponse:
        """Create a chat completion."""
        response = self._client.post(
            "/chat/completions",
            json={
                "messages": [m.model_dump() if hasattr(m, "model_dump") else m for m in messages],
                "model": model,
                "temperature": temperature,
                "max_tokens": max_tokens,
                "stream": False,
            },
        )
        response.raise_for_status()
        return ChatCompletionResponse(**response.json()["data"])

    def stream(
        self,
        messages: List[ChatMessage],
        on_chunk: Callable[[str], None],
        model: str = "qwen-2.5-7b",
        temperature: float = 0.7,
    ):
        """Stream a chat completion (SSE)."""
        with self._client.stream(
            "POST",
            "/chat/completions/stream",
            json={
                "messages": [m.model_dump() if hasattr(m, "model_dump") else m for m in messages],
                "model": model,
                "temperature": temperature,
                "stream": True,
            },
        ) as response:
            response.raise_for_status()
            for line in response.iter_lines():
                if line.startswith("data: "):
                    data = line[6:]
                    if data == "[DONE]":
                        return
                    try:
                        import json
                        chunk = json.loads(data)
                        content = chunk.get("content") or chunk.get("choices", [{}])[0].get("delta", {}).get("content")
                        if content:
                            on_chunk(content)
                    except json.JSONDecodeError:
                        pass

    def list_conversations(self, limit: int = 50) -> List[dict]:
        """List conversation history."""
        response = self._client.get("/chat/conversations", params={"limit": limit})
        response.raise_for_status()
        return response.json()["data"]


# ── Images API ────────────────────────────────────────────────────────────────
class ImagesAPI:
    def __init__(self, client: httpx.Client):
        self._client = client

    def generate(self, **kwargs) -> ImageGenerationResponse:
        """Generate images from text prompt."""
        request = ImageGenerationRequest(**kwargs)
        response = self._client.post("/images/generate", json=request.model_dump())
        response.raise_for_status()
        return ImageGenerationResponse(**response.json()["data"])

    def get_gallery(self, limit: int = 50) -> List[dict]:
        """Get user's image gallery."""
        response = self._client.get("/images/gallery", params={"limit": limit})
        response.raise_for_status()
        return response.json()["data"]


# ── Voice API ─────────────────────────────────────────────────────────────────
class VoiceAPI:
    def __init__(self, client: httpx.Client):
        self._client = client

    def transcribe(
        self,
        audio: Union[bytes, BinaryIO, Path],
        language: str = "en",
        model: str = "base",
    ) -> STTResponse:
        """Speech-to-text transcription."""
        if isinstance(audio, Path):
            audio = audio.read_bytes()
        elif hasattr(audio, "read"):
            audio = audio.read()

        files = {"audio": ("audio.wav", audio, "audio/wav")}
        data = {"language": language, "model": model}

        response = self._client.post("/voice/stt", files=files, data=data)
        response.raise_for_status()
        return STTResponse(**response.json()["data"])

    def synthesize(self, text: str, voice: str = "en-US-female-1", speed: float = 1.0) -> bytes:
        """Text-to-speech synthesis."""
        response = self._client.post("/voice/tts", json={"text": text, "voice": voice, "speed": speed})
        response.raise_for_status()
        return response.content


# ── Code API ──────────────────────────────────────────────────────────────────
class CodeAPI:
    def __init__(self, client: httpx.Client):
        self._client = client

    def execute(self, **kwargs) -> CodeExecutionResponse:
        """Execute code in sandboxed environment."""
        request = CodeExecutionRequest(**kwargs)
        response = self._client.post("/code/execute", json=request.model_dump())
        response.raise_for_status()
        return CodeExecutionResponse(**response.json()["data"])


# ── Documents API ─────────────────────────────────────────────────────────────
class DocumentsAPI:
    def __init__(self, client: httpx.Client):
        self._client = client

    def upload(self, file: Union[bytes, BinaryIO, Path]) -> dict:
        """Upload and parse a document."""
        if isinstance(file, Path):
            file = file.read_bytes()
        elif hasattr(file, "read"):
            file = file.read()

        files = {"document": ("document.pdf", file, "application/pdf")}
        response = self._client.post("/documents/upload", files=files)
        response.raise_for_status()
        return response.json()["data"]


# ── Translate API ─────────────────────────────────────────────────────────────
class TranslateAPI:
    def __init__(self, client: httpx.Client):
        self._client = client

    def translate(self, **kwargs) -> TranslateResponse:
        """Translate text to another language."""
        request = TranslateRequest(**kwargs)
        response = self._client.post("/translate", json=request.model_dump())
        response.raise_for_status()
        return TranslateResponse(**response.json()["data"])


# ── Summarize API ─────────────────────────────────────────────────────────────
class SummarizeAPI:
    def __init__(self, client: httpx.Client):
        self._client = client

    def summarize(self, **kwargs) -> SummarizeResponse:
        """Summarize text."""
        request = SummarizeRequest(**kwargs)
        response = self._client.post("/summarize", json=request.model_dump())
        response.raise_for_status()
        return SummarizeResponse(**response.json()["data"])
