from wolfgpt.api import ChatAPI
