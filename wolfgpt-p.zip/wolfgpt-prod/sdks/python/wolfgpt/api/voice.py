from wolfgpt.api import VoiceAPI
