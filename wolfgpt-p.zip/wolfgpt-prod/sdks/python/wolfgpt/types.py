"""Type definitions for WolfGPT SDK."""

from typing import List, Literal, Optional, Union
from pydantic import BaseModel, Field


# ── Chat ──────────────────────────────────────────────────────────────────────
class ChatMessage(BaseModel):
    role: Literal["user", "assistant", "system"]
    content: str


class ChatCompletionRequest(BaseModel):
    messages: List[ChatMessage]
    model: str = "qwen-2.5-7b"
    temperature: float = Field(0.7, ge=0.0, le=2.0)
    max_tokens: int = Field(2048, ge=1, le=32768)
    stream: bool = False


class ChatUsage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class ChatCompletionResponse(BaseModel):
    message: str
    model: str
    conversation_id: str
    usage: ChatUsage


# ── Images ────────────────────────────────────────────────────────────────────
class ImageGenerationRequest(BaseModel):
    prompt: str
    negative_prompt: Optional[str] = None
    model: str = "flux-schnell"
    width: int = Field(1024, ge=256, le=2048)
    height: int = Field(1024, ge=256, le=2048)
    steps: int = Field(4, ge=1, le=100)
    num_images: int = Field(1, ge=1, le=4)
    seed: Optional[int] = None


class GeneratedImage(BaseModel):
    base64: str
    width: int
    height: int
    seed: Optional[int] = None


class ImageGenerationResponse(BaseModel):
    images: List[GeneratedImage]
    model: str
    generation_time: float


# ── Voice ─────────────────────────────────────────────────────────────────────
class STTResponse(BaseModel):
    text: str
    language: str
    duration: float
    confidence: float


class TTSRequest(BaseModel):
    text: str
    voice: str = "en-US-female-1"
    speed: float = Field(1.0, ge=0.5, le=2.0)


# ── Code ──────────────────────────────────────────────────────────────────────
class CodeExecutionRequest(BaseModel):
    code: str
    language: Literal["python", "javascript", "typescript", "bash", "go", "rust"]
    stdin: str = ""
    timeout: int = Field(30, ge=1, le=300)


class CodeExecutionResponse(BaseModel):
    output: str
    error: Optional[str]
    execution_time: float
    language: str
    timed_out: bool


# ── Documents ─────────────────────────────────────────────────────────────────
class DocumentParseResponse(BaseModel):
    text: str
    page_count: int
    word_count: int
    char_count: int
    file_type: str
    truncated: bool


# ── Translate ─────────────────────────────────────────────────────────────────
class TranslateRequest(BaseModel):
    text: str
    target_language: str
    source_language: str = "auto"


class TranslateResponse(BaseModel):
    original: str
    translated: str
    source_language: str
    target_language: str


# ── Summarize ─────────────────────────────────────────────────────────────────
class SummarizeRequest(BaseModel):
    text: str
    style: Literal["brief", "detailed", "bullets", "tldr", "academic"] = "brief"
    max_length: int = Field(500, ge=50, le=1000)


class SummarizeResponse(BaseModel):
    summary: str
    style: str
    word_count: int
    original_length: int
    compression_ratio: int


# ── Errors ────────────────────────────────────────────────────────────────────
class WolfGPTError(Exception):
    """Base exception for WolfGPT SDK."""

    def __init__(self, message: str, code: Optional[str] = None, status_code: Optional[int] = None):
        super().__init__(message)
        self.code = code
        self.status_code = status_code
