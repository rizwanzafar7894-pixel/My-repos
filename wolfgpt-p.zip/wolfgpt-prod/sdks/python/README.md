# 🐺 WolfGPT Python SDK

Official Python SDK for WolfGPT API.

## Installation

```bash
pip install wolfgpt
```

## Quick Start

```python
from wolfgpt import WolfGPT

# Initialize client
wolfgpt = WolfGPT(api_key="YOUR_API_KEY")

# Chat completion
response = wolfgpt.chat.create(
    messages=[{"role": "user", "content": "Hello!"}]
)
print(response.message)

# Streaming chat
def on_chunk(text):
    print(text, end="", flush=True)

wolfgpt.chat.stream(
    messages=[{"role": "user", "content": "Tell me a story"}],
    on_chunk=on_chunk
)
```

## Features

- ✅ Full type hints with Pydantic models
- ✅ Sync and async clients
- ✅ Streaming support (SSE)
- ✅ Automatic error handling
- ✅ Context manager support

## Examples

### Chat

```python
# Simple chat
response = wolfgpt.chat.create(
    messages=[
        {"role": "system", "content": "You are helpful"},
        {"role": "user", "content": "What is 2+2?"}
    ],
    model="qwen-2.5-32b",
    temperature=0.7
)

# Streaming
wolfgpt.chat.stream(
    messages=[{"role": "user", "content": "Count to 10"}],
    on_chunk=lambda c: print(c, end="")
)
```

### Images

```python
result = wolfgpt.images.generate(
    prompt="A serene mountain landscape",
    model="flux-schnell",
    width=1024,
    height=1024
)

# Save image
import base64
img_data = base64.b64decode(result.images[0].base64)
with open("output.png", "wb") as f:
    f.write(img_data)
```

### Voice

```python
# Speech-to-text
with open("audio.mp3", "rb") as f:
    transcript = wolfgpt.voice.transcribe(f, language="en")
    print(transcript.text)

# Text-to-speech
audio = wolfgpt.voice.synthesize(
    text="Hello world",
    voice="en-US-female-1"
)
with open("speech.wav", "wb") as f:
    f.write(audio)
```

### Code Execution

```python
result = wolfgpt.code.execute(
    code='print("Hello from Python!")',
    language="python"
)
print(result.output)
```

### Documents

```python
from pathlib import Path

# Upload document
doc = wolfgpt.documents.upload(Path("document.pdf"))
print(f"Extracted {doc['word_count']} words")

# Chat with document
response = wolfgpt.documents.chat(
    document_id=doc["id"],
    messages=[{"role": "user", "content": "Summarize this"}]
)
```

## Context Manager

```python
with WolfGPT(api_key="...") as client:
    response = client.chat.create(messages=[...])
```

## Error Handling

```python
from wolfgpt.types import WolfGPTError

try:
    response = wolfgpt.chat.create(messages=[...])
except WolfGPTError as e:
    print(f"Error: {e.message} (code: {e.code})")
```

## License

MIT
