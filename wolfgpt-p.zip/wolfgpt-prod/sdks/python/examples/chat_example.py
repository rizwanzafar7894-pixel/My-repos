from wolfgpt import WolfGPT
client = WolfGPT(api_key='test')