from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="wolfgpt",
    version="1.0.0",
    author="WolfGPT Team",
    author_email="support@wolfgpt.com",
    description="Official Python SDK for WolfGPT API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourorg/wolfgpt-sdk-python",
    project_urls={
        "Bug Tracker": "https://github.com/yourorg/wolfgpt/issues",
        "Documentation": "https://wolfgpt.com/docs/sdk",
    },
    packages=find_packages(exclude=["tests", "examples"]),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.8",
    install_requires=[
        "httpx>=0.27.0",
        "pydantic>=2.0.0",
        "typing-extensions>=4.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-asyncio>=0.21.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "ruff>=0.1.0",
            "mypy>=1.0.0",
        ],
    },
    keywords="wolfgpt ai chatgpt api sdk python chat images voice code",
)
