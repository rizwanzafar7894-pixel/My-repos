import pytest
from wolfgpt import WolfGPT

def test_basic():
    client = WolfGPT(api_key="test")
    assert client is not None
