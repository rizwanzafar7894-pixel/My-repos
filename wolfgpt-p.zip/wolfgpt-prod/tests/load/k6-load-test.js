import http from 'k6/http';
import { check, sleep } from 'k6';
export const options = {
  stages: [
    { duration: '1m', target: 100 },
    { duration: '3m', target: 100 },
    { duration: '1m', target: 0 },
  ],
  thresholds: {
    http_req_duration: ['p(95)<500'],
    http_req_failed: ['rate<0.01'],
  },
};
export default function () {
  const res = http.post('http://localhost:4000/api/chat/completions', 
    JSON.stringify({
      messages: [{ role: 'user', content: 'test' }]
    }),
    { headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer test_token' } }
  );
  check(res, { 'status is 200': (r) => r.status === 200 });
  sleep(1);
}
