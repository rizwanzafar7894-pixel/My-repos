import { jest } from '@jest/globals';

// Global test setup
process.env.NODE_ENV = 'test';
process.env.PORT     = '4001';

// Silence logger output in tests
jest.mock('../backend/src/utils/logger', () => ({
  default: {
    info:  jest.fn(),
    error: jest.fn(),
    warn:  jest.fn(),
    http:  jest.fn(),
    debug: jest.fn(),
  },
}));
