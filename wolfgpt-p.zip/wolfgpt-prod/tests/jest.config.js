/** @type {import('jest').Config} */
module.exports = {
  preset:           'ts-jest',
  testEnvironment:  'node',
  rootDir:          '..',
  testMatch:        ['**/tests/unit/**/*.test.ts'],
  moduleNameMapper: {
    '^@/(.*)$': '<rootDir>/frontend/src/$1',
  },
  transform: {
    '^.+\\.tsx?$': ['ts-jest', {
      tsconfig: {
        strict: false,
        esModuleInterop: true,
        moduleResolution: 'node',
      },
    }],
  },
  collectCoverageFrom: [
    'backend/src/**/*.ts',
    '!backend/src/**/*.d.ts',
    '!backend/src/server.ts',
  ],
  coverageThreshold: {
    global: { branches: 60, functions: 70, lines: 70 },
  },
  setupFilesAfterFramework: [],
  testTimeout: 30000,
};
