import { describe, it, expect, jest, beforeEach } from '@jest/globals';

// ── requireTier ───────────────────────────────────────────────────────────────
describe('requireTier middleware', () => {
  let mockReq: any;
  let mockRes: any;
  let mockNext: jest.Mock;

  beforeEach(() => {
    mockReq  = { user: { uid: 'u1', email: 'e@test.com', tier: 'free' } };
    mockRes  = { status: jest.fn().mockReturnThis(), json: jest.fn() };
    mockNext = jest.fn();
  });

  it('allows access when user meets minimum tier', async () => {
    const { requireTier } = await import('../../backend/src/middleware/requireTier');
    mockReq.user.tier = 'premium';
    requireTier('basic')(mockReq, mockRes, mockNext);
    expect(mockNext).toHaveBeenCalledTimes(1);
    expect(mockRes.status).not.toHaveBeenCalled();
  });

  it('allows access at exact tier level', async () => {
    const { requireTier } = await import('../../backend/src/middleware/requireTier');
    mockReq.user.tier = 'basic';
    requireTier('basic')(mockReq, mockRes, mockNext);
    expect(mockNext).toHaveBeenCalledTimes(1);
  });

  it('blocks access below required tier', async () => {
    const { requireTier } = await import('../../backend/src/middleware/requireTier');
    mockReq.user.tier = 'free';
    requireTier('premium')(mockReq, mockRes, mockNext);
    expect(mockNext).not.toHaveBeenCalled();
    expect(mockRes.status).toHaveBeenCalledWith(403);
    expect(mockRes.json).toHaveBeenCalledWith(
      expect.objectContaining({
        success: false,
        error: expect.objectContaining({ code: 'UPGRADE_REQUIRED' }),
      })
    );
  });

  it('defaults to free tier when user.tier is undefined', async () => {
    const { requireTier } = await import('../../backend/src/middleware/requireTier');
    mockReq.user = undefined;
    requireTier('basic')(mockReq, mockRes, mockNext);
    expect(mockNext).not.toHaveBeenCalled();
    expect(mockRes.status).toHaveBeenCalledWith(403);
  });
});

// ── errorHandler ──────────────────────────────────────────────────────────────
describe('errorHandler middleware', () => {
  it('handles ApiError with correct status code', async () => {
    const { errorHandler, ApiError } = await import('../../backend/src/middleware/errorHandler');
    const mockReq = { path: '/test', method: 'GET', requestId: 'req_1' } as any;
    const mockRes = { status: jest.fn().mockReturnThis(), json: jest.fn() } as any;
    const err = ApiError.notFound('Test resource not found');
    errorHandler(err, mockReq, mockRes, jest.fn());
    expect(mockRes.status).toHaveBeenCalledWith(404);
    expect(mockRes.json).toHaveBeenCalledWith(
      expect.objectContaining({ success: false, error: expect.objectContaining({ code: 'NOT_FOUND' }) })
    );
  });

  it('handles unexpected errors with 500', async () => {
    const { errorHandler } = await import('../../backend/src/middleware/errorHandler');
    const mockReq = { path: '/test', method: 'GET', requestId: 'req_2' } as any;
    const mockRes = { status: jest.fn().mockReturnThis(), json: jest.fn() } as any;
    const err = new Error('Something exploded');
    process.env.NODE_ENV = 'test';
    errorHandler(err, mockReq, mockRes, jest.fn());
    expect(mockRes.status).toHaveBeenCalledWith(500);
    expect(mockRes.json).toHaveBeenCalledWith(
      expect.objectContaining({ success: false, error: expect.objectContaining({ code: 'SERVER_ERROR' }) })
    );
  });

  it('handles JSON parse errors with 400', async () => {
    const { errorHandler } = await import('../../backend/src/middleware/errorHandler');
    const mockReq = { path: '/test', method: 'POST', requestId: 'req_3' } as any;
    const mockRes = { status: jest.fn().mockReturnThis(), json: jest.fn() } as any;
    const err: any = new SyntaxError('Unexpected token');
    err.body = true;  // marks it as body parse error
    errorHandler(err, mockReq, mockRes, jest.fn());
    expect(mockRes.status).toHaveBeenCalledWith(400);
  });
});
