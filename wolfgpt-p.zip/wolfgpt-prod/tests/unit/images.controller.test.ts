import { describe, it, expect, jest, beforeEach } from '@jest/globals';

jest.mock('../../backend/src/config/firebase', () => ({
  db: {
    collection: jest.fn().mockReturnThis(),
    doc:        jest.fn().mockReturnThis(),
    set:        jest.fn().mockResolvedValue(undefined),
    update:     jest.fn().mockResolvedValue(undefined),
    get:        jest.fn().mockResolvedValue({ exists: true, data: () => ({ userId: 'user_123', usage: { images: { used: 0 } } }) }),
    where:      jest.fn().mockReturnThis(),
    orderBy:    jest.fn().mockReturnThis(),
    limit:      jest.fn().mockReturnThis(),
  },
  storage: {
    bucket: jest.fn().mockReturnValue({
      file: jest.fn().mockReturnValue({
        save: jest.fn().mockResolvedValue(undefined),
        makePublic: jest.fn().mockResolvedValue(undefined),
        delete: jest.fn().mockResolvedValue(undefined),
        name: 'wolfgpt-bucket',
      }),
      name: 'wolfgpt-bucket',
    }),
  },
  FieldValue: { increment: jest.fn(n => n) },
}));

jest.mock('axios', () => ({
  post: jest.fn().mockResolvedValue({
    data: {
      images:          [{ base64: 'abc123', width: 1024, height: 1024, seed: null, mode: 'txt2img' }],
      generation_time: 3.14,
      mode:            'txt2img',
    },
  }),
  get: jest.fn().mockResolvedValue({ data: { models: [] } }),
}));

jest.mock('../../backend/src/utils/helpers', () => ({
  generateId: jest.fn(() => 'img_test456'),
}));

describe('Image Controller', () => {
  let mockReq: any;
  let mockRes: any;
  let mockNext: any;

  beforeEach(() => {
    jest.clearAllMocks();
    mockReq = {
      body:   {},
      user:   { uid: 'user_123', tier: 'premium' },
      params: {},
      query:  {},
    };
    mockRes = {
      status: jest.fn().mockReturnThis(),
      json:   jest.fn().mockReturnThis(),
    };
    mockNext = jest.fn();
  });

  describe('POST /images/generate (txt2img)', () => {
    it('should generate an image and return saved metadata', async () => {
      mockReq.body = {
        prompt: 'A majestic wolf howling at the moon',
        model:  'flux-schnell',
        width:  1024,
        height: 1024,
        steps:  4,
      };

      const { imageController } = await import('../../backend/src/controllers/imageController');
      await imageController.generateImage(mockReq, mockRes, mockNext);

      expect(mockRes.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: true,
          data: expect.objectContaining({
            images:         expect.any(Array),
            generationTime: 3.14,
            mode:           'txt2img',
          }),
        })
      );
    });

    it('should block when daily limit is reached (premium = 100/day)', async () => {
      const firebase = await import('../../backend/src/config/firebase');
      (firebase.db.get as jest.Mock).mockResolvedValueOnce({
        data: () => ({ usage: { images: { used: 100 } } }),
      });

      mockReq.user.tier = 'premium';
      mockReq.body      = { prompt: 'test', numImages: 1 };

      const { imageController } = await import('../../backend/src/controllers/imageController');
      await imageController.generateImage(mockReq, mockRes, mockNext);

      // Should call next with an ApiError (limit exceeded)
      expect(mockNext).toHaveBeenCalledWith(expect.objectContaining({ statusCode: 400 }));
    });

    it('should allow unlimited generations for pro tier', async () => {
      mockReq.user.tier = 'pro';
      mockReq.body      = { prompt: 'unlimited test', numImages: 4 };

      const firebase = await import('../../backend/src/config/firebase');
      (firebase.db.get as jest.Mock).mockResolvedValueOnce({
        data: () => ({ usage: { images: { used: 9999 } } }),
      });

      const { imageController } = await import('../../backend/src/controllers/imageController');
      await imageController.generateImage(mockReq, mockRes, mockNext);

      expect(mockRes.json).toHaveBeenCalledWith(expect.objectContaining({ success: true }));
    });
  });

  describe('POST /images/img2img', () => {
    it('should return 400 if referenceImage is missing', async () => {
      mockReq.body = { prompt: 'transform this', model: 'sdxl-base' };

      const { imageController } = await import('../../backend/src/controllers/imageController');
      await imageController.imageToImage(mockReq, mockRes, mockNext);

      expect(mockNext).toHaveBeenCalledWith(
        expect.objectContaining({ code: 'MISSING_REFERENCE_IMAGE' })
      );
    });

    it('should succeed when referenceImage is provided', async () => {
      mockReq.body = {
        prompt:         'transform into oil painting',
        referenceImage: 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQI12NgAAIABQ==',
        model:          'sdxl-base',
        strength:       0.7,
      };

      const { imageController } = await import('../../backend/src/controllers/imageController');
      await imageController.imageToImage(mockReq, mockRes, mockNext);

      expect(mockRes.json).toHaveBeenCalledWith(
        expect.objectContaining({ success: true, data: expect.objectContaining({ mode: 'img2img' }) })
      );
    });
  });

  describe('DELETE /images/:id', () => {
    it('should delete image owned by the requesting user', async () => {
      mockReq.params.id = 'img_test456';

      const { imageController } = await import('../../backend/src/controllers/imageController');
      await imageController.deleteImage(mockReq, mockRes, mockNext);

      expect(mockRes.json).toHaveBeenCalledWith(
        expect.objectContaining({ success: true })
      );
    });

    it('should reject deletion by non-owner', async () => {
      mockReq.params.id  = 'img_notmine';
      mockReq.user.uid   = 'different_user';

      const firebase = await import('../../backend/src/config/firebase');
      (firebase.db.get as jest.Mock).mockResolvedValueOnce({
        exists: true,
        data:   () => ({ userId: 'owner_user_123' }),
      });

      const { imageController } = await import('../../backend/src/controllers/imageController');
      await imageController.deleteImage(mockReq, mockRes, mockNext);

      expect(mockNext).toHaveBeenCalledWith(expect.objectContaining({ statusCode: 403 }));
    });
  });
});
