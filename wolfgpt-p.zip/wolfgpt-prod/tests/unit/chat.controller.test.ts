import { describe, it, expect, jest, beforeEach, afterEach } from '@jest/globals';

// ── Mocks ─────────────────────────────────────────────────────────────────────
const mockDb = {
  collection: jest.fn().mockReturnThis(),
  doc:        jest.fn().mockReturnThis(),
  set:        jest.fn().mockResolvedValue(undefined),
  update:     jest.fn().mockResolvedValue(undefined),
  get:        jest.fn().mockResolvedValue({ exists: true, data: () => ({ usage: { chat: { used: 0 } } }) }),
  where:      jest.fn().mockReturnThis(),
  orderBy:    jest.fn().mockReturnThis(),
  limit:      jest.fn().mockReturnThis(),
  batch:      jest.fn(() => ({ delete: jest.fn(), commit: jest.fn().mockResolvedValue(undefined) })),
};

jest.mock('../../backend/src/config/firebase', () => ({
  db:         mockDb,
  FieldValue: { increment: jest.fn(n => n), serverTimestamp: jest.fn(() => new Date()) },
}));

const mockAxiosPost = jest.fn();
jest.mock('axios', () => ({ post: mockAxiosPost, get: jest.fn() }));

jest.mock('../../backend/src/utils/helpers', () => ({
  generateId: jest.fn(() => 'conv_test_abc123'),
}));

jest.mock('../../backend/src/utils/logger', () => ({
  default: { info: jest.fn(), error: jest.fn(), warn: jest.fn() },
}));

// ── Test suite ────────────────────────────────────────────────────────────────
describe('ChatController', () => {
  let mockReq: any;
  let mockRes: any;
  let mockNext: any;

  beforeEach(() => {
    jest.clearAllMocks();

    mockReq = {
      body:   {},
      user:   { uid: 'user_test', email: 'test@wolfgpt.com', tier: 'premium' },
      params: {},
      query:  {},
      on:     jest.fn(),
    };
    mockRes = {
      status:    jest.fn().mockReturnThis(),
      json:      jest.fn().mockReturnThis(),
      setHeader: jest.fn().mockReturnThis(),
      write:     jest.fn(),
      end:       jest.fn(),
    };
    mockNext = jest.fn();
  });

  describe('createCompletion', () => {
    it('returns a successful chat response', async () => {
      mockAxiosPost.mockResolvedValueOnce({
        data: {
          choices: [{ message: { role: 'assistant', content: 'Hello from WolfGPT!' } }],
          usage: { prompt_tokens: 10, completion_tokens: 20, total_tokens: 30 },
        },
      });

      mockReq.body = {
        messages: [{ role: 'user', content: 'Hello' }],
        model:    'qwen-2.5-7b',
      };

      const { chatController } = await import('../../backend/src/controllers/chatController');
      await chatController.createCompletion(mockReq, mockRes, mockNext);

      expect(mockRes.json).toHaveBeenCalledWith(
        expect.objectContaining({
          success: true,
          data: expect.objectContaining({
            message:        'Hello from WolfGPT!',
            conversationId: 'conv_test_abc123',
          }),
        })
      );
      expect(mockNext).not.toHaveBeenCalled();
    });

    it('rejects when messages array is empty', async () => {
      mockReq.body = { messages: [], model: 'qwen-2.5-7b' };

      const { chatController } = await import('../../backend/src/controllers/chatController');
      await chatController.createCompletion(mockReq, mockRes, mockNext);

      // Should call next with ApiError
      expect(mockNext).toHaveBeenCalledWith(
        expect.objectContaining({ statusCode: 400 })
      );
    });

    it('rejects model not allowed for free tier', async () => {
      mockReq.user.tier = 'free';
      mockReq.body = {
        messages: [{ role: 'user', content: 'test' }],
        model:    'qwen-2.5-72b',  // not available on free
      };

      const { chatController } = await import('../../backend/src/controllers/chatController');
      await chatController.createCompletion(mockReq, mockRes, mockNext);

      expect(mockNext).toHaveBeenCalledWith(
        expect.objectContaining({ statusCode: 403, code: 'MODEL_NOT_ALLOWED' })
      );
    });

    it('saves conversation and increments usage on success', async () => {
      mockAxiosPost.mockResolvedValueOnce({
        data: { choices: [{ message: { role: 'assistant', content: 'OK' } }], usage: {} },
      });
      mockReq.body = { messages: [{ role: 'user', content: 'test' }] };

      const { chatController } = await import('../../backend/src/controllers/chatController');
      await chatController.createCompletion(mockReq, mockRes, mockNext);

      expect(mockDb.set).toHaveBeenCalled();
      expect(mockDb.update).toHaveBeenCalledWith(
        expect.objectContaining({ 'usage.chat.used': expect.any(Number) })
      );
    });
  });

  describe('getConversations', () => {
    it('returns list of conversations for authenticated user', async () => {
      mockDb.get.mockResolvedValueOnce({
        docs: [
          { id: 'conv_1', data: () => ({ id: 'conv_1', userId: 'user_test', messages: [] }) },
          { id: 'conv_2', data: () => ({ id: 'conv_2', userId: 'user_test', messages: [] }) },
        ],
      });

      const { chatController } = await import('../../backend/src/controllers/chatController');
      await chatController.getConversations(mockReq, mockRes, mockNext);

      expect(mockRes.json).toHaveBeenCalledWith(
        expect.objectContaining({ success: true, data: expect.any(Array) })
      );
    });
  });
});
