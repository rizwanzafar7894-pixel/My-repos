import { describe, it, expect, jest } from '@jest/globals';

describe('Image Validators', () => {
  let mockNext: jest.Mock;
  let mockRes: any;

  beforeEach(() => {
    mockNext = jest.fn();
    mockRes  = { status: jest.fn().mockReturnThis(), json: jest.fn() };
  });

  it('validates valid txt2img request', async () => {
    const { validateImageGeneration } = await import('../../backend/src/validators/imageValidator');
    const req: any = { body: { prompt: 'A beautiful wolf', model: 'flux-schnell', width: 1024, height: 1024 } };
    validateImageGeneration(req, mockRes, mockNext);
    expect(mockNext).toHaveBeenCalledTimes(1);
    expect(mockRes.status).not.toHaveBeenCalled();
  });

  it('rejects missing prompt', async () => {
    const { validateImageGeneration } = await import('../../backend/src/validators/imageValidator');
    const req: any = { body: { model: 'flux-schnell' } };
    validateImageGeneration(req, mockRes, mockNext);
    expect(mockNext).not.toHaveBeenCalled();
    expect(mockRes.status).toHaveBeenCalledWith(400);
    expect(mockRes.json).toHaveBeenCalledWith(
      expect.objectContaining({ success: false, error: expect.objectContaining({ code: 'VALIDATION_ERROR' }) })
    );
  });

  it('validates img2img request with referenceImage', async () => {
    const { validateImg2Img } = await import('../../backend/src/validators/imageValidator');
    const req: any = {
      body: {
        prompt:         'Transform to oil painting',
        referenceImage: 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAC0lEQVQI12NgAAIABQ==',
        strength:       0.75,
      },
    };
    validateImg2Img(req, mockRes, mockNext);
    expect(mockNext).toHaveBeenCalledTimes(1);
  });

  it('rejects img2img without referenceImage', async () => {
    const { validateImg2Img } = await import('../../backend/src/validators/imageValidator');
    const req: any = { body: { prompt: 'test' } };
    validateImg2Img(req, mockRes, mockNext);
    expect(mockNext).not.toHaveBeenCalled();
    expect(mockRes.status).toHaveBeenCalledWith(400);
  });
});

describe('Feature Validators', () => {
  let mockNext: jest.Mock;
  let mockRes: any;

  beforeEach(() => {
    mockNext = jest.fn();
    mockRes  = { status: jest.fn().mockReturnThis(), json: jest.fn() };
  });

  it('validates code execution request', async () => {
    const { validateCodeExecution } = await import('../../backend/src/validators/featureValidators');
    const req: any = { body: { code: 'print("Hello")', language: 'python' } };
    validateCodeExecution(req, mockRes, mockNext);
    expect(mockNext).toHaveBeenCalledTimes(1);
  });

  it('rejects unsupported language', async () => {
    const { validateCodeExecution } = await import('../../backend/src/validators/featureValidators');
    const req: any = { body: { code: 'console.log("hi")', language: 'fortran' } };
    validateCodeExecution(req, mockRes, mockNext);
    expect(mockNext).not.toHaveBeenCalled();
    expect(mockRes.status).toHaveBeenCalledWith(400);
  });

  it('validates translate request', async () => {
    const { validateTranslate } = await import('../../backend/src/validators/featureValidators');
    const req: any = { body: { text: 'Hello world', targetLanguage: 'ur' } };
    validateTranslate(req, mockRes, mockNext);
    expect(mockNext).toHaveBeenCalledTimes(1);
  });
});
