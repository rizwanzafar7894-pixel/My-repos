import request from 'supertest';
describe('Security Headers', () => {
  it('should have HSTS header', async () => {
    const res = await request('http://localhost:4000').get('/health');
    expect(res.headers['strict-transport-security']).toBeDefined();
  });
  it('should have CSP header', async () => {
    const res = await request('http://localhost:3000').get('/');
    expect(res.headers['content-security-policy']).toBeDefined();
  });
});