#!/bin/bash
# Snyk security testing
echo "Running Snyk security tests..."
snyk test --all-projects
snyk monitor
