import request from 'supertest';
const API = 'http://localhost:4000';
describe('API Integration', () => {
  let token: string;
  beforeAll(async () => {
    const res = await request(API).post('/api/auth/register').send({
      email: `test${Date.now()}@test.com`, password: 'Test123!', name: 'Test'
    });
    token = res.body.data.token;
  });
  it('should create chat completion', async () => {
    const res = await request(API).post('/api/chat/completions')
      .set('Authorization', `Bearer ${token}`)
      .send({ messages: [{ role: 'user', content: 'test' }] });
    expect(res.status).toBe(200);
  });
});
