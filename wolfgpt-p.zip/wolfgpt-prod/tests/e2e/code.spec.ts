import { test, expect } from '@playwright/test';
test('should execute code', async ({ page }) => {
  await page.goto('/dashboard/code');
  await page.fill('[data-testid="code-editor"]', 'print("test")');
  await page.click('[data-testid="run-code"]');
  await expect(page.locator('[data-testid="output"]')).toContainText('test');
});