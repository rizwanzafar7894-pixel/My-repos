import { test } from '@playwright/test';
test('should synthesize speech', async ({ page }) => {
  await page.goto('/dashboard/voice');
  await page.fill('[data-testid="tts-text"]', 'Hello');
  await page.click('[data-testid="synthesize"]');
});