import { test, expect } from '@playwright/test';
test('should generate image', async ({ page }) => {
  await page.goto('/dashboard/images');
  await page.fill('[data-testid="prompt"]', 'test');
  await page.click('[data-testid="generate"]');
  await expect(page.locator('[data-testid="generated-image"]')).toBeVisible({ timeout: 30000 });
});