import { test, expect } from '@playwright/test';
test.describe('Authentication Flow', () => {
  test('should register and login', async ({ page }) => {
    await page.goto('/auth/register');
    await page.fill('[name="email"]', `test${Date.now()}@test.com`);
    await page.fill('[name="password"]', 'SecurePass123!');
    await page.fill('[name="name"]', 'Test User');
    await page.click('button[type="submit"]');
    await expect(page).toHaveURL('/dashboard');
  });
});
