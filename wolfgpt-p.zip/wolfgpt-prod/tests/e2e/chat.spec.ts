import { test, expect } from '@playwright/test';
test.describe('Chat Feature', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/auth/login');
    await page.fill('[name="email"]', 'test@test.com');
    await page.fill('[name="password"]', 'Test123!');
    await page.click('button[type="submit"]');
  });
  test('should send message and get response', async ({ page }) => {
    await page.goto('/dashboard/chat');
    await page.fill('[data-testid="chat-input"]', 'Hello');
    await page.click('[data-testid="send-button"]');
    await expect(page.locator('[data-testid="chat-message"]')).toContainText('Hello');
  });
});
